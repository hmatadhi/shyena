This sample program illustrates the use of event handlers to transform a 
PER-encoded message into an XML document.  The document is constructed in 
accordance with the XER rules.

