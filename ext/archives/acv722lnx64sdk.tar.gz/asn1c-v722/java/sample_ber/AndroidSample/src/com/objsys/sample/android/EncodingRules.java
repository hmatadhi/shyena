package com.objsys.sample.android;

public enum EncodingRules {
   BER, ALIGNED_PER, UNALIGNED_PER
}
