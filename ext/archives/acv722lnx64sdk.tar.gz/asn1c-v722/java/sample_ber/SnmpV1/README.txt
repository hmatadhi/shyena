This sample program will format an SNMP V1 Get Request to get the 
sysDescr MIB OBJECT as defined in RFC 1213.

