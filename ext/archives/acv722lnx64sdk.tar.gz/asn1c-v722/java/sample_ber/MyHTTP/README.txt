This example program is taken from the book "ASN.1 Communication Between 
Heterogeneous Systems" by Oliver Dubuisson.  This book can be freely 
downloaded from the following URL: http://asn1.elibel.tm.fr/book/

This example was originally adapted from the sample at 
http://www.w3.org/Protocols/HTTP-NG/asn1.

