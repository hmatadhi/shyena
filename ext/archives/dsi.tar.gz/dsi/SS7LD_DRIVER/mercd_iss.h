/*
=====================================================================

            Copyright (C) Dialogic Corporation 2010-2013.
            All Rights Reserved.

	        DM3 MERCD DSI history

	        mercd_iss.txt



    ************************************************************************* 
    ************************************************************************* 
    ************************************************************************* 
                            ! Attention !

                    Updates to mercd.c are required!
		    Updates to mercd_linux_entry.c are required!
    ************************************************************************* 
    ************************************************************************* 
    ************************************************************************* 

==========+======+==============================================================
Date      | Name |  Description of status/changes
----------+------+--------------------------------------------------------------
23-Sep-10   MH    - New file.
                  - 1st drop.
                  - Update Makefile to seperate build and install.
                    Remove 2.4.x support.
                  - MERCD V0.01.

22-Oct-10   MH    -  Driver drop:
                    \\pysnas02\INT_BLD\scm\subsystem_builds\dm3drvl\
                        dm3drvl_2.0.2\DM3DRVL_2.0.2_60\linux\3.4.3\drivers\mercd
                  - MERCD V0.02.

23-Nov-10   MH    - Driver drop:
                    dm3drvl_2.0.2
                  - MERCD V0.03.

06-Dec-10   MH    - Patch from Prashant.
                  - Correct remove script.
                  - Correct Makefile 'clean'
                  - MERCD V0.04.

07-Dec-10   MH    - Drop from Prashant 06-Dec-10.
                  - MERCD V0.05.

08-Dec-10   MH    - Makefile updates.
                  - MERCD V0.06.

10-Jan-11   MH    - Ignore errors if the symbol table copy fails.
                  - Add BSD + GPL V2 license text.
16-Mar-11   MH    - Update mercd source to 2.02_16.
                  - MERCD V0.07

30-Mar-11   MH    - Update mercd soruce to 2.02_16 + mods.
                  - MERCD V0.08

06-Apr-11   MH    - Update driver banner to use DSI format.
                  - MERCD V0.09

19-Apr-11   MH    - Update install + build shell scripts to specify /bin/bash.
                  - MERCD V0.10

20-Apr-11   IDP   - Merge fix to support 2 boards with the same switch setting
                  - MERCD V0.11

10-May-11   JLP   - Added workaround - hold board in reset for 500ms
                  - MERCD V0.12

09-Jun-11   IDP   - CN474DPK - Merge fix to avoid NMI during driver insert
                  - MERCD V0.13

18-Jul-11   IDP   - Merge 2.0.2_71 fix to avoid board lockups
                  - MERCD V0.14

01-Aug-11   IDP   - CN495DPK - Fix for build under Debian 6.0.2 AMD64
                  - MERCD V0.15

12-Dec-11   IDP   - Merge 2.0.2_72
                  - CN462DPK - BKL & IOCTL
                  - CN493DPK - Linux 3.x support
                  - CN523DPK - Dont remove device nodes on insert
                  - MERCD V0.16

26-Jan-12   IDP   - Bug fixes for 6.2 (and before) issues
                  - MERCD V0.17

05-Nov-12   IDP   - CN593DPK - Restore CMD register last
                    CN615DPK - Disable device fully on removal
                  - MERCD V0.18

08-Nov-12   MH    - CN553DPK - 'Rebuild of LNX driver always succeeds'
                  - MERCD V0.19

13-Feb-13   IDP   - CN625DPK - Support ss7.dc7 > 2M
                  - MERCD V0.20

23-Jul-13   MH    - TS141DPK
                  - MERCD V0.21

17-Nov-15   IDP   - Merge DM3DRVL_2.0.2_91
02-Mar-16   MH    - MERCD V0.22
*/

#ifndef __SS7LDDDLNX_ISS_H__
#define __SS7LDDDLNX_ISS_H__

#define SS7LDDDLNX_MAJ          (0)
#define SS7LDDDLNX_MIN          (22)

#define COPYRIGHT_BEGIN         (2010)

#endif
