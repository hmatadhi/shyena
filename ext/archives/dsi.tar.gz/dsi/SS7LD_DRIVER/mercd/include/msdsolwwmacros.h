/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic Corporation nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* 4.    Except as provided herein, no license under any patent, copyright,
* trade secret or other intellectual property right is granted to or
* conferred upon you by disclosure or delivery of this software, either
* expressly, by implication, inducement, estoppel or otherwise. Any license
* under such intellectual property rights must be express and approved by
* Dialogic in writing.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
//=======================================================================
//        FILE: msdsolwwmacros.h
// DESCRIPTION: Mercury Streams Driver Data Structure Defination file
//
//=======================================================================

//=======================================================================
// HISTORY:
// Date                 Who     Description
// 22-Jan-01            RG      Initial Creation.
//
//========================================================================

#ifndef _MSDSOLWWMACROS_H
#define _MSDSOLWWMACROS_H

//Macros For WW support
#define MsdWWSramGetPostLocation(padapter, loc) \
            ddi_get8(padapter->phw_info->virt_map_q[MERCD_PCI_SRAM_MAP]->acc_handle, \
                     (padapter->phost_info->reg_block.HostRamStart + loc))

#define MsdWWGetRemapRegister(padapter) \
           ddi_get32(((pmercd_virt_map_sT)(padapter->phw_info->\
           virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
           (pmerc_ulong_t)(((pmercd_virt_map_sT)(padapter->phw_info->\
           virt_map_q[MERCD_PCI_PLX_MAP]))->virt_addr+\
           MERCD_WW_REMAP_REG_LOCATION))

#define MsdWWPutRemapRegister(padapter, val) \
          ddi_put32(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
          (pmerc_ulong_t)(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->virt_addr+\
          MERCD_WW_REMAP_REG_LOCATION), val)

#define MsdWWPutinBoundQReg(padapter,val) \
          ddi_put32(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
          (pmerc_ulong_t)padapter->pww_info->inBoundQRegAddress, val)

#define MsdWWGetinBoundQReg(padapter) \
          ddi_get32(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
          (pmerc_ulong_t)padapter->pww_info->inBoundQRegAddress)


#define MsdWWPutoutBoundQReg(padapter,val) \
          ddi_put32(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
          (pmerc_ulong_t)padapter->pww_info->outBoundQRegAddress, val)

#define MsdWWGetoutBoundQReg(padapter) \
          ddi_get32(((pmercd_virt_map_sT)(padapter->phw_info->\
          virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
          (pmerc_ulong_t)padapter->pww_info->outBoundQRegAddress)

#define MsdWWGenerateInitIntrDoorBell(padapter, val) \
          loc = (pmerc_ulong_t)(((size_t)(padapter->phw_info->\
                virt_map_q[MERCD_PCI_PLX_MAP]->virt_addr))+MERCD_WW_HOST_TO_BOARD_INTERRUPT_REG); \
          ddi_put32(padapter->phw_info->virt_map_q[MERCD_PCI_PLX_MAP]->acc_handle, loc, val);

#define MsdWWGenerateInitMsgRdyIntrDoorBell(padapter, val) \
  loc = (pmerc_uint_t) (((size_t)((pmercd_virt_map_sT)(padapter->phw_info->\
        virt_map_q[MERCD_PCI_PLX_MAP]))->\
        virt_addr)+MERCD_WW_HOST_TO_BOARD_INTERRUPT_REG); \
        ddi_put32(((pmercd_virt_map_sT)(padapter->phw_info->\
        virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle, loc, val);

#define MsdWWGetIntrRequest(padapter, reason) { \
         if (padapter->pww_info->state == MERCD_ADAPTER_WW_MODE_INIT_INTR_PENDING) \
         {  \
         reason = ddi_get32(((pmercd_virt_map_sT)(padapter->pww_info->pww_plx_space_tree))->\
         acc_handle, (pmerc_ulong_t)(((pmercd_virt_map_sT)\
         (padapter->pww_info->pww_plx_space_tree))->\
         virt_addr+MERCD_WW_BOARD_TO_HOST_INTERRUPT_REG)); \
         } else { \
         reason = ddi_get32(((pmercd_virt_map_sT)(padapter->phw_info->\
         virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle, (pmerc_ulong_t)\
         (((pmercd_virt_map_sT)(padapter->phw_info->virt_map_q[MERCD_PCI_PLX_MAP]))->\
         virt_addr+MERCD_WW_BOARD_TO_HOST_INTERRUPT_REG)); \
         } \
      }

#define MsdWWClearIntrRequest(padapter, reason) { \
     if (padapter->pww_info->state == MERCD_ADAPTER_WW_MODE_INIT_INTR_PENDING) {   \
         ddi_put32(((pmercd_virt_map_sT)(padapter->pww_info->pww_plx_space_tree))->\
         acc_handle,(pmerc_uint_t)(((size_t)((pmercd_virt_map_sT)(padapter->pww_info->\
         pww_plx_space_tree))->virt_addr)+MERCD_WW_BOARD_TO_HOST_INTERRUPT_REG), reason); \
         } else { \
         ddi_put32(((pmercd_virt_map_sT)(padapter->phw_info->\
         virt_map_q[MERCD_PCI_PLX_MAP]))->acc_handle,\
         (pmerc_uint_t)(((size_t)((pmercd_virt_map_sT)\
         (padapter->phw_info->virt_map_q[MERCD_PCI_PLX_MAP]))->virt_addr)+\
         MERCD_WW_BOARD_TO_HOST_INTERRUPT_REG), reason); \
         } \
       }

#define MsdWWGetNumPageBoundaries(numBoundaries){ \
        pageNum = hat_getkpfnum((caddr_t)Msg->b_rptr); \
        boundrp = (pmerc_uchar_t)(pageNum*PAGESIZE); \
        pageNum = hat_getkpfnum((caddr_t)Msg->w_rptr); \
        physwp = (pmerc_uchar_t)(pageNum*PAGESIZE+((merc_ulong_t)\
                                (Msg->b_wptr) & PAGEOFFSET)); \
        while (boundrp < physwp) \
        { \
          boundrp += PAGESIZE; \
          numBoundaries++; \
        } \
       numBoundaries--; \
      }



#define MsdWWPeekIsc(padapter) \
         ddi_peek32(padapter->pdevi,\
         (pmerc_uint_t)(((pmercd_virt_map_sT)(pwwDev->pww_plx_space_tree))->\
         virt_addr+MSD_PCI_PLX_INTR_REG), &PeekVal)


#define MsdWWSyncDevice(pwwDev) \
               ddi_dma_sync(pwwDev->mfaBaseAddressDescr.dma_hdlp,\
                                                      syncOffset,\
                                                        syncSize,\
                                              DDI_DMA_SYNC_FORDEV )

#define MsdWWSyncCpu(pwwDev) \
               ddi_dma_sync(pwwDev->mfaBaseAddressDescr.dma_hdlp,\
                                                      syncOffset,\
                                                        syncSize,\
                                              DDI_DMA_SYNC_FORCPU)

#define MsdWWBigMsgDataBlocksSyncDevice(pbigmsg) \
                                  ddi_dma_sync(pbigmsg->dma_hdlp,\
                                                      syncOffset,\
                                                        syncSize,\
                                              DDI_DMA_SYNC_FORDEV)

#define MsdWWBigMsgDataBlocksSyncCpu(pbigmsg) \
                                  ddi_dma_sync(pbigmsg->dma_hdlp,\
                                                      syncOffset,\
                                                        syncSize,\
                                              DDI_DMA_SYNC_FORCPU)

//WW support
#define MSD_ENTER_SNDBIGMSG_MEMSTR_MUTEX() \
        mutex_enter(&pwwDev->BigMsgSndMemStr.sndbigmsg_mutex) ;
#define MSD_EXIT_SNDBIGMSG_MEMSTR_MUTEX() \
        mutex_exit(&pwwDev->BigMsgSndMemStr.sndbigmsg_mutex) ;

#define MSD_ENTER_RCVBIGMSG_MEMSTR_MUTEX() \
        mutex_enter(&pwwDev->BigMsgRcvMemStr.rcvbigmsg_mutex) ;
#define MSD_EXIT_RCVBIGMSG_MEMSTR_MUTEX() \
        mutex_exit(&pwwDev->BigMsgRcvMemStr.rcvbigmsg_mutex) ;

#define MSD_ENTER_MSG_PENDQ_MUTEX() \
        mutex_enter(&pwwDev->ww_msgpendq_mutex) ;
#define MSD_EXIT_MSG_PENDQ_MUTEX() \
        mutex_exit(&pwwDev->ww_msgpendq_mutex) ;

#endif //_MSDSOLWWMACROS_H
