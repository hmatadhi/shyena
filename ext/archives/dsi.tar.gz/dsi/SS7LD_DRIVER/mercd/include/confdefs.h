/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
/*
 * This file was automatically generated from confdefs.mdl.
 * Version: "3.2"
 * The output was written to confdefs.h.
 * Produced by mmdl translator version 1.3.
 */

#if !defined(_confdefs_h_)
#define _confdefs_h_ 1
/*All Kernel messages start from 0x800000*/
/*Hardware Configuration Structures Request Message*/
/*Kernel Board Configurable Information Structures Request Message*/

/*
 * QHwCfgGet (value = 0x800100) is a message of generic use.
 */

#define QHwCfgGet_Size     0

#define QHwCfgGet 0x800100 /* 8388864 */
/*Kernel Board Configurable Information Structures Transfer Message*/

/*
 * QKerBoardCfgGet (value = 0x800101) is a message of generic use.
 */

#define QKerBoardCfgGet_Size     0

#define QKerBoardCfgGet 0x800101 /* 8388865 */

#define QKerBoardCfgSet_numStrmGroupCfgs  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_numStrmGroupCfgs_t;

#define QKerBoardCfgSet_numGlobalPoolCfgs 0x300003 /* 3145731 */
typedef  UInt24   QKerBoardCfgSet_numGlobalPoolCfgs_t;

#define QKerBoardCfgSet_numSpGroupCfgs 0x300006 /* 3145734 */
typedef  UInt24   QKerBoardCfgSet_numSpGroupCfgs_t;

#define QKerBoardCfgSet_varStart 0x9

#define QKerBoardCfgSet_qStrmGroupCfg_groupId   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qStrmGroupCfg_groupId_t;

#define QKerBoardCfgSet_qStrmGroupCfg_numStreams   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qStrmGroupCfg_numStreams_t;

#define QKerBoardCfgSet_qStrmGroupCfg_streamSize   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qStrmGroupCfg_streamSize_t;


typedef struct {
   UInt24   groupId;
   UInt24   numStreams;
   UInt24   streamSize;
} QKerBoardCfgSet_qStrmGroupCfg_t;

#define QKerBoardCfgSet_qStrmGroupCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qStrmGroupCfg_groupId), &((structAddr)->groupId),   \
         (QKerBoardCfgSet_qStrmGroupCfg_numStreams), &((structAddr)->numStreams),   \
         (QKerBoardCfgSet_qStrmGroupCfg_streamSize), &((structAddr)->streamSize))


#define QKerBoardCfgSet_qStrmGroupCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qStrmGroupCfg_groupId), &((structAddr)->groupId),   \
         (QKerBoardCfgSet_qStrmGroupCfg_numStreams), &((structAddr)->numStreams),   \
         (QKerBoardCfgSet_qStrmGroupCfg_streamSize), &((structAddr)->streamSize))


#define QKerBoardCfgSet_qStrmGroupCfg_Size      9

#define QKerBoardCfgSet_qStrmGroupCfg  0  /* 0 */

#define QKerBoardCfgSet_qGlobalPoolCfg_poolId   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qGlobalPoolCfg_poolId_t;

#define QKerBoardCfgSet_qGlobalPoolCfg_numBlocks   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qGlobalPoolCfg_numBlocks_t;

#define QKerBoardCfgSet_qGlobalPoolCfg_blockSize   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qGlobalPoolCfg_blockSize_t;


typedef struct {
   UInt24   poolId;
   UInt24   numBlocks;
   UInt24   blockSize;
} QKerBoardCfgSet_qGlobalPoolCfg_t;

#define QKerBoardCfgSet_qGlobalPoolCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qGlobalPoolCfg_poolId), &((structAddr)->poolId), \
         (QKerBoardCfgSet_qGlobalPoolCfg_numBlocks), &((structAddr)->numBlocks), \
         (QKerBoardCfgSet_qGlobalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerBoardCfgSet_qGlobalPoolCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qGlobalPoolCfg_poolId), &((structAddr)->poolId), \
         (QKerBoardCfgSet_qGlobalPoolCfg_numBlocks), &((structAddr)->numBlocks), \
         (QKerBoardCfgSet_qGlobalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerBoardCfgSet_qGlobalPoolCfg_Size     9

#define QKerBoardCfgSet_qGlobalPoolCfg 0x1   /* 1 */

#define QKerBoardCfgSet_qSpGroupCfg_spdbNum  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qSpGroupCfg_spdbNum_t;

#define QKerBoardCfgSet_qSpGroupCfg_gmcsBaseAddr   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qSpGroupCfg_gmcsBaseAddr_t;

#define QKerBoardCfgSet_qSpGroupCfg_pmcsBaseAddr   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qSpGroupCfg_pmcsBaseAddr_t;


typedef struct {
   UInt24   spdbNum;
   UInt24   gmcsBaseAddr;
   UInt24   pmcsBaseAddr;
} QKerBoardCfgSet_qSpGroupCfg_t;

#define QKerBoardCfgSet_qSpGroupCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qSpGroupCfg_spdbNum), &((structAddr)->spdbNum),  \
         (QKerBoardCfgSet_qSpGroupCfg_gmcsBaseAddr), &((structAddr)->gmcsBaseAddr), \
         (QKerBoardCfgSet_qSpGroupCfg_pmcsBaseAddr), &((structAddr)->pmcsBaseAddr))


#define QKerBoardCfgSet_qSpGroupCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_qSpGroupCfg_spdbNum), &((structAddr)->spdbNum),  \
         (QKerBoardCfgSet_qSpGroupCfg_gmcsBaseAddr), &((structAddr)->gmcsBaseAddr), \
         (QKerBoardCfgSet_qSpGroupCfg_pmcsBaseAddr), &((structAddr)->pmcsBaseAddr))


#define QKerBoardCfgSet_qSpGroupCfg_Size     9

#define QKerBoardCfgSet_qSpGroupCfg 0x2   /* 2 */

#define QKerBoardCfgSet_qMmaTimeCfg_hostTime 0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qMmaTimeCfg_hostTime_t;

#define QKerBoardCfgSet_qMmaTimeCfg_cpTime   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qMmaTimeCfg_cpTime_t;

#define QKerBoardCfgSet_qMmaTimeCfg_grp0Time 0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qMmaTimeCfg_grp0Time_t;

#define QKerBoardCfgSet_qMmaTimeCfg_grp1Time 0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qMmaTimeCfg_grp1Time_t;

#define QKerBoardCfgSet_qMmaTimeCfg_grp2Time 0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qMmaTimeCfg_grp2Time_t;


typedef struct {
   UInt24   hostTime;
   UInt24   cpTime;
   UInt24   grp0Time;
   UInt24   grp1Time;
   UInt24   grp2Time;
} QKerBoardCfgSet_qMmaTimeCfg_t;

#define QKerBoardCfgSet_qMmaTimeCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKerBoardCfgSet_qMmaTimeCfg_hostTime), &((structAddr)->hostTime),   \
         (QKerBoardCfgSet_qMmaTimeCfg_cpTime), &((structAddr)->cpTime), \
         (QKerBoardCfgSet_qMmaTimeCfg_grp0Time), &((structAddr)->grp0Time),   \
         (QKerBoardCfgSet_qMmaTimeCfg_grp1Time), &((structAddr)->grp1Time),   \
         (QKerBoardCfgSet_qMmaTimeCfg_grp2Time), &((structAddr)->grp2Time))


#define QKerBoardCfgSet_qMmaTimeCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKerBoardCfgSet_qMmaTimeCfg_hostTime), &((structAddr)->hostTime),   \
         (QKerBoardCfgSet_qMmaTimeCfg_cpTime), &((structAddr)->cpTime), \
         (QKerBoardCfgSet_qMmaTimeCfg_grp0Time), &((structAddr)->grp0Time),   \
         (QKerBoardCfgSet_qMmaTimeCfg_grp1Time), &((structAddr)->grp1Time),   \
         (QKerBoardCfgSet_qMmaTimeCfg_grp2Time), &((structAddr)->grp2Time))


#define QKerBoardCfgSet_qMmaTimeCfg_Size     15

#define QKerBoardCfgSet_qMmaTimeCfg 0x3   /* 3 */

#define QKerBoardCfgSet_qInstWidthCfg_instwidth 0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qInstWidthCfg_instwidth_t;


typedef struct {
   UInt24   instwidth;
} QKerBoardCfgSet_qInstWidthCfg_t;

#define QKerBoardCfgSet_qInstWidthCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerBoardCfgSet_qInstWidthCfg_instwidth), &((structAddr)->instwidth))


#define QKerBoardCfgSet_qInstWidthCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerBoardCfgSet_qInstWidthCfg_instwidth), &((structAddr)->instwidth))


#define QKerBoardCfgSet_qInstWidthCfg_Size      3

#define QKerBoardCfgSet_qInstWidthCfg  0x4   /* 4 */

#define QKerBoardCfgSet_qFrameTimerRate_frameTimerRate   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qFrameTimerRate_frameTimerRate_t;


typedef struct {
   UInt24   frameTimerRate;
} QKerBoardCfgSet_qFrameTimerRate_t;

#define QKerBoardCfgSet_qFrameTimerRate_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerBoardCfgSet_qFrameTimerRate_frameTimerRate), &((structAddr)->frameTimerRate))


#define QKerBoardCfgSet_qFrameTimerRate_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerBoardCfgSet_qFrameTimerRate_frameTimerRate), &((structAddr)->frameTimerRate))


#define QKerBoardCfgSet_qFrameTimerRate_Size    3

#define QKerBoardCfgSet_qFrameTimerRate   0x5   /* 5 */

#define QKerBoardCfgSet_qClusterCfg_maxNumberOfClusters  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qClusterCfg_maxNumberOfClusters_t;

#define QKerBoardCfgSet_qClusterCfg_maxNumberOfSCBusRes  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgSet_qClusterCfg_maxNumberOfSCBusRes_t;


typedef struct {
   UInt24   maxNumberOfClusters;
   UInt24   maxNumberOfSCBusRes;
} QKerBoardCfgSet_qClusterCfg_t;

#define QKerBoardCfgSet_qClusterCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKerBoardCfgSet_qClusterCfg_maxNumberOfClusters), &((structAddr)->maxNumberOfClusters),  \
         (QKerBoardCfgSet_qClusterCfg_maxNumberOfSCBusRes), &((structAddr)->maxNumberOfSCBusRes))


#define QKerBoardCfgSet_qClusterCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKerBoardCfgSet_qClusterCfg_maxNumberOfClusters), &((structAddr)->maxNumberOfClusters),  \
         (QKerBoardCfgSet_qClusterCfg_maxNumberOfSCBusRes), &((structAddr)->maxNumberOfSCBusRes))


#define QKerBoardCfgSet_qClusterCfg_Size     6

#define QKerBoardCfgSet_qClusterCfg 0x6   /* 6 */

/*
 * QKerBoardCfgSet (value = 0x800102) is a message of generic use.
 */


typedef struct {
   UInt24   numStrmGroupCfgs;
   UInt24   numGlobalPoolCfgs;
   UInt24   numSpGroupCfgs;
} QKerBoardCfgSet_t;

#define QKerBoardCfgSet_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_numStrmGroupCfgs), &((structAddr)->numStrmGroupCfgs),  \
         (QKerBoardCfgSet_numGlobalPoolCfgs), &((structAddr)->numGlobalPoolCfgs),   \
         (QKerBoardCfgSet_numSpGroupCfgs), &((structAddr)->numSpGroupCfgs))


#define QKerBoardCfgSet_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgSet_numStrmGroupCfgs), &((structAddr)->numStrmGroupCfgs),  \
         (QKerBoardCfgSet_numGlobalPoolCfgs), &((structAddr)->numGlobalPoolCfgs),   \
         (QKerBoardCfgSet_numSpGroupCfgs), &((structAddr)->numSpGroupCfgs))


#define QKerBoardCfgSet_Size     9

#define QKerBoardCfgSet 0x800102 /* 8388866 */
#define QHOST_8BIT_INSTWIDTH     0
#define QHOST_16BIT_INSTWIDTH    1
/*Kernel Processor Configurable Information  Structures Request Message*/
/*Processor Configurable Information  Structure Transfer Message*/

/*
 * QKerProcCfgGet (value = 0x800103) is a message of generic use.
 */

#define QKerProcCfgGet_Size      0

#define QKerProcCfgGet  0x800103 /* 8388867 */

#define QKerProcCfgSet_numCStreams  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_numCStreams_t;

#define QKerProcCfgSet_pmcsCircBufSize 0x300003 /* 3145731 */
typedef  UInt24   QKerProcCfgSet_pmcsCircBufSize_t;

#define QKerProcCfgSet_numFrameTimers  0x300006 /* 3145734 */
typedef  UInt24   QKerProcCfgSet_numFrameTimers_t;

#define QKerProcCfgSet_maxComponents   0x300009 /* 3145737 */
typedef  UInt24   QKerProcCfgSet_maxComponents_t;

#define QKerProcCfgSet_maxInstances 0x30000c /* 3145740 */
typedef  UInt24   QKerProcCfgSet_maxInstances_t;

#define QKerProcCfgSet_defKernelTaskMsgQSize 0x30000f /* 3145743 */
typedef  UInt24   QKerProcCfgSet_defKernelTaskMsgQSize_t;

#define QKerProcCfgSet_qSpPrintFlag 0x300012 /* 3145746 */
typedef  UInt24   QKerProcCfgSet_qSpPrintFlag_t;

#define QKerProcCfgSet_numLocalPoolCfgs   0x300015 /* 3145749 */
typedef  UInt24   QKerProcCfgSet_numLocalPoolCfgs_t;

#define QKerProcCfgSet_numGlobalPoolCacheCfgs   0x300018 /* 3145752 */
typedef  UInt24   QKerProcCfgSet_numGlobalPoolCacheCfgs_t;

#define QKerProcCfgSet_varStart  0x1b

#define QKerProcCfgSet_qLocalPoolCfg_poolId  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qLocalPoolCfg_poolId_t;

#define QKerProcCfgSet_qLocalPoolCfg_numBlocks  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qLocalPoolCfg_numBlocks_t;

#define QKerProcCfgSet_qLocalPoolCfg_memRegion  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qLocalPoolCfg_memRegion_t;

#define QKerProcCfgSet_qLocalPoolCfg_blockSize  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qLocalPoolCfg_blockSize_t;


typedef struct {
   UInt24   poolId;
   UInt24   numBlocks;
   UInt24   memRegion;
   UInt24   blockSize;
} QKerProcCfgSet_qLocalPoolCfg_t;

#define QKerProcCfgSet_qLocalPoolCfg_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 4, &(offset),  \
         (QKerProcCfgSet_qLocalPoolCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgSet_qLocalPoolCfg_numBlocks), &((structAddr)->numBlocks),   \
         (QKerProcCfgSet_qLocalPoolCfg_memRegion), &((structAddr)->memRegion),   \
         (QKerProcCfgSet_qLocalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerProcCfgSet_qLocalPoolCfg_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 4, &(offset),  \
         (QKerProcCfgSet_qLocalPoolCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgSet_qLocalPoolCfg_numBlocks), &((structAddr)->numBlocks),   \
         (QKerProcCfgSet_qLocalPoolCfg_memRegion), &((structAddr)->memRegion),   \
         (QKerProcCfgSet_qLocalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerProcCfgSet_qLocalPoolCfg_Size    12

#define QKerProcCfgSet_qLocalPoolCfg   0x7   /* 7 */

#define QKerProcCfgSet_qGlobalPoolCacheCfg_poolId  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qGlobalPoolCacheCfg_poolId_t;

#define QKerProcCfgSet_qGlobalPoolCacheCfg_highWater  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qGlobalPoolCacheCfg_highWater_t;

#define QKerProcCfgSet_qGlobalPoolCacheCfg_lowWater   0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qGlobalPoolCacheCfg_lowWater_t;

#define QKerProcCfgSet_qGlobalPoolCacheCfg_highWaterDeallocAmount 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qGlobalPoolCacheCfg_highWaterDeallocAmount_t;

#define QKerProcCfgSet_qGlobalPoolCacheCfg_lowWaterAllocAmount 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qGlobalPoolCacheCfg_lowWaterAllocAmount_t;


typedef struct {
   UInt24   poolId;
   UInt24   highWater;
   UInt24   lowWater;
   UInt24   highWaterDeallocAmount;
   UInt24   lowWaterAllocAmount;
} QKerProcCfgSet_qGlobalPoolCacheCfg_t;

#define QKerProcCfgSet_qGlobalPoolCacheCfg_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_highWater), &((structAddr)->highWater),   \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_lowWater), &((structAddr)->lowWater),  \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_highWaterDeallocAmount), &((structAddr)->highWaterDeallocAmount), \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_lowWaterAllocAmount), &((structAddr)->lowWaterAllocAmount))


#define QKerProcCfgSet_qGlobalPoolCacheCfg_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_highWater), &((structAddr)->highWater),   \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_lowWater), &((structAddr)->lowWater),  \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_highWaterDeallocAmount), &((structAddr)->highWaterDeallocAmount), \
         (QKerProcCfgSet_qGlobalPoolCacheCfg_lowWaterAllocAmount), &((structAddr)->lowWaterAllocAmount))


#define QKerProcCfgSet_qGlobalPoolCacheCfg_Size    15

#define QKerProcCfgSet_qGlobalPoolCacheCfg   0x8   /* 8 */

#define QKerProcCfgSet_qtraceCfg_traceqsize  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qtraceCfg_traceqsize_t;


typedef struct {
   UInt24   traceqsize;
} QKerProcCfgSet_qtraceCfg_t;

#define QKerProcCfgSet_qtraceCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qtraceCfg_traceqsize), &((structAddr)->traceqsize))


#define QKerProcCfgSet_qtraceCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qtraceCfg_traceqsize), &((structAddr)->traceqsize))


#define QKerProcCfgSet_qtraceCfg_Size     3

#define QKerProcCfgSet_qtraceCfg 0x9   /* 9 */

#define QKerProcCfgSet_qMmaRequestCfg_mmaReqlstSize   0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qMmaRequestCfg_mmaReqlstSize_t;


typedef struct {
   UInt24   mmaReqlstSize;
} QKerProcCfgSet_qMmaRequestCfg_t;

#define QKerProcCfgSet_qMmaRequestCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qMmaRequestCfg_mmaReqlstSize), &((structAddr)->mmaReqlstSize))


#define QKerProcCfgSet_qMmaRequestCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qMmaRequestCfg_mmaReqlstSize), &((structAddr)->mmaReqlstSize))


#define QKerProcCfgSet_qMmaRequestCfg_Size      3

#define QKerProcCfgSet_qMmaRequestCfg  0xa   /* 10 */

#define QKerProcCfgSet_qSharedMemCfg_qSharedMemCfgCount  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qSharedMemCfg_qSharedMemCfgCount_t;


typedef struct {
   UInt24   qSharedMemCfgCount;
} QKerProcCfgSet_qSharedMemCfg_t;

#define QKerProcCfgSet_qSharedMemCfg_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qSharedMemCfg_qSharedMemCfgCount), &((structAddr)->qSharedMemCfgCount))


#define QKerProcCfgSet_qSharedMemCfg_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qSharedMemCfg_qSharedMemCfgCount), &((structAddr)->qSharedMemCfgCount))


#define QKerProcCfgSet_qSharedMemCfg_Size    3

#define QKerProcCfgSet_qSharedMemCfg   0xb   /* 11 */

#define QKerProcCfgSet_qSharedMemRegion_regionId   0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qSharedMemRegion_regionId_t;

#define QKerProcCfgSet_qSharedMemRegion_memSize 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qSharedMemRegion_memSize_t;

#define QKerProcCfgSet_qSharedMemRegion_memAlign   0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qSharedMemRegion_memAlign_t;


typedef struct {
   UInt24   regionId;
   UInt24   memSize;
   UInt24   memAlign;
} QKerProcCfgSet_qSharedMemRegion_t;

#define QKerProcCfgSet_qSharedMemRegion_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerProcCfgSet_qSharedMemRegion_regionId), &((structAddr)->regionId),  \
         (QKerProcCfgSet_qSharedMemRegion_memSize), &((structAddr)->memSize), \
         (QKerProcCfgSet_qSharedMemRegion_memAlign), &((structAddr)->memAlign))


#define QKerProcCfgSet_qSharedMemRegion_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerProcCfgSet_qSharedMemRegion_regionId), &((structAddr)->regionId),  \
         (QKerProcCfgSet_qSharedMemRegion_memSize), &((structAddr)->memSize), \
         (QKerProcCfgSet_qSharedMemRegion_memAlign), &((structAddr)->memAlign))


#define QKerProcCfgSet_qSharedMemRegion_Size    9

#define QKerProcCfgSet_qSharedMemRegion   0xc   /* 12 */

#define QKerProcCfgSet_qPStreamsCfg_numPStreams 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgSet_qPStreamsCfg_numPStreams_t;


typedef struct {
   UInt24   numPStreams;
} QKerProcCfgSet_qPStreamsCfg_t;

#define QKerProcCfgSet_qPStreamsCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qPStreamsCfg_numPStreams), &((structAddr)->numPStreams))


#define QKerProcCfgSet_qPStreamsCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerProcCfgSet_qPStreamsCfg_numPStreams), &((structAddr)->numPStreams))


#define QKerProcCfgSet_qPStreamsCfg_Size     3

#define QKerProcCfgSet_qPStreamsCfg 0xd   /* 13 */

/*
 * QKerProcCfgSet (value = 0x800104) is a message of generic use.
 */


typedef struct {
   UInt24   numCStreams;
   UInt24   pmcsCircBufSize;
   UInt24   numFrameTimers;
   UInt24   maxComponents;
   UInt24   maxInstances;
   UInt24   defKernelTaskMsgQSize;
   UInt24   qSpPrintFlag;
   UInt24   numLocalPoolCfgs;
   UInt24   numGlobalPoolCacheCfgs;
} QKerProcCfgSet_t;

#define QKerProcCfgSet_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 9, &(offset),  \
         (QKerProcCfgSet_numCStreams), &((structAddr)->numCStreams), \
         (QKerProcCfgSet_pmcsCircBufSize), &((structAddr)->pmcsCircBufSize),  \
         (QKerProcCfgSet_numFrameTimers), &((structAddr)->numFrameTimers), \
         (QKerProcCfgSet_maxComponents), &((structAddr)->maxComponents),   \
         (QKerProcCfgSet_maxInstances), &((structAddr)->maxInstances),  \
         (QKerProcCfgSet_defKernelTaskMsgQSize), &((structAddr)->defKernelTaskMsgQSize),  \
         (QKerProcCfgSet_qSpPrintFlag), &((structAddr)->qSpPrintFlag),  \
         (QKerProcCfgSet_numLocalPoolCfgs), &((structAddr)->numLocalPoolCfgs),   \
         (QKerProcCfgSet_numGlobalPoolCacheCfgs), &((structAddr)->numGlobalPoolCacheCfgs))


#define QKerProcCfgSet_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 9, &(offset),  \
         (QKerProcCfgSet_numCStreams), &((structAddr)->numCStreams), \
         (QKerProcCfgSet_pmcsCircBufSize), &((structAddr)->pmcsCircBufSize),  \
         (QKerProcCfgSet_numFrameTimers), &((structAddr)->numFrameTimers), \
         (QKerProcCfgSet_maxComponents), &((structAddr)->maxComponents),   \
         (QKerProcCfgSet_maxInstances), &((structAddr)->maxInstances),  \
         (QKerProcCfgSet_defKernelTaskMsgQSize), &((structAddr)->defKernelTaskMsgQSize),  \
         (QKerProcCfgSet_qSpPrintFlag), &((structAddr)->qSpPrintFlag),  \
         (QKerProcCfgSet_numLocalPoolCfgs), &((structAddr)->numLocalPoolCfgs),   \
         (QKerProcCfgSet_numGlobalPoolCacheCfgs), &((structAddr)->numGlobalPoolCacheCfgs))


#define QKerProcCfgSet_Size      27

#define QKerProcCfgSet  0x800104 /* 8388868 */
/*C-Stream Transformation Table Message*/

#define QCStreamXTableSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QCStreamXTableSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/*Host System Date Message*/

/*
 * QCStreamXTableSet (value = 0xc00138) is a message of generic use.
 */

#define QCStreamXTableSet_Size      0

#define QCStreamXTableSet  0xc00138 /* 12583224 */

#define QKerGetSystemDate_day 0x380000 /* 3670016 */
typedef  UInt32   QKerGetSystemDate_day_t;

#define QKerGetSystemDate_month  0x380004 /* 3670020 */
typedef  UInt32   QKerGetSystemDate_month_t;

#define QKerGetSystemDate_year   0x380008 /* 3670024 */
typedef  UInt32   QKerGetSystemDate_year_t;

/*
 * QKerGetSystemDate (value = 0x800139) is a message of generic use.
 */


typedef struct {
   UInt32   day;
   UInt32   month;
   UInt32   year;
} QKerGetSystemDate_t;

#define QKerGetSystemDate_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerGetSystemDate_day), &((structAddr)->day),  \
         (QKerGetSystemDate_month), &((structAddr)->month), \
         (QKerGetSystemDate_year), &((structAddr)->year))


#define QKerGetSystemDate_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerGetSystemDate_day), &((structAddr)->day),  \
         (QKerGetSystemDate_month), &((structAddr)->month), \
         (QKerGetSystemDate_year), &((structAddr)->year))


#define QKerGetSystemDate_Size      12

#define QKerGetSystemDate  0x800139 /* 8388921 */
/*Reserved messages*/

/*
 * QMailBoxReserve5 (value = 0x80013c) is a message of generic use.
 */

#define QMailBoxReserve5_Size    0

#define QMailBoxReserve5   0x80013c /* 8388924 */

/*
 * QMailBoxReserve6 (value = 0x80013d) is a message of generic use.
 */

#define QMailBoxReserve6_Size    0

#define QMailBoxReserve6   0x80013d /* 8388925 */

/*
 * QMailBoxReserve7 (value = 0x80013e) is a message of generic use.
 */

#define QMailBoxReserve7_Size    0

#define QMailBoxReserve7   0x80013e /* 8388926 */

/*
 * QMailBoxReserve8 (value = 0x80013f) is a message of generic use.
 */

#define QMailBoxReserve8_Size    0

#define QMailBoxReserve8   0x80013f /* 8388927 */

/*
 * QMailBoxReserve9 (value = 0x800140) is a message of generic use.
 */

#define QMailBoxReserve9_Size    0

#define QMailBoxReserve9   0x800140 /* 8388928 */
/*Kernel Inter-Processor Configurable Information  Structures Request Message*/

/*
 * QMailBoxReserve10 (value = 0x800141) is a message of generic use.
 */

#define QMailBoxReserve10_Size      0

#define QMailBoxReserve10  0x800141 /* 8388929 */
/* Inter-Processor Communication (IPC) Configuration Transfer Message */

/*
 * QKerIpcCfgGet (value = 0x800105) is a message of generic use.
 */

#define QKerIpcCfgGet_Size    0

#define QKerIpcCfgGet   0x800105 /* 8388869 */

#define QKerIpcCfgSet_numIpcCfgs 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgSet_numIpcCfgs_t;

#define QKerIpcCfgSet_varStart   0x3

#define QKerIpcCfgSet_qIpcCfg_spProcNum   0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgSet_qIpcCfg_spProcNum_t;

#define QKerIpcCfgSet_qIpcCfg_cpToSpQSize 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgSet_qIpcCfg_cpToSpQSize_t;

#define QKerIpcCfgSet_qIpcCfg_spToCpQSize 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgSet_qIpcCfg_spToCpQSize_t;


typedef struct {
   UInt24   spProcNum;
   UInt24   cpToSpQSize;
   UInt24   spToCpQSize;
} QKerIpcCfgSet_qIpcCfg_t;

#define QKerIpcCfgSet_qIpcCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerIpcCfgSet_qIpcCfg_spProcNum), &((structAddr)->spProcNum), \
         (QKerIpcCfgSet_qIpcCfg_cpToSpQSize), &((structAddr)->cpToSpQSize),   \
         (QKerIpcCfgSet_qIpcCfg_spToCpQSize), &((structAddr)->spToCpQSize))


#define QKerIpcCfgSet_qIpcCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerIpcCfgSet_qIpcCfg_spProcNum), &((structAddr)->spProcNum), \
         (QKerIpcCfgSet_qIpcCfg_cpToSpQSize), &((structAddr)->cpToSpQSize),   \
         (QKerIpcCfgSet_qIpcCfg_spToCpQSize), &((structAddr)->spToCpQSize))


#define QKerIpcCfgSet_qIpcCfg_Size     9

#define QKerIpcCfgSet_qIpcCfg 0xe   /* 14 */

/*
 * QKerIpcCfgSet (value = 0x800106) is a message of generic use.
 */


typedef struct {
   UInt24   numIpcCfgs;
} QKerIpcCfgSet_t;

#define QKerIpcCfgSet_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerIpcCfgSet_numIpcCfgs), &((structAddr)->numIpcCfgs))


#define QKerIpcCfgSet_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerIpcCfgSet_numIpcCfgs), &((structAddr)->numIpcCfgs))


#define QKerIpcCfgSet_Size    3

#define QKerIpcCfgSet   0x800106 /* 8388870 */
/* QmsoPrintf request*/
/* Initialize request from driver */

/*
 * QMsoPrintf (value = 0x810000) is a message of generic use.
 */

#define QMsoPrintf_Size    0

#define QMsoPrintf   0x810000 /* 8454144 */
/* Initialize request from driver */

/*
 * QCNTRL_INITIALIZE (value = 0xc00001) is a message of generic use.
 */

#define QCNTRL_INITIALIZE_Size      0

#define QCNTRL_INITIALIZE  0xc00001 /* 12582913 */
/*CAN_TAKE reply  */

/*
 * QCNTRL_INIT_ACK (value = 0xc00002) is a message of generic use.
 */

#define QCNTRL_INIT_ACK_Size     0

#define QCNTRL_INIT_ACK 0xc00002 /* 12582914 */

#define QCNTRL_CAN_TAKE_numCanTakes 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_CAN_TAKE_numCanTakes_t;

#define QCNTRL_CAN_TAKE_varStart 0x4

#define QCNTRL_CAN_TAKE_ENTRY_id 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_CAN_TAKE_ENTRY_id_t;

#define QCNTRL_CAN_TAKE_ENTRY_canTake  0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_CAN_TAKE_ENTRY_canTake_t;


typedef struct {
   UInt32   id;
   UInt32   canTake;
} QCNTRL_CAN_TAKE_ENTRY_t;

#define QCNTRL_CAN_TAKE_ENTRY_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QCNTRL_CAN_TAKE_ENTRY_id), &((structAddr)->id),   \
         (QCNTRL_CAN_TAKE_ENTRY_canTake), &((structAddr)->canTake))


#define QCNTRL_CAN_TAKE_ENTRY_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QCNTRL_CAN_TAKE_ENTRY_id), &((structAddr)->id),   \
         (QCNTRL_CAN_TAKE_ENTRY_canTake), &((structAddr)->canTake))


#define QCNTRL_CAN_TAKE_ENTRY_Size     8

#define QCNTRL_CAN_TAKE_ENTRY 0xf   /* 15 */

/*
 * QCNTRL_CAN_TAKE (value = 0xc00003) is a message of generic use.
 */


typedef struct {
   UInt32   numCanTakes;
} QCNTRL_CAN_TAKE_t;

#define QCNTRL_CAN_TAKE_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCNTRL_CAN_TAKE_numCanTakes), &((structAddr)->numCanTakes))


#define QCNTRL_CAN_TAKE_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCNTRL_CAN_TAKE_numCanTakes), &((structAddr)->numCanTakes))


#define QCNTRL_CAN_TAKE_Size     4

#define QCNTRL_CAN_TAKE 0xc00003 /* 12582915 */
/* Open Stream Request */

#define QCNTRL_OPEN_STREAM_streamId 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_OPEN_STREAM_streamId_t;

#define QCNTRL_OPEN_STREAM_mode  0x380004 /* 3670020 */
typedef  UInt32   QCNTRL_OPEN_STREAM_mode_t;

#define QCNTRL_OPEN_STREAM_requestSize 0x380008 /* 3670024 */
typedef  UInt32   QCNTRL_OPEN_STREAM_requestSize_t;

#define QCNTRL_OPEN_STREAM_canTakeLimit   0x38000c /* 3670028 */
typedef  UInt32   QCNTRL_OPEN_STREAM_canTakeLimit_t;

/*
 * QCNTRL_OPEN_STREAM (value = 0xc00004) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
   UInt32   mode;
   UInt32   requestSize;
   UInt32   canTakeLimit;
} QCNTRL_OPEN_STREAM_t;

#define QCNTRL_OPEN_STREAM_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 4, &(offset),  \
         (QCNTRL_OPEN_STREAM_streamId), &((structAddr)->streamId),   \
         (QCNTRL_OPEN_STREAM_mode), &((structAddr)->mode),  \
         (QCNTRL_OPEN_STREAM_requestSize), &((structAddr)->requestSize),   \
         (QCNTRL_OPEN_STREAM_canTakeLimit), &((structAddr)->canTakeLimit))


#define QCNTRL_OPEN_STREAM_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 4, &(offset),  \
         (QCNTRL_OPEN_STREAM_streamId), &((structAddr)->streamId),   \
         (QCNTRL_OPEN_STREAM_mode), &((structAddr)->mode),  \
         (QCNTRL_OPEN_STREAM_requestSize), &((structAddr)->requestSize),   \
         (QCNTRL_OPEN_STREAM_canTakeLimit), &((structAddr)->canTakeLimit))


#define QCNTRL_OPEN_STREAM_Size     16

#define QCNTRL_OPEN_STREAM 0xc00004 /* 12582916 */
/* Open Stream Reply */

#define QCNTRL_OPEN_STR_ACK_streamId   0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_OPEN_STR_ACK_streamId_t;

#define QCNTRL_OPEN_STR_ACK_actualSize 0x380004 /* 3670020 */
typedef  UInt32   QCNTRL_OPEN_STR_ACK_actualSize_t;

#define QCNTRL_OPEN_STR_ACK_initialCanTake   0x380008 /* 3670024 */
typedef  UInt32   QCNTRL_OPEN_STR_ACK_initialCanTake_t;

/*
 * QCNTRL_OPEN_STR_ACK (value = 0xc00005) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
   UInt32   actualSize;
   UInt32   initialCanTake;
} QCNTRL_OPEN_STR_ACK_t;

#define QCNTRL_OPEN_STR_ACK_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QCNTRL_OPEN_STR_ACK_streamId), &((structAddr)->streamId),  \
         (QCNTRL_OPEN_STR_ACK_actualSize), &((structAddr)->actualSize), \
         (QCNTRL_OPEN_STR_ACK_initialCanTake), &((structAddr)->initialCanTake))


#define QCNTRL_OPEN_STR_ACK_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QCNTRL_OPEN_STR_ACK_streamId), &((structAddr)->streamId),  \
         (QCNTRL_OPEN_STR_ACK_actualSize), &((structAddr)->actualSize), \
         (QCNTRL_OPEN_STR_ACK_initialCanTake), &((structAddr)->initialCanTake))


#define QCNTRL_OPEN_STR_ACK_Size    12

#define QCNTRL_OPEN_STR_ACK   0xc00005 /* 12582917 */
/* QCNTRL_CLOSE_ABORT Request */

#define QCNTRL_CLOSE_ABORT_streamId 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_CLOSE_ABORT_streamId_t;

/*
 * QCNTRL_CLOSE_ABORT (value = 0xc00006) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
} QCNTRL_CLOSE_ABORT_t;

#define QCNTRL_CLOSE_ABORT_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCNTRL_CLOSE_ABORT_streamId), &((structAddr)->streamId))


#define QCNTRL_CLOSE_ABORT_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCNTRL_CLOSE_ABORT_streamId), &((structAddr)->streamId))


#define QCNTRL_CLOSE_ABORT_Size     4

#define QCNTRL_CLOSE_ABORT 0xc00006 /* 12582918 */
/*QCNTRL_FAILED reply message */

#define QCNTRL_FAILED_inType  0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_FAILED_inType_t;

#define QCNTRL_FAILED_errorCode  0x380004 /* 3670020 */
typedef  UInt32   QCNTRL_FAILED_errorCode_t;

#define QCNTRL_FAILED_streamId   0x380008 /* 3670024 */
typedef  UInt32   QCNTRL_FAILED_streamId_t;

/*
 * QCNTRL_FAILED (value = 0xc00007) is a message of generic use.
 */


typedef struct {
   UInt32   inType;
   UInt32   errorCode;
   UInt32   streamId;
} QCNTRL_FAILED_t;

#define QCNTRL_FAILED_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QCNTRL_FAILED_inType), &((structAddr)->inType),   \
         (QCNTRL_FAILED_errorCode), &((structAddr)->errorCode),   \
         (QCNTRL_FAILED_streamId), &((structAddr)->streamId))


#define QCNTRL_FAILED_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QCNTRL_FAILED_inType), &((structAddr)->inType),   \
         (QCNTRL_FAILED_errorCode), &((structAddr)->errorCode),   \
         (QCNTRL_FAILED_streamId), &((structAddr)->streamId))


#define QCNTRL_FAILED_Size    12

#define QCNTRL_FAILED   0xc00007 /* 12582919 */
/* QCNTRL_SUCCEEDED reply */

#define QCNTRL_SUCCEEDED_inType  0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_SUCCEEDED_inType_t;

#define QCNTRL_SUCCEEDED_streamId   0x380004 /* 3670020 */
typedef  UInt32   QCNTRL_SUCCEEDED_streamId_t;

/*
 * QCNTRL_SUCCEEDED (value = 0xc00008) is a message of generic use.
 */


typedef struct {
   UInt32   inType;
   UInt32   streamId;
} QCNTRL_SUCCEEDED_t;

#define QCNTRL_SUCCEEDED_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QCNTRL_SUCCEEDED_inType), &((structAddr)->inType),   \
         (QCNTRL_SUCCEEDED_streamId), &((structAddr)->streamId))


#define QCNTRL_SUCCEEDED_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QCNTRL_SUCCEEDED_inType), &((structAddr)->inType),   \
         (QCNTRL_SUCCEEDED_streamId), &((structAddr)->streamId))


#define QCNTRL_SUCCEEDED_Size    8

#define QCNTRL_SUCCEEDED   0xc00008 /* 12582920 */
/* QCNTRL_ SESS_CLOSED  reply*/

#define QCNTRL_SESS_CLOSED_streamId 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_SESS_CLOSED_streamId_t;

/*
 * QCNTRL_SESS_CLOSED (value = 0xc00009) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
} QCNTRL_SESS_CLOSED_t;

#define QCNTRL_SESS_CLOSED_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCNTRL_SESS_CLOSED_streamId), &((structAddr)->streamId))


#define QCNTRL_SESS_CLOSED_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCNTRL_SESS_CLOSED_streamId), &((structAddr)->streamId))


#define QCNTRL_SESS_CLOSED_Size     4

#define QCNTRL_SESS_CLOSED 0xc00009 /* 12582921 */
/* QCNTRL_EXIT_NOTIFY  Request */

#define QCNTRL_EXIT_NOTIFY_count 0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_EXIT_NOTIFY_count_t;

#define QCNTRL_EXIT_NOTIFY_varStart 0x4

#define QCNTRL_EXIT_NOTIFY_COMPDESC_source   0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_EXIT_NOTIFY_COMPDESC_source_t;

#define QCNTRL_EXIT_NOTIFY_COMPDESC_sourceDestComponent  0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_EXIT_NOTIFY_COMPDESC_sourceDestComponent_t;


typedef struct {
   UInt32   source;
   UInt32   sourceDestComponent;
} QCNTRL_EXIT_NOTIFY_COMPDESC_t;

#define QCNTRL_EXIT_NOTIFY_COMPDESC_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QCNTRL_EXIT_NOTIFY_COMPDESC_source), &((structAddr)->source), \
         (QCNTRL_EXIT_NOTIFY_COMPDESC_sourceDestComponent), &((structAddr)->sourceDestComponent))


#define QCNTRL_EXIT_NOTIFY_COMPDESC_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QCNTRL_EXIT_NOTIFY_COMPDESC_source), &((structAddr)->source), \
         (QCNTRL_EXIT_NOTIFY_COMPDESC_sourceDestComponent), &((structAddr)->sourceDestComponent))


#define QCNTRL_EXIT_NOTIFY_COMPDESC_Size     8

#define QCNTRL_EXIT_NOTIFY_COMPDESC 0x10  /* 16 */

/*
 * QCNTRL_EXIT_NOTIFY (value = 0xc0000a) is a message of generic use.
 */


typedef struct {
   UInt32   count;
} QCNTRL_EXIT_NOTIFY_t;

#define QCNTRL_EXIT_NOTIFY_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCNTRL_EXIT_NOTIFY_count), &((structAddr)->count))


#define QCNTRL_EXIT_NOTIFY_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCNTRL_EXIT_NOTIFY_count), &((structAddr)->count))


#define QCNTRL_EXIT_NOTIFY_Size     4

#define QCNTRL_EXIT_NOTIFY 0xc0000a /* 12582922 */
/* QCNTRL_EXIT_NOTIFY1  Request */

#define QCNTRL_EXIT_NOTIFY1_count   0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_EXIT_NOTIFY1_count_t;

#define QCNTRL_EXIT_NOTIFY1_varStart   0x4

#define QCNTRL_EXIT_NOTIFY1_COMPDESC_source  0x800000 /* 8388608 */
typedef  QCompDesc   QCNTRL_EXIT_NOTIFY1_COMPDESC_source_t;

#define QCNTRL_EXIT_NOTIFY1_COMPDESC_pad  0x280000 /* 2621440 */
typedef  UInt16   QCNTRL_EXIT_NOTIFY1_COMPDESC_pad_t;


typedef struct {
   QCompDesc   source;
   UInt16   pad;
} QCNTRL_EXIT_NOTIFY1_COMPDESC_t;

#define QCNTRL_EXIT_NOTIFY1_COMPDESC_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QCNTRL_EXIT_NOTIFY1_COMPDESC_source), &((structAddr)->source),   \
         (QCNTRL_EXIT_NOTIFY1_COMPDESC_pad), &((structAddr)->pad))


#define QCNTRL_EXIT_NOTIFY1_COMPDESC_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QCNTRL_EXIT_NOTIFY1_COMPDESC_source), &((structAddr)->source),   \
         (QCNTRL_EXIT_NOTIFY1_COMPDESC_pad), &((structAddr)->pad))


#define QCNTRL_EXIT_NOTIFY1_COMPDESC_Size    8

#define QCNTRL_EXIT_NOTIFY1_COMPDESC   0x11  /* 17 */

/*
 * QCNTRL_EXIT_NOTIFY1 (value = 0xc0000a) is a message of generic use.
 */


typedef struct {
   UInt32   count;
} QCNTRL_EXIT_NOTIFY1_t;

#define QCNTRL_EXIT_NOTIFY1_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCNTRL_EXIT_NOTIFY1_count), &((structAddr)->count))


#define QCNTRL_EXIT_NOTIFY1_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCNTRL_EXIT_NOTIFY1_count), &((structAddr)->count))


#define QCNTRL_EXIT_NOTIFY1_Size    4

#define QCNTRL_EXIT_NOTIFY1   0xc0000a /* 12582922 */
/* QCNTRL_EXIT_NOTIFY_ACK  reply*/
/* Open Stream Request */

/*
 * QCNTRL_EXIT_NOTIFY_ACK (value = 0xc0000b) is a message of generic use.
 */

#define QCNTRL_EXIT_NOTIFY_ACK_Size    0

#define QCNTRL_EXIT_NOTIFY_ACK   0xc0000b /* 12582923 */

#define QCNTRL_TERMINATE_streamId   0x380000 /* 3670016 */
typedef  UInt32   QCNTRL_TERMINATE_streamId_t;

#define QCNTRL_TERMINATE_mode 0x380004 /* 3670020 */
typedef  UInt32   QCNTRL_TERMINATE_mode_t;

/*
 * QCNTRL_TERMINATE (value = 0xc0000c) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
   UInt32   mode;
} QCNTRL_TERMINATE_t;

#define QCNTRL_TERMINATE_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QCNTRL_TERMINATE_streamId), &((structAddr)->streamId),  \
         (QCNTRL_TERMINATE_mode), &((structAddr)->mode))


#define QCNTRL_TERMINATE_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QCNTRL_TERMINATE_streamId), &((structAddr)->streamId),  \
         (QCNTRL_TERMINATE_mode), &((structAddr)->mode))


#define QCNTRL_TERMINATE_Size    8

#define QCNTRL_TERMINATE   0xc0000c /* 12582924 */
/* Kernel Configuration QKerBoardCfgSet Acknowledgment Message */
/* Kernel Configuration QKerProcCfgSet Acknowledgment Message */

/*
 * QKerBoardCfgSetAck (value = 0x800107) is a message of generic use.
 */

#define QKerBoardCfgSetAck_Size     0

#define QKerBoardCfgSetAck 0x800107 /* 8388871 */
/* Kernel Configuration QKerIpcCfgSet Acknowledgment Message */

/*
 * QKerProcCfgSetAck (value = 0x800108) is a message of generic use.
 */

#define QKerProcCfgSetAck_Size      0

#define QKerProcCfgSetAck  0x800108 /* 8388872 */
/*Hardware Configuration Structures Request Message*/

/*
 * QKerIpcCfgSetAck (value = 0x800109) is a message of generic use.
 */

#define QKerIpcCfgSetAck_Size    0

#define QKerIpcCfgSetAck   0x800109 /* 8388873 */

#define QHwCfgResult_numSpdbs 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_numSpdbs_t;

#define QHwCfgResult_numCommdbs  0x200001 /* 2097153 */
typedef  UInt8 QHwCfgResult_numCommdbs_t;

#define QHwCfgResult_numNetifdbs 0x200002 /* 2097154 */
typedef  UInt8 QHwCfgResult_numNetifdbs_t;

#define QHwCfgResult_bb_format_id_h 0x200003 /* 2097155 */
typedef  UInt8 QHwCfgResult_bb_format_id_h_t;

#define QHwCfgResult_bb_format_id_l 0x200004 /* 2097156 */
typedef  UInt8 QHwCfgResult_bb_format_id_l_t;

#define QHwCfgResult_bb_board_type_h   0x200005 /* 2097157 */
typedef  UInt8 QHwCfgResult_bb_board_type_h_t;

#define QHwCfgResult_bb_board_type_l   0x200006 /* 2097158 */
typedef  UInt8 QHwCfgResult_bb_board_type_l_t;

#define QHwCfgResult_bb_hw_version  0x200007 /* 2097159 */
typedef  UInt8 QHwCfgResult_bb_hw_version_t;

#define QHwCfgResult_bb_clk_ratio   0x200008 /* 2097160 */
typedef  UInt8 QHwCfgResult_bb_clk_ratio_t;

#define QHwCfgResult_bb_clk_speed_h 0x200009 /* 2097161 */
typedef  UInt8 QHwCfgResult_bb_clk_speed_h_t;

#define QHwCfgResult_bb_clk_speed_l 0x20000a /* 2097162 */
typedef  UInt8 QHwCfgResult_bb_clk_speed_l_t;

#define QHwCfgResult_bb_cp_mem_type 0x20000b /* 2097163 */
typedef  UInt8 QHwCfgResult_bb_cp_mem_type_t;

#define QHwCfgResult_bb_cp_mem_size 0x20000c /* 2097164 */
typedef  UInt8 QHwCfgResult_bb_cp_mem_size_t;

#define QHwCfgResult_bb_cp_mem_speed   0x20000d /* 2097165 */
typedef  UInt8 QHwCfgResult_bb_cp_mem_speed_t;

#define QHwCfgResult_bb_host_mem_type  0x20000e /* 2097166 */
typedef  UInt8 QHwCfgResult_bb_host_mem_type_t;

#define QHwCfgResult_bb_host_mem_size  0x20000f /* 2097167 */
typedef  UInt8 QHwCfgResult_bb_host_mem_size_t;

#define QHwCfgResult_bb_host_mem_speed 0x200010 /* 2097168 */
typedef  UInt8 QHwCfgResult_bb_host_mem_speed_t;

#define QHwCfgResult_bb_flash_mem_size 0x200011 /* 2097169 */
typedef  UInt8 QHwCfgResult_bb_flash_mem_size_t;

#define QHwCfgResult_bb_flash_mem_type 0x200012 /* 2097170 */
typedef  UInt8 QHwCfgResult_bb_flash_mem_type_t;

#define QHwCfgResult_bb_net_io_type 0x200013 /* 2097171 */
typedef  UInt8 QHwCfgResult_bb_net_io_type_t;

#define QHwCfgResult_bb_phys_io_type   0x200014 /* 2097172 */
typedef  UInt8 QHwCfgResult_bb_phys_io_type_t;

#define QHwCfgResult_bb_ni_stuffed  0x200015 /* 2097173 */
typedef  UInt8 QHwCfgResult_bb_ni_stuffed_t;

#define QHwCfgResult_bb_isdn_hdlc   0x200016 /* 2097174 */
typedef  UInt8 QHwCfgResult_bb_isdn_hdlc_t;

#define QHwCfgResult_bb_tdm_asics_stuffed 0x200017 /* 2097175 */
typedef  UInt8 QHwCfgResult_bb_tdm_asics_stuffed_t;

#define QHwCfgResult_bb_periph_wait 0x200018 /* 2097176 */
typedef  UInt8 QHwCfgResult_bb_periph_wait_t;

#define QHwCfgResult_bb_host_mem_endian   0x200019 /* 2097177 */
typedef  UInt8 QHwCfgResult_bb_host_mem_endian_t;

#define QHwCfgResult_bb_loopback_relays   0x20001a /* 2097178 */
typedef  UInt8 QHwCfgResult_bb_loopback_relays_t;

#define QHwCfgResult_bb_phys_connector 0x20001b /* 2097179 */
typedef  UInt8 QHwCfgResult_bb_phys_connector_t;

#define QHwCfgResult_bb_tdm_asic_type  0x20001c /* 2097180 */
typedef  UInt8 QHwCfgResult_bb_tdm_asic_type_t;

#define QHwCfgResult_bb_reserved1   0x22381d /* 2242589 */
typedef  UInt8 QHwCfgResult_bb_reserved1_t[72];

#define QHwCfgResult_bb_serial_num  0x503865 /* 5257317 */
typedef  Char  QHwCfgResult_bb_serial_num_t[8];

#define QHwCfgResult_bb_reserved2   0x20086d /* 2099309 */
typedef  UInt8 QHwCfgResult_bb_reserved2_t[2];

#define QHwCfgResult_bb_last_test_h 0x20006f /* 2097263 */
typedef  UInt8 QHwCfgResult_bb_last_test_h_t;

#define QHwCfgResult_bb_last_test_l 0x200070 /* 2097264 */
typedef  UInt8 QHwCfgResult_bb_last_test_l_t;

#define QHwCfgResult_bb_times_tested_h 0x200071 /* 2097265 */
typedef  UInt8 QHwCfgResult_bb_times_tested_h_t;

#define QHwCfgResult_bb_times_tested_l 0x200072 /* 2097266 */
typedef  UInt8 QHwCfgResult_bb_times_tested_l_t;

#define QHwCfgResult_bb_assem_num   0x504873 /* 5261427 */
typedef  Char  QHwCfgResult_bb_assem_num_t[10];

#define QHwCfgResult_bb_reserved3   0x20187d /* 2103421 */
typedef  UInt8 QHwCfgResult_bb_reserved3_t[4];

#define QHwCfgResult_bb_check_sum_h 0x200081 /* 2097281 */
typedef  UInt8 QHwCfgResult_bb_check_sum_h_t;

#define QHwCfgResult_bb_check_sum_l 0x200082 /* 2097282 */
typedef  UInt8 QHwCfgResult_bb_check_sum_l_t;

#define QHwCfgResult_bb_glob_mem_size  0x200083 /* 2097283 */
typedef  UInt8 QHwCfgResult_bb_glob_mem_size_t;


typedef struct {
   UInt8 format_id_h;
   UInt8 format_id_l;
   UInt8 board_type_h;
   UInt8 board_type_l;
   UInt8 hw_version;
   UInt8 clk_ratio;
   UInt8 clk_speed_h;
   UInt8 clk_speed_l;
   UInt8 cp_mem_type;
   UInt8 cp_mem_size;
   UInt8 cp_mem_speed;
   UInt8 host_mem_type;
   UInt8 host_mem_size;
   UInt8 host_mem_speed;
   UInt8 flash_mem_size;
   UInt8 flash_mem_type;
   UInt8 net_io_type;
   UInt8 phys_io_type;
   UInt8 ni_stuffed;
   UInt8 isdn_hdlc;
   UInt8 tdm_asics_stuffed;
   UInt8 periph_wait;
   UInt8 host_mem_endian;
   UInt8 loopback_relays;
   UInt8 phys_connector;
   UInt8 tdm_asic_type;
   UInt8 reserved1[72];
   Char  serial_num[8];
   UInt8 reserved2[2];
   UInt8 last_test_h;
   UInt8 last_test_l;
   UInt8 times_tested_h;
   UInt8 times_tested_l;
   Char  assem_num[10];
   UInt8 reserved3[4];
   UInt8 check_sum_h;
   UInt8 check_sum_l;
   UInt8 glob_mem_size;
} QHwCfgResult_bb_t;

#define QHwCfgResult_bb_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 38, &(offset), \
         (QHwCfgResult_bb_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_bb_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_bb_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_bb_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_bb_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_bb_clk_ratio), &((structAddr)->clk_ratio), \
         (QHwCfgResult_bb_clk_speed_h), &((structAddr)->clk_speed_h),   \
         (QHwCfgResult_bb_clk_speed_l), &((structAddr)->clk_speed_l),   \
         (QHwCfgResult_bb_cp_mem_type), &((structAddr)->cp_mem_type),   \
         (QHwCfgResult_bb_cp_mem_size), &((structAddr)->cp_mem_size),   \
         (QHwCfgResult_bb_cp_mem_speed), &((structAddr)->cp_mem_speed), \
         (QHwCfgResult_bb_host_mem_type), &((structAddr)->host_mem_type),  \
         (QHwCfgResult_bb_host_mem_size), &((structAddr)->host_mem_size),  \
         (QHwCfgResult_bb_host_mem_speed), &((structAddr)->host_mem_speed),   \
         (QHwCfgResult_bb_flash_mem_size), &((structAddr)->flash_mem_size),   \
         (QHwCfgResult_bb_flash_mem_type), &((structAddr)->flash_mem_type),   \
         (QHwCfgResult_bb_net_io_type), &((structAddr)->net_io_type),   \
         (QHwCfgResult_bb_phys_io_type), &((structAddr)->phys_io_type), \
         (QHwCfgResult_bb_ni_stuffed), &((structAddr)->ni_stuffed),  \
         (QHwCfgResult_bb_isdn_hdlc), &((structAddr)->isdn_hdlc), \
         (QHwCfgResult_bb_tdm_asics_stuffed), &((structAddr)->tdm_asics_stuffed),   \
         (QHwCfgResult_bb_periph_wait), &((structAddr)->periph_wait),   \
         (QHwCfgResult_bb_host_mem_endian), &((structAddr)->host_mem_endian), \
         (QHwCfgResult_bb_loopback_relays), &((structAddr)->loopback_relays), \
         (QHwCfgResult_bb_phys_connector), &((structAddr)->phys_connector),   \
         (QHwCfgResult_bb_tdm_asic_type), &((structAddr)->tdm_asic_type),  \
         (QHwCfgResult_bb_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_bb_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_bb_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_bb_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_bb_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_bb_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_bb_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_bb_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_bb_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_bb_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_bb_check_sum_l), &((structAddr)->check_sum_l),   \
         (QHwCfgResult_bb_glob_mem_size), &((structAddr)->glob_mem_size))


#define QHwCfgResult_bb_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 38, &(offset), \
         (QHwCfgResult_bb_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_bb_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_bb_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_bb_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_bb_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_bb_clk_ratio), &((structAddr)->clk_ratio), \
         (QHwCfgResult_bb_clk_speed_h), &((structAddr)->clk_speed_h),   \
         (QHwCfgResult_bb_clk_speed_l), &((structAddr)->clk_speed_l),   \
         (QHwCfgResult_bb_cp_mem_type), &((structAddr)->cp_mem_type),   \
         (QHwCfgResult_bb_cp_mem_size), &((structAddr)->cp_mem_size),   \
         (QHwCfgResult_bb_cp_mem_speed), &((structAddr)->cp_mem_speed), \
         (QHwCfgResult_bb_host_mem_type), &((structAddr)->host_mem_type),  \
         (QHwCfgResult_bb_host_mem_size), &((structAddr)->host_mem_size),  \
         (QHwCfgResult_bb_host_mem_speed), &((structAddr)->host_mem_speed),   \
         (QHwCfgResult_bb_flash_mem_size), &((structAddr)->flash_mem_size),   \
         (QHwCfgResult_bb_flash_mem_type), &((structAddr)->flash_mem_type),   \
         (QHwCfgResult_bb_net_io_type), &((structAddr)->net_io_type),   \
         (QHwCfgResult_bb_phys_io_type), &((structAddr)->phys_io_type), \
         (QHwCfgResult_bb_ni_stuffed), &((structAddr)->ni_stuffed),  \
         (QHwCfgResult_bb_isdn_hdlc), &((structAddr)->isdn_hdlc), \
         (QHwCfgResult_bb_tdm_asics_stuffed), &((structAddr)->tdm_asics_stuffed),   \
         (QHwCfgResult_bb_periph_wait), &((structAddr)->periph_wait),   \
         (QHwCfgResult_bb_host_mem_endian), &((structAddr)->host_mem_endian), \
         (QHwCfgResult_bb_loopback_relays), &((structAddr)->loopback_relays), \
         (QHwCfgResult_bb_phys_connector), &((structAddr)->phys_connector),   \
         (QHwCfgResult_bb_tdm_asic_type), &((structAddr)->tdm_asic_type),  \
         (QHwCfgResult_bb_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_bb_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_bb_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_bb_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_bb_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_bb_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_bb_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_bb_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_bb_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_bb_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_bb_check_sum_l), &((structAddr)->check_sum_l),   \
         (QHwCfgResult_bb_glob_mem_size), &((structAddr)->glob_mem_size))


#define QHwCfgResult_bb_Size     129

#define QHwCfgResult_bb 0x12  /* 18 */

#define QHwCfgResult_varStart 0x84

#define QHwCfgResult_sp_format_id_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_format_id_h_t;

#define QHwCfgResult_sp_format_id_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_format_id_l_t;

#define QHwCfgResult_sp_board_type_h   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_board_type_h_t;

#define QHwCfgResult_sp_board_type_l   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_board_type_l_t;

#define QHwCfgResult_sp_hw_version  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_hw_version_t;

#define QHwCfgResult_sp_sp_stuffed  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sp_stuffed_t;

#define QHwCfgResult_sp_sp_stuffed_1   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sp_stuffed_1_t;

#define QHwCfgResult_sp_sp_stuffed_2   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sp_stuffed_2_t;

#define QHwCfgResult_sp_clk_speed_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_clk_speed_h_t;

#define QHwCfgResult_sp_clk_speed_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_clk_speed_l_t;

#define QHwCfgResult_sp_clk_ratio   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_clk_ratio_t;

#define QHwCfgResult_sp_sh_mem_type 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sh_mem_type_t;

#define QHwCfgResult_sp_sh_mem_size 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sh_mem_size_t;

#define QHwCfgResult_sp_sh_mem_speed   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_sh_mem_speed_t;

#define QHwCfgResult_sp_add_mem_type   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_add_mem_type_t;

#define QHwCfgResult_sp_add_mem_size   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_add_mem_size_t;

#define QHwCfgResult_sp_add_mem_speed  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_add_mem_speed_t;

#define QHwCfgResult_sp_byte_addrsable 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_byte_addrsable_t;

#define QHwCfgResult_sp_nic_type 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_nic_type_t;

#define QHwCfgResult_sp_enet_addr_3 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_enet_addr_3_t;

#define QHwCfgResult_sp_enet_addr_4 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_enet_addr_4_t;

#define QHwCfgResult_sp_enet_addr_5 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_enet_addr_5_t;

#define QHwCfgResult_sp_reserved1   0x214800 /* 2181120 */
typedef  UInt8 QHwCfgResult_sp_reserved1_t[42];

#define QHwCfgResult_sp_cust_info   0x210800 /* 2164736 */
typedef  UInt8 QHwCfgResult_sp_cust_info_t[34];

#define QHwCfgResult_sp_serial_num  0x503800 /* 5257216 */
typedef  Char  QHwCfgResult_sp_serial_num_t[8];

#define QHwCfgResult_sp_reserved2   0x200800 /* 2099200 */
typedef  UInt8 QHwCfgResult_sp_reserved2_t[2];

#define QHwCfgResult_sp_last_test_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_last_test_h_t;

#define QHwCfgResult_sp_last_test_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_last_test_l_t;

#define QHwCfgResult_sp_times_tested_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_times_tested_h_t;

#define QHwCfgResult_sp_times_tested_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_times_tested_l_t;

#define QHwCfgResult_sp_assem_num   0x504800 /* 5261312 */
typedef  Char  QHwCfgResult_sp_assem_num_t[10];

#define QHwCfgResult_sp_reserved3   0x201800 /* 2103296 */
typedef  UInt8 QHwCfgResult_sp_reserved3_t[4];

#define QHwCfgResult_sp_check_sum_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_check_sum_h_t;

#define QHwCfgResult_sp_check_sum_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_sp_check_sum_l_t;


typedef struct {
   UInt8 format_id_h;
   UInt8 format_id_l;
   UInt8 board_type_h;
   UInt8 board_type_l;
   UInt8 hw_version;
   UInt8 sp_stuffed;
   UInt8 sp_stuffed_1;
   UInt8 sp_stuffed_2;
   UInt8 clk_speed_h;
   UInt8 clk_speed_l;
   UInt8 clk_ratio;
   UInt8 sh_mem_type;
   UInt8 sh_mem_size;
   UInt8 sh_mem_speed;
   UInt8 add_mem_type;
   UInt8 add_mem_size;
   UInt8 add_mem_speed;
   UInt8 byte_addrsable;
   UInt8 nic_type;
   UInt8 enet_addr_3;
   UInt8 enet_addr_4;
   UInt8 enet_addr_5;
   UInt8 reserved1[42];
   UInt8 cust_info[34];
   Char  serial_num[8];
   UInt8 reserved2[2];
   UInt8 last_test_h;
   UInt8 last_test_l;
   UInt8 times_tested_h;
   UInt8 times_tested_l;
   Char  assem_num[10];
   UInt8 reserved3[4];
   UInt8 check_sum_h;
   UInt8 check_sum_l;
} QHwCfgResult_sp_t;

#define QHwCfgResult_sp_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 34, &(offset), \
         (QHwCfgResult_sp_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_sp_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_sp_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_sp_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_sp_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_sp_sp_stuffed), &((structAddr)->sp_stuffed),  \
         (QHwCfgResult_sp_sp_stuffed_1), &((structAddr)->sp_stuffed_1), \
         (QHwCfgResult_sp_sp_stuffed_2), &((structAddr)->sp_stuffed_2), \
         (QHwCfgResult_sp_clk_speed_h), &((structAddr)->clk_speed_h),   \
         (QHwCfgResult_sp_clk_speed_l), &((structAddr)->clk_speed_l),   \
         (QHwCfgResult_sp_clk_ratio), &((structAddr)->clk_ratio), \
         (QHwCfgResult_sp_sh_mem_type), &((structAddr)->sh_mem_type),   \
         (QHwCfgResult_sp_sh_mem_size), &((structAddr)->sh_mem_size),   \
         (QHwCfgResult_sp_sh_mem_speed), &((structAddr)->sh_mem_speed), \
         (QHwCfgResult_sp_add_mem_type), &((structAddr)->add_mem_type), \
         (QHwCfgResult_sp_add_mem_size), &((structAddr)->add_mem_size), \
         (QHwCfgResult_sp_add_mem_speed), &((structAddr)->add_mem_speed),  \
         (QHwCfgResult_sp_byte_addrsable), &((structAddr)->byte_addrsable),   \
         (QHwCfgResult_sp_nic_type), &((structAddr)->nic_type),   \
         (QHwCfgResult_sp_enet_addr_3), &((structAddr)->enet_addr_3),   \
         (QHwCfgResult_sp_enet_addr_4), &((structAddr)->enet_addr_4),   \
         (QHwCfgResult_sp_enet_addr_5), &((structAddr)->enet_addr_5),   \
         (QHwCfgResult_sp_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_sp_cust_info), &((structAddr)->cust_info), \
         (QHwCfgResult_sp_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_sp_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_sp_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_sp_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_sp_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_sp_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_sp_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_sp_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_sp_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_sp_check_sum_l), &((structAddr)->check_sum_l))


#define QHwCfgResult_sp_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 34, &(offset), \
         (QHwCfgResult_sp_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_sp_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_sp_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_sp_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_sp_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_sp_sp_stuffed), &((structAddr)->sp_stuffed),  \
         (QHwCfgResult_sp_sp_stuffed_1), &((structAddr)->sp_stuffed_1), \
         (QHwCfgResult_sp_sp_stuffed_2), &((structAddr)->sp_stuffed_2), \
         (QHwCfgResult_sp_clk_speed_h), &((structAddr)->clk_speed_h),   \
         (QHwCfgResult_sp_clk_speed_l), &((structAddr)->clk_speed_l),   \
         (QHwCfgResult_sp_clk_ratio), &((structAddr)->clk_ratio), \
         (QHwCfgResult_sp_sh_mem_type), &((structAddr)->sh_mem_type),   \
         (QHwCfgResult_sp_sh_mem_size), &((structAddr)->sh_mem_size),   \
         (QHwCfgResult_sp_sh_mem_speed), &((structAddr)->sh_mem_speed), \
         (QHwCfgResult_sp_add_mem_type), &((structAddr)->add_mem_type), \
         (QHwCfgResult_sp_add_mem_size), &((structAddr)->add_mem_size), \
         (QHwCfgResult_sp_add_mem_speed), &((structAddr)->add_mem_speed),  \
         (QHwCfgResult_sp_byte_addrsable), &((structAddr)->byte_addrsable),   \
         (QHwCfgResult_sp_nic_type), &((structAddr)->nic_type),   \
         (QHwCfgResult_sp_enet_addr_3), &((structAddr)->enet_addr_3),   \
         (QHwCfgResult_sp_enet_addr_4), &((structAddr)->enet_addr_4),   \
         (QHwCfgResult_sp_enet_addr_5), &((structAddr)->enet_addr_5),   \
         (QHwCfgResult_sp_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_sp_cust_info), &((structAddr)->cust_info), \
         (QHwCfgResult_sp_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_sp_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_sp_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_sp_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_sp_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_sp_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_sp_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_sp_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_sp_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_sp_check_sum_l), &((structAddr)->check_sum_l))


#define QHwCfgResult_sp_Size     128

#define QHwCfgResult_sp 0x13  /* 19 */

#define QHwCfgResult_comm_format_id_h  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_comm_format_id_h_t;

#define QHwCfgResult_comm_format_id_l  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_comm_format_id_l_t;

#define QHwCfgResult_comm_board_type_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_comm_board_type_h_t;

#define QHwCfgResult_comm_board_type_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_comm_board_type_l_t;

#define QHwCfgResult_comm_hw_version   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_comm_hw_version_t;

#define QHwCfgResult_comm_mac_addr_low 0x501000 /* 5246976 */
typedef  Char  QHwCfgResult_comm_mac_addr_low_t[3];

#define QHwCfgResult_comm_boot_params  0x53b800 /* 5486592 */
typedef  Char  QHwCfgResult_comm_boot_params_t[120];


typedef struct {
   UInt8 format_id_h;
   UInt8 format_id_l;
   UInt8 board_type_h;
   UInt8 board_type_l;
   UInt8 hw_version;
   Char  mac_addr_low[3];
   Char  boot_params[120];
} QHwCfgResult_comm_t;

#define QHwCfgResult_comm_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 7, &(offset),  \
         (QHwCfgResult_comm_format_id_h), &((structAddr)->format_id_h), \
         (QHwCfgResult_comm_format_id_l), &((structAddr)->format_id_l), \
         (QHwCfgResult_comm_board_type_h), &((structAddr)->board_type_h),  \
         (QHwCfgResult_comm_board_type_l), &((structAddr)->board_type_l),  \
         (QHwCfgResult_comm_hw_version), &((structAddr)->hw_version),   \
         (QHwCfgResult_comm_mac_addr_low), &((structAddr)->mac_addr_low),  \
         (QHwCfgResult_comm_boot_params), &((structAddr)->boot_params))


#define QHwCfgResult_comm_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 7, &(offset),  \
         (QHwCfgResult_comm_format_id_h), &((structAddr)->format_id_h), \
         (QHwCfgResult_comm_format_id_l), &((structAddr)->format_id_l), \
         (QHwCfgResult_comm_board_type_h), &((structAddr)->board_type_h),  \
         (QHwCfgResult_comm_board_type_l), &((structAddr)->board_type_l),  \
         (QHwCfgResult_comm_hw_version), &((structAddr)->hw_version),   \
         (QHwCfgResult_comm_mac_addr_low), &((structAddr)->mac_addr_low),  \
         (QHwCfgResult_comm_boot_params), &((structAddr)->boot_params))


#define QHwCfgResult_comm_Size      128

#define QHwCfgResult_comm  0x14  /* 20 */

#define QHwCfgResult_netif_format_id_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_format_id_h_t;

#define QHwCfgResult_netif_format_id_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_format_id_l_t;

#define QHwCfgResult_netif_board_type_h   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_board_type_h_t;

#define QHwCfgResult_netif_board_type_l   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_board_type_l_t;

#define QHwCfgResult_netif_hw_version  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_hw_version_t;

#define QHwCfgResult_netif_phys_io_type   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_phys_io_type_t;

#define QHwCfgResult_netif_ni_stuffed  0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_ni_stuffed_t;

#define QHwCfgResult_netif_isdn_hdlc   0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_isdn_hdlc_t;

#define QHwCfgResult_netif_reserved1   0x21b800 /* 2209792 */
typedef  UInt8 QHwCfgResult_netif_reserved1_t[56];

#define QHwCfgResult_netif_cust_info   0x210800 /* 2164736 */
typedef  UInt8 QHwCfgResult_netif_cust_info_t[34];

#define QHwCfgResult_netif_serial_num  0x503800 /* 5257216 */
typedef  Char  QHwCfgResult_netif_serial_num_t[8];

#define QHwCfgResult_netif_reserved2   0x200800 /* 2099200 */
typedef  UInt8 QHwCfgResult_netif_reserved2_t[2];

#define QHwCfgResult_netif_last_test_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_last_test_h_t;

#define QHwCfgResult_netif_last_test_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_last_test_l_t;

#define QHwCfgResult_netif_times_tested_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_times_tested_h_t;

#define QHwCfgResult_netif_times_tested_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_times_tested_l_t;

#define QHwCfgResult_netif_assem_num   0x504800 /* 5261312 */
typedef  Char  QHwCfgResult_netif_assem_num_t[10];

#define QHwCfgResult_netif_reserved3   0x201800 /* 2103296 */
typedef  UInt8 QHwCfgResult_netif_reserved3_t[4];

#define QHwCfgResult_netif_check_sum_h 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_check_sum_h_t;

#define QHwCfgResult_netif_check_sum_l 0x200000 /* 2097152 */
typedef  UInt8 QHwCfgResult_netif_check_sum_l_t;


typedef struct {
   UInt8 format_id_h;
   UInt8 format_id_l;
   UInt8 board_type_h;
   UInt8 board_type_l;
   UInt8 hw_version;
   UInt8 phys_io_type;
   UInt8 ni_stuffed;
   UInt8 isdn_hdlc;
   UInt8 reserved1[56];
   UInt8 cust_info[34];
   Char  serial_num[8];
   UInt8 reserved2[2];
   UInt8 last_test_h;
   UInt8 last_test_l;
   UInt8 times_tested_h;
   UInt8 times_tested_l;
   Char  assem_num[10];
   UInt8 reserved3[4];
   UInt8 check_sum_h;
   UInt8 check_sum_l;
} QHwCfgResult_netif_t;

#define QHwCfgResult_netif_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 20, &(offset), \
         (QHwCfgResult_netif_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_netif_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_netif_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_netif_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_netif_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_netif_phys_io_type), &((structAddr)->phys_io_type), \
         (QHwCfgResult_netif_ni_stuffed), &((structAddr)->ni_stuffed),  \
         (QHwCfgResult_netif_isdn_hdlc), &((structAddr)->isdn_hdlc), \
         (QHwCfgResult_netif_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_netif_cust_info), &((structAddr)->cust_info), \
         (QHwCfgResult_netif_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_netif_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_netif_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_netif_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_netif_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_netif_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_netif_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_netif_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_netif_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_netif_check_sum_l), &((structAddr)->check_sum_l))


#define QHwCfgResult_netif_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 20, &(offset), \
         (QHwCfgResult_netif_format_id_h), &((structAddr)->format_id_h),   \
         (QHwCfgResult_netif_format_id_l), &((structAddr)->format_id_l),   \
         (QHwCfgResult_netif_board_type_h), &((structAddr)->board_type_h), \
         (QHwCfgResult_netif_board_type_l), &((structAddr)->board_type_l), \
         (QHwCfgResult_netif_hw_version), &((structAddr)->hw_version),  \
         (QHwCfgResult_netif_phys_io_type), &((structAddr)->phys_io_type), \
         (QHwCfgResult_netif_ni_stuffed), &((structAddr)->ni_stuffed),  \
         (QHwCfgResult_netif_isdn_hdlc), &((structAddr)->isdn_hdlc), \
         (QHwCfgResult_netif_reserved1), &((structAddr)->reserved1), \
         (QHwCfgResult_netif_cust_info), &((structAddr)->cust_info), \
         (QHwCfgResult_netif_serial_num), &((structAddr)->serial_num),  \
         (QHwCfgResult_netif_reserved2), &((structAddr)->reserved2), \
         (QHwCfgResult_netif_last_test_h), &((structAddr)->last_test_h),   \
         (QHwCfgResult_netif_last_test_l), &((structAddr)->last_test_l),   \
         (QHwCfgResult_netif_times_tested_h), &((structAddr)->times_tested_h),   \
         (QHwCfgResult_netif_times_tested_l), &((structAddr)->times_tested_l),   \
         (QHwCfgResult_netif_assem_num), &((structAddr)->assem_num), \
         (QHwCfgResult_netif_reserved3), &((structAddr)->reserved3), \
         (QHwCfgResult_netif_check_sum_h), &((structAddr)->check_sum_h),   \
         (QHwCfgResult_netif_check_sum_l), &((structAddr)->check_sum_l))


#define QHwCfgResult_netif_Size     128

#define QHwCfgResult_netif 0x15  /* 21 */

/*
 * QHwCfgResult (value = 0x80010a) is a message of generic use.
 */


typedef struct {
   UInt8 numSpdbs;
   UInt8 numCommdbs;
   UInt8 numNetifdbs;
   QHwCfgResult_bb_t QHwCfgResult_bb_i;
} QHwCfgResult_t;

#define QHwCfgResult_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QHwCfgResult_numSpdbs), &((structAddr)->numSpdbs),   \
         (QHwCfgResult_numCommdbs), &((structAddr)->numCommdbs),  \
         (QHwCfgResult_numNetifdbs), &((structAddr)->numNetifdbs));  \
          QHwCfgResult_bb_get(msgPtr, &((structAddr)->QHwCfgResult_bb_i), offset)


#define QHwCfgResult_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QHwCfgResult_numSpdbs), &((structAddr)->numSpdbs),   \
         (QHwCfgResult_numCommdbs), &((structAddr)->numCommdbs),  \
         (QHwCfgResult_numNetifdbs), &((structAddr)->numNetifdbs));  \
          QHwCfgResult_bb_put(msgPtr, &((structAddr)->QHwCfgResult_bb_i), offset)


#define QHwCfgResult_Size     132

#define QHwCfgResult 0x80010a /* 8388874 */
/*Kernel Board Configuration Structures Reply Message*/

#define QKerBoardCfgResult_numStrmGroupCfgs  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_numStrmGroupCfgs_t;

#define QKerBoardCfgResult_numGlobalPoolCfgs 0x300003 /* 3145731 */
typedef  UInt24   QKerBoardCfgResult_numGlobalPoolCfgs_t;

#define QKerBoardCfgResult_numSpGroupCfgs 0x300006 /* 3145734 */
typedef  UInt24   QKerBoardCfgResult_numSpGroupCfgs_t;

#define QKerBoardCfgResult_varStart 0x9

#define QKerBoardCfgResult_qStrmGroupCfg_groupId   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qStrmGroupCfg_groupId_t;

#define QKerBoardCfgResult_qStrmGroupCfg_numStreams   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qStrmGroupCfg_numStreams_t;

#define QKerBoardCfgResult_qStrmGroupCfg_streamSize   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qStrmGroupCfg_streamSize_t;


typedef struct {
   UInt24   groupId;
   UInt24   numStreams;
   UInt24   streamSize;
} QKerBoardCfgResult_qStrmGroupCfg_t;

#define QKerBoardCfgResult_qStrmGroupCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qStrmGroupCfg_groupId), &((structAddr)->groupId),   \
         (QKerBoardCfgResult_qStrmGroupCfg_numStreams), &((structAddr)->numStreams),   \
         (QKerBoardCfgResult_qStrmGroupCfg_streamSize), &((structAddr)->streamSize))


#define QKerBoardCfgResult_qStrmGroupCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qStrmGroupCfg_groupId), &((structAddr)->groupId),   \
         (QKerBoardCfgResult_qStrmGroupCfg_numStreams), &((structAddr)->numStreams),   \
         (QKerBoardCfgResult_qStrmGroupCfg_streamSize), &((structAddr)->streamSize))


#define QKerBoardCfgResult_qStrmGroupCfg_Size      9

#define QKerBoardCfgResult_qStrmGroupCfg  0x16  /* 22 */

#define QKerBoardCfgResult_qGlobalPoolCfg_poolId   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qGlobalPoolCfg_poolId_t;

#define QKerBoardCfgResult_qGlobalPoolCfg_numBlocks   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qGlobalPoolCfg_numBlocks_t;

#define QKerBoardCfgResult_qGlobalPoolCfg_blockSize   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qGlobalPoolCfg_blockSize_t;


typedef struct {
   UInt24   poolId;
   UInt24   numBlocks;
   UInt24   blockSize;
} QKerBoardCfgResult_qGlobalPoolCfg_t;

#define QKerBoardCfgResult_qGlobalPoolCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qGlobalPoolCfg_poolId), &((structAddr)->poolId), \
         (QKerBoardCfgResult_qGlobalPoolCfg_numBlocks), &((structAddr)->numBlocks), \
         (QKerBoardCfgResult_qGlobalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerBoardCfgResult_qGlobalPoolCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qGlobalPoolCfg_poolId), &((structAddr)->poolId), \
         (QKerBoardCfgResult_qGlobalPoolCfg_numBlocks), &((structAddr)->numBlocks), \
         (QKerBoardCfgResult_qGlobalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerBoardCfgResult_qGlobalPoolCfg_Size     9

#define QKerBoardCfgResult_qGlobalPoolCfg 0x17  /* 23 */

#define QKerBoardCfgResult_qSpGroupCfg_spdbNum  0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qSpGroupCfg_spdbNum_t;

#define QKerBoardCfgResult_qSpGroupCfg_gmcsBaseAddr   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qSpGroupCfg_gmcsBaseAddr_t;

#define QKerBoardCfgResult_qSpGroupCfg_pmcsBaseAddr   0x300000 /* 3145728 */
typedef  UInt24   QKerBoardCfgResult_qSpGroupCfg_pmcsBaseAddr_t;


typedef struct {
   UInt24   spdbNum;
   UInt24   gmcsBaseAddr;
   UInt24   pmcsBaseAddr;
} QKerBoardCfgResult_qSpGroupCfg_t;

#define QKerBoardCfgResult_qSpGroupCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qSpGroupCfg_spdbNum), &((structAddr)->spdbNum),  \
         (QKerBoardCfgResult_qSpGroupCfg_gmcsBaseAddr), &((structAddr)->gmcsBaseAddr), \
         (QKerBoardCfgResult_qSpGroupCfg_pmcsBaseAddr), &((structAddr)->pmcsBaseAddr))


#define QKerBoardCfgResult_qSpGroupCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_qSpGroupCfg_spdbNum), &((structAddr)->spdbNum),  \
         (QKerBoardCfgResult_qSpGroupCfg_gmcsBaseAddr), &((structAddr)->gmcsBaseAddr), \
         (QKerBoardCfgResult_qSpGroupCfg_pmcsBaseAddr), &((structAddr)->pmcsBaseAddr))


#define QKerBoardCfgResult_qSpGroupCfg_Size     9

#define QKerBoardCfgResult_qSpGroupCfg 0x18  /* 24 */

/*
 * QKerBoardCfgResult (value = 0x80010b) is a message of generic use.
 */


typedef struct {
   UInt24   numStrmGroupCfgs;
   UInt24   numGlobalPoolCfgs;
   UInt24   numSpGroupCfgs;
} QKerBoardCfgResult_t;

#define QKerBoardCfgResult_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_numStrmGroupCfgs), &((structAddr)->numStrmGroupCfgs),  \
         (QKerBoardCfgResult_numGlobalPoolCfgs), &((structAddr)->numGlobalPoolCfgs),   \
         (QKerBoardCfgResult_numSpGroupCfgs), &((structAddr)->numSpGroupCfgs))


#define QKerBoardCfgResult_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerBoardCfgResult_numStrmGroupCfgs), &((structAddr)->numStrmGroupCfgs),  \
         (QKerBoardCfgResult_numGlobalPoolCfgs), &((structAddr)->numGlobalPoolCfgs),   \
         (QKerBoardCfgResult_numSpGroupCfgs), &((structAddr)->numSpGroupCfgs))


#define QKerBoardCfgResult_Size     9

#define QKerBoardCfgResult 0x80010b /* 8388875 */
/*Kernel Processor Configuration Structures Reply Message*/

#define QKerProcCfgResult_numCStreams  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_numCStreams_t;

#define QKerProcCfgResult_pmcsCircBufSize 0x300003 /* 3145731 */
typedef  UInt24   QKerProcCfgResult_pmcsCircBufSize_t;

#define QKerProcCfgResult_numFrameTimers  0x300006 /* 3145734 */
typedef  UInt24   QKerProcCfgResult_numFrameTimers_t;

#define QKerProcCfgResult_maxComponents   0x300009 /* 3145737 */
typedef  UInt24   QKerProcCfgResult_maxComponents_t;

#define QKerProcCfgResult_maxInstances 0x30000c /* 3145740 */
typedef  UInt24   QKerProcCfgResult_maxInstances_t;

#define QKerProcCfgResult_defKernelTaskMsgQSize 0x30000f /* 3145743 */
typedef  UInt24   QKerProcCfgResult_defKernelTaskMsgQSize_t;

#define QKerProcCfgResult_qSpPrintFlag 0x300012 /* 3145746 */
typedef  UInt24   QKerProcCfgResult_qSpPrintFlag_t;

#define QKerProcCfgResult_numLocalPoolCfgs   0x300015 /* 3145749 */
typedef  UInt24   QKerProcCfgResult_numLocalPoolCfgs_t;

#define QKerProcCfgResult_numGlobalPoolCacheCfgs   0x300018 /* 3145752 */
typedef  UInt24   QKerProcCfgResult_numGlobalPoolCacheCfgs_t;

#define QKerProcCfgResult_varStart  0x1b

#define QKerProcCfgResult_qLocalPoolCfg_poolId  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qLocalPoolCfg_poolId_t;

#define QKerProcCfgResult_qLocalPoolCfg_numBlocks  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qLocalPoolCfg_numBlocks_t;

#define QKerProcCfgResult_qLocalPoolCfg_memRegion  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qLocalPoolCfg_memRegion_t;

#define QKerProcCfgResult_qLocalPoolCfg_blockSize  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qLocalPoolCfg_blockSize_t;


typedef struct {
   UInt24   poolId;
   UInt24   numBlocks;
   UInt24   memRegion;
   UInt24   blockSize;
} QKerProcCfgResult_qLocalPoolCfg_t;

#define QKerProcCfgResult_qLocalPoolCfg_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 4, &(offset),  \
         (QKerProcCfgResult_qLocalPoolCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgResult_qLocalPoolCfg_numBlocks), &((structAddr)->numBlocks),   \
         (QKerProcCfgResult_qLocalPoolCfg_memRegion), &((structAddr)->memRegion),   \
         (QKerProcCfgResult_qLocalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerProcCfgResult_qLocalPoolCfg_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 4, &(offset),  \
         (QKerProcCfgResult_qLocalPoolCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgResult_qLocalPoolCfg_numBlocks), &((structAddr)->numBlocks),   \
         (QKerProcCfgResult_qLocalPoolCfg_memRegion), &((structAddr)->memRegion),   \
         (QKerProcCfgResult_qLocalPoolCfg_blockSize), &((structAddr)->blockSize))


#define QKerProcCfgResult_qLocalPoolCfg_Size    12

#define QKerProcCfgResult_qLocalPoolCfg   0x19  /* 25 */

#define QKerProcCfgResult_qGlobalPoolCacheCfg_poolId  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qGlobalPoolCacheCfg_poolId_t;

#define QKerProcCfgResult_qGlobalPoolCacheCfg_highWater  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qGlobalPoolCacheCfg_highWater_t;

#define QKerProcCfgResult_qGlobalPoolCacheCfg_lowWater   0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qGlobalPoolCacheCfg_lowWater_t;

#define QKerProcCfgResult_qGlobalPoolCacheCfg_highWaterDeallocAmount 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qGlobalPoolCacheCfg_highWaterDeallocAmount_t;

#define QKerProcCfgResult_qGlobalPoolCacheCfg_lowWaterAllocAmount 0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qGlobalPoolCacheCfg_lowWaterAllocAmount_t;


typedef struct {
   UInt24   poolId;
   UInt24   highWater;
   UInt24   lowWater;
   UInt24   highWaterDeallocAmount;
   UInt24   lowWaterAllocAmount;
} QKerProcCfgResult_qGlobalPoolCacheCfg_t;

#define QKerProcCfgResult_qGlobalPoolCacheCfg_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_highWater), &((structAddr)->highWater),   \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_lowWater), &((structAddr)->lowWater),  \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_highWaterDeallocAmount), &((structAddr)->highWaterDeallocAmount), \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_lowWaterAllocAmount), &((structAddr)->lowWaterAllocAmount))


#define QKerProcCfgResult_qGlobalPoolCacheCfg_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_poolId), &((structAddr)->poolId),   \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_highWater), &((structAddr)->highWater),   \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_lowWater), &((structAddr)->lowWater),  \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_highWaterDeallocAmount), &((structAddr)->highWaterDeallocAmount), \
         (QKerProcCfgResult_qGlobalPoolCacheCfg_lowWaterAllocAmount), &((structAddr)->lowWaterAllocAmount))


#define QKerProcCfgResult_qGlobalPoolCacheCfg_Size    15

#define QKerProcCfgResult_qGlobalPoolCacheCfg   0x1a  /* 26 */

#define QKerProcCfgResult_qtraceCfg_traceqsize  0x300000 /* 3145728 */
typedef  UInt24   QKerProcCfgResult_qtraceCfg_traceqsize_t;


typedef struct {
   UInt24   traceqsize;
} QKerProcCfgResult_qtraceCfg_t;

#define QKerProcCfgResult_qtraceCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerProcCfgResult_qtraceCfg_traceqsize), &((structAddr)->traceqsize))


#define QKerProcCfgResult_qtraceCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerProcCfgResult_qtraceCfg_traceqsize), &((structAddr)->traceqsize))


#define QKerProcCfgResult_qtraceCfg_Size     3

#define QKerProcCfgResult_qtraceCfg 0x1b  /* 27 */

/*
 * QKerProcCfgResult (value = 0x80010c) is a message of generic use.
 */


typedef struct {
   UInt24   numCStreams;
   UInt24   pmcsCircBufSize;
   UInt24   numFrameTimers;
   UInt24   maxComponents;
   UInt24   maxInstances;
   UInt24   defKernelTaskMsgQSize;
   UInt24   qSpPrintFlag;
   UInt24   numLocalPoolCfgs;
   UInt24   numGlobalPoolCacheCfgs;
} QKerProcCfgResult_t;

#define QKerProcCfgResult_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 9, &(offset),  \
         (QKerProcCfgResult_numCStreams), &((structAddr)->numCStreams), \
         (QKerProcCfgResult_pmcsCircBufSize), &((structAddr)->pmcsCircBufSize),  \
         (QKerProcCfgResult_numFrameTimers), &((structAddr)->numFrameTimers), \
         (QKerProcCfgResult_maxComponents), &((structAddr)->maxComponents),   \
         (QKerProcCfgResult_maxInstances), &((structAddr)->maxInstances),  \
         (QKerProcCfgResult_defKernelTaskMsgQSize), &((structAddr)->defKernelTaskMsgQSize),  \
         (QKerProcCfgResult_qSpPrintFlag), &((structAddr)->qSpPrintFlag),  \
         (QKerProcCfgResult_numLocalPoolCfgs), &((structAddr)->numLocalPoolCfgs),   \
         (QKerProcCfgResult_numGlobalPoolCacheCfgs), &((structAddr)->numGlobalPoolCacheCfgs))


#define QKerProcCfgResult_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 9, &(offset),  \
         (QKerProcCfgResult_numCStreams), &((structAddr)->numCStreams), \
         (QKerProcCfgResult_pmcsCircBufSize), &((structAddr)->pmcsCircBufSize),  \
         (QKerProcCfgResult_numFrameTimers), &((structAddr)->numFrameTimers), \
         (QKerProcCfgResult_maxComponents), &((structAddr)->maxComponents),   \
         (QKerProcCfgResult_maxInstances), &((structAddr)->maxInstances),  \
         (QKerProcCfgResult_defKernelTaskMsgQSize), &((structAddr)->defKernelTaskMsgQSize),  \
         (QKerProcCfgResult_qSpPrintFlag), &((structAddr)->qSpPrintFlag),  \
         (QKerProcCfgResult_numLocalPoolCfgs), &((structAddr)->numLocalPoolCfgs),   \
         (QKerProcCfgResult_numGlobalPoolCacheCfgs), &((structAddr)->numGlobalPoolCacheCfgs))


#define QKerProcCfgResult_Size      27

#define QKerProcCfgResult  0x80010c /* 8388876 */
/* Inter-Processor Communication (IPC) Configuration Transfer Message */

#define QKerIpcCfgResult_numIpcCfgs 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgResult_numIpcCfgs_t;

#define QKerIpcCfgResult_varStart   0x3

#define QKerIpcCfgResult_qIpcCfg_spProcNum   0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgResult_qIpcCfg_spProcNum_t;

#define QKerIpcCfgResult_qIpcCfg_cpToSpQSize 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgResult_qIpcCfg_cpToSpQSize_t;

#define QKerIpcCfgResult_qIpcCfg_spToCpQSize 0x300000 /* 3145728 */
typedef  UInt24   QKerIpcCfgResult_qIpcCfg_spToCpQSize_t;


typedef struct {
   UInt24   spProcNum;
   UInt24   cpToSpQSize;
   UInt24   spToCpQSize;
} QKerIpcCfgResult_qIpcCfg_t;

#define QKerIpcCfgResult_qIpcCfg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerIpcCfgResult_qIpcCfg_spProcNum), &((structAddr)->spProcNum), \
         (QKerIpcCfgResult_qIpcCfg_cpToSpQSize), &((structAddr)->cpToSpQSize),   \
         (QKerIpcCfgResult_qIpcCfg_spToCpQSize), &((structAddr)->spToCpQSize))


#define QKerIpcCfgResult_qIpcCfg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerIpcCfgResult_qIpcCfg_spProcNum), &((structAddr)->spProcNum), \
         (QKerIpcCfgResult_qIpcCfg_cpToSpQSize), &((structAddr)->cpToSpQSize),   \
         (QKerIpcCfgResult_qIpcCfg_spToCpQSize), &((structAddr)->spToCpQSize))


#define QKerIpcCfgResult_qIpcCfg_Size     9

#define QKerIpcCfgResult_qIpcCfg 0x1c  /* 28 */

/*
 * QKerIpcCfgResult (value = 0x80010d) is a message of generic use.
 */


typedef struct {
   UInt24   numIpcCfgs;
} QKerIpcCfgResult_t;

#define QKerIpcCfgResult_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerIpcCfgResult_numIpcCfgs), &((structAddr)->numIpcCfgs))


#define QKerIpcCfgResult_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerIpcCfgResult_numIpcCfgs), &((structAddr)->numIpcCfgs))


#define QKerIpcCfgResult_Size    3

#define QKerIpcCfgResult   0x80010d /* 8388877 */
/* Request to start all modules on a processor */
/* Message from the host (CPLOAD) to the HMP Linux boot kernel with the name
 * of the mlm file to be downloaded. */

/*
 * QModuleStart (value = 0x80010e) is a message of generic use.
 */

#define QModuleStart_Size     0

#define QModuleStart 0x80010e /* 8388878 */

#define QModuleName_moduleName   0x57f800 /* 5765120 */
typedef  Char  QModuleName_moduleName_t[256];

/*
 * QModuleName (value = 0x800145) is a message of generic use.
 */


typedef struct {
   Char  moduleName[256];
} QModuleName_t;

#define QModuleName_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QModuleName_moduleName), &((structAddr)->moduleName))


#define QModuleName_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QModuleName_moduleName), &((structAddr)->moduleName))


#define QModuleName_Size      256

#define QModuleName  0x800145 /* 8388933 */
/* Unknown Message received */

#define Err_UnknownMsg  0  /* 0 */
/* Stream group id exceeds range */

#define Err_InvalidStrmGroupId   0x1   /* 1 */
/* Global pool id exceeds range */

#define Err_InvalidGlobalPoolId  0x2   /* 2 */
/* SP daug-board invalid/missing */

#define Err_InvalidSpDbNum 0x3   /* 3 */
/* Local pool id exceeds range */

#define Err_InvalidLocalPoolId   0x4   /* 4 */
/* Processor invalid/missing */

#define Err_InvalidProcNum 0x5   /* 5 */
/* CP Boot-to-RTK mailbox is full */

#define Err_RTK_MailBoxFull   0x6   /* 6 */
/* Error Invoking CFSP call to set
 * Timer*/
/* SC4000 Configuration Transfer Message */

#define Err_InvokingCFSP   0x7   /* 7 */

#define QSC4kCfgSet_SCbusClockRate  0x300000 /* 3145728 */
typedef  UInt24   QSC4kCfgSet_SCbusClockRate_t;

#define QSC4kCfgSet_LocalbusClockRate  0x300003 /* 3145731 */
typedef  UInt24   QSC4kCfgSet_LocalbusClockRate_t;

#define QSC4kCfgSet_MasterClockInpFreq 0x300006 /* 3145734 */
typedef  UInt24   QSC4kCfgSet_MasterClockInpFreq_t;

/*
 * QSC4kCfgSet (value = 0x80010f) is a message of generic use.
 */


typedef struct {
   UInt24   SCbusClockRate;
   UInt24   LocalbusClockRate;
   UInt24   MasterClockInpFreq;
} QSC4kCfgSet_t;

#define QSC4kCfgSet_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QSC4kCfgSet_SCbusClockRate), &((structAddr)->SCbusClockRate), \
         (QSC4kCfgSet_LocalbusClockRate), &((structAddr)->LocalbusClockRate), \
         (QSC4kCfgSet_MasterClockInpFreq), &((structAddr)->MasterClockInpFreq))


#define QSC4kCfgSet_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QSC4kCfgSet_SCbusClockRate), &((structAddr)->SCbusClockRate), \
         (QSC4kCfgSet_LocalbusClockRate), &((structAddr)->LocalbusClockRate), \
         (QSC4kCfgSet_MasterClockInpFreq), &((structAddr)->MasterClockInpFreq))


#define QSC4kCfgSet_Size      9

#define QSC4kCfgSet  0x80010f /* 8388879 */
/* Kernel Configuration QSC4kCfgSet Acknowledgment Message */
/* Kernel Configuration Upload Message */

/*
 * QSC4kCfgSetAck (value = 0x800110) is a message of generic use.
 */

#define QSC4kCfgSetAck_Size      0

#define QSC4kCfgSetAck  0x800110 /* 8388880 */
/* SC4000 Configuration Reply Message */

/*
 * QSC4kCfgGet (value = 0x800111) is a message of generic use.
 */

#define QSC4kCfgGet_Size      0

#define QSC4kCfgGet  0x800111 /* 8388881 */

#define QSC4kCfgResult_SCbusClockRate  0x300000 /* 3145728 */
typedef  UInt24   QSC4kCfgResult_SCbusClockRate_t;

#define QSC4kCfgResult_LocalbusClockRate  0x300003 /* 3145731 */
typedef  UInt24   QSC4kCfgResult_LocalbusClockRate_t;

#define QSC4kCfgResult_MasterClockInpFreq 0x300006 /* 3145734 */
typedef  UInt24   QSC4kCfgResult_MasterClockInpFreq_t;

/*
 * QSC4kCfgResult (value = 0x800112) is a message of generic use.
 */


typedef struct {
   UInt24   SCbusClockRate;
   UInt24   LocalbusClockRate;
   UInt24   MasterClockInpFreq;
} QSC4kCfgResult_t;

#define QSC4kCfgResult_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QSC4kCfgResult_SCbusClockRate), &((structAddr)->SCbusClockRate), \
         (QSC4kCfgResult_LocalbusClockRate), &((structAddr)->LocalbusClockRate), \
         (QSC4kCfgResult_MasterClockInpFreq), &((structAddr)->MasterClockInpFreq))


#define QSC4kCfgResult_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QSC4kCfgResult_SCbusClockRate), &((structAddr)->SCbusClockRate), \
         (QSC4kCfgResult_LocalbusClockRate), &((structAddr)->LocalbusClockRate), \
         (QSC4kCfgResult_MasterClockInpFreq), &((structAddr)->MasterClockInpFreq))


#define QSC4kCfgResult_Size      9

#define QSC4kCfgResult  0x800112 /* 8388882 */
/* SC4000 Event Message */

#define QSC4kEvent_id   0x300000 /* 3145728 */
typedef  UInt24   QSC4kEvent_id_t;

#define QSC4kEvent_source  0x300003 /* 3145731 */
typedef  UInt24   QSC4kEvent_source_t;

/*
 * QSC4kEvent (value = 0x800113) is a message of generic use.
 */


typedef struct {
   UInt24   id;
   UInt24   source;
} QSC4kEvent_t;

#define QSC4kEvent_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QSC4kEvent_id), &((structAddr)->id),  \
         (QSC4kEvent_source), &((structAddr)->source))


#define QSC4kEvent_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QSC4kEvent_id), &((structAddr)->id),  \
         (QSC4kEvent_source), &((structAddr)->source))


#define QSC4kEvent_Size    6

#define QSC4kEvent   0x800113 /* 8388883 */
/* SC4000 Event Message */

#define QSC4kCmd_numCmds   0x300000 /* 3145728 */
typedef  UInt24   QSC4kCmd_numCmds_t;

#define QSC4kCmd_varStart  0x3

#define QSC4kCmd_cmd_recipient   0x300000 /* 3145728 */
typedef  UInt24   QSC4kCmd_cmd_recipient_t;

#define QSC4kCmd_cmd_id 0x300000 /* 3145728 */
typedef  UInt24   QSC4kCmd_cmd_id_t;

#define QSC4kCmd_cmd_value 0x300000 /* 3145728 */
typedef  UInt24   QSC4kCmd_cmd_value_t;


typedef struct {
   UInt24   recipient;
   UInt24   id;
   UInt24   value;
} QSC4kCmd_cmd_t;

#define QSC4kCmd_cmd_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QSC4kCmd_cmd_recipient), &((structAddr)->recipient), \
         (QSC4kCmd_cmd_id), &((structAddr)->id),   \
         (QSC4kCmd_cmd_value), &((structAddr)->value))


#define QSC4kCmd_cmd_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QSC4kCmd_cmd_recipient), &((structAddr)->recipient), \
         (QSC4kCmd_cmd_id), &((structAddr)->id),   \
         (QSC4kCmd_cmd_value), &((structAddr)->value))


#define QSC4kCmd_cmd_Size     9

#define QSC4kCmd_cmd 0x1d  /* 29 */

/*
 * QSC4kCmd (value = 0x800114) is a message of generic use.
 */


typedef struct {
   UInt24   numCmds;
} QSC4kCmd_t;

#define QSC4kCmd_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QSC4kCmd_numCmds), &((structAddr)->numCmds))


#define QSC4kCmd_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QSC4kCmd_numCmds), &((structAddr)->numCmds))


#define QSC4kCmd_Size      3

#define QSC4kCmd  0x800114 /* 8388884 */
/* SC4000 Command Acknowledgment Message */
/* SC4000 Command Error Message */

/*
 * QSC4kCmdAck (value = 0x800115) is a message of generic use.
 */

#define QSC4kCmdAck_Size      0

#define QSC4kCmdAck  0x800115 /* 8388885 */

#define QSC4kCmdError_id   0x300000 /* 3145728 */
typedef  UInt24   QSC4kCmdError_id_t;

#define QSC4kCmdError_errcode 0x300003 /* 3145731 */
typedef  UInt24   QSC4kCmdError_errcode_t;

/*
 * QSC4kCmdError (value = 0x800116) is a message of generic use.
 */


typedef struct {
   UInt24   id;
   UInt24   errcode;
} QSC4kCmdError_t;

#define QSC4kCmdError_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QSC4kCmdError_id), &((structAddr)->id),  \
         (QSC4kCmdError_errcode), &((structAddr)->errcode))


#define QSC4kCmdError_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QSC4kCmdError_id), &((structAddr)->id),  \
         (QSC4kCmdError_errcode), &((structAddr)->errcode))


#define QSC4kCmdError_Size    6

#define QSC4kCmdError   0x800116 /* 8388886 */
/* Enables events on both SC4000s */
/* Acknowledgment for QSC4kEnableEvents */

/*
 * QSC4kEnableEvents (value = 0x800117) is a message of generic use.
 */

#define QSC4kEnableEvents_Size      0

#define QSC4kEnableEvents  0x800117 /* 8388887 */
/* Kernel SC4000 State Request Message */

/*
 * QSC4kEnableEventsAck (value = 0x800118) is a message of generic use.
 */

#define QSC4kEnableEventsAck_Size      0

#define QSC4kEnableEventsAck  0x800118 /* 8388888 */
/* SC4000 Status Reply Message */

/*
 * QSC4kStatusGet (value = 0x800119) is a message of generic use.
 */

#define QSC4kStatusGet_Size      0

#define QSC4kStatusGet  0x800119 /* 8388889 */

#define QSC4kStatusResult_refStatus 0x300000 /* 3145728 */
typedef  UInt24   QSC4kStatusResult_refStatus_t;

#define QSC4kStatusResult_refMonitor   0x300003 /* 3145731 */
typedef  UInt24   QSC4kStatusResult_refMonitor_t;

#define QSC4kStatusResult_eventGen  0x300006 /* 3145734 */
typedef  UInt24   QSC4kStatusResult_eventGen_t;

#define QSC4kStatusResult_SC4k_1_clockMode   0x300009 /* 3145737 */
typedef  UInt24   QSC4kStatusResult_SC4k_1_clockMode_t;

#define QSC4kStatusResult_SC4k_1_diagMode 0x30000c /* 3145740 */
typedef  UInt24   QSC4kStatusResult_SC4k_1_diagMode_t;

#define QSC4kStatusResult_SC4k_1_clockRef 0x30000f /* 3145743 */
typedef  UInt24   QSC4kStatusResult_SC4k_1_clockRef_t;

#define QSC4kStatusResult_SC4k_1_SREFout  0x300012 /* 3145746 */
typedef  UInt24   QSC4kStatusResult_SC4k_1_SREFout_t;

#define QSC4kStatusResult_SC4k_1_clockStatus 0x300015 /* 3145749 */
typedef  UInt24   QSC4kStatusResult_SC4k_1_clockStatus_t;


typedef struct {
   UInt24   clockMode;
   UInt24   diagMode;
   UInt24   clockRef;
   UInt24   SREFout;
   UInt24   clockStatus;
} QSC4kStatusResult_SC4k_1_t;

#define QSC4kStatusResult_SC4k_1_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QSC4kStatusResult_SC4k_1_clockMode), &((structAddr)->clockMode), \
         (QSC4kStatusResult_SC4k_1_diagMode), &((structAddr)->diagMode),   \
         (QSC4kStatusResult_SC4k_1_clockRef), &((structAddr)->clockRef),   \
         (QSC4kStatusResult_SC4k_1_SREFout), &((structAddr)->SREFout),  \
         (QSC4kStatusResult_SC4k_1_clockStatus), &((structAddr)->clockStatus))


#define QSC4kStatusResult_SC4k_1_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QSC4kStatusResult_SC4k_1_clockMode), &((structAddr)->clockMode), \
         (QSC4kStatusResult_SC4k_1_diagMode), &((structAddr)->diagMode),   \
         (QSC4kStatusResult_SC4k_1_clockRef), &((structAddr)->clockRef),   \
         (QSC4kStatusResult_SC4k_1_SREFout), &((structAddr)->SREFout),  \
         (QSC4kStatusResult_SC4k_1_clockStatus), &((structAddr)->clockStatus))


#define QSC4kStatusResult_SC4k_1_Size     15

#define QSC4kStatusResult_SC4k_1 0x1e  /* 30 */

#define QSC4kStatusResult_SC4k_2_clockMode   0x300018 /* 3145752 */
typedef  UInt24   QSC4kStatusResult_SC4k_2_clockMode_t;

#define QSC4kStatusResult_SC4k_2_diagMode 0x30001b /* 3145755 */
typedef  UInt24   QSC4kStatusResult_SC4k_2_diagMode_t;

#define QSC4kStatusResult_SC4k_2_clockRef 0x30001e /* 3145758 */
typedef  UInt24   QSC4kStatusResult_SC4k_2_clockRef_t;

#define QSC4kStatusResult_SC4k_2_SREFout  0x300021 /* 3145761 */
typedef  UInt24   QSC4kStatusResult_SC4k_2_SREFout_t;

#define QSC4kStatusResult_SC4k_2_clockStatus 0x300024 /* 3145764 */
typedef  UInt24   QSC4kStatusResult_SC4k_2_clockStatus_t;


typedef struct {
   UInt24   clockMode;
   UInt24   diagMode;
   UInt24   clockRef;
   UInt24   SREFout;
   UInt24   clockStatus;
} QSC4kStatusResult_SC4k_2_t;

#define QSC4kStatusResult_SC4k_2_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QSC4kStatusResult_SC4k_2_clockMode), &((structAddr)->clockMode), \
         (QSC4kStatusResult_SC4k_2_diagMode), &((structAddr)->diagMode),   \
         (QSC4kStatusResult_SC4k_2_clockRef), &((structAddr)->clockRef),   \
         (QSC4kStatusResult_SC4k_2_SREFout), &((structAddr)->SREFout),  \
         (QSC4kStatusResult_SC4k_2_clockStatus), &((structAddr)->clockStatus))


#define QSC4kStatusResult_SC4k_2_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QSC4kStatusResult_SC4k_2_clockMode), &((structAddr)->clockMode), \
         (QSC4kStatusResult_SC4k_2_diagMode), &((structAddr)->diagMode),   \
         (QSC4kStatusResult_SC4k_2_clockRef), &((structAddr)->clockRef),   \
         (QSC4kStatusResult_SC4k_2_SREFout), &((structAddr)->SREFout),  \
         (QSC4kStatusResult_SC4k_2_clockStatus), &((structAddr)->clockStatus))


#define QSC4kStatusResult_SC4k_2_Size     15

#define QSC4kStatusResult_SC4k_2 0x1f  /* 31 */

/*
 * QSC4kStatusResult (value = 0x80011a) is a message of generic use.
 */


typedef struct {
   UInt24   refStatus;
   UInt24   refMonitor;
   UInt24   eventGen;
   QSC4kStatusResult_SC4k_1_t QSC4kStatusResult_SC4k_1_i;
   QSC4kStatusResult_SC4k_2_t QSC4kStatusResult_SC4k_2_i;
} QSC4kStatusResult_t;

#define QSC4kStatusResult_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QSC4kStatusResult_refStatus), &((structAddr)->refStatus),  \
         (QSC4kStatusResult_refMonitor), &((structAddr)->refMonitor),   \
         (QSC4kStatusResult_eventGen), &((structAddr)->eventGen));   \
          QSC4kStatusResult_SC4k_2_get(msgPtr, &((structAddr)->QSC4kStatusResult_SC4k_2_i), offset);  \
          QSC4kStatusResult_SC4k_1_get(msgPtr, &((structAddr)->QSC4kStatusResult_SC4k_1_i), offset)


#define QSC4kStatusResult_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QSC4kStatusResult_refStatus), &((structAddr)->refStatus),  \
         (QSC4kStatusResult_refMonitor), &((structAddr)->refMonitor),   \
         (QSC4kStatusResult_eventGen), &((structAddr)->eventGen));   \
          QSC4kStatusResult_SC4k_2_put(msgPtr, &((structAddr)->QSC4kStatusResult_SC4k_2_i), offset);  \
          QSC4kStatusResult_SC4k_1_put(msgPtr, &((structAddr)->QSC4kStatusResult_SC4k_1_i), offset)


#define QSC4kStatusResult_Size      39

#define QSC4kStatusResult  0x80011a /* 8388890 */
#define SM_BAD_DIAG_MODE         SH_BAD_DIAG_MODE
#define SM_BAD_SCBUS_FR_MODE     SH_BAD_SCBUS_FR_MODE
#define SM_BAD_LOCBUS_FR_MODE    SH_BAD_LOCBUS_FR_MODE
#define SM_BAD_MCLK_INP_FREQ     SH_BAD_MCLK_INP_FREQ
#define SM_BAD_CLOCK_MODE        SH_BAD_CLOCK_MODE
#define SM_BAD_CLOCK_REF         SH_BAD_CLOCK_REF
#define SM_PREVIOUS_CLOCK_PRIMARY   SH_PREVIOUS_CLOCK_PRIMARY
#define SM_BAD_CMDID       SH_BAD_PARMID
#define SM_BAD_CMDVAL         SH_BAD_PARMVAL
#define SM_MCLK_NOT_ENABLED      SH_MCLK_NOT_ENABLED
#define SM_CLOCK_PRIMARY      SH_CLOCK_PRIMARY
#define SM_CLOCK_SLAVE     SH_CLOCK_SLAVE
#define SM_CLOCK_SECONDARY SH_CLOCK_SECONDARY
#define SM_CLOCK_REF_INTERNAL SC4K_INT_PLL_FREE_RUN
#define SM_CLOCK_REF_1     SC4K_INT_PLL_REF_8K_0
#define SM_CLOCK_REF_2     SC4K_INT_PLL_REF_8K_1
#define SM_CLOCK_REF_3     SC4K_INT_PLL_REF_8K_2
#define SM_CLOCK_REF_4     SC4K_INT_PLL_REF_8K_3
#define SM_CLOCK_SREF      SC4K_INT_PLL_SREF_8K
#define SM_DISABLED        SH_DISABLED
#define SM_ENABLED         SH_ENABLED
#define SM_SC4K_1       0
#define SM_SC4K_2       1
#define SM_MCLK_2048KHZ    SC4K_MCLK_2048KHZ
#define SM_MCLK_4096KHZ    SC4K_MCLK_4096KHZ
#define SM_MCLK_8192KHZ    SC4K_MCLK_8192KHZ
#define SM_MCLK_16384KHZ      SC4K_MCLK_16384KHZ
#define SM_MCLK_32768KHZ      SC4K_MCLK_32768KHZ
#define SM_MCLK_65536KHZ      SC4K_MCLK_65536KHZ
#define SM_SCBUS_2048KBPS     SC4K_SCBUS_2048KBPS
#define SM_SCBUS_4096KBPS     SC4K_SCBUS_4096KBPS
#define SM_SCBUS_8192KBPS     SC4K_SCBUS_8192KBPS
#define SM_LOCBUS_2048KBPS    SC4K_LOCBUS_2048KBPS
#define SM_LOCBUS_4096KBPS    SC4K_LOCBUS_4096KBPS
#define SM_LOCBUS_8192KBPS    SC4K_LOCBUS_8192KBPS
#define SM_CMD_CLKMODE     0x0
#define SM_CMD_CLKREF      0x1
#define SM_CMD_SREFOUT     0x2
#define SM_CMD_DIAGMODE    0x3
#define SM_CMD_ENABLE_REFMON  0x4
#define SM_CMD_DISABLE_REFMON 0x5
#define SM_EVENT_CLKFAIL      0x0
#define SM_EVENT_CLKDEGRAD 0x1
#define SM_EVENT_CLKRECOVERY  0x2
#define SM_EVENT_REFLOSS      0x3
#define SM_EVENT_REFRECOVERY  0x4
#define SM_EVENT_NEWPRIMARY   0x5
/* Request kernel version string */
/* Reply message to QKerVersionGet */

/*
 * QKerVersionGet (value = 0x80011b) is a message of generic use.
 */

#define QKerVersionGet_Size      0

#define QKerVersionGet  0x80011b /* 8388891 */

#define QKerVersionResult_version   0x507000 /* 5271552 */
typedef  Char  QKerVersionResult_version_t[15];

#define QKerVersionResult_dwnldProtocol   0x30000f /* 3145743 */
typedef  UInt24   QKerVersionResult_dwnldProtocol_t;

#define QKerVersionResult_varStart  0x12

#define QKerVersionResult_qDwnldGroupCfg_dwnldSpeed   0x300000 /* 3145728 */
typedef  UInt24   QKerVersionResult_qDwnldGroupCfg_dwnldSpeed_t;


typedef struct {
   UInt24   dwnldSpeed;
} QKerVersionResult_qDwnldGroupCfg_t;

#define QKerVersionResult_qDwnldGroupCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerVersionResult_qDwnldGroupCfg_dwnldSpeed), &((structAddr)->dwnldSpeed))


#define QKerVersionResult_qDwnldGroupCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerVersionResult_qDwnldGroupCfg_dwnldSpeed), &((structAddr)->dwnldSpeed))


#define QKerVersionResult_qDwnldGroupCfg_Size      3

#define QKerVersionResult_qDwnldGroupCfg  0x20  /* 32 */

#define QKerVersionResult_qDwnldErrorCfg_dwnlderror   0x300000 /* 3145728 */
typedef  UInt24   QKerVersionResult_qDwnldErrorCfg_dwnlderror_t;


typedef struct {
   UInt24   dwnlderror;
} QKerVersionResult_qDwnldErrorCfg_t;

#define QKerVersionResult_qDwnldErrorCfg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerVersionResult_qDwnldErrorCfg_dwnlderror), &((structAddr)->dwnlderror))


#define QKerVersionResult_qDwnldErrorCfg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerVersionResult_qDwnldErrorCfg_dwnlderror), &((structAddr)->dwnlderror))


#define QKerVersionResult_qDwnldErrorCfg_Size      3

#define QKerVersionResult_qDwnldErrorCfg  0x21  /* 33 */

/*
 * QKerVersionResult (value = 0x80011c) is a message of generic use.
 */


typedef struct {
   Char  version[15];
   UInt24   dwnldProtocol;
} QKerVersionResult_t;

#define QKerVersionResult_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKerVersionResult_version), &((structAddr)->version),   \
         (QKerVersionResult_dwnldProtocol), &((structAddr)->dwnldProtocol))


#define QKerVersionResult_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKerVersionResult_version), &((structAddr)->version),   \
         (QKerVersionResult_dwnldProtocol), &((structAddr)->dwnldProtocol))


#define QKerVersionResult_Size      18

#define QKerVersionResult  0x80011c /* 8388892 */
/* The current Downloader version is now 6.
 *                  Version 6 includes the QTBC message.
 *       Version 5  includes Fast Downloader support.
 *       Version 4 includes MMA Timeslice parameters.
 *       Version 4 includes request list size configuration.
 *       Version 4 inlcudes mult sp mem write.
 *       Version 3 includes the "New" TDM Bus Configuration Protocol.
 *       Version 3 is fully backwards compatable with Version 2. */
#define QDOWNLOADVERSION      6
/*The valid Downloader speeds are:
 *          0 - original download speed - no pool
 *          1 - download speed increased by requesting number of big pools
 *    */
#define QDOWNLOADSPEED0 0
#define QDOWNLOADSPEED1 1
/*SP Daughterboard Ethernet Kernel Configuration Information Structures
 * Request Message */
/* SP Daughterboard Ethernet Kernel Configuration Transfer Message */

/*
 * QKerSpDbEnetCfgGet (value = 0x80011d) is a message of generic use.
 */

#define QKerSpDbEnetCfgGet_Size     0

#define QKerSpDbEnetCfgGet 0x80011d /* 8388893 */

#define QKerSpDbEnetCfgSet_ipAddr   0x50e800 /* 5302272 */
typedef  Char  QKerSpDbEnetCfgSet_ipAddr_t[30];

#define QKerSpDbEnetCfgSet_subnetMask  0x50401e /* 5259294 */
typedef  Char  QKerSpDbEnetCfgSet_subnetMask_t[9];

#define QKerSpDbEnetCfgSet_targetName  0x509827 /* 5281831 */
typedef  Char  QKerSpDbEnetCfgSet_targetName_t[20];

#define QKerSpDbEnetCfgSet_hostIpAddr  0x50e83b /* 5302331 */
typedef  Char  QKerSpDbEnetCfgSet_hostIpAddr_t[30];

#define QKerSpDbEnetCfgSet_hostName 0x509859 /* 5281881 */
typedef  Char  QKerSpDbEnetCfgSet_hostName_t[20];

#define QKerSpDbEnetCfgSet_userName 0x50986d /* 5281901 */
typedef  Char  QKerSpDbEnetCfgSet_userName_t[20];

#define QKerSpDbEnetCfgSet_gatewayIpAddr  0x50e881 /* 5302401 */
typedef  Char  QKerSpDbEnetCfgSet_gatewayIpAddr_t[30];

/*
 * QKerSpDbEnetCfgSet (value = 0x80011e) is a message of generic use.
 */


typedef struct {
   Char  ipAddr[30];
   Char  subnetMask[9];
   Char  targetName[20];
   Char  hostIpAddr[30];
   Char  hostName[20];
   Char  userName[20];
   Char  gatewayIpAddr[30];
} QKerSpDbEnetCfgSet_t;

#define QKerSpDbEnetCfgSet_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 7, &(offset),  \
         (QKerSpDbEnetCfgSet_ipAddr), &((structAddr)->ipAddr), \
         (QKerSpDbEnetCfgSet_subnetMask), &((structAddr)->subnetMask),  \
         (QKerSpDbEnetCfgSet_targetName), &((structAddr)->targetName),  \
         (QKerSpDbEnetCfgSet_hostIpAddr), &((structAddr)->hostIpAddr),  \
         (QKerSpDbEnetCfgSet_hostName), &((structAddr)->hostName),   \
         (QKerSpDbEnetCfgSet_userName), &((structAddr)->userName),   \
         (QKerSpDbEnetCfgSet_gatewayIpAddr), &((structAddr)->gatewayIpAddr))


#define QKerSpDbEnetCfgSet_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 7, &(offset),  \
         (QKerSpDbEnetCfgSet_ipAddr), &((structAddr)->ipAddr), \
         (QKerSpDbEnetCfgSet_subnetMask), &((structAddr)->subnetMask),  \
         (QKerSpDbEnetCfgSet_targetName), &((structAddr)->targetName),  \
         (QKerSpDbEnetCfgSet_hostIpAddr), &((structAddr)->hostIpAddr),  \
         (QKerSpDbEnetCfgSet_hostName), &((structAddr)->hostName),   \
         (QKerSpDbEnetCfgSet_userName), &((structAddr)->userName),   \
         (QKerSpDbEnetCfgSet_gatewayIpAddr), &((structAddr)->gatewayIpAddr))


#define QKerSpDbEnetCfgSet_Size     159

#define QKerSpDbEnetCfgSet 0x80011e /* 8388894 */
#define  NIC_NOT_PRESENT      0
#define  ST_NIC_8_BIT         1
#define  ST_NIC_16_BIT        2
/*SP daughterboard Ethernet Configuration Transfer Message */

#define QKerSpDbEnetCfgResult_ipAddr   0x50e800 /* 5302272 */
typedef  Char  QKerSpDbEnetCfgResult_ipAddr_t[30];

#define QKerSpDbEnetCfgResult_subnetMask  0x50401e /* 5259294 */
typedef  Char  QKerSpDbEnetCfgResult_subnetMask_t[9];

#define QKerSpDbEnetCfgResult_targetName  0x509827 /* 5281831 */
typedef  Char  QKerSpDbEnetCfgResult_targetName_t[20];

#define QKerSpDbEnetCfgResult_hostIpAddr  0x50e83b /* 5302331 */
typedef  Char  QKerSpDbEnetCfgResult_hostIpAddr_t[30];

#define QKerSpDbEnetCfgResult_hostName 0x509859 /* 5281881 */
typedef  Char  QKerSpDbEnetCfgResult_hostName_t[20];

#define QKerSpDbEnetCfgResult_userName 0x50986d /* 5281901 */
typedef  Char  QKerSpDbEnetCfgResult_userName_t[20];

#define QKerSpDbEnetCfgResult_gatewayIpAddr  0x50e881 /* 5302401 */
typedef  Char  QKerSpDbEnetCfgResult_gatewayIpAddr_t[30];

/*
 * QKerSpDbEnetCfgResult (value = 0x80011f) is a message of generic use.
 */


typedef struct {
   Char  ipAddr[30];
   Char  subnetMask[9];
   Char  targetName[20];
   Char  hostIpAddr[30];
   Char  hostName[20];
   Char  userName[20];
   Char  gatewayIpAddr[30];
} QKerSpDbEnetCfgResult_t;

#define QKerSpDbEnetCfgResult_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 7, &(offset),  \
         (QKerSpDbEnetCfgResult_ipAddr), &((structAddr)->ipAddr), \
         (QKerSpDbEnetCfgResult_subnetMask), &((structAddr)->subnetMask),  \
         (QKerSpDbEnetCfgResult_targetName), &((structAddr)->targetName),  \
         (QKerSpDbEnetCfgResult_hostIpAddr), &((structAddr)->hostIpAddr),  \
         (QKerSpDbEnetCfgResult_hostName), &((structAddr)->hostName),   \
         (QKerSpDbEnetCfgResult_userName), &((structAddr)->userName),   \
         (QKerSpDbEnetCfgResult_gatewayIpAddr), &((structAddr)->gatewayIpAddr))


#define QKerSpDbEnetCfgResult_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 7, &(offset),  \
         (QKerSpDbEnetCfgResult_ipAddr), &((structAddr)->ipAddr), \
         (QKerSpDbEnetCfgResult_subnetMask), &((structAddr)->subnetMask),  \
         (QKerSpDbEnetCfgResult_targetName), &((structAddr)->targetName),  \
         (QKerSpDbEnetCfgResult_hostIpAddr), &((structAddr)->hostIpAddr),  \
         (QKerSpDbEnetCfgResult_hostName), &((structAddr)->hostName),   \
         (QKerSpDbEnetCfgResult_userName), &((structAddr)->userName),   \
         (QKerSpDbEnetCfgResult_gatewayIpAddr), &((structAddr)->gatewayIpAddr))


#define QKerSpDbEnetCfgResult_Size     159

#define QKerSpDbEnetCfgResult 0x80011f /* 8388895 */
/* Kernel Configuration QKerSpDbEnetCfgSet Acknowledgment Message */
/* Message to signal the downloader that all components have been started and
 * initialized */

/*
 * QKerSpDbEnetCfgSetAck (value = 0x800120) is a message of generic use.
 */

#define QKerSpDbEnetCfgSetAck_Size     0

#define QKerSpDbEnetCfgSetAck 0x800120 /* 8388896 */
/* Kernel debugging command message */

/*
 * QModuleStartCmplt (value = 0x800121) is a message of generic use.
 */

#define QModuleStartCmplt_Size      0

#define QModuleStartCmplt  0x800121 /* 8388897 */
/* Command number/id    */

#define QKerDebugCmd_cmdId 0x300000 /* 3145728 */
typedef  UInt24   QKerDebugCmd_cmdId_t;
/* Id of the stream receiving trace results */

#define QKerDebugCmd_streamId 0x380003 /* 3670019 */
typedef  UInt32   QKerDebugCmd_streamId_t;
/* Number of components    */

#define QKerDebugCmd_count 0x200007 /* 2097159 */
typedef  UInt8 QKerDebugCmd_count_t;

#define QKerDebugCmd_varStart 0x8
/* parameter list    */

#define QKerDebugCmd_parm  0x100000 /* 1048576 */
typedef  Int24 QKerDebugCmd_parm_t;

/*
 * QKerDebugCmd (value = 0x800122) is an input message of generic use.
 */


typedef struct {
   UInt24   cmdId;
   UInt32   streamId;
   UInt8 count;
} QKerDebugCmd_t;

#define QKerDebugCmd_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerDebugCmd_cmdId), &((structAddr)->cmdId),   \
         (QKerDebugCmd_streamId), &((structAddr)->streamId),   \
         (QKerDebugCmd_count), &((structAddr)->count))


#define QKerDebugCmd_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerDebugCmd_cmdId), &((structAddr)->cmdId),   \
         (QKerDebugCmd_streamId), &((structAddr)->streamId),   \
         (QKerDebugCmd_count), &((structAddr)->count))


#define QKerDebugCmd_Size     8

#define QKerDebugCmd 0x800122 /* 8388898 */
/* Message to set the Trace Level for a specific processor */

#define QTraceLevel_level  0x300000 /* 3145728 */
typedef  UInt24   QTraceLevel_level_t;

#define QTraceLevel_processor 0x300003 /* 3145731 */
typedef  UInt24   QTraceLevel_processor_t;

/*
 * QTraceLevel (value = 0x800123) is a message of generic use.
 */


typedef struct {
   UInt24   level;
   UInt24   processor;
} QTraceLevel_t;

#define QTraceLevel_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTraceLevel_level), &((structAddr)->level), \
         (QTraceLevel_processor), &((structAddr)->processor))


#define QTraceLevel_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTraceLevel_level), &((structAddr)->level), \
         (QTraceLevel_processor), &((structAddr)->processor))


#define QTraceLevel_Size      6

#define QTraceLevel  0x800123 /* 8388899 */
/* Message to request that the Trace data for a specific processor be sent to
 * (dumped) to the host via the specified stream */

#define QTraceDump_processor  0x300000 /* 3145728 */
typedef  UInt24   QTraceDump_processor_t;

#define QTraceDump_stream  0x300003 /* 3145731 */
typedef  UInt24   QTraceDump_stream_t;

#define QTraceDump_mode 0x300006 /* 3145734 */
typedef  UInt24   QTraceDump_mode_t;

/*
 * QTraceDump (value = 0x800124) is a message of generic use.
 */


typedef struct {
   UInt24   processor;
   UInt24   stream;
   UInt24   mode;
} QTraceDump_t;

#define QTraceDump_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QTraceDump_processor), &((structAddr)->processor),   \
         (QTraceDump_stream), &((structAddr)->stream),   \
         (QTraceDump_mode), &((structAddr)->mode))


#define QTraceDump_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QTraceDump_processor), &((structAddr)->processor),   \
         (QTraceDump_stream), &((structAddr)->stream),   \
         (QTraceDump_mode), &((structAddr)->mode))


#define QTraceDump_Size    9

#define QTraceDump   0x800124 /* 8388900 */
/* Message is sent in response to a QTraceDump request. These messages are
 * sent on the stream specified by the QTraceDump message. */

#define QTraceMsg_version  0x200000 /* 2097152 */
typedef  UInt8 QTraceMsg_version_t;

#define QTraceMsg_nline 0x200001 /* 2097153 */
typedef  UInt8 QTraceMsg_nline_t;

#define QTraceMsg_buf   0x527802 /* 5404674 */
typedef  Char  QTraceMsg_buf_t[80];

#define QTraceMsg_level 0x300052 /* 3145810 */
typedef  UInt24   QTraceMsg_level_t;

#define QTraceMsg_tickvalue   0x300055 /* 3145813 */
typedef  UInt24   QTraceMsg_tickvalue_t;

/*
 * QTraceMsg (value = 0x800125) is a message of generic use.
 */


typedef struct {
   UInt8 version;
   UInt8 nline;
   Char  buf[80];
   UInt24   level;
   UInt24   tickvalue;
} QTraceMsg_t;

#define QTraceMsg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QTraceMsg_version), &((structAddr)->version),  \
         (QTraceMsg_nline), &((structAddr)->nline),   \
         (QTraceMsg_buf), &((structAddr)->buf), \
         (QTraceMsg_level), &((structAddr)->level),   \
         (QTraceMsg_tickvalue), &((structAddr)->tickvalue))


#define QTraceMsg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QTraceMsg_version), &((structAddr)->version),  \
         (QTraceMsg_nline), &((structAddr)->nline),   \
         (QTraceMsg_buf), &((structAddr)->buf), \
         (QTraceMsg_level), &((structAddr)->level),   \
         (QTraceMsg_tickvalue), &((structAddr)->tickvalue))


#define QTraceMsg_Size     88

#define QTraceMsg 0x800125 /* 8388901 */
#define QTraceMsgVerNum    1
/* QTBCCmdQueryCap is now contained in mercdefs. */
/* QTBCRspCap is now contained in mercdefs. */
/* Message to set a board's master mode. */

#define QTBCCmdMaster_BusNumber  0x380000 /* 3670016 */
typedef  UInt32   QTBCCmdMaster_BusNumber_t;

#define QTBCCmdMaster_MasterState   0x380004 /* 3670020 */
typedef  UInt32   QTBCCmdMaster_MasterState_t;

#define QTBCCmdMaster_MasterBusSelect  0x380008 /* 3670024 */
typedef  UInt32   QTBCCmdMaster_MasterBusSelect_t;

#define QTBCCmdMaster_RefBusPin  0x38000c /* 3670028 */
typedef  UInt32   QTBCCmdMaster_RefBusPin_t;

#define QTBCCmdMaster_RefClkSpeed   0x380010 /* 3670032 */
typedef  UInt32   QTBCCmdMaster_RefClkSpeed_t;

/*
 * QTBCCmdMaster (value = 0x800128) is a message of generic use.
 */


typedef struct {
   UInt32   BusNumber;
   UInt32   MasterState;
   UInt32   MasterBusSelect;
   UInt32   RefBusPin;
   UInt32   RefClkSpeed;
} QTBCCmdMaster_t;

#define QTBCCmdMaster_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QTBCCmdMaster_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdMaster_MasterState), &((structAddr)->MasterState),  \
         (QTBCCmdMaster_MasterBusSelect), &((structAddr)->MasterBusSelect),   \
         (QTBCCmdMaster_RefBusPin), &((structAddr)->RefBusPin),   \
         (QTBCCmdMaster_RefClkSpeed), &((structAddr)->RefClkSpeed))


#define QTBCCmdMaster_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QTBCCmdMaster_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdMaster_MasterState), &((structAddr)->MasterState),  \
         (QTBCCmdMaster_MasterBusSelect), &((structAddr)->MasterBusSelect),   \
         (QTBCCmdMaster_RefBusPin), &((structAddr)->RefBusPin),   \
         (QTBCCmdMaster_RefClkSpeed), &((structAddr)->RefClkSpeed))


#define QTBCCmdMaster_Size    20

#define QTBCCmdMaster   0x800128 /* 8388904 */
#define TBC_MASTER_STATE_PRIMARY    1
#define TBC_MASTER_STATE_PRIMARY_NORMAL      0x0001
#define TBC_MASTER_STATE_PRIMARY_HOLDOVER 0x0201
#define TBC_MASTER_STATE_PRIMARY_FREE_RUN 0x0301
#define TBC_MASTER_STATE_PRIMARY_AUTO_HOLDOVER  0x0601
#define TBC_MASTER_STATE_PRIMARY_AUTO_FREE_RUN  0x0701
#define TBC_MASTER_STATE_SECONDARY     2
#define TBC_MASTER_STATE_SECONDARY_NORMAL    0x0002
#define TBC_MASTER_STATE_SECONDARY_HOLDOVER     0x0202
#define TBC_MASTER_STATE_SECONDARY_FREE_RUN     0x0302
#define TBC_MASTER_STATE_SECONDARY_AUTO_HOLDOVER   0x0602
#define TBC_MASTER_STATE_SECONDARY_AUTO_FREE_RUN   0x0702
#define TBC_MASTER_STATE_SLAVE      0
#define TBC_MASTER_BUS_SELECT_CT_A     0
#define TBC_MASTER_BUS_SELECT_CT_B     1
#define TBC_MASTER_BUS_SELECT_SC_NRM   0
#define TBC_MASTER_BUS_SELECT_SC_ALT   1
#define TBC_REFPIN_NETREF1       6
#define TBC_REFPIN_NETREF2       7
#define TBC_REFPIN_SREF8k        3
#define TBC_REFPIN_SREF8kA       -1
#define TBC_REFPIN_INTERNAL         0
/* Message to confiugre the TDM Bus. */

#define QTBCCmdTDMBusConfig_BusNumber  0x380000 /* 3670016 */
typedef  UInt32   QTBCCmdTDMBusConfig_BusNumber_t;

#define QTBCCmdTDMBusConfig_BusType 0x380004 /* 3670020 */
typedef  UInt32   QTBCCmdTDMBusConfig_BusType_t;

#define QTBCCmdTDMBusConfig_DiagMode   0x380008 /* 3670024 */
typedef  UInt32   QTBCCmdTDMBusConfig_DiagMode_t;

#define QTBCCmdTDMBusConfig_SCBusSpeed 0x38000c /* 3670028 */
typedef  UInt32   QTBCCmdTDMBusConfig_SCBusSpeed_t;

#define QTBCCmdTDMBusConfig_Group1Speed   0x380010 /* 3670032 */
typedef  UInt32   QTBCCmdTDMBusConfig_Group1Speed_t;

#define QTBCCmdTDMBusConfig_Group2Speed   0x380014 /* 3670036 */
typedef  UInt32   QTBCCmdTDMBusConfig_Group2Speed_t;

#define QTBCCmdTDMBusConfig_Group3Speed   0x380018 /* 3670040 */
typedef  UInt32   QTBCCmdTDMBusConfig_Group3Speed_t;

#define QTBCCmdTDMBusConfig_Group4Speed   0x38001c /* 3670044 */
typedef  UInt32   QTBCCmdTDMBusConfig_Group4Speed_t;

/*
 * QTBCCmdTDMBusConfig (value = 0x800129) is a message of generic use.
 */


typedef struct {
   UInt32   BusNumber;
   UInt32   BusType;
   UInt32   DiagMode;
   UInt32   SCBusSpeed;
   UInt32   Group1Speed;
   UInt32   Group2Speed;
   UInt32   Group3Speed;
   UInt32   Group4Speed;
} QTBCCmdTDMBusConfig_t;

#define QTBCCmdTDMBusConfig_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 8, &(offset),  \
         (QTBCCmdTDMBusConfig_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdTDMBusConfig_BusType), &((structAddr)->BusType), \
         (QTBCCmdTDMBusConfig_DiagMode), &((structAddr)->DiagMode),  \
         (QTBCCmdTDMBusConfig_SCBusSpeed), &((structAddr)->SCBusSpeed), \
         (QTBCCmdTDMBusConfig_Group1Speed), &((structAddr)->Group1Speed),  \
         (QTBCCmdTDMBusConfig_Group2Speed), &((structAddr)->Group2Speed),  \
         (QTBCCmdTDMBusConfig_Group3Speed), &((structAddr)->Group3Speed),  \
         (QTBCCmdTDMBusConfig_Group4Speed), &((structAddr)->Group4Speed))


#define QTBCCmdTDMBusConfig_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 8, &(offset),  \
         (QTBCCmdTDMBusConfig_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdTDMBusConfig_BusType), &((structAddr)->BusType), \
         (QTBCCmdTDMBusConfig_DiagMode), &((structAddr)->DiagMode),  \
         (QTBCCmdTDMBusConfig_SCBusSpeed), &((structAddr)->SCBusSpeed), \
         (QTBCCmdTDMBusConfig_Group1Speed), &((structAddr)->Group1Speed),  \
         (QTBCCmdTDMBusConfig_Group2Speed), &((structAddr)->Group2Speed),  \
         (QTBCCmdTDMBusConfig_Group3Speed), &((structAddr)->Group3Speed),  \
         (QTBCCmdTDMBusConfig_Group4Speed), &((structAddr)->Group4Speed))


#define QTBCCmdTDMBusConfig_Size    32

#define QTBCCmdTDMBusConfig   0x800129 /* 8388905 */
#define TBC_BUS_TYPE_H100        1
#define TBC_BUS_TYPE_H110        2
#define TBC_BUS_TYPE_SC       3
#define TBC_DIAG_MODE_ENABLE        SH_ENABLED
#define TBC_DIAG_MODE_DISABLE    SH_DISABLED
#define TBC_BUS_SPEED_2MHz       2
#define TBC_BUS_SPEED_4MHz       4
#define TBC_BUS_SPEED_8MHz       8
/* Message to Output (or stop outputting) clockref. */

#define QTBCCmdOutputClkref_BusNumber  0x380000 /* 3670016 */
typedef  UInt32   QTBCCmdOutputClkref_BusNumber_t;

#define QTBCCmdOutputClkref_ClkrefSource  0x380004 /* 3670020 */
typedef  UInt32   QTBCCmdOutputClkref_ClkrefSource_t;

#define QTBCCmdOutputClkref_ClkrefSpeed   0x380008 /* 3670024 */
typedef  UInt32   QTBCCmdOutputClkref_ClkrefSpeed_t;

/*
 * QTBCCmdOutputClkref (value = 0x80012a) is a message of generic use.
 */


typedef struct {
   UInt32   BusNumber;
   UInt32   ClkrefSource;
   UInt32   ClkrefSpeed;
} QTBCCmdOutputClkref_t;

#define QTBCCmdOutputClkref_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QTBCCmdOutputClkref_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdOutputClkref_ClkrefSource), &((structAddr)->ClkrefSource),   \
         (QTBCCmdOutputClkref_ClkrefSpeed), &((structAddr)->ClkrefSpeed))


#define QTBCCmdOutputClkref_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QTBCCmdOutputClkref_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCCmdOutputClkref_ClkrefSource), &((structAddr)->ClkrefSource),   \
         (QTBCCmdOutputClkref_ClkrefSpeed), &((structAddr)->ClkrefSpeed))


#define QTBCCmdOutputClkref_Size    12

#define QTBCCmdOutputClkref   0x80012a /* 8388906 */
#define TBC_CLKSRC_NID_1         8
#define TBC_CLKSRC_NID_2         9
#define TBC_CLKSRC_NID_3         10
#define TBC_CLKSRC_NID_4         11
#define TBC_CLKSRC_DISABLE                          -1
/* Message to enable alarm events. */

#define QTBCCmdAlarmEventsEnable_BusNumber   0x380000 /* 3670016 */
typedef  UInt32   QTBCCmdAlarmEventsEnable_BusNumber_t;

#define QTBCCmdAlarmEventsEnable_AlarmEvents 0x380004 /* 3670020 */
typedef  UInt32   QTBCCmdAlarmEventsEnable_AlarmEvents_t;

#define QTBCCmdAlarmEventsEnable_Mask  0x380008 /* 3670024 */
typedef  UInt32   QTBCCmdAlarmEventsEnable_Mask_t;

#define QTBCCmdAlarmEventsEnable_AlarmRetAddr   0x80000c /* 8388620 */
typedef  QCompDesc   QTBCCmdAlarmEventsEnable_AlarmRetAddr_t;

/*
 * QTBCCmdAlarmEventsEnable (value = 0x80012b) is a message of generic use.
 */


typedef struct {
   UInt32   BusNumber;
   UInt32   AlarmEvents;
   UInt32   Mask;
   QCompDesc   AlarmRetAddr;
} QTBCCmdAlarmEventsEnable_t;

#define QTBCCmdAlarmEventsEnable_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 4, &(offset),  \
         (QTBCCmdAlarmEventsEnable_BusNumber), &((structAddr)->BusNumber), \
         (QTBCCmdAlarmEventsEnable_AlarmEvents), &((structAddr)->AlarmEvents),   \
         (QTBCCmdAlarmEventsEnable_Mask), &((structAddr)->Mask),  \
         (QTBCCmdAlarmEventsEnable_AlarmRetAddr), &((structAddr)->AlarmRetAddr))


#define QTBCCmdAlarmEventsEnable_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 4, &(offset),  \
         (QTBCCmdAlarmEventsEnable_BusNumber), &((structAddr)->BusNumber), \
         (QTBCCmdAlarmEventsEnable_AlarmEvents), &((structAddr)->AlarmEvents),   \
         (QTBCCmdAlarmEventsEnable_Mask), &((structAddr)->Mask),  \
         (QTBCCmdAlarmEventsEnable_AlarmRetAddr), &((structAddr)->AlarmRetAddr))


#define QTBCCmdAlarmEventsEnable_Size     18

#define QTBCCmdAlarmEventsEnable 0x80012b /* 8388907 */
#define TBC_ALARM_EVENT_CT_BUS_A    1
#define TBC_ALARM_EVENT_CT_BUS_B    2
#define TBC_ALARM_EVENT_SC_BUS      4
#define TBC_ALARM_EVENT_MVIP_BUS    8
#define TBC_ALARM_EVENT_MASTER_PLL     16
#define TBC_ALARM_EVENT_SREF8K_LOSS 32
#define TBC_ALARM_EVENT_NETREF1_LOSS   64
#define TBC_ALARM_EVENT_NETREF2_LOSS   128
/* Message reports that Alarm Events have changed. */

#define QTBCRspAlarmEventsChng_BusNumber  0x380000 /* 3670016 */
typedef  UInt32   QTBCRspAlarmEventsChng_BusNumber_t;

#define QTBCRspAlarmEventsChng_AlarmEventsStatus   0x380004 /* 3670020 */
typedef  UInt32   QTBCRspAlarmEventsChng_AlarmEventsStatus_t;

/*
 * QTBCRspAlarmEventsChng (value = 0x80012c) is a message of generic use.
 */


typedef struct {
   UInt32   BusNumber;
   UInt32   AlarmEventsStatus;
} QTBCRspAlarmEventsChng_t;

#define QTBCRspAlarmEventsChng_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspAlarmEventsChng_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCRspAlarmEventsChng_AlarmEventsStatus), &((structAddr)->AlarmEventsStatus))


#define QTBCRspAlarmEventsChng_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspAlarmEventsChng_BusNumber), &((structAddr)->BusNumber),   \
         (QTBCRspAlarmEventsChng_AlarmEventsStatus), &((structAddr)->AlarmEventsStatus))


#define QTBCRspAlarmEventsChng_Size    8

#define QTBCRspAlarmEventsChng   0x80012c /* 8388908 */
/* QTBCCmdQueryStatus is now contained in mercdefs. */
/* QTBCRspStatus is now contained in mercdefs. */
/* Messages to acknowledge commands. */

#define QTBCRspMaster_ReturnCode 0x380000 /* 3670016 */
typedef  UInt32   QTBCRspMaster_ReturnCode_t;

#define QTBCRspMaster_ErrorCode  0x380004 /* 3670020 */
typedef  UInt32   QTBCRspMaster_ErrorCode_t;

/*
 * QTBCRspMaster (value = 0x80012f) is a message of generic use.
 */


typedef struct {
   UInt32   ReturnCode;
   UInt32   ErrorCode;
} QTBCRspMaster_t;

#define QTBCRspMaster_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspMaster_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspMaster_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspMaster_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspMaster_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspMaster_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspMaster_Size    8

#define QTBCRspMaster   0x80012f /* 8388911 */

#define QTBCRspTDMBusConfig_ReturnCode 0x380000 /* 3670016 */
typedef  UInt32   QTBCRspTDMBusConfig_ReturnCode_t;

#define QTBCRspTDMBusConfig_ErrorCode  0x380004 /* 3670020 */
typedef  UInt32   QTBCRspTDMBusConfig_ErrorCode_t;

/*
 * QTBCRspTDMBusConfig (value = 0x800130) is a message of generic use.
 */


typedef struct {
   UInt32   ReturnCode;
   UInt32   ErrorCode;
} QTBCRspTDMBusConfig_t;

#define QTBCRspTDMBusConfig_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspTDMBusConfig_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspTDMBusConfig_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspTDMBusConfig_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspTDMBusConfig_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspTDMBusConfig_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspTDMBusConfig_Size    8

#define QTBCRspTDMBusConfig   0x800130 /* 8388912 */

#define QTBCRspOutputClkref_ReturnCode 0x380000 /* 3670016 */
typedef  UInt32   QTBCRspOutputClkref_ReturnCode_t;

#define QTBCRspOutputClkref_ErrorCode  0x380004 /* 3670020 */
typedef  UInt32   QTBCRspOutputClkref_ErrorCode_t;

/*
 * QTBCRspOutputClkref (value = 0x800131) is a message of generic use.
 */


typedef struct {
   UInt32   ReturnCode;
   UInt32   ErrorCode;
} QTBCRspOutputClkref_t;

#define QTBCRspOutputClkref_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspOutputClkref_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspOutputClkref_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspOutputClkref_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspOutputClkref_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspOutputClkref_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspOutputClkref_Size    8

#define QTBCRspOutputClkref   0x800131 /* 8388913 */

#define QTBCRspAlarmEventsEnable_ReturnCode  0x380000 /* 3670016 */
typedef  UInt32   QTBCRspAlarmEventsEnable_ReturnCode_t;

#define QTBCRspAlarmEventsEnable_ErrorCode   0x380004 /* 3670020 */
typedef  UInt32   QTBCRspAlarmEventsEnable_ErrorCode_t;

/*
 * QTBCRspAlarmEventsEnable (value = 0x800132) is a message of generic use.
 */


typedef struct {
   UInt32   ReturnCode;
   UInt32   ErrorCode;
} QTBCRspAlarmEventsEnable_t;

#define QTBCRspAlarmEventsEnable_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspAlarmEventsEnable_ReturnCode), &((structAddr)->ReturnCode),  \
         (QTBCRspAlarmEventsEnable_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspAlarmEventsEnable_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspAlarmEventsEnable_ReturnCode), &((structAddr)->ReturnCode),  \
         (QTBCRspAlarmEventsEnable_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspAlarmEventsEnable_Size     8

#define QTBCRspAlarmEventsEnable 0x800132 /* 8388914 */
/*SP Board Configurable Information Structures Transfer Message*/

#define QKerSPBoardCfgSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QKerSPBoardCfgSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/*SP Board Initialization Information Structure Transfer Message*/

/*
 * QKerSPBoardCfgSet (value = 0xc00134) is a message of generic use.
 */

#define QKerSPBoardCfgSet_Size      0

#define QKerSPBoardCfgSet  0xc00134 /* 12583220 */

#define QKerBoardInitSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QKerBoardInitSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/*Kernel ID Information Structure Transfer Message*/

/*
 * QKerBoardInitSet (value = 0xc00135) is a message of generic use.
 */

#define QKerBoardInitSet_Size    0

#define QKerBoardInitSet   0xc00135 /* 12583221 */

#define QKerIDSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QKerIDSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/*SP Hardware Configuration Information Messages Transfer Message*/

/*
 * QKerIDSet (value = 0xc00136) is a message of generic use.
 */

#define QKerIDSet_Size     0

#define QKerIDSet 0xc00136 /* 12583222 */

#define QSPHwCfgSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QSPHwCfgSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/* Request external box firmware version string */

/*
 * QSPHwCfgSet (value = 0xc00137) is a message of generic use.
 */

#define QSPHwCfgSet_Size      0

#define QSPHwCfgSet  0xc00137 /* 12583223 */
/* Reply message to QKerExternalVersionGet */

/*
 * QKerExternalVersionGet (value = 0x800133) is a message of generic use.
 */

#define QKerExternalVersionGet_Size    0

#define QKerExternalVersionGet   0x800133 /* 8388915 */

#define QKerExternalVersionResult_firmwareVersion  0x507000 /* 5271552 */
typedef  Char  QKerExternalVersionResult_firmwareVersion_t[15];

#define QKerExternalVersionResult_protocolVersion  0x30000f /* 3145743 */
typedef  UInt24   QKerExternalVersionResult_protocolVersion_t;

#define QKerExternalVersionResult_reserved1  0x300012 /* 3145746 */
typedef  UInt24   QKerExternalVersionResult_reserved1_t;

#define QKerExternalVersionResult_reserved2  0x300015 /* 3145749 */
typedef  UInt24   QKerExternalVersionResult_reserved2_t;

#define QKerExternalVersionResult_reserved3  0x300018 /* 3145752 */
typedef  UInt24   QKerExternalVersionResult_reserved3_t;

/*
 * QKerExternalVersionResult (value = 0x800134) is a message of generic use.
 */


typedef struct {
   Char  firmwareVersion[15];
   UInt24   protocolVersion;
   UInt24   reserved1;
   UInt24   reserved2;
   UInt24   reserved3;
} QKerExternalVersionResult_t;

#define QKerExternalVersionResult_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKerExternalVersionResult_firmwareVersion), &((structAddr)->firmwareVersion),   \
         (QKerExternalVersionResult_protocolVersion), &((structAddr)->protocolVersion),   \
         (QKerExternalVersionResult_reserved1), &((structAddr)->reserved1),   \
         (QKerExternalVersionResult_reserved2), &((structAddr)->reserved2),   \
         (QKerExternalVersionResult_reserved3), &((structAddr)->reserved3))


#define QKerExternalVersionResult_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKerExternalVersionResult_firmwareVersion), &((structAddr)->firmwareVersion),   \
         (QKerExternalVersionResult_protocolVersion), &((structAddr)->protocolVersion),   \
         (QKerExternalVersionResult_reserved1), &((structAddr)->reserved1),   \
         (QKerExternalVersionResult_reserved2), &((structAddr)->reserved2),   \
         (QKerExternalVersionResult_reserved3), &((structAddr)->reserved3))


#define QKerExternalVersionResult_Size    27

#define QKerExternalVersionResult   0x800134 /* 8388916 */
/* The current protocol version is 1. */
#define QPROTOCOL_VERSION_1 1
/*SP Hardware Configuration Information Messages Transfer Message*/

#define QKerSPInstWidthCfgSet_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QKerSPInstWidthCfgSet_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)


/*
 * QKerSPInstWidthCfgSet (value = 0xc00139) is a message of generic use.
 */

#define QKerSPInstWidthCfgSet_Size     0

#define QKerSPInstWidthCfgSet 0xc00139 /* 12583225 */

#define QKerInstWidthOfCP_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QKerInstWidthOfCP_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/* Message to set the TDM Bus law. */

/*
 * QKerInstWidthOfCP (value = 0xc0013a) is a message of generic use.
 */

#define QKerInstWidthOfCP_Size      0

#define QKerInstWidthOfCP  0xc0013a /* 12583226 */

#define QTBCCmdTDMBusLawSet_BusLaw  0x380000 /* 3670016 */
typedef  UInt32   QTBCCmdTDMBusLawSet_BusLaw_t;

/*
 * QTBCCmdTDMBusLawSet (value = 0x800135) is a message of generic use.
 */


typedef struct {
   UInt32   BusLaw;
} QTBCCmdTDMBusLawSet_t;

#define QTBCCmdTDMBusLawSet_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QTBCCmdTDMBusLawSet_BusLaw), &((structAddr)->BusLaw))


#define QTBCCmdTDMBusLawSet_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QTBCCmdTDMBusLawSet_BusLaw), &((structAddr)->BusLaw))


#define QTBCCmdTDMBusLawSet_Size    4

#define QTBCCmdTDMBusLawSet   0x800135 /* 8388917 */
#define TBC_BUS_LAW_MU     1
#define TBC_BUS_LAW_A      2
/* Message to acknowledge QTBCCmdTDMBusLawSet command. */

#define QTBCRspTDMBusLawSet_ReturnCode 0x380000 /* 3670016 */
typedef  UInt32   QTBCRspTDMBusLawSet_ReturnCode_t;

#define QTBCRspTDMBusLawSet_ErrorCode  0x380004 /* 3670020 */
typedef  UInt32   QTBCRspTDMBusLawSet_ErrorCode_t;

/*
 * QTBCRspTDMBusLawSet (value = 0x800136) is a message of generic use.
 */


typedef struct {
   UInt32   ReturnCode;
   UInt32   ErrorCode;
} QTBCRspTDMBusLawSet_t;

#define QTBCRspTDMBusLawSet_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QTBCRspTDMBusLawSet_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspTDMBusLawSet_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspTDMBusLawSet_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QTBCRspTDMBusLawSet_ReturnCode), &((structAddr)->ReturnCode), \
         (QTBCRspTDMBusLawSet_ErrorCode), &((structAddr)->ErrorCode))


#define QTBCRspTDMBusLawSet_Size    8

#define QTBCRspTDMBusLawSet   0x800136 /* 8388918 */
/* Message to CP Kernel from the host signifying download completion  */

#define QKerDownloadComplete_reserved  0x380000 /* 3670016 */
typedef  UInt32   QKerDownloadComplete_reserved_t;

/*
 * QKerDownloadComplete (value = 0x800137) is a message of generic use.
 */


typedef struct {
   UInt32   reserved;
} QKerDownloadComplete_t;

#define QKerDownloadComplete_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKerDownloadComplete_reserved), &((structAddr)->reserved))


#define QKerDownloadComplete_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKerDownloadComplete_reserved), &((structAddr)->reserved))


#define QKerDownloadComplete_Size      4

#define QKerDownloadComplete  0x800137 /* 8388919 */
/*This is a generic message which is sent to the Boot Kernel. The first field
 * within this message actually identifies the message.. */

#define QBootKerMailBoxMsg_bootMsgType 0x300000 /* 3145728 */
typedef  UInt24   QBootKerMailBoxMsg_bootMsgType_t;

#define QBootKerMailBoxMsg_varStart 0x3

#define QBootKerMailBoxMsg_qLicenseKey_version  0x280000 /* 2621440 */
typedef  UInt16   QBootKerMailBoxMsg_qLicenseKey_version_t;

#define QBootKerMailBoxMsg_qLicenseKey_keylength   0x280000 /* 2621440 */
typedef  UInt16   QBootKerMailBoxMsg_qLicenseKey_keylength_t;


typedef struct {
   UInt16   version;
   UInt16   keylength;
} QBootKerMailBoxMsg_qLicenseKey_t;

#define QBootKerMailBoxMsg_qLicenseKey_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QBootKerMailBoxMsg_qLicenseKey_version), &((structAddr)->version),  \
         (QBootKerMailBoxMsg_qLicenseKey_keylength), &((structAddr)->keylength))


#define QBootKerMailBoxMsg_qLicenseKey_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QBootKerMailBoxMsg_qLicenseKey_version), &((structAddr)->version),  \
         (QBootKerMailBoxMsg_qLicenseKey_keylength), &((structAddr)->keylength))


#define QBootKerMailBoxMsg_qLicenseKey_Size     4

#define QBootKerMailBoxMsg_qLicenseKey 0x22  /* 34 */

/*
 * QBootKerMailBoxMsg (value = 0x80013a) is a message of generic use.
 */


typedef struct {
   UInt24   bootMsgType;
} QBootKerMailBoxMsg_t;

#define QBootKerMailBoxMsg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QBootKerMailBoxMsg_bootMsgType), &((structAddr)->bootMsgType))


#define QBootKerMailBoxMsg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QBootKerMailBoxMsg_bootMsgType), &((structAddr)->bootMsgType))


#define QBootKerMailBoxMsg_Size     3

#define QBootKerMailBoxMsg 0x80013a /* 8388922 */
#define QLicenseKeySet     0x000001
#define QBootKerMailBoxMsg_qlicenseKey_licenseKeyType 0x200000
/* Acknowledgement for the Boot Kernel Mail Box Msg */

#define QBootKerMailBoxMsgAck_bootMsgType 0x300000 /* 3145728 */
typedef  UInt24   QBootKerMailBoxMsgAck_bootMsgType_t;

/*
 * QBootKerMailBoxMsgAck (value = 0x800138) is a message of generic use.
 */


typedef struct {
   UInt24   bootMsgType;
} QBootKerMailBoxMsgAck_t;

#define QBootKerMailBoxMsgAck_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QBootKerMailBoxMsgAck_bootMsgType), &((structAddr)->bootMsgType))


#define QBootKerMailBoxMsgAck_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QBootKerMailBoxMsgAck_bootMsgType), &((structAddr)->bootMsgType))


#define QBootKerMailBoxMsgAck_Size     3

#define QBootKerMailBoxMsgAck 0x800138 /* 8388920 */
#define QLicenseKeySetAck     0x000001
/* Message from the Host Memory Host Interface Boot kernel to Host Memory Host
 * Interface RTK */

#define QKerHostMemMailBoxMsg_type  0x380000 /* 3670016 */
typedef  UInt32   QKerHostMemMailBoxMsg_type_t;

#define QKerHostMemMailBoxMsg_data  0x387804 /* 3700740 */
typedef  UInt32   QKerHostMemMailBoxMsg_data_t[16];

/*
 * QKerHostMemMailBoxMsg (value = 0x80013b) is a message of generic use.
 */


typedef struct {
   UInt32   type;
   UInt32   data[16];
} QKerHostMemMailBoxMsg_t;

#define QKerHostMemMailBoxMsg_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKerHostMemMailBoxMsg_type), &((structAddr)->type),  \
         (QKerHostMemMailBoxMsg_data), &((structAddr)->data))


#define QKerHostMemMailBoxMsg_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKerHostMemMailBoxMsg_type), &((structAddr)->type),  \
         (QKerHostMemMailBoxMsg_data), &((structAddr)->data))


#define QKerHostMemMailBoxMsg_Size     68

#define QKerHostMemMailBoxMsg 0x80013b /* 8388923 */
/* Message from Host Memory Host Interface used to send the messages to the
 * Host such as ACK etc. */

#define QKerHostMemHostMFMsg_type   0x380000 /* 3670016 */
typedef  UInt32   QKerHostMemHostMFMsg_type_t;

#define QKerHostMemHostMFMsg_data   0x382004 /* 3678212 */
typedef  UInt32   QKerHostMemHostMFMsg_data_t[5];

/*
 * QKerHostMemHostMFMsg (value = 0x800142) is a message of generic use.
 */


typedef struct {
   UInt32   type;
   UInt32   data[5];
} QKerHostMemHostMFMsg_t;

#define QKerHostMemHostMFMsg_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKerHostMemHostMFMsg_type), &((structAddr)->type),   \
         (QKerHostMemHostMFMsg_data), &((structAddr)->data))


#define QKerHostMemHostMFMsg_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKerHostMemHostMFMsg_type), &((structAddr)->type),   \
         (QKerHostMemHostMFMsg_data), &((structAddr)->data))


#define QKerHostMemHostMFMsg_Size      24

#define QKerHostMemHostMFMsg  0x800142 /* 8388930 */
/*C-Stream Transformation Table Reset Message*/

#define QCStreamXTableReset_count   0x200000 /* 2097152 */
typedef  UInt8 QCStreamXTableReset_count_t;

#define QCStreamXTableReset_varStart   0x1

#define QCStreamXTableReset_xtableentry_streamNum  0x200000 /* 2097152 */
typedef  UInt8 QCStreamXTableReset_xtableentry_streamNum_t;

#define QCStreamXTableReset_xtableentry_transVal   0x100000 /* 1048576 */
typedef  Int24 QCStreamXTableReset_xtableentry_transVal_t;

#define QCStreamXTableReset_xtableentry_recVal  0x100000 /* 1048576 */
typedef  Int24 QCStreamXTableReset_xtableentry_recVal_t;


typedef struct {
   UInt8 streamNum;
   Int24 transVal;
   Int24 recVal;
} QCStreamXTableReset_xtableentry_t;

#define QCStreamXTableReset_xtableentry_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QCStreamXTableReset_xtableentry_streamNum), &((structAddr)->streamNum),   \
         (QCStreamXTableReset_xtableentry_transVal), &((structAddr)->transVal),  \
         (QCStreamXTableReset_xtableentry_recVal), &((structAddr)->recVal))


#define QCStreamXTableReset_xtableentry_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QCStreamXTableReset_xtableentry_streamNum), &((structAddr)->streamNum),   \
         (QCStreamXTableReset_xtableentry_transVal), &((structAddr)->transVal),  \
         (QCStreamXTableReset_xtableentry_recVal), &((structAddr)->recVal))


#define QCStreamXTableReset_xtableentry_Size    7

#define QCStreamXTableReset_xtableentry   0x23  /* 35 */

/*
 * QCStreamXTableReset (value = 0x800143) is a message of generic use.
 */


typedef struct {
   UInt8 count;
} QCStreamXTableReset_t;

#define QCStreamXTableReset_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QCStreamXTableReset_count), &((structAddr)->count))


#define QCStreamXTableReset_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QCStreamXTableReset_count), &((structAddr)->count))


#define QCStreamXTableReset_Size    1

#define QCStreamXTableReset   0x800143 /* 8388931 */
/* Sent from Serial SP to tell CP to update Xtable and Geo */
/*This is a message which is sent to the boot kernel or run-time kernel to
 * retrieve the board ID */

/*
 * QClusterSerXGeo (value = 0x800144) is a message of generic use.
 */

#define QClusterSerXGeo_Size     0

#define QClusterSerXGeo 0x800144 /* 8388932 */

#define QKerLicenseKeyGet_time   0x380000 /* 3670016 */
typedef  UInt32   QKerLicenseKeyGet_time_t;

#define QKerLicenseKeyGet_reserved1 0x380004 /* 3670020 */
typedef  UInt32   QKerLicenseKeyGet_reserved1_t;

#define QKerLicenseKeyGet_reserved2 0x380008 /* 3670024 */
typedef  UInt32   QKerLicenseKeyGet_reserved2_t;

/*
 * QKerLicenseKeyGet (value = 0x800146) is a message of generic use.
 */


typedef struct {
   UInt32   time;
   UInt32   reserved1;
   UInt32   reserved2;
} QKerLicenseKeyGet_t;

#define QKerLicenseKeyGet_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKerLicenseKeyGet_time), &((structAddr)->time),   \
         (QKerLicenseKeyGet_reserved1), &((structAddr)->reserved1),  \
         (QKerLicenseKeyGet_reserved2), &((structAddr)->reserved2))


#define QKerLicenseKeyGet_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKerLicenseKeyGet_time), &((structAddr)->time),   \
         (QKerLicenseKeyGet_reserved1), &((structAddr)->reserved1),  \
         (QKerLicenseKeyGet_reserved2), &((structAddr)->reserved2))


#define QKerLicenseKeyGet_Size      12

#define QKerLicenseKeyGet  0x800146 /* 8388934 */
/*This is a message is sent to the host with the encrypted board ID */

#define QKerLicenseKeyResult_version   0x380000 /* 3670016 */
typedef  UInt32   QKerLicenseKeyResult_version_t;

#define QKerLicenseKeyResult_blocksize 0x380004 /* 3670020 */
typedef  UInt32   QKerLicenseKeyResult_blocksize_t;

#define QKerLicenseKeyResult_reserved1 0x380008 /* 3670024 */
typedef  UInt32   QKerLicenseKeyResult_reserved1_t;

#define QKerLicenseKeyResult_reserved2 0x38000c /* 3670028 */
typedef  UInt32   QKerLicenseKeyResult_reserved2_t;

#define QKerLicenseKeyResult_key 0x3bf810 /* 3930128 */
typedef  UInt32   QKerLicenseKeyResult_key_t[128];

/*
 * QKerLicenseKeyResult (value = 0x800147) is a message of generic use.
 */


typedef struct {
   UInt32   version;
   UInt32   blocksize;
   UInt32   reserved1;
   UInt32   reserved2;
   UInt32   key[128];
} QKerLicenseKeyResult_t;

#define QKerLicenseKeyResult_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKerLicenseKeyResult_version), &((structAddr)->version),   \
         (QKerLicenseKeyResult_blocksize), &((structAddr)->blocksize),  \
         (QKerLicenseKeyResult_reserved1), &((structAddr)->reserved1),  \
         (QKerLicenseKeyResult_reserved2), &((structAddr)->reserved2),  \
         (QKerLicenseKeyResult_key), &((structAddr)->key))


#define QKerLicenseKeyResult_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKerLicenseKeyResult_version), &((structAddr)->version),   \
         (QKerLicenseKeyResult_blocksize), &((structAddr)->blocksize),  \
         (QKerLicenseKeyResult_reserved1), &((structAddr)->reserved1),  \
         (QKerLicenseKeyResult_reserved2), &((structAddr)->reserved2),  \
         (QKerLicenseKeyResult_key), &((structAddr)->key))


#define QKerLicenseKeyResult_Size      528

#define QKerLicenseKeyResult  0x800147 /* 8388935 */
/*C-Stream Configuration Set Message*/

#define QCStreamConfig_get(msgPtr, structAddr, size) \
memcpy(structAddr, (*msgPtr).data, size)


#define QCStreamConfig_put(msgPtr, structAddr, size) \
memcpy((*msgPtr).data, structAddr, size)

/* Message from Host to open stream. Used only for HMP Linux. */

/*
 * QCStreamConfig (value = 0xc0013b) is a message of generic use.
 */

#define QCStreamConfig_Size      0

#define QCStreamConfig  0xc0013b /* 12583227 */

#define QKER_OPEN_STREAM_streamId   0x280000 /* 2621440 */
typedef  UInt16   QKER_OPEN_STREAM_streamId_t;

#define QKER_OPEN_STREAM_mode 0x280002 /* 2621442 */
typedef  UInt16   QKER_OPEN_STREAM_mode_t;

#define QKER_OPEN_STREAM_requestSize   0x380004 /* 3670020 */
typedef  UInt32   QKER_OPEN_STREAM_requestSize_t;

#define QKER_OPEN_STREAM_canTakeLimit  0x380008 /* 3670024 */
typedef  UInt32   QKER_OPEN_STREAM_canTakeLimit_t;

#define QKER_OPEN_STREAM_sourceDesc 0x80000c /* 8388620 */
typedef  QCompDesc   QKER_OPEN_STREAM_sourceDesc_t;

/*
 * QKER_OPEN_STREAM (value = 0xc0000d) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
   UInt16   mode;
   UInt32   requestSize;
   UInt32   canTakeLimit;
   QCompDesc   sourceDesc;
} QKER_OPEN_STREAM_t;

#define QKER_OPEN_STREAM_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 5, &(offset),  \
         (QKER_OPEN_STREAM_streamId), &((structAddr)->streamId),  \
         (QKER_OPEN_STREAM_mode), &((structAddr)->mode), \
         (QKER_OPEN_STREAM_requestSize), &((structAddr)->requestSize),  \
         (QKER_OPEN_STREAM_canTakeLimit), &((structAddr)->canTakeLimit),   \
         (QKER_OPEN_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_OPEN_STREAM_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 5, &(offset),  \
         (QKER_OPEN_STREAM_streamId), &((structAddr)->streamId),  \
         (QKER_OPEN_STREAM_mode), &((structAddr)->mode), \
         (QKER_OPEN_STREAM_requestSize), &((structAddr)->requestSize),  \
         (QKER_OPEN_STREAM_canTakeLimit), &((structAddr)->canTakeLimit),   \
         (QKER_OPEN_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_OPEN_STREAM_Size    18

#define QKER_OPEN_STREAM   0xc0000d /* 12582925 */
/* Open Stream Reply only on HMP Linux */

#define QKER_OPEN_STR_ACK_streamId  0x280000 /* 2621440 */
typedef  UInt16   QKER_OPEN_STR_ACK_streamId_t;

#define QKER_OPEN_STR_ACK_actualSize   0x280002 /* 2621442 */
typedef  UInt16   QKER_OPEN_STR_ACK_actualSize_t;

#define QKER_OPEN_STR_ACK_initialCanTake  0x280004 /* 2621444 */
typedef  UInt16   QKER_OPEN_STR_ACK_initialCanTake_t;

#define QKER_OPEN_STR_ACK_transactionId   0x380006 /* 3670022 */
typedef  UInt32   QKER_OPEN_STR_ACK_transactionId_t;

/*
 * QKER_OPEN_STR_ACK (value = 0xc0000e) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
   UInt16   actualSize;
   UInt16   initialCanTake;
   UInt32   transactionId;
} QKER_OPEN_STR_ACK_t;

#define QKER_OPEN_STR_ACK_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 4, &(offset),  \
         (QKER_OPEN_STR_ACK_streamId), &((structAddr)->streamId), \
         (QKER_OPEN_STR_ACK_actualSize), &((structAddr)->actualSize),   \
         (QKER_OPEN_STR_ACK_initialCanTake), &((structAddr)->initialCanTake), \
         (QKER_OPEN_STR_ACK_transactionId), &((structAddr)->transactionId))


#define QKER_OPEN_STR_ACK_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 4, &(offset),  \
         (QKER_OPEN_STR_ACK_streamId), &((structAddr)->streamId), \
         (QKER_OPEN_STR_ACK_actualSize), &((structAddr)->actualSize),   \
         (QKER_OPEN_STR_ACK_initialCanTake), &((structAddr)->initialCanTake), \
         (QKER_OPEN_STR_ACK_transactionId), &((structAddr)->transactionId))


#define QKER_OPEN_STR_ACK_Size      10

#define QKER_OPEN_STR_ACK  0xc0000e /* 12582926 */
/* Message from the host to close a specific stream. This is only used for HMP
 * Linux */

#define QKER_CLOSE_STREAM_streamId  0x280000 /* 2621440 */
typedef  UInt16   QKER_CLOSE_STREAM_streamId_t;

#define QKER_CLOSE_STREAM_sourceDesc   0x800002 /* 8388610 */
typedef  QCompDesc   QKER_CLOSE_STREAM_sourceDesc_t;

/*
 * QKER_CLOSE_STREAM (value = 0xc0000f) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
   QCompDesc   sourceDesc;
} QKER_CLOSE_STREAM_t;

#define QKER_CLOSE_STREAM_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKER_CLOSE_STREAM_streamId), &((structAddr)->streamId), \
         (QKER_CLOSE_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_CLOSE_STREAM_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKER_CLOSE_STREAM_streamId), &((structAddr)->streamId), \
         (QKER_CLOSE_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_CLOSE_STREAM_Size      8

#define QKER_CLOSE_STREAM  0xc0000f /* 12582927 */
/*Close Stream opn successful response to the QKER_STREAM_CLOSE msg. Only for
 * HMP Linux */

#define QKER_STREAM_CLOSE_SUCCEEDED_requestType 0x380000 /* 3670016 */
typedef  UInt32   QKER_STREAM_CLOSE_SUCCEEDED_requestType_t;

#define QKER_STREAM_CLOSE_SUCCEEDED_streamId 0x280004 /* 2621444 */
typedef  UInt16   QKER_STREAM_CLOSE_SUCCEEDED_streamId_t;

/*
 * QKER_STREAM_CLOSE_SUCCEEDED (value = 0xc00010) is a message of generic use.
 */


typedef struct {
   UInt32   requestType;
   UInt16   streamId;
} QKER_STREAM_CLOSE_SUCCEEDED_t;

#define QKER_STREAM_CLOSE_SUCCEEDED_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKER_STREAM_CLOSE_SUCCEEDED_requestType), &((structAddr)->requestType),   \
         (QKER_STREAM_CLOSE_SUCCEEDED_streamId), &((structAddr)->streamId))


#define QKER_STREAM_CLOSE_SUCCEEDED_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKER_STREAM_CLOSE_SUCCEEDED_requestType), &((structAddr)->requestType),   \
         (QKER_STREAM_CLOSE_SUCCEEDED_streamId), &((structAddr)->streamId))


#define QKER_STREAM_CLOSE_SUCCEEDED_Size     6

#define QKER_STREAM_CLOSE_SUCCEEDED 0xc00010 /* 12582928 */
/*This is the equivalent of the QCNTRL_FAILED message on HMP Linux. Can be
 * sent in response to any opn which failed. */

#define QKER_STREAM_OPN_FAILED_requestType   0x380000 /* 3670016 */
typedef  UInt32   QKER_STREAM_OPN_FAILED_requestType_t;

#define QKER_STREAM_OPN_FAILED_streamId   0x280004 /* 2621444 */
typedef  UInt16   QKER_STREAM_OPN_FAILED_streamId_t;

#define QKER_STREAM_OPN_FAILED_errCode 0x280006 /* 2621446 */
typedef  UInt16   QKER_STREAM_OPN_FAILED_errCode_t;

/*
 * QKER_STREAM_OPN_FAILED (value = 0xc00011) is a message of generic use.
 */


typedef struct {
   UInt32   requestType;
   UInt16   streamId;
   UInt16   errCode;
} QKER_STREAM_OPN_FAILED_t;

#define QKER_STREAM_OPN_FAILED_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKER_STREAM_OPN_FAILED_requestType), &((structAddr)->requestType),  \
         (QKER_STREAM_OPN_FAILED_streamId), &((structAddr)->streamId),  \
         (QKER_STREAM_OPN_FAILED_errCode), &((structAddr)->errCode))


#define QKER_STREAM_OPN_FAILED_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKER_STREAM_OPN_FAILED_requestType), &((structAddr)->requestType),  \
         (QKER_STREAM_OPN_FAILED_streamId), &((structAddr)->streamId),  \
         (QKER_STREAM_OPN_FAILED_errCode), &((structAddr)->errCode))


#define QKER_STREAM_OPN_FAILED_Size    8

#define QKER_STREAM_OPN_FAILED   0xc00011 /* 12582929 */
/* Message from the host to terminate a specific cache prompt stream only.
 * This is only used for HMP Linux */

#define QKER_TERMINATE_STREAM_streamId 0x280000 /* 2621440 */
typedef  UInt16   QKER_TERMINATE_STREAM_streamId_t;

#define QKER_TERMINATE_STREAM_sourceDesc  0x800002 /* 8388610 */
typedef  QCompDesc   QKER_TERMINATE_STREAM_sourceDesc_t;

/*
 * QKER_TERMINATE_STREAM (value = 0xc00012) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
   QCompDesc   sourceDesc;
} QKER_TERMINATE_STREAM_t;

#define QKER_TERMINATE_STREAM_get(msgPtr, structAddr, offset)  \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKER_TERMINATE_STREAM_streamId), &((structAddr)->streamId),   \
         (QKER_TERMINATE_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_TERMINATE_STREAM_put(msgPtr, structAddr, offset)  \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKER_TERMINATE_STREAM_streamId), &((structAddr)->streamId),   \
         (QKER_TERMINATE_STREAM_sourceDesc), &((structAddr)->sourceDesc))


#define QKER_TERMINATE_STREAM_Size     8

#define QKER_TERMINATE_STREAM 0xc00012 /* 12582930 */
/*Session closed message sent to the host. Only for HMP Linux */

#define QKER_STREAM_SESSION_CLOSED_streamId  0x280000 /* 2621440 */
typedef  UInt16   QKER_STREAM_SESSION_CLOSED_streamId_t;

/*
 * QKER_STREAM_SESSION_CLOSED (value = 0xc00013) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
} QKER_STREAM_SESSION_CLOSED_t;

#define QKER_STREAM_SESSION_CLOSED_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 1, &(offset),  \
         (QKER_STREAM_SESSION_CLOSED_streamId), &((structAddr)->streamId))


#define QKER_STREAM_SESSION_CLOSED_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 1, &(offset),  \
         (QKER_STREAM_SESSION_CLOSED_streamId), &((structAddr)->streamId))


#define QKER_STREAM_SESSION_CLOSED_Size      2

#define QKER_STREAM_SESSION_CLOSED  0xc00013 /* 12582931 */
/*Can take message for HMP Linux */

#define QKER_STREAM_CANTAKE_streamId   0x380000 /* 3670016 */
typedef  UInt32   QKER_STREAM_CANTAKE_streamId_t;

#define QKER_STREAM_CANTAKE_canTake 0x380004 /* 3670020 */
typedef  UInt32   QKER_STREAM_CANTAKE_canTake_t;

/*
 * QKER_STREAM_CANTAKE (value = 0xc00014) is a message of generic use.
 */


typedef struct {
   UInt32   streamId;
   UInt32   canTake;
} QKER_STREAM_CANTAKE_t;

#define QKER_STREAM_CANTAKE_get(msgPtr, structAddr, offset) \
          qMsgVarFieldGet((msgPtr), 2, &(offset),  \
         (QKER_STREAM_CANTAKE_streamId), &((structAddr)->streamId),  \
         (QKER_STREAM_CANTAKE_canTake), &((structAddr)->canTake))


#define QKER_STREAM_CANTAKE_put(msgPtr, structAddr, offset) \
          qMsgVarFieldPut((msgPtr), 2, &(offset),  \
         (QKER_STREAM_CANTAKE_streamId), &((structAddr)->streamId),  \
         (QKER_STREAM_CANTAKE_canTake), &((structAddr)->canTake))


#define QKER_STREAM_CANTAKE_Size    8

#define QKER_STREAM_CANTAKE   0xc00014 /* 12582932 */
/* Message from the firmware to the host notifying that there is data on the
 * read stream */

#define QKER_READ_STREAM_NOTIFICATION_streamId  0x280000 /* 2621440 */
typedef  UInt16   QKER_READ_STREAM_NOTIFICATION_streamId_t;

#define QKER_READ_STREAM_NOTIFICATION_dataSize  0x280002 /* 2621442 */
typedef  UInt16   QKER_READ_STREAM_NOTIFICATION_dataSize_t;

#define QKER_READ_STREAM_NOTIFICATION_streamFlags  0x380004 /* 3670020 */
typedef  UInt32   QKER_READ_STREAM_NOTIFICATION_streamFlags_t;

/*
 * QKER_READ_STREAM_NOTIFICATION (value = 0xc00015) is a message of generic use.
 */


typedef struct {
   UInt16   streamId;
   UInt16   dataSize;
   UInt32   streamFlags;
} QKER_READ_STREAM_NOTIFICATION_t;

#define QKER_READ_STREAM_NOTIFICATION_get(msgPtr, structAddr, offset)   \
          qMsgVarFieldGet((msgPtr), 3, &(offset),  \
         (QKER_READ_STREAM_NOTIFICATION_streamId), &((structAddr)->streamId), \
         (QKER_READ_STREAM_NOTIFICATION_dataSize), &((structAddr)->dataSize), \
         (QKER_READ_STREAM_NOTIFICATION_streamFlags), &((structAddr)->streamFlags))


#define QKER_READ_STREAM_NOTIFICATION_put(msgPtr, structAddr, offset)   \
          qMsgVarFieldPut((msgPtr), 3, &(offset),  \
         (QKER_READ_STREAM_NOTIFICATION_streamId), &((structAddr)->streamId), \
         (QKER_READ_STREAM_NOTIFICATION_dataSize), &((structAddr)->dataSize), \
         (QKER_READ_STREAM_NOTIFICATION_streamFlags), &((structAddr)->streamFlags))


#define QKER_READ_STREAM_NOTIFICATION_Size      8

#define QKER_READ_STREAM_NOTIFICATION  0xc00015 /* 12582933 */

#endif /* !defined(_confdefs_h_) */
