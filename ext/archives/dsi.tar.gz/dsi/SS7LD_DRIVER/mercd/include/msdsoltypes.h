/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic Corporation nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* 4.    Except as provided herein, no license under any patent, copyright,
* trade secret or other intellectual property right is granted to or
* conferred upon you by disclosure or delivery of this software, either
* expressly, by implication, inducement, estoppel or otherwise. Any license
* under such intellectual property rights must be express and approved by
* Dialogic in writing.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
#ifndef	_MSDSOLTYPES_H__

#define	_MSDSOLTYPES_H__

typedef dev_info_t             mercd_dev_info_T;
typedef dev_info_t            *pdevice_information_T ;
typedef ddi_acc_handle_t       mercd_dev_acc_handle_T;
typedef ddi_device_acc_attr_t  mercd_acc_attr_T;



typedef int                 md_status_t;
typedef clock_t             mercd_clock_t;
typedef queue_t            *pmercd_strm_queue_sT;
typedef kmutex_t            mercd_mutex_T;
typedef kcondvar_t          mercd_kcondvar_t;
typedef ddi_softintr_t      mercd_softintr_T;
typedef ddi_iblock_cookie_t mercd_iblock_cookie_T; 	   

typedef unsigned short     *pmercd_adapter_map_T;

typedef PMSD_FUNCTION       pmercd_function_T;


#endif	/* _MSDSOLTYPES_H__ */
