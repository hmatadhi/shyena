/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
/**********************************************************************
 * File Name                    : msdtypes.h
 * Description                  : driver type definitions
 *
 *
 **********************************************************************/

#ifndef _MDTYPES_
#define _MDTYPES_

typedef int   merc_int_t;
typedef int   *pmerc_int_t;
typedef char  merc_char_t;
typedef char  *pmerc_char_t;
typedef void  merc_void_t;
typedef void  *pmerc_void_t;
typedef long  merc_long_t;
typedef long  *pmerc_long_t;
typedef short merc_short_t;
typedef short *pmerc_short_t;

typedef unsigned int   merc_uint_t;
typedef unsigned int   *pmerc_uint_t;
typedef unsigned char  merc_uchar_t;
typedef unsigned char  *pmerc_uchar_t;
typedef unsigned long  merc_ulong_t;
typedef unsigned long  *pmerc_ulong_t;
typedef unsigned short merc_ushort_t;
typedef unsigned short *pmerc_ushort_t;

/* Left old definitions for backward compatibility */
typedef unsigned long	ULONG;
typedef unsigned long	*PULONG;
typedef unsigned short  USHORT;
typedef unsigned short  *PUSHORT;
typedef unsigned char	UCHAR;
typedef unsigned char	*PUCHAR;
typedef char		CHAR;
typedef char		*PCHAR;
typedef short		SHORT;
typedef short		*PSHORT;
typedef long		LONG;
typedef long		*PLONG;
//typedef unsigned int	UInt32;
typedef unsigned int	UINT32;
typedef unsigned int	*PUINT32;
typedef int		INT32;
typedef int		*PINT32;
typedef void		*PVOID;

typedef unsigned long	MD_STATUS;
// Duplicate for Library
typedef USHORT		MD_HANDLE;

#ifndef _8_BIT_INSTANCE
typedef UINT32          MBD_HANDLE;
#endif

typedef USHORT		MSD_HANDLE;

typedef ULONG		KAW_HANDLE;

/* Duplicate for Library */
typedef ULONG		(*PMD_FUNCTION)(void);
typedef ULONG		(*PMSD_FUNCTION)(void);

typedef struct msgb 	STRM_MSG;
typedef struct msgb 	*PSTRM_MSG;

#define	REGISTER	register

#define MD_PRIVATE

#endif
