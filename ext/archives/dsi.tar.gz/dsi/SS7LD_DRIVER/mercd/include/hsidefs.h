/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
/*
 * This file was automatically generated from hsidefs.mdl.
 * Author: "HMP Group"
 * Version: "1.3"
 * Date: Fri Nov 11 15:48:39 2005
 * The output was written to hsidefs.h.
 * Produced by mmdl translator version 1.3.
 */

#if !defined(_hsidefs_h_)
#define _hsidefs_h_ 1
/* All HSI manager messages start from 0x800300 */
/* Message to initialize the DM3 kernel HSI manager */
/* Message protocol revision */

#define UInt32 UINT32

#define QKerHSIBufferInit_revision	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInit_revision_t;
/* Maximum number of Tx/Rx bridge timeslots */

#define QKerHSIBufferInit_bridgeSize	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBufferInit_bridgeSize_t;
/* Timer tick rate in milliseconds */

#define QKerHSIBufferInit_tickRate	0x380008	/* 3670024 */
typedef	UInt32	QKerHSIBufferInit_tickRate_t;
/* Rate interrupt or CT Bus sync */

#define QKerHSIBufferInit_startType	0x38000c	/* 3670028 */
typedef	UInt32	QKerHSIBufferInit_startType_t;
/* Number buffers per bridge timeslot */

#define QKerHSIBufferInit_numBufs	0x380010	/* 3670032 */
typedef	UInt32	QKerHSIBufferInit_numBufs_t;
/* Receive sync CT Bus timeslot */

#define QKerHSIBufferInit_rxSyncTs	0x380014	/* 3670036 */
typedef	UInt32	QKerHSIBufferInit_rxSyncTs_t;
/* Reserved for future use */

#define QKerHSIBufferInit_reserved2	0x380018	/* 3670040 */
typedef	UInt32	QKerHSIBufferInit_reserved2_t;

#define QKerHSIBufferInit_varStart	0x1c
/* Lower part of base addresses for transmit */

#define QKerHSIBufferInit_BufferBase_txLow	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInit_BufferBase_txLow_t;
/* Upper part of base addresses for transmit */

#define QKerHSIBufferInit_BufferBase_txHigh	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInit_BufferBase_txHigh_t;
/* Lower part of base addresses for receive */

#define QKerHSIBufferInit_BufferBase_rxLow	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInit_BufferBase_rxLow_t;
/* Upper part of base addresses for receive */

#define QKerHSIBufferInit_BufferBase_rxHigh	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInit_BufferBase_rxHigh_t;


typedef struct {
	UInt32	txLow;
	UInt32	txHigh;
	UInt32	rxLow;
	UInt32	rxHigh;
} QKerHSIBufferInit_BufferBase_t;

#define QKerHSIBufferInit_BufferBase_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 4, &(offset),	\
			(QKerHSIBufferInit_BufferBase_txLow), &((structAddr)->txLow),	\
			(QKerHSIBufferInit_BufferBase_txHigh), &((structAddr)->txHigh),	\
			(QKerHSIBufferInit_BufferBase_rxLow), &((structAddr)->rxLow),	\
			(QKerHSIBufferInit_BufferBase_rxHigh), &((structAddr)->rxHigh))


#define QKerHSIBufferInit_BufferBase_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 4, &(offset),	\
			(QKerHSIBufferInit_BufferBase_txLow), &((structAddr)->txLow),	\
			(QKerHSIBufferInit_BufferBase_txHigh), &((structAddr)->txHigh),	\
			(QKerHSIBufferInit_BufferBase_rxLow), &((structAddr)->rxLow),	\
			(QKerHSIBufferInit_BufferBase_rxHigh), &((structAddr)->rxHigh))


#define QKerHSIBufferInit_BufferBase_Size		16

#define QKerHSIBufferInit_BufferBase	0	/* 0 */

/*
 * QKerHSIBufferInit (value = 0x800300) is an input message of generic use.
 */


typedef struct {
	UInt32	revision;
	UInt32	bridgeSize;
	UInt32	tickRate;
	UInt32	startType;
	UInt32	numBufs;
	UInt32	rxSyncTs;
	UInt32	reserved2;
} QKerHSIBufferInit_t;

#define QKerHSIBufferInit_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 7, &(offset),	\
			(QKerHSIBufferInit_revision), &((structAddr)->revision),	\
			(QKerHSIBufferInit_bridgeSize), &((structAddr)->bridgeSize),	\
			(QKerHSIBufferInit_tickRate), &((structAddr)->tickRate),	\
			(QKerHSIBufferInit_startType), &((structAddr)->startType),	\
			(QKerHSIBufferInit_numBufs), &((structAddr)->numBufs),	\
			(QKerHSIBufferInit_rxSyncTs), &((structAddr)->rxSyncTs),	\
			(QKerHSIBufferInit_reserved2), &((structAddr)->reserved2))


#define QKerHSIBufferInit_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 7, &(offset),	\
			(QKerHSIBufferInit_revision), &((structAddr)->revision),	\
			(QKerHSIBufferInit_bridgeSize), &((structAddr)->bridgeSize),	\
			(QKerHSIBufferInit_tickRate), &((structAddr)->tickRate),	\
			(QKerHSIBufferInit_startType), &((structAddr)->startType),	\
			(QKerHSIBufferInit_numBufs), &((structAddr)->numBufs),	\
			(QKerHSIBufferInit_rxSyncTs), &((structAddr)->rxSyncTs),	\
			(QKerHSIBufferInit_reserved2), &((structAddr)->reserved2))


#define QKerHSIBufferInit_Size		28

#define QKerHSIBufferInit	0x800300	/* 8389376 */

#define QHSI_PROTOCOL_VERSION_1 1

#define QHSI_TICK_RATE_2MS 2
#define QHSI_TICK_RATE_4MS 4

#define QHSI_START_TYPE_RATE 0
#define QHSI_START_TYPE_CTBUS 1
/* Message used to indicate that the HSI manager has processed the
 * QKerHSIBufferInit message */
/* HSI manager message set protocol revision */

#define QKerHSIBufferInitAck_revision	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferInitAck_revision_t;
/* Return status of the QKerHSIBufferInit message */

#define QKerHSIBufferInitAck_status	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBufferInitAck_status_t;
/* Delay in 125 us samples from the host buffers to the CT Bus */

#define QKerHSIBufferInitAck_txDelay	0x380008	/* 3670024 */
typedef	UInt32	QKerHSIBufferInitAck_txDelay_t;
/* Delay in 125 us samples from the CT Bus to the host buffers */

#define QKerHSIBufferInitAck_rxDelay	0x38000c	/* 3670028 */
typedef	UInt32	QKerHSIBufferInitAck_rxDelay_t;
/* Transmit synchronization delay in 125 us samples */

#define QKerHSIBufferInitAck_txSyncDelay	0x380010	/* 3670032 */
typedef	UInt32	QKerHSIBufferInitAck_txSyncDelay_t;
/* Receive synchronization delay in 125 us samples */

#define QKerHSIBufferInitAck_rxSyncDelay	0x380014	/* 3670036 */
typedef	UInt32	QKerHSIBufferInitAck_rxSyncDelay_t;
/* Reserved for future use */

#define QKerHSIBufferInitAck_reserved1	0x380018	/* 3670040 */
typedef	UInt32	QKerHSIBufferInitAck_reserved1_t;

/*
 * QKerHSIBufferInitAck (value = 0x800301) is an output message of generic use.
 */


typedef struct {
	UInt32	revision;
	UInt32	status;
	UInt32	txDelay;
	UInt32	rxDelay;
	UInt32	txSyncDelay;
	UInt32	rxSyncDelay;
	UInt32	reserved1;
} QKerHSIBufferInitAck_t;

#define QKerHSIBufferInitAck_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 7, &(offset),	\
			(QKerHSIBufferInitAck_revision), &((structAddr)->revision),	\
			(QKerHSIBufferInitAck_status), &((structAddr)->status),	\
			(QKerHSIBufferInitAck_txDelay), &((structAddr)->txDelay),	\
			(QKerHSIBufferInitAck_rxDelay), &((structAddr)->rxDelay),	\
			(QKerHSIBufferInitAck_txSyncDelay), &((structAddr)->txSyncDelay),	\
			(QKerHSIBufferInitAck_rxSyncDelay), &((structAddr)->rxSyncDelay),	\
			(QKerHSIBufferInitAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBufferInitAck_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 7, &(offset),	\
			(QKerHSIBufferInitAck_revision), &((structAddr)->revision),	\
			(QKerHSIBufferInitAck_status), &((structAddr)->status),	\
			(QKerHSIBufferInitAck_txDelay), &((structAddr)->txDelay),	\
			(QKerHSIBufferInitAck_rxDelay), &((structAddr)->rxDelay),	\
			(QKerHSIBufferInitAck_txSyncDelay), &((structAddr)->txSyncDelay),	\
			(QKerHSIBufferInitAck_rxSyncDelay), &((structAddr)->rxSyncDelay),	\
			(QKerHSIBufferInitAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBufferInitAck_Size		28

#define QKerHSIBufferInitAck	0x800301	/* 8389377 */

#define QHSI_STATUS_SUCCESS 0

/* Message used to stop the DM3 kernel HSI manager */
/* Reserved for future use */

#define QKerHSIBufferStop_reserved1	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferStop_reserved1_t;
/* Reserved for future use */

#define QKerHSIBufferStop_reserved2	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBufferStop_reserved2_t;

/*
 * QKerHSIBufferStop (value = 0x800302) is an input message of generic use.
 */


typedef struct {
	UInt32	reserved1;
	UInt32	reserved2;
} QKerHSIBufferStop_t;

#define QKerHSIBufferStop_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 2, &(offset),	\
			(QKerHSIBufferStop_reserved1), &((structAddr)->reserved1),	\
			(QKerHSIBufferStop_reserved2), &((structAddr)->reserved2))


#define QKerHSIBufferStop_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 2, &(offset),	\
			(QKerHSIBufferStop_reserved1), &((structAddr)->reserved1),	\
			(QKerHSIBufferStop_reserved2), &((structAddr)->reserved2))


#define QKerHSIBufferStop_Size		8

#define QKerHSIBufferStop	0x800302	/* 8389378 */
/* Message used to indicate that the HSI manager has processed the
 * QKerHSIBufferStop message */
/* Return status */

#define QKerHSIBufferStopAck_status	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBufferStopAck_status_t;
/* Reserved for future use */

#define QKerHSIBufferStopAck_reserved1	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBufferStopAck_reserved1_t;

/*
 * QKerHSIBufferStopAck (value = 0x800303) is an output message of generic use.
 */


typedef struct {
	UInt32	status;
	UInt32	reserved1;
} QKerHSIBufferStopAck_t;

#define QKerHSIBufferStopAck_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 2, &(offset),	\
			(QKerHSIBufferStopAck_status), &((structAddr)->status),	\
			(QKerHSIBufferStopAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBufferStopAck_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 2, &(offset),	\
			(QKerHSIBufferStopAck_status), &((structAddr)->status),	\
			(QKerHSIBufferStopAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBufferStopAck_Size		8

#define QKerHSIBufferStopAck	0x800303	/* 8389379 */
/* Message used to create or destroy one or more bridge connections */
/* Number of bridge routes defined in this message */

#define QKerHSIBridgeRoute_numBridges	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBridgeRoute_numBridges_t;
/* Reserved for future use */

#define QKerHSIBridgeRoute_reserved1	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBridgeRoute_reserved1_t;

#define QKerHSIBridgeRoute_varStart	0x8
/* Bridge port number */

#define QKerHSIBridgeRoute_BridgeInfo_bridgePort	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBridgeRoute_BridgeInfo_bridgePort_t;
/* Hard CT Bus timeslot number */

#define QKerHSIBridgeRoute_BridgeInfo_hardBusTs	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBridgeRoute_BridgeInfo_hardBusTs_t;
/* Route flags */

#define QKerHSIBridgeRoute_BridgeInfo_flags	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBridgeRoute_BridgeInfo_flags_t;


typedef struct {
	UInt32	bridgePort;
	UInt32	hardBusTs;
	UInt32	flags;
} QKerHSIBridgeRoute_BridgeInfo_t;

#define QKerHSIBridgeRoute_BridgeInfo_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 3, &(offset),	\
			(QKerHSIBridgeRoute_BridgeInfo_bridgePort), &((structAddr)->bridgePort),	\
			(QKerHSIBridgeRoute_BridgeInfo_hardBusTs), &((structAddr)->hardBusTs),	\
			(QKerHSIBridgeRoute_BridgeInfo_flags), &((structAddr)->flags))


#define QKerHSIBridgeRoute_BridgeInfo_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 3, &(offset),	\
			(QKerHSIBridgeRoute_BridgeInfo_bridgePort), &((structAddr)->bridgePort),	\
			(QKerHSIBridgeRoute_BridgeInfo_hardBusTs), &((structAddr)->hardBusTs),	\
			(QKerHSIBridgeRoute_BridgeInfo_flags), &((structAddr)->flags))


#define QKerHSIBridgeRoute_BridgeInfo_Size		12

#define QKerHSIBridgeRoute_BridgeInfo	0x1	/* 1 */

/*
 * QKerHSIBridgeRoute (value = 0x800304) is an input message of generic use.
 */


typedef struct {
	UInt32	numBridges;
	UInt32	reserved1;
} QKerHSIBridgeRoute_t;

#define QKerHSIBridgeRoute_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 2, &(offset),	\
			(QKerHSIBridgeRoute_numBridges), &((structAddr)->numBridges),	\
			(QKerHSIBridgeRoute_reserved1), &((structAddr)->reserved1))


#define QKerHSIBridgeRoute_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 2, &(offset),	\
			(QKerHSIBridgeRoute_numBridges), &((structAddr)->numBridges),	\
			(QKerHSIBridgeRoute_reserved1), &((structAddr)->reserved1))


#define QKerHSIBridgeRoute_Size		8

#define QKerHSIBridgeRoute	0x800304	/* 8389380 */

#define QHSI_BRIDGE_DIR_MASK 1

#define QHSI_BRIDGE_DIR_TX 0
#define QHSI_BRIDGE_DIR_RX 1

/* Message used to acknowledge processing of the QKerHSIBridgeRoute message
 * has been completed */
/* Return status */

#define QKerHSIBridgeRouteAck_status	0x380000	/* 3670016 */
typedef	UInt32	QKerHSIBridgeRouteAck_status_t;
/* Reserved for future use */

#define QKerHSIBridgeRouteAck_reserved1	0x380004	/* 3670020 */
typedef	UInt32	QKerHSIBridgeRouteAck_reserved1_t;

/*
 * QKerHSIBridgeRouteAck (value = 0x800305) is an output message of generic use.
 */


typedef struct {
	UInt32	status;
	UInt32	reserved1;
} QKerHSIBridgeRouteAck_t;

#define QKerHSIBridgeRouteAck_get(msgPtr, structAddr, offset)	\
		    qMsgVarFieldGet((msgPtr), 2, &(offset),	\
			(QKerHSIBridgeRouteAck_status), &((structAddr)->status),	\
			(QKerHSIBridgeRouteAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBridgeRouteAck_put(msgPtr, structAddr, offset)	\
		    qMsgVarFieldPut((msgPtr), 2, &(offset),	\
			(QKerHSIBridgeRouteAck_status), &((structAddr)->status),	\
			(QKerHSIBridgeRouteAck_reserved1), &((structAddr)->reserved1))


#define QKerHSIBridgeRouteAck_Size		8

#define QKerHSIBridgeRouteAck	0x800305	/* 8389381 */

#undef UInt32

#endif /* !defined(_hsidefs_h_) */

