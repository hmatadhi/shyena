/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
/**********************************************************************
 * File Name                    : dtrace.h
 * Description                  : driver trace definitions
 *
 **********************************************************************/

#ifndef _DTRACE_
#define _DTRACE_

#include "msdtypes.h"

#define MSD_MAX_TRACE_BUF_SIZE      10500
#define MSD_MAX_TRACE_MSGS          1000
#define MSD_MAX_TRACE_FILTER_MSGS     31
#define MSD_DUMPTHRESHOLD_FACTOR 3
#define NO_STREAMID -1

typedef struct _mercd_trace_copy_sT {

    merc_uint_t     FlagTransactionId;
    merc_uint_t     MessageType;
    merc_uint_t     Source;
    merc_uint_t     Destination;
    merc_uint_t     SourceDestComponent;
    merc_uint_t     BodySize;
    merc_uint_t     Reserved;
    merc_ulong_t    TimeStamp;
    merc_ulong_t    TimeUSec;
}mercd_trace_copy_sT, *pmercd_trace_copy_sT;

#endif

