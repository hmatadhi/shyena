/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2010 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic Corporation nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* 4.    Except as provided herein, no license under any patent, copyright,
* trade secret or other intellectual property right is granted to or
* conferred upon you by disclosure or delivery of this software, either
* expressly, by implication, inducement, estoppel or otherwise. Any license
* under such intellectual property rights must be express and approved by
* Dialogic in writing.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
typedef struct _MSD_MUTEX_BLOCK {
   unsigned long    Flags;
   kmutex_t HwIntrMutex;
   kmutex_t SoftIntrMutex;
   kmutex_t StrmLstIntrMutex;
} MSD_MUTEX_BLOCK, *PMSD_MUTEX_BLOCK;

#define MSD_MUTEX_FLAG_SOFT_READY	0x00000001
#define MSD_MUTEX_FLAG_HW_READY		0x00000002
#define MSD_MUTEX_FLAG_STRM_LST_READY	0x00000004
#define MSD_MUTEX_FLAG_DONT_EXIT	0x00000008

// Mutex Code

#define MSD_ENTER_CONTROL_BLOCK_MUTEX() \
	mutex_enter(&MsdControlBlock->mercd_ctrl_block_mutex) ;

#define MSD_EXIT_CONTROL_BLOCK_MUTEX() \
	mutex_exit(&MsdControlBlock->mercd_ctrl_block_mutex) ; 

#define MSD_ENTER_CONFIG_MAP_TABLE_MUTEX() \
	mutex_enter(&config_map_table_mutex);

#define MSD_EXIT_CONFIG_MAP_TABLE_MUTEX() \
	mutex_exit(&config_map_table_mutex);


#define MSD_ENTER_OPEN_LIST_MUTEX() \
	mutex_enter(&mercd_open_list_mutex) ; 

#define MSD_EXIT_OPEN_LIST_MUTEX() \
	mutex_exit(&mercd_open_list_mutex); 

#define MSD_ENTER_MUTEX(ourmutex1) \
	mutex_enter(ourmutex1);

#define MSD_EXIT_MUTEX(ourmutex2)  \
	mutex_exit(ourmutex2);

#define MSD_INIT_MUTEX(mutex_name, mutexstr, mutexptr)	\
	mutex_init(mutex_name, mutexstr, MUTEX_DRIVER, mutexptr);

#define MSD_INIT_CV(OurCV) \
	cv_init(OurCV,NULL, CV_DRIVER, NULL);

#define MSD_SIGNAL_CV(OurCV) \
	cv_signal(OurCV)

#define MSD_DESTROY_CV(OurCV) \
	cv_destroy(OurCV)

#define MSD_DESTROY_MUTEX(ourmutex2) \
	mutex_destroy(ourmutex2);

#define MSD_ENTER_HW_MUTEX(ConfigId) \
    mutex_enter(&MsdControlBlock->padapter_block_list[mercd_adapter_map[ConfigId]]->phw_info->intr_info->intr_mutex);

#define MSD_EXIT_HW_MUTEX(ConfigId)  \
    mutex_exit(&MsdControlBlock->padapter_block_list[mercd_adapter_map[ConfigId]]->phw_info->intr_info->intr_mutex);

#define MSD_CV_TIMED_WAIT(OurCV, OurMutex,OurTime) \
   cv_timedwait(OurCV, OurMutex,OurTime)
	

