/**********@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********************************
* Copyright (C) 2001-2011 Dialogic Corporation. All Rights Reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1.    Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* 2.    Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in
* the documentation and/or other materials provided with the
* distribution.
*
* 3.    Neither the name Dialogic nor the names of its
* contributors may be used to endorse or promote products derived from this
* software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
***********************************@@@SOFT@@@WARE@@@COPY@@@RIGHT@@@**********/
/**********************************************************************
 * File Name 			: msdshrdata.c
 * Description			: Shared data across the Driver
 *
 *
 **********************************************************************/

#include "msd.h"

#define _MSDSHRDATA_C_
// In this module all the global variables are declared

//pmercd_control_block_sT MsdControlBlock;

merc_char_t   MsdDriverBuild[100] = { 0 };
merc_char_t   MsdDriverVersion[100] = { 0 };
mercd_mutex_T config_map_table_mutex = { 0 };
mercd_mutex_T mercd_open_list_mutex = { 0 };

MSD_BIND_MAP_ENTRY      MsdBindMapTable[MSD_ABSOLUTE_MAX_BIND];
merc_uint_t             mercd_adapter_map[MSD_MAX_ADAPTER_COUNT+1];
merc_uint_t             mercd_adapter_log_to_phy_map_table[MSD_MAX_ADAPTER_COUNT+1];

MSD_QUEUE               MsdOpenList;

// Array to store profiles information

typedef void (*MERCD_ABSTARCT_FUNC)(void *rcvPtr);
MERCD_INTERFACE_FUNC  mercd_osal_mid_func[MAX_INTERFACE_FUNCTION];
MERCD_ABSTRACT_FUNC mercd_osal_func[MAX_OSAL_FUNC];
MERCD_ABSTRACT_FUNC mercd_dhal_func[MAX_DHAL_FUNC];

//PMSD_MUTEX_STATS pmutex_stats;

#undef _MSDSHRDATA_C_
