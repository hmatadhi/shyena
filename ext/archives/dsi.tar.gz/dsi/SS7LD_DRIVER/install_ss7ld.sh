#!/bin/bash
#
#                       Copyright (C) Dialogic Corporation 2010-2011
#                       All Rights Reserved.
#
#   File:               install_ss7ld.sh
#
#   Script to install:  Linux SS7LD device driver.
#   for use with:       Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1     23-Sep-10   MH   - First version for external release
#           06-Dec-10   MH   - Remove '|| exit 1' from 'remove' commands.
#           17-Mar-11   MH   - Un-BASHify.
#           06-Apr-11   MH   - Add 'create-devnode' command.
#           17-Nov-11   IDP  - CN524DPK - Correct node removal on insert
#
#   Usage:
#     ./install_ss7ld.sh          - Load device driver module and create
#                                   device nodes
#     ./install_ss7ld.sh remove   - Unload device driver and delete
#                                   device nodes
#     ./install_ss7ld.sh create-devnode - Create the device nodes

# look up the version string
OS_VER=`uname -r`

# and read the minor version number
MAJVER=`echo $OS_VER | cut -f 1 -d "."`
MINVER=`echo $OS_VER | cut -f 2 -d "."`

DRIVER_NAME="mercd"
NODE_NAME="mercd"
DEVICE_NAME="mercd"
CTI_DRIVER_NAME="ctimod"

# Function - Load the driver module
load_driver()
{
  /sbin/insmod -f ./ctimod/${CTI_MODULE_NAME}${MODULE_EXT} || exit 1
  /sbin/insmod -f ./mercd/${MODULE_NAME}${MODULE_EXT} || exit 1
}

# Function - Unload the driver module
unload_driver()
{
  /sbin/rmmod ${MODULE_NAME} 
  /sbin/rmmod ${CTI_MODULE_NAME} 
}

# Function - Create the device nodes
create_devnodes()
{
  # determine the major device number and add the nodes
  MAJOR=`cat /proc/devices | awk "\\$2==\"${DEVICE_NAME}\" {print \\$1}"`

  mknod -m0666 /dev/${NODE_NAME} c ${MAJOR} 0
}

# Function - Remove all added device nodes
remove_devnodes()
{
  rm -f /dev/${NODE_NAME}* > /dev/null
}

# Determine the kernel specific module name and extention
case "$MAJVER" in
  "2")
    case "$MINVER" in
      "6")
        MODULE_NAME="${DRIVER_NAME}"
        MODULE_EXT=".ko"
        CTI_MODULE_NAME="${CTI_DRIVER_NAME}"
        ;;
      *)
        echo Unsupported kernel revision $MAJVER.$MINVER
        exit 1
        ;;
    esac
    ;;

  "3")
    MODULE_NAME="${DRIVER_NAME}"
    MODULE_EXT=".ko"
    CTI_MODULE_NAME="${CTI_DRIVER_NAME}"
    ;;

  *)
    echo Unsupported kernel revision $MAJVER.$MINVER
    exit 1
    ;;
esac

# Determine if the driver is already loaded.
found=`grep -c $DRIVER_NAME /proc/modules`
if [ '0' = $found ]
then
  driver_loaded=0
else
  driver_loaded=1
fi

# Do the action requested by the user
case "$1" in
  "remove")
    remove_devnodes
    if [ $driver_loaded = 0 ]
    then
      echo "Error: $DEVICE_NAME driver not loaded."
      exit 1
    fi
    unload_driver
    ;;

  "create-devnode")
    remove_devnodes
    create_devnodes
    ;;

  *)
    if [ $driver_loaded = 1 ]; then
      echo "Error: $DEVICE_NAME driver loaded."
      exit 1
    fi
    load_driver
    remove_devnodes
    create_devnodes
    ;;
esac
