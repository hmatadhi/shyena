#!/bin/bash

#
#   Copyright (C) Dialogic Corporation 2010-2012
#   All Rights Reserved.
#
#   File:               build_ss7ld.sh
#
#   Script to build:    Linux SS7LD device drivers.
#   for use with:       Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1     23-Sep-10   MH   - New file
#           11-Nov-10   MH   - Update for different driver layout.
#           17-Mar-11   MH   - Un-BASHify.
#           30-Mar-11   MH   - Pipe errors to a file.
#           08-Nov-12   MH   - CN553DPK - 'Rebuild of LNX driver always succeeds'
#
#
#   Usage:
#     ./build_ss7ld.sh          - Build device driver
#     ./build_ss7ld.sh clean    - Delete device driver and object files

# Check whether make clean is requested 
if [ "$1" = "clean" ]
then
  CLEAN="$1"
fi

# Check whether we should install
if [ "$1" = "install" ]
then
  INSTALL="$1"
fi

# and read the major and minor version number
OS_VER=`uname -r`

MAJVER=`echo $OS_VER | cut -f 1 -d "."`
MINVER=`echo $OS_VER | cut -f 2 -d "."`
case "$MAJVER.$MINVER" in
  "2.6")
    # Build the file for Linux Ver 2.6
    # Perform build in /lib/modules/... this calls back to our Makefile
    if [ "$CLEAN" = "clean" ]
    then
      make -C ctimod -f Makefile clean
      make -C mercd -f Makefile clean
      rm -rf build_ctimod.log
      rm -rf build_mercd.log
    else
      echo "ctimod - Building ..."; 
      rm -rf ctimod/ctimod.ko
      make -C ctimod -f Makefile >& build_ctimod.log;
      if [ -f ctimod/ctimod.ko ]
      then
      # Test for ctimod.ko. If not rpesent than flag the log.
        echo "ctimod - Success"; 
      else 
        echo "ctimod - Failed. Check 'build_ctimod.log' for build errors." 
      fi

      echo "mercd - Building ..."; 
      rm -rf mercd/mercd.ko
      make -C mercd -f Makefile >& build_mercd.log
      if [ -f mercd/mercd.ko ]
      then
        echo "mercd - Success"; 
      else 
        echo "mercd - Failed. Check 'build_mercd.log' for build errors." 
      fi
    fi
    exit
    ;;
esac

case "$MAJVER" in
  "3")
    # Build the file for Linux Ver 3.x
    # Perform build in /lib/modules/... this calls back to our Makefile
    if [ "$CLEAN" = "clean" ]
    then
      make -C ctimod -f Makefile clean
      make -C mercd -f Makefile clean
      rm -rf build_ctimod.log
      rm -rf build_mercd.log
    else
      echo "ctimod - Building ..."; 
      make -C ctimod -f Makefile >& build_ctimod.log;
      if [ -f ctimod/ctimod.ko ]
      then
      # Test for ctimod.ko. If not rpesent than flag the log.
        echo "ctimod - Success"; 
      else 
        echo "ctimod - Failed. Check 'build_ctimod.log' for build errors." 
      fi

      echo "mercd - Building ..."; 
      make -C mercd -f Makefile >& build_mercd.log
      if [ -f mercd/mercd.ko ]
      then
        echo "mercd - Success"; 
      else 
        echo "mercd - Failed. Check 'build_mercd.log' for build errors." 
      fi
    fi
    exit
    ;;
esac

echo Currently no support for Linux $MAJVER.$MINVER
exit

