#!/bin/sh
#
#                       Copyright (C) Dialogic Corporation 2011
#                       All Rights Reserved.
#
#   File:               install_dsikmod.sh
#
#   Script to install:  Install all DSI kernel modules
#   for use with:       Linux 2.4.x or Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1     05-Apr-11   MH   - New file.
#
#   Usage:
#
#   Update /etc/rc.local (or your distribution's equivalent) to run this file on boot.
#
#   Remove the comment from column 0 for each board types present.

# look up the version string
KVER=`uname -r`

# Call the driver installation scripts:

# SPCI
#. /lib/modules/$KVER/extra/ss7/install_spci_cpm.sh create-devnode

# SS7HD
#. /lib/modules/$KVER/extra/ss7/install_ss7hd.sh create-devnode

# SS7MD
#. /lib/modules/$KVER/extra/ss7/install_ss7md.sh create-devnode

# SS7LD
#. /lib/modules/$KVER/extra/ss7/install_ss7ld.sh create-devnode

