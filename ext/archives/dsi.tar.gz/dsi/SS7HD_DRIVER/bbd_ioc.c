/*
                Copyright (C) Dialogic Corporation 2002-2013.
                All Rights Reserved.

 Name:          bbd_ioc.c

 Description:   ioctl file for the BBD Linux device driver

 Functions:     BBD_reset_environment
                BBD_assert_reset
                BBD_deassert_reset
                BBD_read_bar
                BBD_write_bar
                BBD_test_reset_complete
                BBD_put_cmd
                BBD_get_status
                BBD_geog_address
                BBD_detach_cpci
                BBD_attach_cpci
                BBD_read_pciconfig
                BBD_buffers_ready
                BBD_buffers_clear
                BBD_read_hotswap
                BBD_run_mode

 Notes:         Slave id MUST be set to zero at present as direct comms 
                with the signalling processors is NOT available
 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    07-Jan-03   IDP  - Initial file.
   B    13-May-03   IDP  - Removed reliance on final bit in flags field 
   C    22-May-03   IDP  - Removed delay from buffers_clear
   D    30-May-03   IDP  - Additional/changes buffers commands for interrupts
   E    05-Jun-03   IDP  - Addition of set run mode ioctl
   F    10-Jun-03   IDP  - Clear all scratchpad regs to zero during
                           reset_environment
   G    19-Jun-03   IDP  - Mark buffers as empty when exiting rx_buffers_free
   H    19-Sep-03   GNK  - Disable output using __DEBUG__ flag.
   1    16-Oct-03   IDP  - Bump to whole number for code review
   2    13-Apr-04   IDP  - Addition of hotswap functions
   3    12-Apr-05   GNK  - Remove msg.h from include list
                         - Tidy up for source code release.
        27-Oct-05   MH   - Reinstance the PCI configuration space
                           IOCTLs.
   -    01-May-07   GNK  - Update copyright banner.
   -    29-Oct-13   IDP  - CN045BBD Support read slave info IOCTL.
*/

#include "bbd_def.h"
#include "bbd_pro.h"
#include "bbd_hbi.h"

/*
 * Accessor macros to hide implementation details from the user
 */
#define PUT_HOST_COMMAND(pbbd, cmd) \
  (BARU16W(pbbd, 0, BBD_HSI_HST_NP_HOST_COMMAND, cmd))

#define GET_GEOG_ADDRESS(pbbd)\
  (BARU32R(pbbd, 0, BBD_HSI_HST_NP_GEOG_ADDR))

#define GET_HOST_COMMAND(pbbd) \
  (BARU32R(Pbbd, 0, BBD_HSI_HST_NP_HOST_COMMAND))

#define GET_SLAVE_STATUS(pbbd) \
  (BARU32R(pbbd, 0, BBD_HSI_HST_NP_SLAVE_STATUS))

#define PUT_SLAVE_STATUS(pbbd, data) \
  (BARU32W(pbbd, 0, BBD_HSI_HST_NP_SLAVE_STATUS, data))

#define PUT_HSI_HOST_MEMBASE(pbbd, bus_addr) \
  (BARU32W(pbbd, 0, BBD_HSI_HST_NP_HOST_MEMBASE, bus_addr))

#define PUT_SLAVE_RUN_MODE(pbbd, mode) \
  (BARU32W(pbbd, 0, BBD_HSI_HST_NP_RUN_MODE, mode))

#define HST_INT_SLV_NEW_COMMAND(pbbd) \
  (BBD_SLV_IRQ_SET_NEW_CMD(pbbd))


#include <linux/delay.h>
/*
 * BBD_board_check - Check BBD board is still running correctly
 *
 * Parameters
 *  Pbbd - Board to check
 *
 * Returns
 *   LNXSLV_SUCCESS on board running correctly
 *   LNXSLV_BOARD_FAILURE on error
 */
static int BBD_board_check(BBD_BOARD *Pbbd)
{
  return(LNXSLV_SUCCESS);
}

/*
 * BBD_reset_environment - Reset the HBI queues to full / empty as required
 *
 * Parameters
 *   Pbbd - Pointer to the board structure
 *
 * Returns
 *   == 0 on success
 *   != 0 on failure
 */
int BBD_reset_environment(BBD_BOARD *Pbbd)
{
  HBI_HOST_CONTROL  *cfg_ptr; /* Pointer to the host side of the HBI */

  DRV_DEBUG(("%s(%i)\n", __FUNCTION__, Pbbd->board_number));

  /*
   * Reset all the reserved scratchpad registers to zero
   * Figure out where in (kernel) memory the host and slave control areas are
   * Put the BUS address of the HBI memory region lives
   * Clear the count for the number of ticks the reset has taken
   * Initialise the board pointer to the first and current buffers for tx & rx
   * Set all the TX buffers to READY and SENT
   * Set all the RX buffers to UNUSED
   * Mark the last RX and TX buffers as the last of their kind
   * Set the host magic numbers
   */
  BARU32W(Pbbd, 0, BBD_HSI_HST_RESERVED_5, 0);
  BARU32W(Pbbd, 0, BBD_HSI_HST_RESERVED_6, 0);
  BARU32W(Pbbd, 0, BBD_HSI_HST_RESERVED_7, 0);
  cfg_ptr = (HBI_HOST_CONTROL  *)(Pbbd->mtr_memory + HBI_CONTROL_OFFSET);

  cfg_ptr->host_revision = 0;

  cfg_ptr->hst2slv_head  = 0;
  cfg_ptr->hst2slv_tail  = 0;
  cfg_ptr->hst2slv_last  = HBI_BUFFER_SIZE;
  cfg_ptr->hst2slv_data  = HBI_CONTROL_OFFSET + HBI_CONTROL_SIZE;

  cfg_ptr->slv2hst_head  = 0;
  cfg_ptr->slv2hst_tail  = 0;
  cfg_ptr->slv2hst_last  = HBI_BUFFER_SIZE;
  cfg_ptr->slv2hst_data  = cfg_ptr->hst2slv_data + HBI_BUFFER_SIZE;

  DRV_DEBUG(("Hst->Slv @ %5i %5i\n",cfg_ptr->hst2slv_data,cfg_ptr->hst2slv_last));
  DRV_DEBUG(("Hst<-Slv @ %5i %5i\n",cfg_ptr->slv2hst_data,cfg_ptr->slv2hst_last));

  Pbbd->test_reset_complete_count = 0;
 
  /*
   * Past this next statement the information contained in the HBI is
   * considered VALID
   */
  cfg_ptr->host_magic = HBI_HOST_MAGIC;

  DRV_DEBUG(("REVISION = %i\n",cfg_ptr->host_revision));
  DRV_DEBUG(("MAGIC    = %08x\n",cfg_ptr->host_magic));

  PUT_HSI_HOST_MEMBASE(Pbbd, Pbbd->mtr_base_address);

  Pbbd->slv2hst_mpt = 1;
  Pbbd->hst2slv_full = 0;

  return(0);
}

/*
 * BBD_assert_reset - Assert the BBD resource reset line
 *
 * Parameters
 *   Pbbd     - Board to reset
 *   slave_id - Resource on the board to reset
 *
 * Returns
 *   LNXSLV_SUCCESS      on success
 *   LNXSLV_DRIVER_ERROR on failure
 *
 * Notes
 *   Currently resets the entire board via the I82555 secondary PCI reset bit
 */
int BBD_assert_reset(BBD_BOARD *Pbbd, u16 slave_id)
{
  u32 val; /* Temp register value storage variable */

  DRV_DEBUG(("%s(%i)\n",__FUNCTION__,Pbbd->board_number));

  /*
   * Read I21555 secondary reset register
   * Set bit to reset the secondary (BBD side) PCI bus
   * Restore secondary reset register
   * Setup startup registers
   * Initialise HBI
   */
  if(PCIReadConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, &val) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  val |= I21555_RCR_SEC_RESET;

  if(PCIWriteConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, val) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  /*
   * Tell the slave it is about to be reset (if not already done)
   * also set the slave status incase we check before the slave
   * gets a chance to change it
   */
  PUT_HOST_COMMAND(Pbbd, (u16)BBDHBI_HCMD_RSTREQ);
  PUT_SLAVE_STATUS(Pbbd, BBDHBI_SLAVE_PWRUP);

  BBD_reset_environment(Pbbd);

  return(LNXSLV_SUCCESS);
}

/*
 * BBD_deassert_reset - Deassert the BBD resource reset line
 *
 * Parameters
 *   Pbbd     - Board to reset
 *   slave_id - Resource to reset
 *
 * Returns
 *   LNXSLV_SUCCESS      on success
 *   LNXSLV_DRIVER_ERROR on failure
 */
int BBD_deassert_reset(BBD_BOARD *Pbbd, u16 slave_id)
{
  u32 val32; /* Temp reg storage variable */

  DRV_DEBUG(("%s(%i)\n",__FUNCTION__,Pbbd->board_number));

  /*
   * Read I21555 secondary reset register
   * Clear bit to reset the secondary (BBD side) PCI bus
   * Restore secondary reset register
   */
  if(PCIReadConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, &val32) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  val32 &= ~I21555_RCR_SEC_RESET;

  if(PCIWriteConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, val32) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  return(LNXSLV_SUCCESS);
}


/*
 * BBD_read_bar - Read data from one of the BAR regions of the card
 *
 * Parameters
 *   Pbbd   - Board to access
 *   barnum - Number of the bar we wish to access
 *   offset - Offset within the bar we wish to access
 *   length - Number of bits we wish to read
 *   data   - Address where the data is to be stored
 *
 * Returns
 *   LNXSLV_SUCCESS      on success
 *   LNXSLV_DRIVER_ERROR on failure
 *
 * Notes
 *   Very little range checking is performed
 *   Accesses to non aligned addresses may fail on certain hosts
 *   Only 8, 16 or 32 bit reads are supported
 */
int BBD_read_bar(BBD_BOARD *Pbbd, int barnum, u32 offset, u32 length, u32 *data)
{
  BBD_PCI_BAR *bar; /* BAR region of the PCI chip we wish to read */
  int ret_val;      /* Return value from the function */

  /*
   * Validate the bar is acceptable and mapped
   */
  if((barnum < 0) || (barnum >= BBD_MAX_BAR))
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  bar = Pbbd->bar + barnum;

  if(bar->handle == NULL)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  /*
   * Read the data
   */
  ret_val = LNXSLV_SUCCESS;
  switch(length) {
    case 8:
       *data = NMSRDU8(bar->handle, bar->base_address, offset);
       break;
   
     case 16:
       *data = NMSRDU16(bar->handle, bar->base_address, offset);
       break;
   
     case 32:
       *data = NMSRDU32(bar->handle, bar->base_address, offset);
       break;

    default:
      ret_val = LNXSLV_DRIVER_ERROR;
  }
  return(ret_val);
}

/*
 * BBD_write_bar - Write data to one of the BAR regions of the card
 *
 * Parameters
 *   Pbbd   - Board to access
 *   barnum - Number of the bar we wish to access
 *   offset - Offset within the bar we wish to access
 *   length - Number of bits we wish to write
 *   data   - Data is to be stored
 *
 * Returns
 *   0                  on success
 *   non 0              on failure
 *
 * Notes
 *   Very little range checking is performed
 *   Accesses to non aligned addresses may fail on certain hosts
 *   Only 8, 16 or 32 bit reads are supported
 */
int BBD_write_bar(BBD_BOARD *Pbbd, int barnum, u32 offset, u32 length, u32 data)
{
  BBD_PCI_BAR *bar; /* BAR region to read */
  int ret_val;      /* Return value from function */

  if((barnum < 0) || (barnum >= BBD_MAX_BAR))
  {
    return(-1);
  }

  bar = Pbbd->bar + barnum;
  if(bar->handle == NULL)
  {
    return(-2);
  }

  ret_val = 0;
  switch(length) {
    case 8:
       NMSWRTU8(bar->handle, bar->base_address, offset, data);
       break;
   
     case 16:
       NMSWRTU16(bar->handle, bar->base_address, offset, data);
       break;
   
     case 32:
       NMSWRTU32(bar->handle, bar->base_address, offset, data);
       break;

    default:
      ret_val = -1;
  }
  return(ret_val);
}


/*
 * BBD_read_cfg - Read data from the PCI devices PCI configuration space
 *
 * Parameters
 *   Pbbd   - Board to access
 *   regnum - Number of the register we wish to access
 *   data   - Address where the data is to be stored
 *
 * Notes
 *   Very little range checking is performed
 *   Accesses to non aligned addresses may fail on certain hosts
 *   32 bit reads are supported
 */
int BBD_read_cfg(BBD_BOARD *Pbbd, int regnum, u32 *data)
{
  if((regnum < 0) || (regnum > 255) || (regnum & 3))
  {
    return(-1);
  }

  if(PCIReadConfig32(Pbbd->pci, regnum, data) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }
  return(0);
}

/*
 * BBD_write_cfg - Write data to the PCI devices PCI configuration space
 *
 * Parameters
 *   Pbbd   - Board to access
 *   regnum - Number of the register we wish to access
 *   data   - Data is to be stored
 *
 * Notes
 *   Very little range checking is performed
 *   Accesses to non aligned addresses may fail on certain hosts
 *   32 bit reads are supported
 */
int BBD_write_cfg(BBD_BOARD *Pbbd, int regnum, u32 data)
{
  if((regnum < 0) || (regnum > 255) || (regnum & 3))
  {
    return(-1);
  }

  if(PCIWriteConfig32(Pbbd->pci, regnum, data) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }
  return(0);
}

/*
 * BBD_test_reset_complete - Determine if the slave has completed its reset
 *
 * Parameters
 *   Pbbd     - Board to access
 *   slave_id - Resource to determine reset status of
 *
 * Returns
 *   == LNXSLV_SUCCESS on slave has completed reset
 *   == LNXSLV_NOT_COMPLETE on slave has not completed reset
 */
int BBD_test_reset_complete(BBD_BOARD *Pbbd, u16 slave_id)
{
  u32 slv_status; /* Status of the slave */

  DRV_DEBUG(("%s(%i)\n", __FUNCTION__, Pbbd->board_number));
  /*
   * The first time we are called we deassert the reset line
   */
  if (Pbbd->test_reset_complete_count++ == 0)
  {
    if(BBD_deassert_reset(Pbbd, slave_id) != 0)
    {
      return(LNXSLV_NOT_COMPLETE);
    }
  }

  /*
   * Read the slave status and return completion status
   */
  slv_status = GET_SLAVE_STATUS(Pbbd);
  if (slv_status != BBDHBI_SLAVE_RESET)
  {
    return(LNXSLV_NOT_COMPLETE);
  }

  return(LNXSLV_SUCCESS);
}

/*
 * BBD_put_cmd - Submit a command to the slave resource
 *
 * Parameters
 *   Pbbd     - Board to access
 *   slave_id - Resource to send command to
 *   cmd      - Command to send
 *
 * Returns
 *   LNXSLV_SUCCESS             on success
 *   LNXSLV_BOARD_FAILURE       on failure
 */
int BBD_put_cmd(BBD_BOARD *Pbbd, u16 slave_id, u16 cmd)
{
  if (BBD_board_check(Pbbd) != 0)
  {
    return(LNXSLV_BOARD_FAILURE);
  }

  /*
   * Send command to the slave
   * Interrupt the slave
   */
  PUT_HOST_COMMAND(Pbbd, cmd);
  HST_INT_SLV_NEW_COMMAND(Pbbd);

  return(LNXSLV_SUCCESS);
}

/*
 * BBD_get_status - Retrieve the slave resources status
 *
 * Parameters
 *   Pbbd        - Board to access
 *   slave_id    - Slave resource to access
 *   np_status   - Return field for the processor status
 *   cong_status - Return field for the congestion status
 *
 * Returns
 *   == LNXSLV_SUCCESS on success
 *   != LNXSLV_SUCCESS on failure
 */
int BBD_get_status(BBD_BOARD *Pbbd,     u16 slave_id,
                   u16 *np_status,      u16 *cong_status)
{
  u32 status; /* Status as reported from the board */

  if (BBD_board_check(Pbbd) != 0)
  {
    return(LNXSLV_BOARD_FAILURE);
  }

  status = GET_SLAVE_STATUS(Pbbd);

  /*
   * Split 32 bit status field into two 16 bits ones
   */
  *cong_status = (status >> 16);
  *np_status = status;

  return(LNXSLV_SUCCESS);
}

/*
 * BBD_geog_address - Retrieve geographic address from the board
 *
 * Parameters
 *   Pbbd   - Board structure
 *   g_addr - Return address for the geographic address
 *
 * Returns
 *   == LNXSLV_SUCCESS on success
 *   != LNXSLV_SUCCESS on failure
 */
int BBD_geog_address(BBD_BOARD *Pbbd, u32 *g_addr)
{
  if (BBD_board_check(Pbbd) != 0)
  {
    return(LNXSLV_BOARD_FAILURE);
  }

  *g_addr = GET_GEOG_ADDRESS(Pbbd);

  return(LNXSLV_SUCCESS);
}

/*
 * BBD_run_mode - Set the run mode for a board
 *
 * Parameters
 *   Pbbd     - Board to access
 *   slave_id - Resource to set run mode to
 *   mode     - Run mode
 *
 * Returns
 *   == LNXSLV_SUCCESS on success
 *   != LNXSLV_SUCCESS on failure
 */
int BBD_run_mode(BBD_BOARD *Pbbd, u16 slave_id, u32 mode)
{
  if (BBD_board_check(Pbbd) != 0)
  {
    return(LNXSLV_BOARD_FAILURE);
  }

  PUT_SLAVE_RUN_MODE(Pbbd, mode);

  return(LNXSLV_SUCCESS);
}

int BBD_get_board_info(BBD_BOARD *Pbbd, BBD_BOARD_INFO *Pinfo)
{
  int i;

  Pinfo->driver[0] = Pbbd->subdev_id;
  Pinfo->driver[1] = GET_SLAVE_STATUS(Pbbd);

#if 0
  //checkpoint
  //Pinfo->driver[2] = NMSRDU32(Pbbd->bar[2].handle, Pbbd->bar[2].base_address, 0x800-4);
#endif

  Pinfo->board[0] = NMSRDU32(Pbbd->bar[2].handle, Pbbd->bar[2].base_address, 0x800);
  if(Pinfo->board[0] != 0xd0bbd0bb)
    return(LNXSLV_NOT_COMPLETE);
  for (i=0; i<13; ++i) {
    Pinfo->board[i] = NMSRDU32(Pbbd->bar[2].handle, Pbbd->bar[2].base_address, 0x800 + (i*4));
  }
  return(LNXSLV_SUCCESS);
}

/*
 * BBD_get_slave_info - Retrieve the per slave crash dump
 *
 * Parameters
 *   Pbbd     - Board to access
 *   Pinfo    - Pointer to ioctl control block
 *   mode     - Run mode
 *
 * Returns
 *   == LNXSLV_SUCCESS on success
 *   != LNXSLV_SUCCESS on failure
 */
int BBD_get_slave_info(BBD_BOARD *Pbbd, BBD_SLAVE_INFO *Pinfo)
{
  u32 tmp32;
  u32 offsp;
  int i;

  /*
   * Validate information
   * Map the slave info region into bar3
   * Read the requested information
   */
  if(Pinfo->length > sizeof(Pinfo->buffer))
    Pinfo->length = sizeof(Pinfo->buffer);

  tmp32 = BARU32R(Pbbd, 0, 0x70);

  BARU32W(Pbbd, 0, 0x70, 0x83000000);
  offsp = (0x4000 * Pinfo->slave_id);

  i = 0;
  while(i != Pinfo->length)
  {
    Pinfo->buffer[i] = NMSRDU8(Pbbd->bar[3].handle, Pbbd->bar[3].base_address, Pinfo->offset + offsp + i);
    i++;
  }

  BARU32W(Pbbd, 0, 0x70, tmp32);

  return(LNXSLV_SUCCESS);
}

