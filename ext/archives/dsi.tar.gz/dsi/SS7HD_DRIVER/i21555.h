/*
            Copyright (C) 2002-2007 Dialogic Corporation. All Rights Reserved.

 Name:          i21555.h

 Description:   Header for intel i21555 PCI Bridge

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Sep-02   GHS   - Initial file.
        08-Jan-03   MH    - 
                           
 */


#ifndef __INC_I21555_H
#define __INC_I21555_H


#define I21555_VENDOR_ID                        (0x8086)
#define I21555_DEVICE_ID                        (0xB555)
/*
 * MH OK
 */

#define I21555_CSR_I20_IB_QUEUE                 (0x0040)
#define I21555_CSR_I20_OB_QUEUE                 (0x0044)
#define I21555_CSR_PRI_CLR_IRQ                  (0x0098)
#define I21555_CSR_SEC_CLR_IRQ                  (0x009a)
#define I21555_CSR_PRI_SET_IRQ                  (0x009c)
#define I21555_CSR_SEC_SET_IRQ                  (0x009e)
#define I21555_CSR_PRI_UNMASK_IRQ               (0x00a0)
#define I21555_CSR_SEC_UNMASK_IRQ               (0x00a2)
#define I21555_CSR_PRI_MASK_IRQ                 (0x00a4)
#define I21555_CSR_SEC_MASK_IRQ                 (0x00a6)

#define I21555_CSR_SCRATCHPAD_0                 (0x00a8)
#define I21555_CSR_SCRATCHPAD_1                 (0x00ac)
#define I21555_CSR_SCRATCHPAD_2                 (0x00b0)
#define I21555_CSR_SCRATCHPAD_3                 (0x00b4)
#define I21555_CSR_SCRATCHPAD_4                 (0x00b8)
#define I21555_CSR_SCRATCHPAD_5                 (0x00bc)
#define I21555_CSR_SCRATCHPAD_6                 (0x00c0)
#define I21555_CSR_SCRATCHPAD_7                 (0x00c4)

#define I21555_SECPCI_CFG_US_MEM_1_BAR          (0x001c)

#define I21555_DEVSPC_CFG_US_MEM1_TRBASE        (0x00a8)
#define I21555_DEVSPC_CFG_CHIP_CTRL_0           (0x00cc)
#define I21555_DEVSPC_CFG_CHIP_CTRL_1           (0x00ce)
#define I21555_DEVSPC_CFG_RESET_CTRL            (0x00d8)

/*
 * 21555 I2O Init functions and associated definitions 
 */

/*
 * Chip Control 1 Bits 
 */
#define I21555_I2O_DISABLE                  (0)
#define I21555_I2O_ENABLE                   (0x1000)

#define I21555_I2O_SIZE_256                 (0x0000)
#define I21555_I2O_SIZE_512                 (0x2000)
#define I21555_I2O_SIZE_1024                (0x4000)
#define I21555_I2O_SIZE_2048                (0x6000)
#define I21555_I2O_SIZE_4096                (0x8000)
#define I21555_I2O_SIZE_8192                (0xA000)
#define I21555_I2O_SIZE_16384               (0xC000)
#define I21555_I2O_SIZE_32768               (0xE000)

/*
 * IDP
 */
/* Secondary PCI reset bit */
#define I21555_RCR_SEC_RESET                    (0x00000001)



/* 
 * 21555 Primary Interface Configuration Space Offsets 
 *
 * (As viewed from the secondary side of the 21555) 
 */
#define	I21555_PRIPCI_CFG_VENDOR_ID             (0x40)
#define	I21555_PRIPCI_CFG_DEVICE_ID             (0x42)
#define	I21555_PRIPCI_CFG_COMMAND               (0x44)
#define	I21555_PRIPCI_CFG_STATUS                (0x46)
#define	I21555_PRIPCI_CFG_REVISION              (0x48)
#define	I21555_PRIPCI_CFG_PROGRAMMING_IF        (0x49)
#define	I21555_PRIPCI_CFG_SUBCLASS              (0x4a)
#define	I21555_PRIPCI_CFG_CLASS                 (0x4b)
#define	I21555_PRIPCI_CFG_CACHE_LINE_SIZE       (0x4c)
#define	I21555_PRIPCI_CFG_LATENCY_TIMER         (0x4d)
#define	I21555_PRIPCI_CFG_HEADER_TYPE           (0x4e)
#define	I21555_PRIPCI_CFG_BIST                  (0x4f)
#define	I21555_PRIPCI_CFG_CSR_DS_MEM_0_BAR      (0x50)
#define	I21555_PRIPCI_CFG_CSR_IO_BAR            (0x54)
#define	I21555_PRIPCI_CFG_DS_IO_MEM_1_BAR       (0x58)
#define	I21555_PRIPCI_CFG_DS_MEM_2_BAR          (0x5c)
#define	I21555_PRIPCI_CFG_DS_MEM_3_BAR          (0x60)
#define	I21555_PRIPCI_CFG_UP32_DS_MEM_3_BAR     (0x64)
#define	I21555_PRIPCI_CFG_RESERVED1             (0x68)
#define	I21555_PRIPCI_CFG_SUBSYS_VNDR_ID        (0x6c)
#define	I21555_PRIPCI_CFG_SUBSYS_ID             (0x6e)
#define	I21555_PRIPCI_CFG_EXPANSION_ROM         (0x70)
#define	I21555_PRIPCI_CFG_CAPABILITY_PTR        (0x74)
#define	I21555_PRIPCI_CFG_RESERVED2             (0x75)
#define	I21555_PRIPCI_CFG_RESERVED3             (0x78)
#define	I21555_PRIPCI_CFG_INTERRUPT_LINE        (0x7c)
#define	I21555_PRIPCI_CFG_INTERRUPT_PIN         (0x7d)
#define	I21555_PRIPCI_CFG_MIN_GRANT             (0x7e)
#define	I21555_PRIPCI_CFG_MAX_LATENCY           (0x7f)

#define I21555_DEVSPC_CFG_DS_MEM2_SETUP         (0xb4)
#define I21555_DEVSPC_CFG_DS_MEM2_TRBASE        (0x9c)
#define I21555_DEVSPC_CFG_DS_IOMEM0_TRBASE      (0x98)

/*
 * MH OK ABOVE ^^^^^^^^
 */
/*
*******************************************************************************
 */

#ifdef MH_TO_CHECK
/* 
 * I21555 Secondary Interface Configuration Space Offsets 
 */
/*
 * (As viewed from the secondary side of the 21554) 
 */
#define	I21555_SECPCI_CFG_VENDOR_ID	        (0x00)
#define	I21555_SECPCI_CFG_DEVICE_ID     	  (0x02)
#define	I21555_SECPCI_CFG_COMMAND   		    (0x04)
#define	I21555_SECPCI_CFG_STATUS    		    (0x06)
#define	I21555_SECPCI_CFG_REVISION      	  (0x08)
#define	I21555_SECPCI_CFG_PROGRAMMING_IF	  (0x09)
#define	I21555_SECPCI_CFG_SUBCLASS      	  (0x0a)
#define	I21555_SECPCI_CFG_CLASS     		    (0x0b)
#define	I21555_SECPCI_CFG_CACHE_LINE_SIZE	  (0x0c)
#define	I21555_SECPCI_CFG_LATENCY_TIMER 	  (0x0d)
#define	I21555_SECPCI_CFG_HEADER_TYPE   	  (0x0e)
#define	I21555_SECPCI_CFG_BIST	        	  (0x0f)
#define	I21555_SECPCI_CFG_CSR_BAR           (0x10)
#define	I21555_SECPCI_CFG_CSR_IO_BAR      	(0x14)
#define	I21555_SECPCI_CFG_US_IO_MEM_0_BAR   (0x18)
#define	I21555_SECPCI_CFG_US_MEM_1_BAR      (0x1c)
#define	I21555_SECPCI_CFG_US_MEM_2_BAR      (0x20)
#define	I21555_SECPCI_CFG_RESERVED1         (0x24)
#define	I21555_SECPCI_CFG_RESERVED2         (0x28)
#define	I21555_SECPCI_CFG_SUBSYS_VNDR_ID    (0x2c)
#define	I21555_SECPCI_CFG_SUBSYS_ID         (0x2e)
#define	I21555_SECPCI_CFG_RESERVED3      	  (0x30)
#define	I21555_SECPCI_CFG_CAPABILITY_PTR   	(0x34)
#define	I21555_SECPCI_CFG_RESERVED4        	(0x35)
#define	I21555_SECPCI_CFG_RESERVED5        	(0x38)
#define	I21555_SECPCI_CFG_INTERRUPT_LINE	  (0x3c)
#define	I21555_SECPCI_CFG_INTERRUPT_PIN 	  (0x3d)
#define	I21555_SECPCI_CFG_MIN_GRANT      	  (0x3e)
#define	I21555_SECPCI_CFG_MAX_LATENCY   	  (0x3f)



/*
 * I21555 Device-Specific Configuration Space Offsets 
 */
#define I21555_DEVSPC_CFG_DS_CFG_ADDR       (0x80)
#define I21555_DEVSPC_CFG_DS_CFG_DATA       (0x84)
#define I21555_DEVSPC_CFG_US_CFG_ADDR       (0x88)
#define I21555_DEVSPC_CFG_US_CFG_DATA       (0x8c)
#define I21555_DEVSPC_CFG_OWN_BITS          (0x90)
#define I21555_DEVSPC_CFG_CTRLSTATUS        (0x92)
#define I21555_DEVSPC_CFG_DS_MEM0_TRBASE    (0x94)
#define I21555_DEVSPC_CFG_DS_MEM3_TRBASE    (0xa0)
#define I21555_DEVSPC_CFG_US_IOMEM0_TRBASE  (0xa4)
#define I21555_DEVSPC_CFG_DS_MEM0_SETUP     (0xac)
#define I21555_DEVSPC_CFG_DS_IOMEM1_SETUP   (0xb0)
#define I21555_DEVSPC_CFG_DS_MEM3_SETUP     (0xb8)
#define I21555_DEVSPC_CFG_UPPER32_DS_MEM3   (0xbc)
#define I21555_DEVSPC_CFG_PRIEXPROM_SETUP   (0xc0)
#define I21555_DEVSPC_CFG_US_IOMEM0_SETUP   (0xc4)
#define I21555_DEVSPC_CFG_US_MEM1_SETUP     (0xc8)
#define I21555_DEVSPC_CFG_CHIP_CTRL_0       (0xcc)
#define I21555_DEVSPC_CFG_CHIP_CTRL_1       (0xce)
#define I21555_DEVSPC_CFG_CHIP_STATUS       (0xd0)
#define I21555_DEVSPC_CFG_ARBITER_CTRL      (0xd2)
#define I21555_DEVSPC_CFG_PRI_SERR_DISABLE  (0xd4)
#define I21555_DEVSPC_CFG_SEC_SERR_DISABLE  (0xd5)
#define I21555_DEVSPC_CFG_RESERVED          (0xd6)
#define I21555_DEVSPC_CFG_RESET_CTRL        (0xd8)
#define I21555_DEVSPC_CFG_PM_CAPABILITY_ID  (0xdc)
#define I21555_DEVSPC_CFG_PM_NEXT_ITEM_PTR  (0xdd)
#define I21555_DEVSPC_CFG_PM_CAPABILITIES   (0xde)
#define I21555_DEVSPC_CFG_PM_CSR            (0xe0)
#define I21555_DEVSPC_CFG_PM_CSR_BSE        (0xe2)
#define I21555_DEVSPC_CFG_PM_DATA           (0xe3)
#define I21555_DEVSPC_CFG_VPD_CAPABILITY_ID (0xe4)
#define I21555_DEVSPC_CFG_VPD_NEXT_ITEM_PTR (0xe5)
#define I21555_DEVSPC_CFG_VPD_ADDRESS       (0xe6)
#define I21555_DEVSPC_CFG_VPD_DATA          (0xe8)
#define I21555_DEVSPC_CFG_HS_CAPABILITY_ID  (0xec)
#define I21555_DEVSPC_CFG_HS_NEXT_ITEM_PTR  (0xed)
#define I21555_DEVSPC_CFG_HS_CTRL           (0xee)
#define I21555_DEVSPC_RESERVED              (0xef)


#define LD_IPC                              (BIT31)
#define LD_IFC                              (BIT31)
#define LD_OPC                              (BIT31)
#define LD_OFC                              (BIT31)
#define MU_POST_LIST_STATUS_MASK            (BIT03)

/* Macros */
#define I21555_REGBASE                      (0xFF030000)

#define I21555_I2O_SIZE                     (256)


#endif /* MH_TO_CHECK */

/*
 * The following i21555 scratch registers are used for command, status, index
 * and board location information.
 */
#define HBI_HOST_COMMAND        (I21555_CSR_SCRATCHPAD_0)
#define HBI_SLAVE_STATUS        (I21555_CSR_SCRATCHPAD_1)
#define HBI_HOST_MEMBASE        (I21555_CSR_SCRATCHPAD_2)
#define HBI_RUN_MODE            (I21555_CSR_SCRATCHPAD_3)
#define HBI_SLAVE_GEOG_ADDR     (I21555_CSR_SCRATCHPAD_4)


#endif
