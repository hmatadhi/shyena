/*

            Copyright (C) 2003-2007 Dialogic Corporation. All Rights Reserved.

 Name:          bbd_hbi.h

 Description:   Bluebird Host-Board interface definitions

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Jan-03   MH    - Initial file
   B    10-Mar-03   MH    - Add more slave status values.
   C    07-Apr-03   GHS   - Increase dimension of slave_tb[] in SLAVE_CONTROL
        28-May-03   MH    - Add interrupt bit definitions.
        10-Jun-03   GHS   - Add SLV_INVALID_BUFFER
        11-Jul-03   IDP   - Convert to single buffer in each direction
        17-Jul-03   GHS   - Added BBDHBI_SLAVE_LICCRP (license data corrupt)
        09-Sep-03   IDP   - Added BBDHBI_SLAVE_FAILED
        26-Oct-05   MH    - Add extended failure codes.
        08-Dec-05   MH    - Add more extended failure codes.
*/

#ifndef __BBD_HBI_H
#define __BBD_HBI_H

/*
 * Magic numbers
 */
#define HBI_HOST_MAGIC                  (0x42424448)
#define HBI_SLAVE_MAGIC                 (0x42424453)

#define HBI_SLAVE_REV                   (0xFFFF0000)


#define HBI_BLEN                        (2048)

#define HBI_CONTROL_OFFSET             (0x00000000)
#define HBI_CONTROL_SIZE               (0x00001000)
#define HBI_BUFFER_SIZE                (0x00004000)

#define HBI_80312_OFFSET               (0x00010000)
#define HBI_80312_SIZE                 (0x00001000)

#define HBI_21555_OFFSET               (HBI_80312_OFFSET + HBI_80312_SIZE)
#define HBI_21555_SIZE                 (0x00001000)

#define HBI_MMAP_SIZE                  (HBI_21555_OFFSET + HBI_21555_SIZE)

/*
 * Definitions of the structures found on both host
 * and slave containing per-buffer control variables
 * and the data buffer used to convey the variable
 * length data.
 */
typedef struct hbi_host_control
{
  u32   host_magic;

  u32   host_revision;

  u32   hst2slv_head;
  u32   hst2slv_tail;
  u32   hst2slv_last;
  u32   hst2slv_data;

  u32   slv2hst_head;
  u32   slv2hst_tail;
  u32   slv2hst_last;
  u32   slv2hst_data;
} HBI_HOST_CONTROL;

typedef struct hbi_slave_control
{
  u32   slave_magic;

  u32   slave_revision;

  u32   hst2slv_head;
  u32   hst2slv_tail;
  u32   hst2slv_last;
  u32   hst2slv_data;

  u32   slv2hst_head;
  u32   slv2hst_tail;
  u32   slv2hst_last;
  u32   slv2hst_data;
} HBI_SLAVE_CONTROL;


#define BBDHBI_HCMD_RSTREQ              (0xbbd0)
#define BBDHBI_HCMD_DLREQ               (0xbbd3)
#define BBDHBI_HCMD_RUNREQ              (0xbbd7)
#define BBDHBI_HCMD_DLCOMP              (0xbbd9)

#define BBDHBI_SLAVE_PWRUP              (0xb000)
#define BBDHBI_SLAVE_RESET              (0xb002)
#define BBDHBI_SLAVE_DLACK              (0xb004)
#define BBDHBI_SLAVE_DLOK               (0xb006)
#define BBDHBI_SLAVE_RUNACK             (0xb008)
#define BBDHBI_SLAVE_LICERR             (0xb00a)
#define BBDHBI_SLAVE_RUNERR             (0xb00b)
#define BBDHBI_SLAVE_RFAILED            (0xb00c)
#define BBDHBI_SLAVE_ACTIVE             (0xb00d)
#define BBDHBI_SLAVE_LICCRP             (0xb00f)
#define BBDHBI_SLAVE_FAILED             (0xb010)

/*
 * SS7HD extra board failure values.
 * Returned to the host in the upper 16 bits of the board status register.
 */
#define BBDHBI_SLAVE_FAILED_HBI_HW	(0x0001)
#define BBDHBI_SLAVE_FAILED_HBI_SW	(0x0002)
#define BBDHBI_SLAVE_FAILED_GCT		(0x0003)
#define BBDHBI_SLAVE_FAILED_SP		(0x0004)
#define BBDHBI_SLAVE_FAILED_CPUEX	(0x0005)
#define BBDHBI_SLAVE_FAILED_POST        (0x0006)
#define BBDHBI_SLAVE_FAILED_WDOG	(0x0007)
#define BBDHBI_SLAVE_FAILED_HBI_CRC_ERROR (0x0008)
#define BBDHBI_SLAVE_FAILED_BAD_ID      (0x0009)
#define BBDHBI_SLAVE_FAILED_BAD_MAGIC   (0x000a)
#define BBDHBI_SLAVE_FAILED_BAD_SP      (0x000b)

#define SUCCESS         (0)
#define QUEUE_EMPTY     (-1)
#define QUEUE_FULL      (-2)


#define SLV_ERROR       (-100)
#define HST_NO_BUFFERS  (-101)
#define SLV_NO_BUFFERS  (-102)
#define SLV_NO_POST     (-103)
#define SLV_INVALID_BUFFER  (-104)


/*
 * Host notification bits
 */
#define HBI_HIB_NEW_STATUS              (0x2)
#define HBI_HIB_XFER_CMPLT              (0x1)

#define BBD_HBI_INT_IB_FREE             (0x0001)
#define BBD_HBI_INT_OB_POST             (0x0002)

#endif
