/*
===========================================================================

    Copyright (C) Dialogic Corporation 2003-2015.
    All Rights Reserved.

    HDLX-NP Linux V2.4.x / V2.6.x Device Driver - Source Code History

    bbdddlnx_iss.h

==========+======+=========================================================
Date      | Name | Description of status / changes
==========+======+=========================================================
12-Mar-03    MH   - Initial file.
13-May-03    IDP  - Removal of FINAL flag
13-May-03    IDP  *** RELEASE V0.02 *** Required SSDH >= V0.04
21-May-03    IDP  - Changed references from Bluebird to SS7HD
21-May-03    IDP  *** RELEASE V0.03 *** Required SSDH >= V0.04
22-May-03    IDP  - Removal of delay from driver
22-May-03    IDP  *** RELEASE V0.04 *** Required SSDH >= V0.04
24-May-03    IDP  - Addition of code to display PCI slot size
27-May-03    GNK  *** RELEASE V0.05 *** 
24-May-03    IDP  - Addition of bbd_isr.c - use of interrupts
                  [ requres SSDH source release >= 0.08 ]
                  - Replace DRV_DEBUG with __DEBUG__ flag       
                  - Change from use of <malloc.h> to <slab.h>
27-May-03    GNK  *** RELEASE V0.06 *** 
05-Jun-03    IDP  - Run mode added
                  [ requres SSDH source release >= 0.09 ]
10-Jun-03    IDP  - Clear all 21555 scratchpad regs during reset
11-Jun-03    IDP  *** RELEASE V0.07 ***
11-Jun-03    IDP  - Check subvendor and subdevice IDs during module load
13-Jun-03    IDP  - Call mem_map_reserve for memory allocated for DMA
13-Jun-03    IDP  *** RELEASE V0.08 ***
17-Jun-03    IDP  - Removal of debug output for release
17-Jun-03    IDP  *** RELEASE V0.09 ***
19-Jun-03    IDP  - Always mark device as empty when exiting rx_buffers_free
                  - Dont clear RX interrupt bit in POLL routine
19-Jun-03    IDP  *** RELEASE V0.10 ***
17-Jul-03    IDP  - Added cPCI sub device id
                  - Use new HBI mechanism.
19-Jun-03    IDP  - Make all devbug dependant on __DEBUG__ flag
19-Jun-03    IDP  *** RELEASE V0.11 **
29-Sep-03    IDP  - Move to new method of PCI device discovery
30-Sep-03    IDP  *** RELEASE V0.12 **
09-Oct-03    IDP  - Move to interrupt compatible spin locks
                    Use REMAP_PAGE_RANGE macro to hide API change
09-Oct-03    IDP  *** RELEASE V0.13 **

16-Oct-03    IDP  - Whole number release for code review
16-Oct-03    IDP  *** RELEASE V1.00

26-Feb-04    IDP  - Make REMAP_PAGE_RANGE macro work on RHEL
26-Feb-04    IDP  *** RELEASE V1.01

08-Mar-04    IDP  - Bug fix logic hole in the driver poll function.
08-Mar-04    IDP  *** RELEASE V1.02

13-Apr-04    IDP  - Updates for hotswap events
13-Apr-04    IDP  *** RELEASE V1.03

28-Apr-04    IDP  - Bug fix to fully cleanup if no board present when driver
                     is loaded
28-Apr-04    IDP  *** RELEASE V1.04

14-May-04    GNK  - Work around re-introduced for the diferent remap_page_range
                    parmeters used by RedHat EL.
14-May-04    GNK  *** RELEASE V1.05

20-Apr-05    GNK  - Prepare source code for release.
                  - Add support for Linux 2.6
03-May-05    GNK  *** RELEASE V1.06
20-Nov-05     IS  - Support for Linux HSK and RH

21-Dec-05    SH   - Support for 32-bit IOCTLs on x86_64 hardware.
                  - Spinlocks around the IOCTL handler - needed for
                    compat_ioctl and will also allow the BKL to be removed
                    in the future.
                  - Bug fix: call pci_enable_device() and pci_disable_device()
                    to fix ACPI PCI IRQ routing problems on kernels >= 2.6.10.
                  *** RELEASE V1.08
25-Jan-06    SH   - HSK support
                  *** RELEASE V1.09

03-Feb-06    PL   - Bug fix - BBD_suspend was not called on some kernels
             GNK  - Update copyright year
                  *** RELEASE V1.10

13-Apr-06    SH   - Moved the spin_lock_irqsave() and spin_unlock_irqsave()
                    calls in BBD_ioctl() since copy_from_user() and
                    copy_to_user() are illegal when interrupts are disabled.
                    Fixes RHEL4 support.
                  *** RELEASE V1.11
23-May-06    GK   - CN DPK\124: Update install script to delete the 255 device node.
                  - CN DPK\124: Increase number of device nodes created to 16 [was 4]
                  *** RELEASE V1.12
31-Aug-06    SH   - CN DPK\135: Added usage information to scripts
                  *** RELEASE V1.13

01-May-07    GNK  - Update copyright banners
                  - CN DPK\156 - Re-run driver 'install' script destroys nodes
                  *** RELEASE V1.14
13-Jul-07    SH   - Fix driver for kernels >= 2.6.18 and add sysfs support
                    (allows auto /dev node creation by udev)
08-Nov-07    MH   *** RELEASE V1.15

11-Nov-07    MH   - Work-around for pci_module_init() changing from 'deprecated' to
                    being removed.
11-Nov-07    MH   *** RELEASE V1.16

12-Nov-07         - Add support for SS7HDE boards.
                  - Correct spinklock 'hole' in IOCTL handler.
15-Nov-07    MH   *** RELEASE V1.17

19-Nov-07    IDP  - Use mutex around probe/suspend/open/release/ioctl routines
                    to hotplug atomic issues.
21-Nov-07    MH   - Merge in the PnP mods.
21-Nov-07    MH   *** RELEASE V1.18

22-Nov-07    MH   - Make the SYSFS code compile-time selectable.
26-Nov-07    MH   - CN DPK\205 - 'Linux driver installation scripts wrong!'
26-Nov-07    MH   *** RELEASE V1.19

04-Feb-08    MH   - Update driver license to Dual GPL V2.00/BSD.
                  - CN DPK/210 - Report library version number.
                    (Rename this file to bbdddlnx_iss.h).
04-Feb-08    MH   *** RELEASE V1.20

16-Dec-09    MH   - CN DPK/313 - Driver does not compile on later kernels.
19-Jan-10    MH   *** RELEASE V1.21

06-Apr-11    MH   - Support DSI banner.
06-Apr-11    MH   *** RELEASE V1.22

19-Apr-11    MH   - Update install + build scripts to specify /bin/bash.
06-Apr-11    MH   *** RELEASE V1.23

01-Aug-11    IDP  - CN455DPK - Remove warnings on later kernels
01-Aug-11    IDP  - CN397DPK - Remove BBD from debug / output
01-Aug-11    IDP  - CN495DPK - Fix build under Debian 6.0.2 AMD64
01-Aug-11    IDP  *** RELEASE V1.24

13-Dec-11    IDP  - CN493DPK - Fix build under 3.x kernels
13-Dec-11    IDP  - CN524DPK - Dont delete device nodes on reinstall
13-Dec-11    IDP  *** RELEASE V1.25

29-Oct-13    IDP  - CN045BBD - Support read slave info IOCTL
29-Oct-13    IDP  *** RELEASE V1.26

08-Sep-15    IDP  - CN717DPK - Support RHEL7
08-Sep-15    IDP  *** RELEASE V1.27
==========+======+=========================================================
*/

#ifndef __BBDDDLNX_ISS_H__
#define __BBDDDLNX_ISS_H__

#define BBDDDLNX_MAJ        (1)
#define BBDDDLNX_MIN        (27)

#define COPYRIGHT_BEGIN     (2003)

#endif
