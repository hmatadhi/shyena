/*
                Copyright (C) Dialogic Corporation 2002-2013.
                All Rights Reserved.

 Name:          bbd_pro.h

 Description:   Internal prototypes for Bluebranch

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    07-Jan-03   IDP   - Initial file.
   B    30-May-03   IDP   - Additional interrupt functions
   C    05-Jun-03   IDP   - Addition of set run mode ioctl
   1    16-Oct-03   IDP   - Whole number release for code review
   2    13-Apr-04   IDP   - Added read/write config space
   3    10-Jan-05   GNK   - Prepare for source code release.
        20-Apr-05   IS    - Add Linux 2.6 kernel support
   -    01-May-07   GNK   - Update copyright banner.
   -    13-Jul-07   SH    - Fix driver for kernels >= 2.6.18 and add sysfs
                            support (allows auto /dev node creation by udev)
   -    29-Oct-13   IDP   - CN045BBD Support read slave info IOCTL
*/

/*
 * bbd_ioc.c:
 */
int BBD_reset_environment(BBD_BOARD *);
int BBD_assert_reset(BBD_BOARD *Pbbd, u16 slv_id);
int BBD_deassert_reset(BBD_BOARD *Pbbd, u16 slv_id);
int BBD_test_reset_complete(BBD_BOARD *Pbbd, u16 slv_id);
int BBD_put_cmd(BBD_BOARD *Pbbd, u16 slv_id, u16 command);
int BBD_get_status(BBD_BOARD *Pbbd, u16 slv_id, u16 *np_stat, u16 *cg_stat);
int BBD_run_mode(BBD_BOARD *Pbbd, u16 slv_id, u32 mode);
int BBD_read_hotswap(BBD_BOARD *Pbbd, u32 *state);
int BBD_detach_cpci(BBD_BOARD *Pbbd);
int BBD_attach_cpci(BBD_BOARD *Pbbd);
int BBD_read_pciconfig(BBD_BOARD *Pbbd);
int BBD_geog_address(BBD_BOARD *Pbbd, u32 *g_addr);
int BBD_read_bar(BBD_BOARD *Pbbd, int, u32, u32, u32 *);
int BBD_write_bar(BBD_BOARD *Pbbd, int, u32, u32, u32);
int BBD_read_cfg(BBD_BOARD *Pbbd, int regnum, u32 *data);
int BBD_write_cfg(BBD_BOARD *Pbbd, int regnum, u32 data);
int BBD_get_board_info(BBD_BOARD *Pbbd, BBD_BOARD_INFO *Pinfo);
int BBD_get_slave_info(BBD_BOARD *Pbbd, BBD_SLAVE_INFO *Pinfo);

/*
 * bbd_pci.c
 */
int pci_memory_size(struct pci_dev *pci,
                    unsigned int region,
                    int type,
                    unsigned long *addr,
                    unsigned long *size);
int PCIReadConfig_8(struct pci_dev *, u8 off, u8  *val);
int PCIReadConfig16(struct pci_dev *, u8 off, u16 *val);
int PCIReadConfig32(struct pci_dev *, u8 off, u32 *val);
int PCIWriteConfig_8(struct pci_dev *, u8 off, u8  val);
int PCIWriteConfig16(struct pci_dev *, u8 off, u16 val);
int PCIWriteConfig32(struct pci_dev *, u8 off, u32 val);
int PCIReadConfigSpace(struct pci_dev *, u32 *);
int PCIWriteConfigSpace(struct pci_dev *, u32 *);

void BBD_isr_tasklet(unsigned long data);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
void BBD_isr(int irq, void *data, struct pt_regs *regs);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
irqreturn_t BBD_isr(int irq, void *data, struct pt_regs *regs);
#else
irqreturn_t BBD_isr(int irq, void *data);
#endif

/*
 * bbd_isr.c
 */
void BBD_enable_slave_interrupts(BBD_BOARD *Pbbd);
void BBD_disable_slave_interrupts(BBD_BOARD *Pbbd);

/*
 * bbd_hs.c
 */
int BBD_read_hotswap(BBD_BOARD *Pbbd, u32 *State);
int BBD_detach_cpci(BBD_BOARD *Pbbd);
int BBD_attach_cpci(BBD_BOARD *Pbbd);


#if 0
#define DEBUG1(fmt, args...) printk(fmt, ## args)
#else
#define DEBUG1(fmt, args...)
#endif

