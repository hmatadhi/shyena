/*
                Copyright (C) Dialogic Corporation 2002-2007.
                All Rights Reserved.

 Name:          bbd_pci.c

 Description:   PCI config space accessor functions

 Functions:     pci_memory_size()       
                PCIWriteConfigSpace()   PCIReadConfig_8()
                PCIReadConfig16()       PCIReadConfig32()
                PCIWriteConfig_8()      PCIWriteConfig16()
                PCIWriteConfig32()
                PCIReadConfigSpace
                PCIWriteConfigSpace

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Apr-02   MH    - Initial file - based on pcituil.c from SEPTEL.
   1    16-Oct-03   IDP   - Bump to whole number for code review
   2    13-Apr-04   IDP   - Addition of read/write config functions
   3    24-Jan-05   GNK   - Prepare for source code release.
   -    01-May-07   GNK   - Update copyright banner.
 */

/*
 * Required for the module definitions
 */

#include "bbd_def.h"
#include "bbd_pro.h"

/*
 * pci_memory_size - Returns the size of memory associated with a region
 *
 * parameters
 *   pci       - PCI device structure of board
 *   region     - region to be read
 *   type       - ???
 *   addr       - return base of memory region ???
 *   size       - return the size of memory
 *
 * returns
 *   success    - ZERO
 *   failure    - 1
 *
 * Note
 * The memory type is also checked
 */
int pci_memory_size(struct pci_dev *pci,        unsigned int region,
                    int type,                   unsigned long *addr,
                    unsigned long *size)
{
  u32 tmp_reg;
  u32 val_reg;

  /*
   * Determine memory requirements as per PCI spec
   */
  if (pci_read_config_dword(pci, region, &tmp_reg) != 0)
    return(1);

  if (pci_write_config_dword(pci, region, 0xffffffff) != 0)
    return(1);
  if (pci_read_config_dword(pci, region, &val_reg) != 0)
    return(1);

  if (pci_write_config_dword(pci, region, tmp_reg) != 0)
    return(1);

  if ((val_reg & PCI_BASE_ADDRESS_SPACE) != type)
    return(1);

  if (type == PCI_BASE_ADDRESS_SPACE_MEMORY)
  {
    *size = (~(val_reg & PCI_BASE_ADDRESS_MEM_MASK)) + 1;
  }
  else
  {
    *size = (~(val_reg & PCI_BASE_ADDRESS_IO_MASK)) + 1;
  }

  *addr = tmp_reg;

  return(0);
}

/*
 * PCIReadConfigxx  - Read PCI card config space
 *
 * parameters
 *   pci        - PCI device structure of board
 *   off        - offset ???
 *   val        - return variable for the value read
 *
 * Returns
 *   success - Zero
 *   failure - 1
 */
int PCIReadConfig_8(struct pci_dev *pci, u8 off, u8 *val)
{
  if (pci_read_config_byte(pci, off, val) != 0)
    return(1);

  return(0);
}

int PCIReadConfig16(struct pci_dev *pci, u8 off, u16 *val)
{
  if (pci_read_config_word(pci, off, val) != 0)
    return(1);

  return(0);
}

int PCIReadConfig32(struct pci_dev *pci, u8 off, u32 *val)
{
  if (pci_read_config_dword(pci, off, val) != 0)
    return(1);

  return(0);
}

/*
 * PCIWriteConfigxx - Write PCI card config space
 *
 * parameters
 *   pci        - PCI device structure of board
 *   off        - offset ???
 *   val        - value to write
 *
 * Returns
 *   success - Zero
 *   failure - 1
 */
int PCIWriteConfig_8(struct pci_dev *pci, u8 off, u8 val)
{
  if (pci_write_config_byte(pci, off, val) != 0)
    return(1);

  return(0);
}

int PCIWriteConfig16(struct pci_dev *pci, u8 off, u16 val)
{
  if (pci_write_config_word(pci, off, val) != 0)
    return(1);
  return(0);
}

int PCIWriteConfig32(struct pci_dev *pci, u8 off, u32 val)
{
  if (pci_write_config_dword(pci, off, val) != 0)
    return(1);

  return(0);
}

/*
 * PCIReadConfigSpace  - Read the entire PCI card config space
 *
 * parameters
 *   pci        - PCI device structure of board
 *   data       - data into which config data is to be read 
 *
 * Returns
 *   success - Zero
 *   failure - 1
 */
int PCIReadConfigSpace(struct pci_dev *pci, u32 *data)
{
  int cnt;

  cnt = 0;
  while (cnt != 64)
  {
    if (pci_read_config_dword(pci, cnt * 4, data + cnt) != 0)
      return(1);
    cnt++;
  }
  return(0);
}

/*
 * PCIWriteConfigSpace  - Write the entire PCI card config space back
 *
 * parameters
 *   pci        - PCI device structure of board
 *   data       - data to be written
 *
 * Returns
 *   success - Zero
 *   failure - 1
 */
int PCIWriteConfigSpace(struct pci_dev *pci, u32 *data)
{
  int cnt;

  cnt = 0;
  while (cnt != 64)
  {
    if (pci_write_config_dword(pci, cnt * 4, data[cnt]) != 0)
      return(1);
    cnt++;
  }
  return(0);
}

