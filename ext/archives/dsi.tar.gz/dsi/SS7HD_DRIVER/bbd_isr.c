/*
                Copyright (C) Dialogic Corporation 2002-2007.
                All Rights Reserved.

 Name:          bbd_isr.c

 Description:   isr file for the BBD Linux device driver

 Functions:     BBD_enable_slave_interrupts
                BBD_disable_slave_interrupts
                BBD_isr
                BBD_tasklet

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    27-May-03   IDP   - Taken from Linux HSP device driver
   B    09-Oct-03   IDP   - Change spin locks to irq compatible ones
   1    16-Oct-03   IDP   - Bump to whole number for code review
   2    20-Apr-05   GNK   - Prepare for source code release.
                    IS    - Add Linux 2.6 kernel support
   -    01-May-07   GNK   - Update copyright banner.
   -    13-Jul-07   SH    - Fix driver for kernels >= 2.6.18 and add sysfs
                            support (allows auto /dev node creation by udev)
        19-Nov-07   IDP   - Use board open field
 */

#include "bbd_def.h"

extern BBD_BOARD bbd_boards[];

/*
 * Define to hold all the int bits we mask on/off at the start
 */
#define BBD_INT_MASK_ALL (BBD_HBI_INT_IB_FREE | BBD_HBI_INT_OB_POST)

/*
 * BBD_enable_slave_interrupts - Enable the bbd card to generate 
 *      interupts to the host.
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   none
 */
void BBD_enable_slave_interrupts(BBD_BOARD *Pbbd)
{
  DRV_DEBUG(("%s(%i)\n", __FUNCTION__, Pbbd->board_number));

  /*
   * Enable the following bits in the output mask
   * On the 21555 the mask / unmask actions are atomic thus we do NOT need
   * to spin lock while we do this
   */
  BBD_HST_IRQ_UNMASK(Pbbd, BBD_HBI_INT_OB_POST);
}

/*
 * BBD_disable_slave_interrupts - Disable the bbd cards ability to 
 *      generate host interrupts
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   none
 */
void BBD_disable_slave_interrupts(BBD_BOARD *Pbbd)
{
  DRV_DEBUG(("%s(%i)\n", __FUNCTION__, Pbbd->board_number));

  /*
   * Disable the following bits in the output mask
   * On the 21555 the mask / unmask actions are atomic thus we do NOT need
   * to spin lock while we do this
   */
  BBD_HST_IRQ_MASK(Pbbd, BBD_INT_MASK_ALL);
}

/*
 * BBD_isr - Routine called to process a hardware interrupt
 *
 * parameters
 *   irq        - Interrupt ID
 *   data       - value passed as data with interrupt
 *   regs       - not used
 *
 * returns
 *   none
 *
 * Notes
 *  Routine checks card for interrupt requests and schedules a bottom half int
 *  if required
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
void BBD_isr(int irq, void *data, struct pt_regs *regs)
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
irqreturn_t BBD_isr(int irq, void *data, struct pt_regs *regs)
#else
irqreturn_t BBD_isr(int irq, void *data)
#endif
{
  unsigned long flags;  /* spinlock flags */
  BBD_BOARD *Pbbd;      /* memory area for this board */
  u16 val;              /* set of interrupts currently pending*/
  u16 msk;              /* set of currently masked interrupts */

  /*
   * The value passed as data was given by us when the interrupt was requested
   * As we are on a shared interrupt, we could be called when other equipment
   * requires servicing. As we allocate the bbd device structures from 
   * kernel memory their logical address will be unique.
   */
  Pbbd = (BBD_BOARD *)data;
  if ((Pbbd < &bbd_boards[0]) || (Pbbd >= &bbd_boards[BBD_MAX_BOARDS]))
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    return;
#else
    return IRQ_NONE;
#endif
  }

  /*
   * Open count is only incremented before the interrupt is enabled and only
   * decremented after the interrupt is disabled so this is a safe test
   */
  if (Pbbd->brd_open)
  {
    spin_lock_irqsave(&Pbbd->bbd_lock, flags);

    /*
     * Read the Interrupt register
     * Write back this masked value to the interrupt mask register to mask off
     * these interrupts.
     * OR the value we have just received with the current tasklet copy.
     *
     * Note - ALL the currently active interrupts are masked off not just the
     * ones we are interested in.
     */
    val = BBD_GET_HST_IRQ_STATE(Pbbd);
    msk = BBD_GET_HST_IRQ_MASK(Pbbd);

    BBD_HST_IRQ_MASK(Pbbd, val);

    Pbbd->host_int |= (val & ~msk);

    if (Pbbd->host_int)
    {
      tasklet_schedule(&Pbbd->tlet);
    }
    spin_unlock_irqrestore(&Pbbd->bbd_lock, flags);
  }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  return;
#else
  return IRQ_HANDLED;
#endif
}

/*
 * BBD_isr_tasklet - Routine scheduled by the isr tophalf if attention 
 *      is required.
 *
 * parameters
 *   pbbd        - memory area for this board
 *
 * returns
 *   none
 *
 */
void BBD_isr_tasklet(unsigned long data)
{
  BBD_BOARD *Pbbd;

  Pbbd = (BBD_BOARD *)data;

  wake_up_interruptible(&Pbbd->wait);
}
