#!/bin/bash
#
#                       Copyright (C) Dialogic Corporation 2005-2011
#                       All Rights Reserved.
#
#   File:               install_ss7hd.sh
#
#   Script to install:  Linux SS7HD device driver.
#   for use with:       Linux 2.4.x or Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1     20-Apr-05   GK  - First version for external release
#     2     23-May-06   GK  - Update to: delete 255 device node
#                             create and remove 16 device nodes
#           31-Aug-06   SH  - Added usage information
#           26-Nov-07   MH  - Change shell type to /bin/sh (/bin/bash).
#                           - CN DPK\205 - 'Correct node creation'.
#                           - Update copyright notice.
#           06-Apr-11   MH  - Add 'create-devnode' command
#                           - Un-BASHify.
#           17-Nov-11   IDP - CN524DPK - Correct node removal on insert
#           13-Dec-11   IDP - CN493DPK - Fix install for linux 3.x
#
#   Usage:
#     ./install_ss7hd.sh                - Load device driver module and create
#                                         device nodes
#     ./install_ss7hd.sh remove         - Unload device driver and delete
#                                         device nodes
#     ./install_ss7hd.sh create-devnode - Create the device nodes

# look up the version string
OS_VER=`uname -r`

# and read the minor version number
MAJVER=`echo $OS_VER | cut -f 1 -d "."`
MINVER=`echo $OS_VER | cut -f 2 -d "."`

DRIVER_NAME="ss7hddvr"
NODE_NAME="ss7hd"
DEVICE_NAME="SS7HD"
MAX_NODENUM=15

# Function - Load the driver module
load_driver()
{
  /sbin/insmod -f ./${MODULE_NAME}${MODULE_EXT} || exit 1
}

# Function - Unload the driver module
unload_driver()
{
  /sbin/rmmod ${MODULE_NAME} || exit 1
}

# Function - Create the device nodes
create_devnodes()
{
  # determine the major device number and add the nodes
  MAJOR=`cat /proc/devices | awk "\\$2==\"${DEVICE_NAME}\" {print \\$1}"`

  node_num=0
  while [ $node_num -le $MAX_NODENUM ]
  do
    mknod -m0666 /dev/${NODE_NAME}$node_num c ${MAJOR} $node_num
    node_num=`expr $node_num + 1`
  done
  # Create the control device node
  mknod -m0666 /dev/${NODE_NAME}255 c ${MAJOR} 255
}

# Function - Remove all added device nodes
remove_devnodes()
{
  rm -f /dev/${NODE_NAME}* > /dev/null
}

# Determine the kernel specific module name and extention
case "$MAJVER" in
  "2")
    case "$MINVER" in
      "4")
        MODULE_NAME="${DRIVER_NAME}-${OS_VER}"
        MODULE_EXT=".o"
        ;;

      "6")
        MODULE_NAME="${DRIVER_NAME}26"
        MODULE_EXT=".ko"
        ;;

      *)
        echo Unsupported kernel revision $MAJVER.$MINVER
        exit 1
        ;;
    esac
    ;;

  "3")
    MODULE_NAME="${DRIVER_NAME}3x"
    MODULE_EXT=".ko"
    ;;

  *)
    echo Unsupported kernel revision $MAJVER.$MINVER
    exit 1
    ;;
esac

# Determine if the driver is already loaded.
found=`grep -c $DRIVER_NAME /proc/modules`
if [ '0' = $found ]
then
  driver_loaded=0
else
  driver_loaded=1
fi

# Do the action requested by the user
case "$1" in
  "remove")
    remove_devnodes
    if [ $driver_loaded = 0 ]
    then
      echo "Error: $DEVICE_NAME driver not loaded."
      exit 1
    fi
    unload_driver
    ;;

  "create-devnode")
    remove_devnodes
    create_devnodes
    ;;

  *)
    if [ $driver_loaded = 1 ]; then
      echo "Error: $DEVICE_NAME driver loaded."
      exit 1
    fi
    load_driver
    remove_devnodes
    create_devnodes
    ;;
esac

