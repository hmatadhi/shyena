/*
                Copyright (C) Dialogic Corporation 2002-2013.
                All Rights Reserved.

 Name:          bbd_inc.h

 Description:   IOCTL interface to the BBD Linux device driver.


 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Apr-02   MH    - Initial file
   B    30-May-03   IDP   - Additional values required for interrupts
   C    05-Jun-03   IDP   - Addition of set run mode ioctl
   1    16-Oct-03   IDP   - Whole number release for code review
   2    10-Jan-05   GNK   - Prepare for source code release.
        27-Oct-05   MH    - Reinstate PCI configuration space IOCTLs.
   -    01-May-07   GNK   - Update copyright banner.
   -    29-Oct-13   IDP   - CN045BBD Support read slave info IOCTL.
 */

/*
 * Define a starting point for our IOCTL commands
 */
#define BBD_BASE                   ('s' << 8)

#define BBDIOC_ASSERT_RESET        (BBD_BASE +  0)
#define BBDIOC_DEASSERT_RESET      (BBD_BASE +  1)
#define BBDIOC_TEST_RESET_COMPLETE (BBD_BASE +  2)
#define BBDIOC_PUT_CMD             (BBD_BASE +  3)
#define BBDIOC_GET_STATUS          (BBD_BASE +  4)
#define BBDIOC_DEVICE_INFO         (BBD_BASE +  5)
#define BBDIOC_RUN_MODE            (BBD_BASE +  6)
#define BBDIOC_READ_HOTSWAP        (BBD_BASE +  7)
#define BBDIOC_DETACH_CPCI         (BBD_BASE +  8)
#define BBDIOC_ATTACH_CPCI         (BBD_BASE +  9)
#define BBDIOC_DUMMY_DUMMY_DUMMY   (BBD_BASE + 10) /* was BBDIOC_READ_PCICONFIG */
#define BBDIOC_GEOG_ADDRESS        (BBD_BASE + 11)
#define BBDIOC_READ_BAR            (BBD_BASE + 12)
#define BBDIOC_WRITE_BAR           (BBD_BASE + 13)
#define BBDIOC_READ_CFG            (BBD_BASE + 14)
#define BBDIOC_WRITE_CFG           (BBD_BASE + 15)
#define BBDIOC_READ_BOARDINFO      (BBD_BASE + 16)
#define BBDIOC_READ_SLAVEINFO      (BBD_BASE + 17)

#define HS_BOARD_REMOVED        (0x00)
#define HS_BOARD_INSERTED       (0x01)
#define HS_EXTRACT_REQUEST      (0x02)

/*
 * Structures defining the data passed between userland and kernel for
 * the various IOCTL calls
 */
typedef struct
{
  int result;
  u16 slv_id;
} BBD_SLAVE_ID;

typedef struct
{
  int result;
  u16 slv_id;
  u16 cmd;
} BBD_PUT_CMD;

typedef struct
{
  int result;
  u16 slv_id;
  u16 s_status;
  u16 c_status;
} BBD_GET_STATUS;

typedef struct
{
  int result;
  u8  driver_major;
  u8  driver_minor;
  u16 subdevice;
} BBD_DEVICE_INFO;

typedef struct
{
  int result;
  u32 state;
} BBD_READ_HOTSWAP;

typedef struct
{
  int result;
  u32 g_addr;
} BBD_GEOG_ADDRESS;

typedef struct
{
  int result;
  int bar;
  u32 value;
  u32 offset;
  u32 length;
} BBD_BAR_RW;

typedef struct
{
  int result;
  int reg;
  u32 value;
} BBD_CFG_RW;

typedef struct
{
  int result;
  u16 slv_id;
  u32 mode;
} BBD_RUN_MODE;

typedef struct
{
  int result;
  u16 board_id;
  u16 slv_id;
  u32 board_presence_mask;
  u32 driver[6];
  u32 board[16];
} BBD_BOARD_INFO;

typedef struct
{
  int result;
  u16 board_id;
  u16 slave_id;
  u32 offset;
  u32 length;
  u8  buffer[64];
} BBD_SLAVE_INFO;

/*
 * Union holding all the IOCTL structures
 */
typedef union
{
  int                result;
  BBD_SLAVE_ID       slave_id;
  BBD_PUT_CMD        put_cmd;
  BBD_GET_STATUS     get_status;
  BBD_DEVICE_INFO    device_info;
  BBD_READ_HOTSWAP   read_hotswap;
  BBD_GEOG_ADDRESS   geog_address;
  BBD_BAR_RW         bar_rw;
  BBD_CFG_RW         cfg_rw;
  BBD_RUN_MODE       run_mode;
  BBD_BOARD_INFO     board_info;
  BBD_SLAVE_INFO     slave_info;
} BBD_IOCTL_PARAMS;

/*
 * Linux driver success/failure codes
 */
#define LNXSLV_SUCCESS         (0)
#define LNXSLV_DRIVER_ERROR    (1)
#define LNXSLV_NOT_COMPLETE    (2)
#define LNXSLV_BOARD_FAILURE   (3)

/*
 * Macros for decomposing geographic addressing address ???
 */
#define BBD_ADDR_SWX(addr)     ((addr >> 24) & 0xff)
#define BBD_ADDR_SLOT(addr)    ((addr >> 16) & 0xff)
#define BBD_ADDR_SHELF(addr)   ((addr >>  8) & 0xff)
#define BBD_ADDR_GEOG(addr)    ( addr        & 0xff)
