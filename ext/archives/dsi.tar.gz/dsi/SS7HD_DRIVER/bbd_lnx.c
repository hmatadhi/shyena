/*
                Copyright (C) Dialogic Corporation 2002-2015.
                All Rights Reserved.

 Name:          bbd_lnx.c

 Description:   Main entry file for the BBD Linux device driver.

 Functions:     init_module
                cleanup_module

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Apr-02   MH    - Initial file.
   B    19-Jan-03   IDP   - Addition IOCTL commands & support added
   C    21-May-03   IDP   - Changed module loading banner
   D    24-May-03   IDP   - Addition code to indicate PCI slot width
   E    30-May-03   IDP   - Additional resources added for interrupts
   F    05-Jun-03   IDP   - Addition of set run mode ioctl
   G    11-Jun-03   IDP   - Check subvendor ID and subdevice ID
   H    13-Jun-03   IDP   - Reserve and unreserve memory mapped pages
   I    17-Jun-03   IDP   - Remove unapproved debug output for release
   J    19-Jun-03   IDP   - Dont clear the RX interrupt bit in the poll routine
   K    19-Sep-03   GNK   - All tracing dependant on __DEBUG__ flag.
   L    09-Oct-03   IDP   - Change spin locks to irq compatible ones
                            Use REMAP_PAGE_RANGE macro due to API change
   1    16-Oct-03   IDP   - Bump to whole number for code review
   2    13-Apr-04   IDP   - Read config space for hot swap
   3    28-Apr-04   IDP   - Cleanup properly if module installed but no card
                            present
   4    12-Apr-05   GNK   - Prepare for source code release. Remove
                            BBDIOC_READ_CFG, BBDIOC_WRITE_CFG &
                            BBDIOC_READ_PCICONFIG commands
        20-Apr-05   IS    - Add Linux 2.6 kernel support
                          - Add automatic assignment of major device number
        27-Oct-05   MH    - Reinstate the PCI configuation space access
                            IOCTLs.
        19-Dec-05   SH    - x86_64 fixups
                          - Added calls to pci_enable_device() and
                            pci_disable_device(). Should've been done anyway
                            but causes ACPI IRQ routing problems under kernels
                            >= 2.6.10.
        03-Feb-06   PL    - Bug fix - BBD_suspend was not called on some kernels
                    GNK   - Update copyright year
        13-Apr-06   SH    - Fixed ioctl locking (nolonger disables interrupts)
   -    01-May-07   GNK   - Update copyright banner.
   -    13-Jul-07   SH    - Fix driver for kernels >= 2.6.18 and add sysfs
                            support (allows auto /dev node creation by udev)
        11-Nov-07   MH    - Work-around removal of pci_module_init() from 
                            2.6.19 and newer 
                            kernels.
        12-Nov-07   MH    - Spin-lock error corrected. 
                            Error introduced in V1.15
                          - Support SS7HDE board types.
        19-Nov-07   IDP   - Add mutex around board accesses so that hotplug
                            events are handled atomically
        23-Nov-07   IDP   - Move open mutex around open & present tests
        04-Feb-08   MH    - Change driver license to Dual BSD/GPL V2.
        16-Dec-09   MH    - DPK CN/313 - Driver does compile on later kernels
        19-Jan-10   MH    - Update copyright year.
        01-Aug-11   IDP   - CN455DPK - Remove warnings on later kernels
        01-Aug-11   IDP   - CN397DPK - Remove BBD from debug / output
        01-Aug-11   IDP   - CN495DPK - Fix build on later kernels
        13-Dec-11   IDP   - CN493DPK - Fix build on 3.x kernels
        29-Oct-13   IDP   - CN045BBD - Support read slave info IOCTL
        01-Sep-15   IDP   - CN717DPK - Support Centos 7
 */


/*
 * Include files Required for the module definitions
 */
#include <linux/version.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18)
#ifdef BBDDDLNX_SYSFS
#define REGISTER_SYSFS
#endif
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19)
#define pci_module_init     pci_register_driver
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/config.h>
#endif

#include <linux/module.h>

#if defined(MODVERSIONS)
#include <linux/modversions.h>
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#include <linux/wrapper.h>
#else /* >= 2.6.0 */
#include <linux/mm.h>
#include <linux/moduleparam.h>
#define mem_map_reserve(p)   SetPageReserved(p)
#define mem_map_unreserve(p) ClearPageReserved(p)
#undef MOD_INC_USE_COUNT
#undef MOD_DEC_USE_COUNT
#define MOD_INC_USE_COUNT try_module_get(THIS_MODULE)
#define MOD_DEC_USE_COUNT module_put(THIS_MODULE)
#endif /* < 2.6.0 */

#include <linux/init.h>
#include <linux/delay.h>
#if (defined(__x86_64__)) && (! defined(HAVE_COMPAT_IOCTL))
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,15)
    #include <asm/ioctl32.h>
  #endif
  #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    #include <linux/syscalls.h>
  #endif
  #define register_ioctl32_conversion_cast(x,y) register_ioctl32_conversion((x), \
    (int(*)(unsigned int,unsigned int,unsigned long,struct file*))(y))
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,7,0)
#define VM_RESERVED 0
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
#define __devinitdata
#endif

/*
 * SS7HD header files
 */
#include "bbd_def.h"
#include "bbd_pro.h"
#include "bbd_hbi.h"

#ifndef BBDDDLNX_SOURCE_VERSION
#include "prod_rel.h"
#endif

#ifndef IRQF_SHARED
#define IRQF_SHARED SA_SHIRQ
#endif

#ifndef init_MUTEX
#define init_MUTEX(_m) sema_init(_m,1)
#endif

/*
 * Per board structure to hold all details of the card
 */
BBD_BOARD  bbd_boards[BBD_MAX_BOARDS+1];
struct semaphore bbd_mutex[BBD_MAX_BOARDS];

BBD_BOARD *Pmanager = NULL;

static u32 boards_present = 0;
static int eventcount = 0;
static int lastcount = 0;
#ifdef REGISTER_SYSFS
static struct class * ss7hd_class;
#endif

#define MAP_SIZE (65536 * 2)


/*
 * Local functions
 */
static int BBD_ioctl(struct inode *inode, struct file *file,
                     unsigned int cmd,    unsigned long arg);
#ifdef HAVE_UNLOCKED_IOCTL
static long BBD_unlocked_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif
#ifdef HAVE_COMPAT_IOCTL
static long BBD_compat_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif
static int BBD_open(struct inode *inode, struct file *file);
static int BBD_release(struct inode *inode, struct file *file);
static int BBD_mmap(struct file *file, struct vm_area_struct *vma);
static unsigned int BBD_poll(struct file *file, poll_table *wait);

static int  BBD_probe(struct pci_dev *, const struct pci_device_id *);
static void BBD_remove(struct pci_dev *);
static int BBD_resume(struct pci_dev *dev);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
static int BBD_suspend(struct pci_dev *dev, u32 state);
#else
static int BBD_suspend(struct pci_dev *dev, pm_message_t state);
#endif

/*
 * Major number the device driver is registered as.
 * Can be changed by the user on the module load command line.
 */
static unsigned int majno = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
MODULE_PARM(majno, "i");
EXPORT_NO_SYMBOLS;
#else
module_param(majno, int, 0);
#endif


/*
 * Structure holding pointers for the kernel to driver interface
 */
static struct file_operations bbd_fops =
{
  owner:        THIS_MODULE,
  poll:         BBD_poll,
#ifdef HAVE_UNLOCKED_IOCTL
  unlocked_ioctl: BBD_unlocked_ioctl,
#else
  ioctl:        BBD_ioctl,
#endif
#ifdef HAVE_COMPAT_IOCTL
  compat_ioctl: BBD_compat_ioctl,
#endif
  open:         BBD_open,
  release:      BBD_release,
  mmap:         BBD_mmap,
};

static int board_status(int board_id, int status)
{
  DEBUG1("board status(%d,%d)\n", board_id, status);
  if (status)
  {
    boards_present |= (1 << board_id);
  }
  else
  {
    boards_present &= ~(1 << board_id);
  }

  if (Pmanager)
  {
    ++eventcount;
    DEBUG1("wake_up_interruptible\n");
    wake_up_interruptible(&Pmanager->wait); // Wake the poll
  }

  return 0;
}

/*
 * BBD_map_bar - Map a PCI BAR region into kernel land
 *
 * Parameters
 *   dev - PCI device
 *   num - BAR number
 *   bar - Local storage
 *
 * Returns
 *   == 0 on success
 *   != 0 on failure
 */
static int BBD_map_bar(struct pci_dev *dev, int num, BBD_PCI_BAR *bar)
{
  bar->base_address = pci_resource_start(dev, num);
  bar->size         = pci_resource_len(dev, num);
  if(bar->size)
  {
    bar->handle = ioremap(bar->base_address, bar->size);
    DEBUG1("H=0x%p BA=0x%lx S=%lu\n", bar->handle, bar->base_address, bar->size);
    if(bar->handle == NULL)
    {
      return(-1);
    }
  }
  return(0);
}

/*
 * BBD_unmap_bar - Remove the Mapping of a PCI BAR region from kernel land
 *
 * Parameters
 *   dev - PCI device
 *   num - BAR number
 *   bar - Local storage
 *
 * Returns
 *   == 0 on success
 */
static int BBD_unmap_bar(struct pci_dev *dev, int num, BBD_PCI_BAR *bar)
{
  if(bar->handle)
  {
    iounmap((void *)bar->handle);
    bar->handle = NULL;
  }
  return(0);
}

/*
 * BBD_allocate_board - Initialise a BBD card on the PCI bus
 *
 * Parameters
 *   dev       - PCI device structure of board
 *   subdev_id - Sub device identifier
 *
 * Returns
 *  zero when the driver has accepted the device
 *  error code (negative number) otherwise
 */
static int BBD_probe(struct pci_dev *dev, const struct pci_device_id *ent)
{
  int board;                    /* the board to be initialised */
  BBD_BOARD *Pbbd;              /* memory area for this board */

  DEBUG1("%s(%p)\n",__FUNCTION__, dev);

  board = 0;
  while(board != BBD_MAX_BOARDS)
  {
    if (bbd_boards[board].pci == NULL) break;
    board++;
  }
  if (board == BBD_MAX_BOARDS)
  {
    return(-1);
  }

  /*
   * Initialise the memory for this board.
   */
  Pbbd = &bbd_boards[board];
  memset(Pbbd, 0, sizeof(BBD_BOARD));

  pci_set_drvdata(dev, Pbbd);

  Pbbd->board_number = board;
  Pbbd->pci = dev;
  Pbbd->subdev_id = ent->subdevice;

  DEBUG1("%s(%i)\n", __FUNCTION__, board);

#ifndef CONFIG_RH
  if(BBD_resume(dev) != 0)
  {
    BBD_remove(dev);
    return(-1);
  }
#endif

  return 0;
}

/*
 * Releases the board resources
 *
 * Parameters
 *   dev - PCI device
 *
 * Returns
 *   None
 */
static void BBD_remove(struct pci_dev *dev)
{
  BBD_BOARD *Pbbd;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
  u32 state = 3;
#else
  pm_message_t state;

  state.event = 3;
#endif

  DEBUG1("%s(%p)\n",__FUNCTION__, dev);

  Pbbd = pci_get_drvdata(dev);
  if(Pbbd == NULL)
  {
    DEBUG1("%s() no board\n",__FUNCTION__);
    return;
  }
  DEBUG1("%s() board=%d\n",__FUNCTION__, Pbbd->board_number);

  BBD_suspend(dev, state);

  memset(Pbbd, 0, sizeof(BBD_BOARD));
  DEBUG1("==== released....\n");
}

/*
 * BBD open routine for a specified board.
 *
 * Parameters
 *   inode     -
 *   file      - File handle pointer
 *
 * Returns
 *  0 on sucess
 *  non zero on failure
 */
static int BBD_open(struct inode *inode, struct file *file)
{
  unsigned int minor;           /* minor devide id for this board */
  BBD_BOARD *Pbbd;              /* memory area for this board */
  int ret;

  /*
   * Derive minor device ID - check in range.
   */
  minor = MINOR(inode->i_rdev);

  DEBUG1("%s(minor=%d)\n",__FUNCTION__, minor);

  if (minor == 255)
  {
    DEBUG1("255 pipeline !\n");
    if (Pmanager)
    {
      DEBUG1("Already controlled\n");
      return(-EBUSY);
    }

    Pmanager = &bbd_boards[BBD_MAX_BOARDS];
    file->private_data = Pmanager;
    memset(Pmanager, 0, sizeof(BBD_BOARD));

    spin_lock_init(&Pmanager->bbd_lock);
    init_waitqueue_head(&Pmanager->wait);

    MOD_INC_USE_COUNT;
    return 0;
  }

  if (minor >= BBD_MAX_BOARDS)
  {
    DEBUG1("> max board !\n");
    return(-ENODEV);
  }

  Pbbd = &bbd_boards[minor];
  DEBUG1("%s() board=%d\n",__FUNCTION__, Pbbd->board_number);

  if (down_interruptible(bbd_mutex + Pbbd->board_number) != 0)
  {
    return(-ERESTARTSYS);
  }

  /*
   * Currently only one owner per board
   */
  if (Pbbd->brd_open)
  {
    up(bbd_mutex + Pbbd->board_number);
    DEBUG1("already open !\n");
    return(-EBUSY);
  }

  /*
   * Only allow open if the card is present
   */
  if (Pbbd->brd_pres == 0)
  {
    up(bbd_mutex + Pbbd->board_number);
    DEBUG1("not present !\n");
    return(-ENODEV);
  }
  else
  {
    /*
     * Record boards memory block, reset the environment for ti and flag as open
     */
    file->private_data = Pbbd;
    BBD_reset_environment(Pbbd);
    Pbbd->brd_open = 1;
    MOD_INC_USE_COUNT;
    ret = 0;
  }
  up(bbd_mutex + Pbbd->board_number);

  return(ret);
}

/*
 * BBD close routine.
 *
 * Parameters
 *   inode     -
 *   file      - File handle pointer
 *
 * Returns
 *  0 on sucess
 *
 */
static int BBD_release(struct inode *inode, struct file *file)
{
  unsigned int minor;           /* minor devide id for this board */
  BBD_BOARD *Pbbd;              /* memory area for this board */
  int ret;

  minor = MINOR(inode->i_rdev);

  DEBUG1("%s(minor=%d)\n",__FUNCTION__, minor);
  if (minor == 255)
  {
    Pmanager = NULL;
    MOD_DEC_USE_COUNT;
    return 0;
  }

  Pbbd = &bbd_boards[minor];
  DEBUG1("%s() board=%d\n",__FUNCTION__, Pbbd->board_number);

  if(down_interruptible(bbd_mutex + Pbbd->board_number) != 0)
  {
    return(-ERESTARTSYS);
  }
  if(Pbbd->brd_pres)
  {
    /*
     * Disable interrupts
     */
    BBD_disable_slave_interrupts(Pbbd);
    ret = 0;
  }
  else
  {
    ret = -1;
  }
  up(bbd_mutex + Pbbd->board_number);
  if(ret) printk("SS7HD[%x] - no hardware in close\n", Pbbd->board_number);
  Pbbd->errordetected = 0;
  Pbbd->brd_open = 0;

  MOD_DEC_USE_COUNT;

  return(0);
}

/*
 * BBD IOCTL routine.
 *
 * Parameters
 *   inode      -
 *   file       - File handle pointer
 *   cmd        - The ioctl commnad being issued
 *   arg        - parameter flor this command
 *
 * Returns
 *  0 on sucess
 *  non zero on failure
 */
static int BBD_ioctl(   struct inode *inode,    struct file *file,
                        unsigned int cmd,       unsigned long arg)
{
  int retval = 0;
  unsigned int minor;           /* minor devide id for this board */
  BBD_BOARD *Pbbd;              /* memory area for this board */
  BBD_IOCTL_PARAMS params;

  /*
   * Convert the minor number into a card structure
   */
  minor = MINOR(inode->i_rdev);

  if (minor == 255)
  {
    //DEBUG1("ioctl on 255 ! (cmd = %d) 0x%x\n", cmd, boards_present);
    if (cmd == BBDIOC_READ_BOARDINFO)
    {
      if (copy_from_user(&params, (void *)arg, sizeof(params.board_info)))
        return(-EFAULT);
      params.board_info.board_presence_mask = boards_present;
      params.board_info.driver[0] = 0;
      params.board_info.driver[1] = 0;
      params.board_info.board[0] = 0;
      if (params.board_info.board_id < BBD_MAX_BOARDS)
      {
        Pbbd = &bbd_boards[params.board_info.board_id];
        if (down_interruptible(bbd_mutex + Pbbd->board_number) != 0)
        {
          retval = -ERESTARTSYS;
        }
        else
        {
          if (Pbbd->brd_pres)
          {
            params.board_info.result = BBD_get_board_info(Pbbd,
                                         &params.board_info);
          }
          else
          {
            params.board_info.result = -1;
          }
          up(bbd_mutex + Pbbd->board_number);
        }
      }
      else
        params.board_info.result = -2;
      if (copy_to_user((void *)arg, &params, sizeof(params.board_info)))
        return(-EFAULT);
    }
    else
      retval = -EFAULT;
    return retval;
  }

  Pbbd = &bbd_boards[minor];

  /*
   * Check arg == NULL here as all our IOCTL calls require the result to be
   * passed back at the very least
   */
  if ((void*)arg == NULL)
    return(-EINVAL);

  /*
   * We need to make a lock here since the new ioctl stuff doesn't
   * automatically get the BKL
   */

  if (down_interruptible(bbd_mutex + Pbbd->board_number) != 0)
  {
    return(-ERESTARTSYS);
  }

  retval = 0;
  /*
   * Calls take the following format :-
   * Copy parameters from user land to kernel land
   * Call the required function
   * Copy results back to user land
   */
  switch (cmd)
  {
    case BBDIOC_ASSERT_RESET:
      if (copy_from_user(&params, (void *)arg, sizeof(params.slave_id)))
        return(-EFAULT);
      params.slave_id.result = BBD_assert_reset(Pbbd, params.slave_id.slv_id);
      if (copy_to_user((void *)arg, &params, sizeof(params.slave_id)))
        return(-EFAULT);
      break;

    case BBDIOC_DEASSERT_RESET:
      if (copy_from_user(&params, (void *)arg, sizeof(params.slave_id)))
        return(-EFAULT);
      params.result = BBD_deassert_reset(Pbbd, params.slave_id.slv_id);
      if (copy_to_user((void *)arg, &params, sizeof(params.slave_id)))
        return(-EFAULT);
      break;

    case BBDIOC_TEST_RESET_COMPLETE:
      if (copy_from_user(&params, (void *)arg, sizeof(params.slave_id)))
        return(-EFAULT);
      params.result = BBD_test_reset_complete(Pbbd, params.slave_id.slv_id);
      if (copy_to_user((void *)arg, &params, sizeof(params.slave_id)))
        return(-EFAULT);
      break;

    case BBDIOC_PUT_CMD:
      if (copy_from_user(&params, (void *)arg, sizeof(params.put_cmd)))
        return(-EFAULT);
      params.result = BBD_put_cmd(Pbbd,
                                  params.put_cmd.slv_id,
                                  params.put_cmd.cmd);
      if (copy_to_user((void *)arg, &params, sizeof(params.put_cmd)))
        return(-EFAULT);
      break;

    case BBDIOC_GET_STATUS:
      if (copy_from_user(&params, (void *)arg, sizeof(params.get_status)))
        return(-EFAULT);
      params.result = BBD_get_status(Pbbd,
                                     params.get_status.slv_id,
                                     &params.get_status.s_status,
                                     &params.get_status.c_status);
      if (copy_to_user((void *)arg, &params, sizeof(params.get_status)))
        return(-EFAULT);
      break;

    case BBDIOC_DEVICE_INFO:
      if (copy_from_user(&params, (void *)arg, sizeof(params.device_info)))
        return(-EFAULT);
      params.result = 0;
      params.device_info.driver_major = (u8)_MAJREV;
      params.device_info.driver_minor = (u8)_MINREV;
      params.device_info.subdevice    = Pbbd->subdev_id;
      if (copy_to_user((void *)arg, &params, sizeof(params.device_info)))
        return(-EFAULT);
      break;

    case BBDIOC_RUN_MODE:
      if (copy_from_user(&params, (void *)arg, sizeof(params.run_mode)))
        return(-EFAULT);
      params.result = BBD_run_mode(Pbbd,
                                   params.run_mode.slv_id,
                                   params.run_mode.mode);
      if (copy_to_user((void *)arg, &params, sizeof(params.run_mode)))
        return(-EFAULT);
      break;

    case BBDIOC_READ_HOTSWAP:
      params.result = BBD_read_hotswap(Pbbd, &params.read_hotswap.state);
      if (copy_to_user((void *)arg, &params, sizeof(params.read_hotswap)))
        return(-EFAULT);
      break;

    case BBDIOC_DETACH_CPCI:
      params.result = BBD_detach_cpci(Pbbd);
      if (copy_to_user((void *)arg, &params, sizeof(params.result)))
        return(-EFAULT);
      break;

    case BBDIOC_ATTACH_CPCI:
      params.result = BBD_attach_cpci(Pbbd);
      if (copy_to_user((void *)arg, &params, sizeof(params.result)))
        return(-EFAULT);
      break;

    case BBDIOC_GEOG_ADDRESS:
      params.result = BBD_geog_address(Pbbd, &params.geog_address.g_addr);
      if (copy_to_user((void *)arg, &params, sizeof(params.geog_address)))
        return(-EFAULT);
      break;

    case BBDIOC_READ_BAR:
      if (copy_from_user(&params, (void *)arg, sizeof(params.bar_rw)))
        return(-EFAULT);
      params.result = BBD_read_bar(Pbbd,
                                   params.bar_rw.bar,
                                   params.bar_rw.offset,
                                   params.bar_rw.length,
                                   &params.bar_rw.value);
      if (copy_to_user((void *)arg, &params, sizeof(params.bar_rw)))
        return(-EFAULT);
      break;

    case BBDIOC_WRITE_BAR:
      if (copy_from_user(&params, (void *)arg, sizeof(params.bar_rw)))
        return(-EFAULT);
      params.result = BBD_write_bar(Pbbd,
                                    params.bar_rw.bar,
                                    params.bar_rw.offset,
                                    params.bar_rw.length,
                                    params.bar_rw.value);
      if (copy_to_user((void *)arg, &params, sizeof(params.bar_rw)))
        return(-EFAULT);
      break;

    case BBDIOC_READ_CFG:
      if (copy_from_user(&params, (void *)arg, sizeof(params.cfg_rw)))
        return(-EFAULT);
      params.result = BBD_read_cfg(Pbbd,
                                   params.cfg_rw.reg,
                                   &params.cfg_rw.value);
      if (copy_to_user((void *)arg, &params, sizeof(params.cfg_rw)))
        return(-EFAULT);
      break;

    case BBDIOC_WRITE_CFG:
      if (copy_from_user(&params, (void *)arg, sizeof(params.cfg_rw)))
        return(-EFAULT);
      params.result = BBD_write_cfg(Pbbd,
                                    params.cfg_rw.reg,
                                    params.cfg_rw.value);
      if (copy_to_user((void *)arg, &params, sizeof(params.cfg_rw)))
        return(-EFAULT);
      break;

    case BBDIOC_READ_SLAVEINFO:
      if (copy_from_user(&params, (void *)arg, sizeof(params.slave_info)))
        return(-EFAULT);
      params.result = BBD_get_slave_info(Pbbd, &params.slave_info);
      if (copy_to_user((void *)arg, &params, sizeof(params.slave_info)))
        return(-EFAULT);
      break;

    default:
      retval = -EFAULT;
      break;
  }
  
  up(bbd_mutex + Pbbd->board_number);
  
  return(retval);
}

#ifdef HAVE_UNLOCKED_IOCTL
static long BBD_unlocked_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
  return(BBD_ioctl(file->f_dentry->d_inode,file,cmd,arg));
}
#endif

#ifdef HAVE_COMPAT_IOCTL
static long BBD_compat_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
  return(BBD_ioctl(file->f_dentry->d_inode,file,cmd,arg));
}
#endif

/*
 * BBD_mmap - Function called to map device memory into user space
 *
 * Parameters
 *   file       - File handle pointer
 *   vma        -
 *   arg        - parameter flor this command
 *
 * Returns
 *   == 0 on success
 *   != 0 on failure
 */
static int BBD_mmap(struct file *file, struct vm_area_struct *vma)
{
  BBD_BOARD *Pbbd;

  Pbbd = (BBD_BOARD *)(file->private_data);

  if (Pbbd == Pmanager)
  {
    printk("Attempting to map a manager...-> error\n");
    return -1;
  }

  /*
   * We ONLY support mapping the entire memory region into user space so
   * exit if the user is requesting anything else.
   */
  if ((vma->vm_end - vma->vm_start) != (65536 + 4096 + 4096))
    return(-1);

  REMAP_PAGE_RANGE(vma,
                   vma->vm_start,
                   Pbbd->mtr_base_address,
                   65536,
                   vma->vm_page_prot);

  REMAP_PAGE_RANGE(vma,
                   vma->vm_start + 65536,
                   Pbbd->bar[2].base_address,
                   4096,
                   vma->vm_page_prot);

  REMAP_PAGE_RANGE(vma,
                   vma->vm_start + 65536 + 4096,
                   Pbbd->bar[0].base_address,
                   4096,
                   vma->vm_page_prot);

  vma->vm_flags |= (VM_IO | VM_RESERVED);
  return(0);
}

/*
 * BBD_poll function - called by OS called to test device status
 *
 * returns bitmap:
 *  POLLIN  - Data is ready to be read from the device
 *  POLLOUT - Data is ready to accept output
 */
static unsigned int BBD_poll(struct file *file, poll_table *wait)
{
  unsigned long flags;          /* flags */
  BBD_BOARD *Pbbd;              /* memory area for this board */
  unsigned int result;          /* return value */
  u16 rx_int;                   /* receive interrupt for this host */
  u32 head;                     /* read pointer head */
  u32 tail;                     /* read pointer tail */

  Pbbd = (BBD_BOARD *)(file->private_data);

  /*
   * Released from within interrupt routine
   */
  poll_wait(file, &Pbbd->wait, wait);
  if (Pbbd == Pmanager)
  {
    if (eventcount != lastcount)
    {
      lastcount = eventcount;
      DEBUG1("%s() Status has changed !\n",__FUNCTION__);
      return POLLIN;
    }
    return 0;
  }

  result = 0;

  if (Pbbd->errordetected == 1) {
    Pbbd->errordetected = 2;
    DEBUG1("%s() board=%d Error detected -> POLLERR\n",__FUNCTION__, Pbbd->board_number);
    return POLLERR;
  }
  /*
   * Take the spin lock
   * Read (and blank) the current rxed ints
   * Give the spin lock
   */
  spin_lock_irqsave(&Pbbd->bbd_lock, flags);
  rx_int = Pbbd->host_int;
  Pbbd->host_int = 0;
  spin_unlock_irqrestore(&Pbbd->bbd_lock, flags);

  /*
   * If the IB_FREE interrupt is set we have a valid poll_out
   * We can't just check to see if the queue is full as the space left
   * may just be too small
   */
  if (rx_int & BBD_HBI_INT_IB_FREE)
  {
    result |= POLLOUT;
  }

  /*
   * If the slv->hst pointers are not equal there is data to be read
   */
  if (rx_int & BBD_HBI_INT_OB_POST)
  {
    result |= POLLIN;
  }

  head = NMSRDU32(Pbbd->bar[2].handle, Pbbd->bar[2].base_address, 0x14);
  tail = NMSRDU32(Pbbd->bar[2].handle, Pbbd->bar[2].base_address, 0x1c);

  if (head != tail)
  {
    result |= POLLIN;
  }

  return(result);
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
static int BBD_suspend(struct pci_dev *dev, u32 state)
#else
static int BBD_suspend(struct pci_dev *dev, pm_message_t state)
#endif
{
  BBD_BOARD *Pbbd;
  struct page *map;
  struct page *mapend;
  int board;
  int wait = 300;

  DEBUG1("%s(dev=%p, state=%d)\n",__FUNCTION__, dev, state);

  Pbbd = pci_get_drvdata(dev);
  if(Pbbd == NULL)
  {
    DEBUG1("%s() no board\n",__FUNCTION__);
    return -1;
  }
  DEBUG1("%s() board=%d\n",__FUNCTION__, Pbbd->board_number);
  board = Pbbd->board_number;

  printk("SS7HD[%x] - suspend\n", board);

  /*
   * The below is NOT interruptible as we maybe called from the system and
   * from remove (which cannot fail)
   */
  down(bbd_mutex + board);
  if(Pbbd->brd_pres == 0)
  {
    up(bbd_mutex + board);
    DEBUG1("!!!Board %d already suspended\n",  Pbbd->board_number);
    return(0);
  }
  /* Board is no longer available to the user layer */
  Pbbd->brd_pres = 0;
  up(bbd_mutex + board);

  if (Pbbd->brd_open)
  {
    printk("SS7HD[%x] - still open during suspend\n", board);

    DEBUG1("Argh... board %d in use\n", board);
    Pbbd->errordetected = 1;
    wake_up_interruptible(&Pbbd->wait); // Wake the poll
    board_status(board, 0);
    while (wait--)
    {
      if (Pbbd->brd_open == 0) {
        DEBUG1("is closed !\n");
        break;
      }
      set_current_state(TASK_INTERRUPTIBLE);
      schedule_timeout((20*HZ)/1000);
      set_current_state(TASK_RUNNING);
    }
    if (Pbbd->brd_open) {
      DEBUG1("STILL OPEN !");
    }
    DEBUG1("Has exit\n");
  }
  else
    board_status(board, 0);

  if (Pbbd->board_resources & BBD_BM_IRQ_ALLOCATED)
  {
    BBD_disable_slave_interrupts(Pbbd);
    free_irq(Pbbd->irq, Pbbd);
    Pbbd->board_resources &= ~BBD_BM_IRQ_ALLOCATED;
  }

  if (Pbbd->board_resources & BBD_BM_BUS_MAPPED)
  {
    HBI_HOST_CONTROL  *cfg_ptr;
    u32 val;
    cfg_ptr = (HBI_HOST_CONTROL  *)(Pbbd->mtr_memory + HBI_CONTROL_OFFSET);
    cfg_ptr->host_magic = 0UL;
    BARU32W(Pbbd, 0, BBD_HSI_HST_NP_HOST_MEMBASE, 0UL);

    PCIReadConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, &val);
    val |= I21555_RCR_SEC_RESET;
    PCIWriteConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, val);

    BARU16W(Pbbd, 0, BBD_HSI_HST_NP_HOST_COMMAND, BBDHBI_HCMD_RSTREQ);
    BARU32W(Pbbd, 0, BBD_HSI_HST_NP_SLAVE_STATUS, BBDHBI_SLAVE_PWRUP);

    set_current_state(TASK_INTERRUPTIBLE);
    schedule_timeout((20*HZ)/1000);
    set_current_state(TASK_RUNNING);

    PCIReadConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, &val);
    val &= ~I21555_RCR_SEC_RESET;
    PCIWriteConfig32(Pbbd->pci, I21555_DEVSPC_CFG_RESET_CTRL, val);

    /* Ensure interrupt are disable after the Board reset. */
    BBD_disable_slave_interrupts(Pbbd);
   /*
    * Clear the reserved bit for all the allocated pages
    */
    map = virt_to_page(Pbbd->mtr_memory);
    mapend = virt_to_page(Pbbd->mtr_memory + (MAP_SIZE) - 1);

    while(map <= mapend)
    {
      mem_map_unreserve(map);
      map++;
    }
    Pbbd->board_resources &= ~BBD_BM_BUS_MAPPED;
  }

  if(Pbbd->mtr_memory != NULL)
  {
    kfree(Pbbd->mtr_memory);
    Pbbd->mtr_memory = NULL;
  }

  if (Pbbd->board_resources & BBD_BM_TEST) {
    BBD_unmap_bar(dev, 3, Pbbd->bar + 3);
    BBD_unmap_bar(dev, 2, Pbbd->bar + 2);
    BBD_unmap_bar(dev, 0, Pbbd->bar + 0);
    Pbbd->board_resources &= ~BBD_BM_TEST;
  }
  pci_disable_device(dev);

  DEBUG1("%s() board=%d cmplt\n",__FUNCTION__, Pbbd->board_number);
  return 0;
}

static int BBD_resume(struct pci_dev *dev)
{
  BBD_BOARD *Pbbd;
  u8 Tu8;
  int board;
  struct page *map;
  struct page *mapend;

  DEBUG1("%s(%p)\n",__FUNCTION__, dev);

  Pbbd = pci_get_drvdata(dev);
  if(Pbbd == NULL)
  {
    DEBUG1("%s() no board\n",__FUNCTION__);
    return -1;
  }
  DEBUG1("%s() board=%d\n",__FUNCTION__, Pbbd->board_number);
  board = Pbbd->board_number;

  if (pci_enable_device(dev) < 0)
  {
    DEBUG1("SS7HD[%i] - Failure to enable the device\n",board);
    return(-1);
  }
  /*
   * Read the SROM mode configuration register to determine how many bits the
   * device believes its slot to be (bit 6 of this register is set for a 64
   * bit slot).
   */
  if (PCIReadConfig_8(dev, 0xd6, &Tu8) != 0)
  {
    DEBUG1("SS7HD[%i] - Failure to read PCI config space\n",board);
    return(-1);
  }

  if (Tu8 & 0x40)
  {
    Pbbd->board_resources |= BBD_BM_64BIT_SLOT;
  }
  else
  {
    Pbbd->board_resources &= ~BBD_BM_64BIT_SLOT;
  }

  /*
   * Allocate the following BARs on the 21555
   *
   * BAR0 - PCI config space via memory
   * BAR2 - PCI memory space to allow debug access to the card
   * BAR3 - PCI memory space to allow debug access to the card
   */
  if (BBD_map_bar(Pbbd->pci, 0, Pbbd->bar + 0) != 0)
  {
    return -1;
  }

  if (BBD_map_bar(Pbbd->pci, 2, Pbbd->bar + 2) != 0)
  {
    return -1;
  }

  if (BBD_map_bar(Pbbd->pci, 3, Pbbd->bar + 3) != 0)
  {
    return -1;
  }

  Pbbd->board_resources |= BBD_BM_TEST;

  /*
   * Allocate a chunk of DMAable memory 128k long as the space where the BBD
   * card will DMA to and from the HBI buffers.
   */
  Pbbd->mtr_memory = (void *)kmalloc(MAP_SIZE, (GFP_KERNEL | GFP_DMA));
  if(Pbbd->mtr_memory == NULL)
  {
    DEBUG1("SS7HD[%i] - Memory allocation failed\n", board);
    return -1;
  }
  /*
   * The address returned is virtual and can only be used in kernel land.
   * The board needs the actual physical (bus) address of the memory to access.
   */
  Pbbd->mtr_base_address = virt_to_bus(Pbbd->mtr_memory);
  DRV_DEBUG(("SS7HD[%i] - Host memory @ %08lx (bus), %08lx (virtual)\n",
             board,
             Pbbd->mtr_base_address,
             (unsigned long)Pbbd->mtr_memory));

  /*
   * Set the reserved bit for all the allocated pages
   */
  map = virt_to_page(Pbbd->mtr_memory);
  mapend = virt_to_page(Pbbd->mtr_memory + (MAP_SIZE) - 1);

  while(map <= mapend)
  {
    mem_map_reserve(map);
    map++;
  }
  Pbbd->board_resources |= BBD_BM_BUS_MAPPED;

  /*
   * Check err to see if we failed to map any memory region. If so release
   * As we are just testing we ignore all the above errors as we dont test for
   * I/O If we fail to allocate memory space then exit.
   */
  Pbbd->irq = dev->irq;

  if (request_irq(Pbbd->irq, BBD_isr, IRQF_SHARED, BBD_TEXT_ID, Pbbd) != 0)
  {
    DEBUG1("SS7HD[%i] - IRQ request failed\n",board);
    return -1;
  }
  pci_set_master(dev);

  /*
   * Read the configuration space of the board into memory for hotswapping
   */
  if (PCIReadConfigSpace(Pbbd->pci, Pbbd->pci_config))
  {
    DEBUG1("SS7HD[%i] - Reading config space failure\n",board);
    return -1;
  }
  Pbbd->pci_config_valid = 1;

  /*
   * The board is present and we have mapped the memory and allocated the IRQ
   */
  Pbbd->board_resources |= BBD_BM_IRQ_ALLOCATED;

  /*
   * Board is now available for use by the upper layer
   */
  Pbbd->brd_pres = 1;

  /*
   * Initialise spinlock, tasklet and wait queues.
   */
  spin_lock_init(&Pbbd->bbd_lock);

  tasklet_init(&Pbbd->tlet, BBD_isr_tasklet, (unsigned long)Pbbd);

  init_waitqueue_head(&Pbbd->wait);

  /*
   * Reset the board buffers etc
   */
  BBD_reset_environment(Pbbd);
  printk("SS7HD[%i]", board);
  if (Pbbd->board_resources & BBD_BM_64BIT_SLOT)
  {
    printk(" 64bit");
  }
  else
  {
    printk(" 32bit");
  }
  printk("\n");

  BBD_deassert_reset(Pbbd, 0);

  board_status(board, 1);

  DEBUG1("%s() board=%d cmplt\n",__FUNCTION__, Pbbd->board_number);
  return 0;
}


/*
 * Check the EXPORT variable exists before using it!
 */
#ifdef MODULE_AUTHOR
MODULE_AUTHOR("Dialogic Corporation");
#endif

#ifdef MODULE_DESCRIPTION
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
MODULE_DESCRIPTION("Linux2.4 driver for Dialogic Corporation");
#else
MODULE_DESCRIPTION("Linux2.6 driver for Dialogic Corporation");
#endif
#endif

#ifdef MODULE_LICENSE
MODULE_LICENSE("Dual BSD/GPL");
#endif

static struct pci_device_id BBD_pci_tbl[] __devinitdata =
{
  {BBD_VENDOR_ID, BBD_DEVICE_ID, BBD_SUBVENDOR_ID, BBD_SUBDEVICE_ID_CPCI},
  {BBD_VENDOR_ID, BBD_DEVICE_ID, BBD_SUBVENDOR_ID, BBD_SUBDEVICE_ID_PCI},
  {BBD_VENDOR_ID, BBD_DEVICE_ID, BBD_SUBVENDOR_ID, BBD_SUBDEVICE_ID_PCIE},
  { 0 },
};

MODULE_DEVICE_TABLE(pci, BBD_pci_tbl);


static struct pci_driver bbd_driver=
{
  name:           BBD_TEXT_ID,
  id_table:       BBD_pci_tbl,
  probe:          BBD_probe,
  remove:         BBD_remove,
  suspend:        BBD_suspend,
  resume:         BBD_resume,
};

/*
 * bbd_init_module - OS required function to allow dynamic loading and unloading
 * into a kernel
 *
 * Parameters
 *   none
 *
 * Returns
 *   == 0 on success
 *   != 0 on failure
 */
static int bbd_init_module(void)
{
  int res;              /* result of the init attempt */
  int i;
#ifdef REGISTER_SYSFS
  unsigned int board;
#endif

#ifdef BBDDDLNX_SOURCE_VERSION
  printk("\n\nDialogic SS7HD Device Driver V%d.%02d (Source V%d.%d)\n", 
    _MAJREV, _MINREV, BBDDDLNX_MAJ, BBDDDLNX_MIN);
  printk("Copyright (C) Dialogic Corporation 2003-2010.  All Rights Reserved\n");
#else
  printk("DSI SS7HD Release %d.%d.%d (Build %d)\n", 
        PRODUCT_MAJREV, PRODUCT_MINREV, PRODUCT_SPKREV, PRODUCT_BLDREV);
  printk("Part of the Dialogic(R) DSI Development Package for Linux\n");
  if (COPYRIGHT_BEGIN == PRODUCT_COPYRIGHT)
  {
    printk("Copyright (C) Dialogic Corporation %d. All Rights Reserved.\n", COPYRIGHT_BEGIN);
  }
  else
  {
    printk("Copyright (C) Dialogic Corporation %d-%d. All Rights Reserved.\n", COPYRIGHT_BEGIN, PRODUCT_COPYRIGHT);
  }
#endif

  /*
   * Reset all our card information
   */
  memset(bbd_boards, 0, sizeof(bbd_boards));

  i = 0;
  while(i != BBD_MAX_BOARDS) {
    init_MUTEX(bbd_mutex + i);
    i++;
  }

  /*
   * Grab us a character device entry
   */
  res = register_chrdev(majno, BBD_TEXT_ID, &bbd_fops);
  if (res < 0)
    return(-ENODEV);
  
  if (majno == 0)
    majno = res;
  printk("Using major device number %d.\n", majno);

#ifdef REGISTER_SYSFS
  ss7hd_class = class_create(THIS_MODULE, BBD_TEXT_ID);
  if (IS_ERR(ss7hd_class))
  {
    printk("Could not register class\n");
    res = -ENODEV;
  }
  else
  {
    res = pci_module_init(&bbd_driver);
    if (res < 0)
    {
      printk("No boards present\n");
      class_destroy(ss7hd_class);
    }
    else
    {
      /*
       * Create all the device nodes.  This should really be done on probe,
       * but that would require changes to the hotplug code in ssd
       */
      for (board = 0; board < BBD_MAX_BOARDS; board++)
      {
        class_device_create(ss7hd_class, NULL, MKDEV(majno, board), NULL, "%s%u", BBD_DEVNODE_ID, board);
      }
      class_device_create(ss7hd_class, NULL, MKDEV(majno, 255), NULL, "%s%u", BBD_DEVNODE_ID, 255);
    }
  }
  if (res < 0)
    unregister_chrdev(majno, BBD_TEXT_ID);
#else
  res = pci_module_init(&bbd_driver);
  if (res < 0)
  {
    printk("No boards present\n");
    unregister_chrdev(majno, BBD_TEXT_ID);
  }
#endif


#if (defined(__x86_64__)) && (! defined(HAVE_COMPAT_IOCTL))
  else
  {
    register_ioctl32_conversion_cast(BBDIOC_ASSERT_RESET,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_DEASSERT_RESET,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_TEST_RESET_COMPLETE,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_PUT_CMD,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_GET_STATUS,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_DEVICE_INFO,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_RUN_MODE,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_READ_HOTSWAP,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_DETACH_CPCI,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_ATTACH_CPCI,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_GEOG_ADDRESS,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_READ_BAR,sys_ioctl);
    register_ioctl32_conversion_cast(BBDIOC_WRITE_BAR,sys_ioctl);
  }
#endif
  return(res);
}

/*
 * bbd_cleanup_module - remove the driver
 *
 * Parameters
 *   none
 *
 * Returns
 *   none
 */
static void bbd_cleanup_module(void)
{
#ifdef REGISTER_SYSFS
  unsigned int board;
#endif

  DEBUG1("%s()\n",__FUNCTION__);

#if (defined(__x86_64__)) && (! defined(HAVE_COMPAT_IOCTL))
  unregister_ioctl32_conversion(BBDIOC_ASSERT_RESET);
  unregister_ioctl32_conversion(BBDIOC_DEASSERT_RESET);
  unregister_ioctl32_conversion(BBDIOC_TEST_RESET_COMPLETE);
  unregister_ioctl32_conversion(BBDIOC_PUT_CMD);
  unregister_ioctl32_conversion(BBDIOC_GET_STATUS);
  unregister_ioctl32_conversion(BBDIOC_DEVICE_INFO);
  unregister_ioctl32_conversion(BBDIOC_RUN_MODE);
  unregister_ioctl32_conversion(BBDIOC_READ_HOTSWAP);
  unregister_ioctl32_conversion(BBDIOC_DETACH_CPCI);
  unregister_ioctl32_conversion(BBDIOC_ATTACH_CPCI);
  unregister_ioctl32_conversion(BBDIOC_GEOG_ADDRESS);
  unregister_ioctl32_conversion(BBDIOC_READ_BAR);
  unregister_ioctl32_conversion(BBDIOC_WRITE_BAR);
#endif
  pci_unregister_driver(&bbd_driver);

#ifdef REGISTER_SYSFS
  class_device_destroy(ss7hd_class, MKDEV(majno, 255));
  /*
   * Destroy all the device nodes.  This should really be done on device
   * removal, but that would require changes to the hotplug code in ssd
   */
  for (board = 0; board < BBD_MAX_BOARDS; board++)
    class_device_destroy(ss7hd_class, MKDEV(majno, board));
  class_destroy(ss7hd_class);
#endif
  
  unregister_chrdev(majno, BBD_TEXT_ID);

  DEBUG1("%s() cmplt\n",__FUNCTION__);
}

module_init(bbd_init_module);
module_exit(bbd_cleanup_module);

