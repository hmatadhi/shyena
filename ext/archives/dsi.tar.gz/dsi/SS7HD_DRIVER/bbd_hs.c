/*
                Copyright (C) Dialogic Corporation 2003-2007.
                All Rights Reserved.

 Name:          bbd_hs.c

 Description:   ioctl file for the BBD Linux device driver

 Functions:     BBD_read_hotswap
                BBD_detach_cpci
                BBD_attach_cpci

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    03-Dec-03   IDP   - Split from bbd_ioc.c
   1    12-Apr-05   GNK   - Prepare for source code release.
   -    01-May-07   GNK   - Update copyright banner.
*/

#include "bbd_def.h"
#include "bbd_pro.h"

/*
 * get_pci_hs_csr - Read the hotswap csr for the board
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   csr register value (or 0xffff on error)
 */
__inline__ static u16 get_pci_hs_csr(BBD_BOARD *Pbbd)
{
  u16 csr;      /* control status register */

  if(PCIReadConfig16(Pbbd->pci, 0xee, &csr) != 0)
  {
    csr = 0xffff;
  }
  return(csr);
}

/*
 * set_pci_hs_csr - Write the hotswap csr for the board
 *
 * parameters
 *   csr        - control status register value (or 0xffff on error)
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   none
 */
__inline__ static void set_pci_hs_csr(BBD_BOARD *Pbbd, u16 csr)
{
  DRV_DEBUG(("%s(%i,%04x)\n",__FUNCTION__,Pbbd->board_number,csr));
  PCIWriteConfig16(Pbbd->pci, 0xee, csr);
}

/*
 * BBD_valid_device -  Validate the vendor & device ID and sub vendor 
 *      and sub device to ensure that the inserted card IS a BBD cPCI
 *
 * parameters
 *   pci       - PCI device structure of board
 *
 * returns
 *   success    - ZERO
 *   failure    - 1
 */
static int BBD_valid_device(struct pci_dev *pci)
{
  u32 temp;

  if(PCIReadConfig32(pci, 0x00, &temp) != 0) 
  {
    return(-1);
  }
  if(temp != ((BBD_DEVICE_ID << 16) | BBD_VENDOR_ID))
  {
    return(-1);
  }
  if(PCIReadConfig32(pci, 0x2c, &temp) != 0)
  {
    return(-1);
  }
  if(temp != ((BBD_SUBDEVICE_ID_CPCI << 16) | BBD_SUBVENDOR_ID)) 
  {
    return(-1);
  }
  return(0);
}

/*
 * BBD_read_hotswap - Check the hotswap status of the board
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *   State      - return value of state
 *
 * returns
 *   success    - LNXSLV_SUCCESS
 *   failure    - LNXSLV_DRIVER_ERROR
 */
int BBD_read_hotswap(BBD_BOARD *Pbbd, u32 *State)
{
  u16 csr;      /* control status register */
  
  DRV_DEBUG(("%s(%i)\n",__FUNCTION__,Pbbd->board_number));

  if(BBD_valid_device(Pbbd->pci) != 0)
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  if ((csr = get_pci_hs_csr(Pbbd)) == 0xffff)
  {
    *State = HS_BOARD_REMOVED;
  }
  else
  {
    /*
     * We are requesting an extract or the LED is lit as we have not yet
     * removed the card
     */
    if (csr & (HS_CSR_EXTRACT_REQUEST | HS_CSR_BLUE_LED))
    {
      *State = HS_EXTRACT_REQUEST;
    }
    else
    {
      if (csr & HS_CSR_INSERT_REQUEST)
      {
        set_pci_hs_csr(Pbbd, HS_CSR_INSERT_REQUEST);
      }
      *State = HS_BOARD_INSERTED;
    }
  }
  return(LNXSLV_SUCCESS);
}

/*
 * BBD_detach_cpci - Prepare a board for removal
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   success    - SLV_SUCCESS
 *   failure    - SLV_BOARD_FAILURE
 *              - SLV_DRIVER_ERROR
 */
int BBD_detach_cpci(BBD_BOARD *Pbbd)
{
  u16 csr;      /* control status register */

  DRV_DEBUG(("%s(%i)\n",__FUNCTION__,Pbbd->board_number));

  /*
   * Ensure the board is one of our cPCI boards
   */
  switch(Pbbd->subdev_id)
  {
    case BBD_SUBDEVICE_ID_PCI:
    default:
      return (LNXSLV_BOARD_FAILURE);

    case BBD_SUBDEVICE_ID_CPCI:
      break;
  }

  /*
   * Disable interrupts from the card and reset the secondary bus
   */
  BBD_disable_slave_interrupts(Pbbd);
  BBD_assert_reset(Pbbd, 0);

  /*
   * Light the blue LED
   */
  csr = get_pci_hs_csr(Pbbd);
  set_pci_hs_csr(Pbbd, csr | HS_CSR_BLUE_LED);
  return(LNXSLV_SUCCESS);
}

/*
 * BBD_attach_cpci - Prepare a board after insertion
 *
 * parameters
 *   Pbbd       - memory area for this board 
 *
 * returns
 *   success    - LNXSLV_SUCCESS
 *   failure    - LNXSLV_BOARD_FAILURE
 *              - LNXSLV_DRIVER_ERROR
 */
int BBD_attach_cpci(BBD_BOARD *Pbbd)
{
  u16 csr;      /* control status register */

  DRV_DEBUG(("%s(%i)\n",__FUNCTION__,Pbbd->board_number));
  /*
   * Ensure the board is one of ours
   */
  switch(Pbbd->subdev_id)
  {
    case BBD_SUBDEVICE_ID_PCI:
    default:
      return (LNXSLV_BOARD_FAILURE);

    case BBD_SUBDEVICE_ID_CPCI:
      break;
  }

  csr = get_pci_hs_csr(Pbbd);

  if (csr & HS_CSR_BLUE_LED)
  {
    return(LNXSLV_BOARD_FAILURE);
  }

  if (Pbbd->pci_config_valid == 0)
  {
    printk("Error no valid PCI config data for this slot\n");
    return(LNXSLV_BOARD_FAILURE);
  }
  /*
   * Copy our saved config data to the board
   */
  if (PCIWriteConfigSpace(Pbbd->pci, Pbbd->pci_config))
  {
    return(LNXSLV_DRIVER_ERROR);
  }

  /*
   * Enable interrupts from the card
   */
  BBD_enable_slave_interrupts(Pbbd);
  return(LNXSLV_SUCCESS);
}
