#!/bin/bash

#
#   Copyright (C) Dialogic Corporation 2005-2011.
#   All Rights Reserved.
#
#   File:               build_ss7hd.sh
#
#   Script to build:    Linux SS7HD device driver.
#   for use with:       Linux 2.4.x or Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1     10-May-05   GK  - First version for external release
#     -     31-Aug-06   SH  - Added usage information
#     -     01-May-07   GK  - Update copyright banner
#     -     13-Jul-07   SH  - Fix driver for kernels >= 2.6.18 and add sysfs
#                             support (allows auto /dev node creation by udev)
#     -     13-Dec-11   IDP - CN493DPK - Fix driver for 3.x kernels
#   -------+---------+------+------------------------------------------
#
#   Usage:
#     ./build_ss7hd.sh          - Build device driver
#     ./build_ss7hd.sh clean    - Delete device driver and object files

MODNAME=ss7hddvr

# Check whether make clean is requested 
if [ "$1" = "clean" ]
then
  CLEAN="$1"
fi

# Check whether we should install
if [ "$1" = "install" ]
then
  INSTALL="$1"
fi

# look up the version string
OS_VER=`uname -r`
KDIR=/lib/modules/$OS_VER/build
INSTALLDIR=/lib/modules/$OS_VER/extra

# Check the arguments of remap_page_range()
REMAP=`grep remap_page_range ${KDIR}/include/linux/mm.h | grep -c vma`

# and read the major and minor version number
MAJVER=`echo $OS_VER | cut -f 1 -d "."`
MINVER=`echo $OS_VER | cut -f 2 -d "."`

case "$MAJVER.$MINVER" in
  "2.4")
    cp Makefile24 Makefile
    make OSVERSTR="-${OS_VER}" REMAP_PAGE_RANGE="${REMAP}" ${CLEAN}
    rm -f Makefile
    exit
    ;;

  "2.6")
    if [ "$CLEAN" = "clean" ]
    then
      make -f Makefile26 OSVERSTR="26" clean
    else
      cp Makefile26 Makefile
      PWD=`pwd`
      make -C $KDIR SUBDIRS=$PWD OSVERSTR="26" REMAP_PAGE_RANGE="${REMAP}" modules
      if [ "$?" = 0 ] && [ "$INSTALL" ]
      then
        echo "Installing module in $INSTALLDIR"
        cp -f ${MODNAME}26.ko "$INSTALLDIR"
        echo "Building module dependencies"
        depmod -a
        echo "Loading module"
        modprobe -r ${MODNAME}26
        modprobe ${MODNAME}26
      fi
      rm -f Makefile
    fi
    exit
    ;;
esac

case "$MAJVER" in
  "3")
    if [ "$CLEAN" = "clean" ]
    then
      make -f Makefile26 OSVERSTR="3x" clean
    else
      cp Makefile26 Makefile
      PWD=`pwd`
      make -C $KDIR SUBDIRS=$PWD OSVERSTR="3x" REMAP_PAGE_RANGE="${REMAP}" modules
      if [ "$?" = 0 ] && [ "$INSTALL" ]
      then
        echo "Installing module in $INSTALLDIR"
        cp -f ${MODNAME}.ko "$INSTALLDIR"
        echo "Building module dependencies"
        depmod -a
        echo "Loading module"
        modprobe -r ${MODNAME}
        modprobe ${MODNAME}
      fi
      rm -f Makefile
    fi
    exit
    ;;
esac

echo Currently no support for Linux $MAJVER.$MINVER
exit
