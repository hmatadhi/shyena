/*
                Copyright (C) Dialogic Corporation 2002-2015
                All Rights Reserved.

 Name:          bbd_def.h

 Description:   Internal defines for the BBD driver.

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    10-Apr-02   MH    - Initial file
   B    21-May-03   IDP   - Changed references from Bluebird to SS7HD
   C    24-May-03   IDP   - Added bit to resources to indicate 64bit operation
   D    30-May-03   IDP   - Support for interrupts in the driver added
   E    03-Jun-03   IDP   - Change <malloc.h> include to <slab.h>
                          - Replace DRV_DEBUG with __DEBUG__ flag, Use to 
                            control creation of DRV_DEBUG macro.
   F    05-Jun-03   IDP   - Addition of set run mode ioctl
   G    10-Jun-03   IDP   - Add defines for ALL scratchpad registers
   H    11-Jun-03   IDP   - Subdevice and subvendor IDs added
   I    09-Oct-03   IDP   - Added define for REMAP_PAGE_RANGE api change
   1    16-Oct-03   IDP   - Bump to whole number for code review
   2    13-Apr-04   IDP   - Added Hotswap defines
   3    18-May-04   GNK   - Use RH EL REMAP_PAGE_RANGE macro for all kernel 
                            versions >= 2,4,20.
   4    09-May-05   GNK   - Prepare for source code release.
                          - Make REMAP_PAGE_RANGE dependant on external 
                            REMAP definition.
   5    20-Dec-05   SH    - Added support for remap_pfn_range(), which replaces
                            remap_page_range() in kernel versions > 2.6.10.
   6    13-Apr-06   SH    - Added ioctl lock
   -    01-May-07   GNK   - Update copyright banner.
   -    13-Jul-07   SH    - Fix driver for kernels >= 2.6.18 and add sysfs
                            support (allows auto /dev node creation by udev)
        12-Nov-07   MH    - Add SS7HDE sub-device Id.
        19-Nov-07   IDP   - Move board present / open from resource bits to
                             separate fields
        01-Sep-15   IDP   - CN717DPK - Support Centos 7
 */

#include <linux/version.h>

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/interrupt.h>
#include <linux/ptrace.h>
#include <linux/in.h>
#include <linux/slab.h>
#include <linux/tty.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/signal.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <linux/poll.h>

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,4,0)
#include <asm/system.h>
#endif
#include <asm/bitops.h>
#include <asm/uaccess.h>
#include <asm/io.h>

#ifdef CONFIG_KMOD
#include <linux/kmod.h>
#endif

#include "bbd_ioc.h"
#include "i21555.h"


#include "bbdddlnx_iss.h"

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,10)
#ifdef OLD_REMAP
#define REMAP_PAGE_RANGE(vma, start, base, size, prot) \
  remap_page_range(start, base, size, prot)
#else
#define REMAP_PAGE_RANGE(vma, start, base, size, prot) \
  remap_page_range(vma, start, base, size, prot)
#endif
#else
#define REMAP_PAGE_RANGE(vma, start, base, size, prot) \
  remap_pfn_range(vma, start, base >> PAGE_SHIFT, size, prot)
#endif

/*
 * internal structures and device constants
 */
#define PCI_MAX_CONFIG_SPACE            (64)

#define BBD_VENDOR_ID                   (I21555_VENDOR_ID)
#define BBD_DEVICE_ID                   (I21555_DEVICE_ID)

#define BBD_SUBVENDOR_ID                (0x12c7)
#define BBD_SUBDEVICE_ID_PCI            (0x5005)
#define BBD_SUBDEVICE_ID_CPCI           (0x5006)
#define BBD_SUBDEVICE_ID_PCIE           (0x500a)

#define BBD_TEXT_ID                     ("SS7HD")
#define BBD_DEVNODE_ID                  ("ss7hd")
#define BBD_DEF_MAJ_NO                  (126)
#define BBD_MAX_BOARDS                  (16)


#define BBD_BM_IRQ_ALLOCATED            (1 << 0)
#define BBD_BM_BUS_MAPPED               (1 << 1)
#define BBD_BM_64BIT_SLOT               (1 << 2)
#define BBD_BM_TEST                     (1 << 3)



#define BBD_HBI_INT_IB_FREE (0x0001)
#define BBD_HBI_INT_OB_POST (0x0002)

typedef struct bbd_pci_bar
{
  unsigned long   base_address;
  void * volatile handle;
  unsigned long   size;
} BBD_PCI_BAR;

#define BBD_MAX_BAR (4)

/*
 * Structure to hold per board information
 */
typedef struct bbd_board
{
  struct pci_dev *pci_bridge;
  struct pci_dev *pci;
  int             brd_pres;
  int             brd_open;
  unsigned int    board_resources;
  int             board_number;
  BBD_PCI_BAR     bar[BBD_MAX_BAR];
  unsigned int    irq;
  int             test_reset_complete_count;
  u16             subdev_id;

  void           *mtr_memory;
  unsigned long   mtr_base_address;

  struct hbi_tb  *tx_init;
  struct hbi_tb  *tx_next;
  struct hbi_tb  *tx_last;

  struct hbi_tb  *rx_init;
  struct hbi_tb  *rx_next;
  struct hbi_tb  *rx_last;

  spinlock_t      bbd_lock;           /* kernel/interrupt spin lock */
  struct tasklet_struct tlet;
  u32             host_int;
  wait_queue_head_t  wait;
  int             errordetected;
  int             hst2slv_full;
  int             slv2hst_mpt;

  int             pci_config_valid;
  u32             pci_config[64];

} BBD_BOARD;

#define DRV_LEVEL_1                 (1)

#define BBD_HSI_NP_INT_DMA_FLUSH    (0x0001)
#define BBD_HSI_NP_INT_NEW_CMD      (0x0002)

#define DPM73S_RSTREQ               (0x00)
#define DPM73S_IDLE                 (0x01)

#define BBD_HSI_HST_NP_INT_REG      (I21555_CSR_PRI_SET_IRQ)
#define BBD_HSI_HST_NP_HOST_COMMAND (I21555_CSR_SCRATCHPAD_0)
#define BBD_HSI_HST_NP_SLAVE_STATUS (I21555_CSR_SCRATCHPAD_1)
#define BBD_HSI_HST_NP_HOST_MEMBASE (I21555_CSR_SCRATCHPAD_2)
#define BBD_HSI_HST_NP_RUN_MODE     (I21555_CSR_SCRATCHPAD_3)
#define BBD_HSI_HST_NP_GEOG_ADDR    (I21555_CSR_SCRATCHPAD_4)
#define BBD_HSI_HST_RESERVED_5      (I21555_CSR_SCRATCHPAD_5)
#define BBD_HSI_HST_RESERVED_6      (I21555_CSR_SCRATCHPAD_6)
#define BBD_HSI_HST_RESERVED_7      (I21555_CSR_SCRATCHPAD_7)

#define BBD_HSI_SLV_TO_HST_QUEUE    (I21555_CSR_I20_OB_QUEUE)
#define BBD_HSI_HST_TO_SLV_QUEUE    (I21555_CSR_I20_IB_QUEUE)

#define BBD_HSI_H2S_HEAD            (0x18)
#define BBD_HSI_H2S_TAIL            (0x10)
#define BBD_HSI_S2H_HEAD            (0x14)
#define BBD_HSI_S2H_TAIL            (0x1c)

/*
 * Offsets of the memory regions in the MTR
 */
#define BBD_MTR_TX_BUFFER_OFFSET    (0x00000000)
#define BBD_MTR_RX_BUFFER_OFFSET    (BBD_MTR_TX_BUFFER_BASE + \
                                    (BBD_TOTAL_BUFFERS / 2) * sizeof(BBD_MTR_BUFFER))

/*
 * Multi octet bytes over PCI bus are done little endian
 */
#define U16NMS(a) (a)
#define U32NMS(a) (a)

#define NMSRDU8(virt,addr,off)      (readb(((virt) + (off))))
#define NMSWRTU8(virt,addr,off,vu8) (writeb(vu8, ((virt) + (off))))

/*
 * Macros to read and write u16 (2 bytes) to the NMS.
 */
#define NMSRDU16(virt,addr,off)       (U16NMS (readw( ((virt) + (off)) )))
#define NMSWRTU16(virt,addr,off,vu16) (writew(U16NMS(vu16), ((virt) + (off)) ))

/*
 * Macros to read and write u32 (4 bytes) to the NMS.
 */
#define NMSRDU32(virt,addr,off)       (U32NMS (readl( ((virt) + (off)) )))
#define NMSWRTU32(virt,addr,off,vu32) (writel(U32NMS(vu32), ((virt) + (off)) ))

#ifdef __DEBUG__
#define DRV_DEBUG(x)            printk x
#else
#define DRV_DEBUG(x)          /*  printk x */
#endif

#define BARU16W(p,b,o,v) NMSWRTU16(p->bar[b].handle, p->bar[b].base_address, o, v)
#define BARU16R(p,b,o)   NMSRDU16(p->bar[b].handle, p->bar[b].base_address, o)

#define BARU32W(p,b,o,v) NMSWRTU32(p->bar[b].handle, p->bar[b].base_address, o, v)
#define BARU32R(p,b,o)   NMSRDU32(p->bar[b].handle, p->bar[b].base_address, o)

/*
 * Functions to mask / unmask the interrupt bits for host<->NP HBI
 */
#define BBD_HST_IRQ_CLR(p,v)    BARU16W(p, 0, I21555_CSR_PRI_CLR_IRQ, v)
#define BBD_HST_IRQ_SET(p,v)    BARU16W(p, 0, I21555_CSR_PRI_SET_IRQ, v)
#define BBD_HST_IRQ_MASK(p,v)   BARU16W(p, 0, I21555_CSR_PRI_MASK_IRQ, v)
#define BBD_HST_IRQ_UNMASK(p,v) BARU16W(p, 0, I21555_CSR_PRI_UNMASK_IRQ, v)

#define BBD_HST_IB_FREE_IRQ_MASK(b) BBD_HST_IRQ_MASK(b, BBD_HBI_INT_IB_FREE)
#define BBD_HST_OB_POST_IRQ_MASK(b) BBD_HST_IRQ_MASK(b, BBD_HBI_INT_OB_POST)

#define BBD_HST_IB_FREE_IRQ_UNMASK(b) BBD_HST_IRQ_UNMASK(b, BBD_HBI_INT_IB_FREE)
#define BBD_HST_OB_POST_IRQ_UNMASK(b) BBD_HST_IRQ_UNMASK(b, BBD_HBI_INT_OB_POST)

#define BBD_HST_IB_FREE_IRQ_CLR(b) BBD_HST_IRQ_CLR(b, BBD_HBI_INT_IB_FREE)
#define BBD_HST_OB_POST_IRQ_CLR(b) BBD_HST_IRQ_CLR(b, BBD_HBI_INT_OB_POST)

#define BBD_GET_HST_IRQ_STATE(p) BARU16R(p, 0, I21555_CSR_PRI_CLR_IRQ)
#define BBD_GET_HST_IRQ_MASK(p)  BARU16R(p, 0, I21555_CSR_PRI_MASK_IRQ)

#define BBD_SLV_IRQ_SET_NEW_CMD(p) BARU16W(p, 0, I21555_CSR_SEC_SET_IRQ, BBD_HSI_NP_INT_NEW_CMD)

#define HS_CSR_BLUE_LED        (0x08)
#define HS_CSR_EXTRACT_REQUEST (0x40)
#define HS_CSR_INSERT_REQUEST  (0x80)

