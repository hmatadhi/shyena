/*
                Copyright (C) Dialogic Corporation 2005-2017.  All Rights Reserved.

 Name:          prod_rel.h

 Description:   This file lists the versions of the binaries included
                in the DevPack for Linux. These are the versions
                reported by the various binaries when executed with the
                -v option.
                Having those versions defined outside of the component
                makefiles avoids requiring that those makefile be changed
                at each new DevPack release (would make their version
                history much more cluttered than needed and we wouldn't
                be able to easily distinguish real changes in the
                makefiles from simple version number increases).
        ---------  -----  ---------------------------------------------
          Date      By                     Changes
        ---------  -----  ---------------------------------------------
        11-Oct-05   GK    - Add comments relating to "last release' versions
                          - SCU V200.01
        17-Oct-05   GK    - DTC V200.01
        23-Nov-05   SH    - Add GUI tool versions definitions
        16-Jan-06   GK    - S7_MGT V200.07
        27-Jan-06   MH    - Move to GCTLIB shared library.
                            Update all app binaries to next major release
                            number.
        30-May-06   GK    - DPK release V5.01
        06-Jul-06   GK    - DPK release V5.02
        24-Jul-06   GK    - BICC build
        16-Oct-06   GK    - DPK release V5.03
        17-Nov-06   GK    - DPK release V5.04
        03-May-07   GK    - Merge Mexia deltas
                          - DPK release V5.05
        08-Jun-07   MH    - DPK release V5.05 Bld 8.
        16-Aug-07   GNK   - DPK release V200.08
        15-Nov-07   MH    - Add 'dpkrel' values.
                          - DPK release V5.07
        22-Nov-07   NEM   - S7_LOG V200.02
        26-Nov-07   MH    - DPK release V5.08
        18-Feb-08   GNK   - Remove ID's for ssd  & binary drivers
                          - DPK release V5.09
        22-Apr-08   GNK   - Release of S7_MGT / SS7_INC for DIVA - from side branch
        25-Apr-08   GNK   - Another release of S7_MGT / SS7_INC for DIVA - from side branch
        25-Apr-08   GNK   - Yet another release of S7_MGT DIVA -  this time temp with 
                            128 link support
        16-Jun-08   GNK   - Back to main branch for S7_MGT
        03-Dec-08   GNK   - Add ssdm
        19-Mar-09   MH    - DPK V6.01
        08-Jul-09   MH    - DPK V6.03
        22-Sep-09   MH    - DPK V6.04
        01-Oct-09   MH    - Add RMM
        13-Nov-09   MH    - DPK V200.09
        08-Jan-10   MH    - S7MGT V200.20
        19-Jan-10   MH    - TXA V1.02
        20-Jan-10   MH    - DPK V200.10 - M3UA SRA Test
        22-Jan-10   MH    - DPK V6.10
        27-Apr-10   JCo   - DPK V200.11 - SSDS/DSA/S7MGT SNMP Test
        30-Apr-10   JCo   - DPK V200.12 - SSDS/DSA Updates SNMP Test
        25-May-10   JCo   - DPK V6.11 - SNMP TRA Release - SSDS/DSA/S7MGT
        01-Jun-10   MH    - TS108DPK - Product consolidation.
        09-Jul-10   MH    - Teligent AMC release - 6.12.1
        16-Jul-10 - MH    - DPK V6.2.0 - TRA
        20-Sep-10 - MH    - DPK V6.2.1 - SRA
        06-Oct-10 - MH    - DPK V6.2.2 - RSI update
        09-Dec-10 - JLP   - DPK V6.2.3 - Added M3UA 1024 link license
                                         plus M2PA,SCTPN and GCTLIB fixes  
        31-Jan-11 - WRR   - DPK V6.2.4 - Support ISUP format/recovery 
        02-Feb-11 - MH    - DPK V6.2.5 - SS7MD MTP2 update for Teligent.
        28-Feb-11 - JLP   - DPK V6.2.6 - MAP update (SendParameters service etc)
        03-Mar-11 - WRR   - DPK V6.2.7 - ISUP update (unlicensed FMT/Recovery only operation)
        28-Mar-11 - MH    - DPK V6.2.8 - Diva syssec release
        07-Apr-11 - MH    - DPK V6.2.9 - Linux DPK GA release.
        20-Apr-11 - MH    - DPK V6.2.10 - Diva s7_mgt.
        20-Apr-11 - JTD   - V200.14.1  - Modified syssec.
        11-May-11   MH    - DPK 6.3.3 - Merge in SS7LD SRA
        09-Jun-11   MH    - DPK 6.3.4 - Update to SS7LD driver.
        05-Jul-11   MH    - DPK 6.3.5 - Maintenance/no TS release.
                                        Updates to MAP, SSDM sub-mods, SCTP, SCTPN, S7MGT
        08-Jul-11   MH    - DPK 6.3.6 - Test build. 
                                        Update RSI.
        03-Aug-11   MH    - DPK 6.3.6 - Actual 6.2.6 release.
                                        Update S7LOG, SCTP and SCTPN.
        08-Sep-11   MH    - DPK 6.3.7 - TS121DPK
        27-Sep-11   MH    - DPK 6.3.8 - Respin.
        06-Dec-11   MH    - DPK 6.3.9 - TS126DPK.
        30-Jan-12   MH    - DPK 6.3.10 - Partial release.
        07-Mar-12   JCo   - DPK 6.3.11 - Partial release - MAP.
        15-Mar-12   JCo   - DPK 6.4.0 - TS130DPK release. 
        04-Apr-12   JCo   - DPK 6.4.1 - Partial release - MAP.
        28-May-12   IDP   - DPK 6.4.2 - Partial release - SSDM.
        xx-xxx-12   JCo   - DPK 6.4.3 - ?
        12-Sep-12   MH    - DPK 200.14.2 - Partial release - gctlib (TS122DPK merge).
        20-Sep-12   MH    - DPK 6.4.4 - Partial release - M3UA + s7MGT
        24-Oct-12   JLP   - DPK 6.4.5 - Partial release - M3UA 
        09-Nov-12   MH    - DPK 6.5.0 - TS135DPK - Diameter.
        03-Jan-13   RAJ   - Update copyright year
        28-Jan-13   RAJ   - Preparation for DMR SRA release.
        20-Jan-13   MH    - DPK 6.5.2 - MAP update
        02-Apr-13   MH    - DPK 6.5.3 - Full release. No TS.
        ??-Apr-13   ??    - DPK 6.5.4 - ??
        20-Jun-13   MH    - DPK 6.5.5 - Partial release - S7MGT + SCTPN.
        25-Jun-13   MH    - DP 200.14.3 - Partial release: SSDL HMP release.
        04-Jul-13   MH    - DPK 6.6.0 - TS141DPK
        04-Sep-13   MH    - DPK 6.6.1 - TS141DPK SRA
        04-Sep-13   IDP   - DPK 200.14.4 - Partial release - SS7MD driver
        06-Sep-13   MH    - DPK 6.6.2 - MAP
        21-Oct-13   MH    - DPK 6.6.3 
        07-Nov-13   MH    - DPK 6.6.4
        28-Nov-13   MH    - DPK 6.6.5 - SSDL build
        03-Dec-13   MH    - DPK 6.6.6 - SS7MD driver update.
        15-Dec-13   MH    - DPK 6.6.7 - TS144DPK - pre-release of SCTPN + MGR
        27-Jan-14   MH    - DPK 6.6.8 - SCTPN update.
        18-Mar-14   MH    - DPK 6.6.9 - Another SCTPN update.
        02-Apr-14   MH    - DPK 6.6.10 - SCTPN 2.2.5
        04-Apr-14   MH    - DPK 6.6.11 - TS144DPK.
        28-May-14   MH    - DPK 6.6.12 - S7MGT, MAP, INAP + INAPAPI update.
        28-Aug-14   MH    - DPK 6.6.13 - MAP update.
        03-Sep-14   MH    - DPK 6.6.14 - IS41 update.
        30-Sep-14   MH    - DPK 6.6.15 - (Another) IS41 update.
        02-Oct-14   MH    - DPK 6.6.16 - TS150DPK
        26-Nov-14   MH    - DPK 6.6.17 - MST update
        06-Dec-14   MH    - DPK 6.6.18 - M3UA update
        25-Feb-15   MH    - DPK 6.7.0 - Pre-built work
        27-Feb-15   MH    - DPK 6.6.19 - Rollback for MST release.
        24-Apr-15   MH    - DPK 6.7.0 - TS152DPK
        14-May-15   MH    - DPK 6.7.1 - CN718DPK
        14-May-15   MH    - DPK 6.7.2 - S7MGT update.
        23-Jun-15   HJM   - DPK 6.7.3 - MST update.
        03-Aug-15   MH    - DPK 6.7.4 - S7MGT update.
        04-Sep-15   HJM   - DPK 6.7.5 - DMR update.
        28-Sep-15   MH    - DPK 6.7.6 - INAP update.
        06-Oct-15   HJM   - DPK 6.7.7 - DMR update.
        01-Nov-15   MH    - DPK 6.7.8 - MAP + DSA updates for Broadforward.
        16-Feb-16   MH    - DPK 200.14.5 - M2PA dev build.
        15-Mar-16   MH    - DPK 6.8.0 - TS159DPK
        18-Apr-16   HJM   - DPK 6.8.1 - CN019DMR 
        21-Apr-16   MH    - DPK 6.8.2 - INAP/INAPI update.
        19-May-16   MH    - DPK 6.8.3 - Update MGR + RPM script.
        25-May-16   MH    - DPK 6.8.4 - G51 testing only.
        20-Jul-16   MH    - DPK 6.8.4 - Update SCTPN + SYSSEC.
        29-Jul-16   MH    - DPK 6.8.5 - Update MAP.
        08-Sep-16   MH    - DPK 6.8.6 - Fix TEMPMON makefile.
        13-Jan-17   MH    - DPK 6.8.7 - IS41 trial build.
        16-Feb-17   MH    - DPK 6.8.7 - TCAP + MAP updates.
        21-Mar-17   MH    - DPK 6.8.8 - Update.
        28-Mar-17   MH    - DPK 6.8.9 - CPL update. (Did not go out).
        11-Apr-17   MH    - DPK 6.8.9 - MAP update.
        21-Apr-17   MH    - DPK 6.8.10 - SCTPN update.
        04-Jul-17   MH    - DPK 6.8.11 - Misc. update.
        14-Jul-17   MH    - DPK 6.8.12 - DMR update.
        10-Aug-17   MH    - DPK 6.8.13 - DMR/RADV update.
        22-Aug-17   RAJ   - DPK 6.8.14 - DMR/RADV update.
        24-Sep-17   MH    - DPK 6.8.15 - TS176DPK.
        27-Sep-17   MH    - DPK 200.
        13-Oct-17   MH    - DPK 6.8.16 - GCTLOAD/GCTLIB
        24-Oct-17   MH    - DPK 6.8.17 - GCTLOAD/GCTLIB
        24-Oct-17   MH    - DPK 6.8.18 - INAPAPI
*/


/*
 * ----------------------------------------
 * DPK Binaries
 * ----------------------------------------
 */

#define PRODUCT_LABEL_PREFIX    "DPKLNX"

#define PRODUCT_COPYRIGHT       2017

/*
 * Last production release:     6.8.18
 * Last development release:    200.14.5
 */
#define PRODUCT_MAJREV          6
#define PRODUCT_MINREV          8
#define PRODUCT_SPKREV          18

/*
 *      ***** Warning! *******
 *      Do not manually modify the #define below.
 *      It will be updated automatically by the scm/label_build script.
 */
#define PRODUCT_BLDREV           1312

