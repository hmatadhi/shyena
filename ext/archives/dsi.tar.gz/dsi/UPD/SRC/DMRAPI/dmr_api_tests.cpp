/*
Copyright (C) Dialogic Inc 2013.  All Rights Reserved.

Name:         dmr_api_tests.cpp

Description:  Test code to illustrate the use of the Diameter
Functional API

Project:      Diameter C++ API

---------  -----  ---------------------------------------------
Date      By                     Changes
---------  -----  ---------------------------------------------
27-Mar-13   HJM    Initial code
*/

#include <iostream>
#include <stdexcept>

#include <stdio.h>
#include <assert.h>


/*
* These header files are found in the "INC" directory of the Dialogic DSI DPK.
* They contain function prototypes and definitions for using the GCT
* message passing environment and for the Dialogic DSI Diameter Stack (DMR module).
*/
extern "C"
{
#include "system.h"
#include "msg.h"
#include "sysgct.h"
#include "ss7_inc.h"
#include "dmr_inc.h"
}

/*
* These header files are also found in the DSI DPK and are part of the 
* DSI Diameter Stack functional API. 
*/
#include "i_dmr_context.h"
// Add additional include files for the Diameter commands you need to use
#include "ts29272/UpdateLocationRequest.h"
#include "ts29272/UpdateLocationAnswer.h"
#include "ts29172/ProvideLocationRequest.h"
#include "ts29172/ProvideLocationAnswer.h"

/*
* The Functional API makes use of a number of namespaces to organise code
* and to help with its use.
*/
// Contains generic classes for data structures used within the API
using namespace com_dialogic_signaling::util;

// Contains classes modelling the DMR module API 
using namespace com_dialogic_signaling::dmr;
using namespace com_dialogic_signaling::dmr::user;

// Contains classes modelling generic Diameter commands and avps
using namespace com_dialogic_signaling::diameter;
// Contains classes modelling commands and avps defined in rfc3588
using namespace com_dialogic_signaling::diameter::rfc3588;

/*
* These constants hold information about the configuration of your DSI system.
* The Dialogic DSI Message passing environment is configured (by your 
* system.txt file) with a number of message queues each identified by a single
* byte ID. Each Task or module using the message passing environment is 
* assigned a MODULE_ID matching which identifies the message queue.
* Within the system.txt file these are defined as follows :
*   'LOCAL <module_id>'
*
* We are assigning a module ID of '0x1d' to this example application.
* By default the DSI DMR module uses DMR_TASK_ID which holds the value '0x74' 
*/ 
static const u8 MY_MODULE_ID = 0x1d;
/*
* Also the DSI DMR module is configured at startup with a static range of 
* session_ids for user initiated sessions (outgoing sessions) and for
* network initiated sessions (incoming sessions). By convention outgoing 
* sessions take valules from '0' to '0x7fff' and incoming sessions take values
* from '0x8000' to '0xfffe'.
* The User application is responsible for allocating new session ids for 
* outgoing sessions and the DMR module for incoming sessions.
*/
static const u16 MAX_OUTGOING_SESSION_ID = 0x7fff;

/*
* Function prototypes used in this file.
*/
IDmrContext * DMR_API_TEST_build_dmr_context(void);
IDmrSessionReq * DMR_API_TEST_build_dmr_session_open_req(IDmrContext * dmr_context);
u16 DMR_API_TEST_get_new_session_id(void);
void DMR_API_TEST_build_provide_location_request(IDmrSessionReq * dmr_session_req);
void DMR_API_TEST_build_provide_location_answer(IDmrSessionInd * dmr_session_ind);
void DMR_API_TEST_transmit_dmr_session_req(IDmrContext * dmr_context, IDmrSessionReq * dmr_session_req);
IDmrSessionInd * DMR_API_TEST_receive_dmr_sesson_ind(IDmrContext * dmr_context);
int DMR_API_TEST_process_dmr_session_ind(IDmrSessionInd * dmr_session_ind);
int DMR_API_TEST_process_provide_location_answer(ts29172::ProvideLocationAnswer * dmtr_cmd);
void DMR_API_TEST_inject_dmr_session_ind(IDmrContext * dmr_context);


/*
* main - Entry point to the example application
*
* This example shows step by step how to use the DSI DMR functional API.
* It illustrates what needs to be done at system start up, followed by the
* process of creating and sending a DMR_SESSION_REQ to the DSI DMR module
* and then receiving a DMR_SESSION_IND back in response. 
*
* This example requires a simple GCT environment to be running allowing GCT 
* Messages to be allocated and sent. This requires only two module IDs and 
* a pool of large messages to be allocated which is achieved by a system.txt 
* file with the following lines.
* Note: s7_log is being run in place of DMR to print out the sent messages
*

LOCAL 0x1d * My module Id
LOCAL 0x74 * DMR module
NUM_LMSGS 1000
FORK_PROCESS /dsi/s7_log -tt -m0x74

* The gct environment is started by the gctload binary 
*   gctload -csystem.txt
*/
int main(int argc, char ** argv)
{
  IDmrContext * dmr_context;
  IDmrSessionReq * dmr_session_req;
  IDmrSessionInd * dmr_session_ind;

  printf ("DMR API Test Application\n");

  /*
  * The DmrContext object is created at the system startup and used through
  * the lifetime of your application.
  */
  dmr_context = DMR_API_TEST_build_dmr_context();

  /*
  * Having created a dmr_context lets start to build a request message
  * To send to the DSI DMR module.
  */
  dmr_session_req = DMR_API_TEST_build_dmr_session_open_req(dmr_context);

  /*
  * Our request now needs the a diameter command to be included. For this
  * example we are going to use a provide location request command
  */
  DMR_API_TEST_build_provide_location_request(dmr_session_req);

  /*
  * We now have a complete dmr_session_req object. The next step is to have
  * this encoded to a DMR_SESSION_REQ messages and sent to the DMR module
  */
  DMR_API_TEST_transmit_dmr_session_req(dmr_context, dmr_session_req);

  dmr_session_ind = DMR_API_TEST_receive_dmr_sesson_ind(dmr_context);

  DMR_API_TEST_process_dmr_session_ind(dmr_session_ind);

}


/*
* DMR_API_TEST_build_dmr_context - this illustrates the creation and 
* configuration of a DmrContext object. DmrContext contains methods to help
* encode and decode messages which are part of the DMR message API into 
* the class based functional API. This includes specific Diameter Commands
* which you wish to use.
*
* The Dialogic DSI Diameter Stack includes XML Diameter Dictionaries which define
* Diameter commands and avps and a utility for generating corresponding classes (dms).
* You can add to and modify these dictionary files as neccesary and create your
* own variants, or just stick to the ones we provide and ship as part of the DSI DPK.
*/
IDmrContext * DMR_API_TEST_build_dmr_context(void)
{
  // Instantiate new instance
  IDmrContext * dmr_context = DMR_CONTEXT_build_new_instance(); 
  // Set the source module id used when sending messages
  dmr_context->set_src_module_id(MY_MODULE_ID);
  // Register commands which we expect to send or receive - this gives the dmr_context 
  // sufficient knowledge of the commands to encode and decode them to and from their class based form
  dmr_context->register_diameter_command(ts29272::UpdateLocationRequest::get_diameter_command_container_description());
  dmr_context->register_diameter_command(ts29272::UpdateLocationAnswer::get_diameter_command_container_description());
  dmr_context->register_diameter_command(ts29172::ProvideLocationRequest::get_diameter_command_container_description());
  dmr_context->register_diameter_command(ts29172::ProvideLocationAnswer::get_diameter_command_container_description());

  return dmr_context;
}


/*
* DMR_API_TEST_build_dmr_session_open_req - 
*
* All application requests from the user module to the DMR module use the
* DMR_SESSION_REQ message defined in the DMR programmes manual. When you are
* opening a new session then you must set the primitive type to OPEN.
*
* Note: even simple request / response transactions have a Diameter session.
*/
IDmrSessionReq * DMR_API_TEST_build_dmr_session_open_req(IDmrContext * dmr_context)
{
  // The DmrContext builds a new session request object for us.
  IDmrSessionReq * dmr_session_req = dmr_context->get_dmr_session_req_encoder()->build_dmr_session_req();

  // set the primitive type
  dmr_session_req->set_primitive_type(DMRSR_OPEN);
  // allocate and set a new session id
  dmr_session_req->set_session_id(DMR_API_TEST_get_new_session_id());
  // 
  // The following are not needed for basic operation
  // dmr_session_req->set_network_context(0); 
  // dmr_session_req->set_routing_policy_key(0);
  // dmr_session_req->set_store_command();

  return dmr_session_req;
}

/*
* DMR_API_TEST_build_provide_location_request -
*
* This builds (and adds to the dmr_session_req) a Provide Location Request
*/
void DMR_API_TEST_build_provide_location_request(IDmrSessionReq * dmr_session_req)
{
  /*
  * The Provide Location Request message is defined by 3GPP ts29172. All the 
  * classes are defined in a namespace corresponding to the defining standard.
  * This allows unambiguous understanding of what command you are dealing with 
  * and the ability to define and differentiate variants of these commands.
  */
  ts29172::ProvideLocationRequest * cmd = new ts29172::ProvideLocationRequest();

  dmr_session_req->set_diameter_command(cmd);

  /*
  * Note: the namespace of the base diameter specification 'rfc3588' was
  * defined at the top of the file removing the need to specify this for avps
  * and commands defined within it
  */
  cmd->addSessionIDAvp(new avps::SessionIDAvp("sessionIdAvp"));
  cmd->addOriginHostAvp(new avps::OriginHostAvp("origin.host.avp"));
  cmd->addOriginRealmAvp(new avps::OriginRealmAvp("origin.realm.avp"));
  cmd->addDestinationHostAvp(new avps::DestinationHostAvp("destination.host.avp"));
  cmd->addDestinationRealmAvp(new avps::DestinationRealmAvp("destination.realm.avp"));

  // Note: enumerated avps have the enumerated values defined within the AVP class
  cmd->addAuthSessionStateAvp(
    new avps::AuthSessionStateAvp(
    avps::AuthSessionStateAvp::STATE_MAINTAINED
    ));
  cmd->addImeiAvp(new ts29272::avps::ImeiAvp("ImeiAvp"));
  cmd->addLcsClientTypeAvp(
    new ts32299::avps::LcsClientTypeAvp(
    ts32299::avps::LcsClientTypeAvp::VALUE_ADDED_SERVICES
    ));
  // Grouped Avps go on to define the avps they contain in a similar manner 
  cmd->addLcsCodewordAvp(new ts29172::avps::LcsCodewordAvp("LcsCodewordAvp"));
  {
    ts29172::avps::LcsEpsClientNameAvp * avp = new ts29172::avps::LcsEpsClientNameAvp();
    avp->addLcsFormatIndicatorAvp(
      new ts32299::avps::LcsFormatIndicatorAvp(
      ts32299::avps::LcsFormatIndicatorAvp::MSISDN
      ));
    avp->addLcsNameStringAvp(
      new ts32299::avps::LcsNameStringAvp(
      "ts32299::avps::LcsNameStringAvp"
      ));
    cmd->addLcsEpsClientNameAvp(new ts29172::avps::LcsEpsClientNameAvp(avp));
  }
  cmd->addLcsPriorityAvp(
    new ts29172::avps::LcsPriorityAvp(
    12
    ));

  {
    ts29172::avps::LcsPrivacyCheckNonSessionAvp * avp = new ts29172::avps::LcsPrivacyCheckNonSessionAvp();
    avp->addLcsPrivacyCheckAvp(
      new ts29172::avps::LcsPrivacyCheckAvp(
      ts29172::avps::LcsPrivacyCheckAvp::ALLOWED_IF_NO_RESPONSE
      ));
    cmd->addLcsPrivacyCheckNonSessionAvp(avp);
  }
  {
    ts29172::avps::LcsPrivacyCheckNonSessionAvp * avp = new ts29172::avps::LcsPrivacyCheckNonSessionAvp();
    avp->addLcsPrivacyCheckAvp(
      new ts29172::avps::LcsPrivacyCheckAvp(
      ts29172::avps::LcsPrivacyCheckAvp::ALLOWED_IF_NO_RESPONSE
      ));
    cmd->addLcsPrivacyCheckNonSessionAvp(avp);
  }
  {
    ts29172::avps::LcsQosAvp * avp = new ts29172::avps::LcsQosAvp();
    avp->addHorizontalAccuracyAvp(
      new ts29172::avps::HorizontalAccuracyAvp(
      32
      ));
    avp->addLcsQosClassAvp(
      new ts29172::avps::LcsQosClassAvp(
      ts29172::avps::LcsQosClassAvp::BEST_EFFORT
      ));

    avp->addResponseTimeAvp(
      new ts29172::avps::ResponseTimeAvp(
      ts29172::avps::ResponseTimeAvp::DELAY_TOLERANT
      ));
    avp->addVerticalAccuracyAvp(
      new ts29172::avps::VerticalAccuracyAvp(
      64
      ));
    avp->addVerticalRequestedAvp(
      new ts29172::avps::VerticalRequestedAvp(
      ts29172::avps::VerticalRequestedAvp::VERTICAL_COORDINATE_IS_NOT_REQUESTED
      ));
    cmd->addLcsQosAvp( new ts29172::avps::LcsQosAvp( avp));
  }
  cmd->addLcsServiceTypeIDAvp(
    new ts29172::avps::LcsServiceTypeIDAvp(
    12346
    ));
  cmd->addLocationTypeAvp(
    new ts29172::avps::LocationTypeAvp(
    ts29172::avps::LocationTypeAvp::INITIAL_LOCATION
    ));

  {
    /*
    * An OctetString class has been defined to model strings of data of arbitrary length
    * If the data passed in is const then the initialiser will copy the data otherwise
    * it will take the data as its own and will deallocate it when it is destroyed.
    */
    const u8 msisdn[] = {0xab, 0xbc, 0xcd, 0xde};
    cmd->addMsisdnAvp(
      new ts29329::avps::MsisdnAvp(
      new OctetString(sizeof(msisdn), msisdn)
      ));
  }

  cmd->addServiceSelectionAvp(
    new rfc5778::avps::ServiceSelectionAvp(
    "ServiceSelectionAvp"
    ));
  {
    ts29229::avps::SupportedFeaturesAvp * avp = new ts29229::avps::SupportedFeaturesAvp();
    avp->addFeatureListAvp(
      new ts29229::avps::FeatureListAvp(
      2345
      ));
    avp->addFeatureListIDAvp(
      new ts29229::avps::FeatureListIDAvp(
      3456
      ));
    avp->addVendorIDAvp(
      new rfc3588::avps::VendorIDAvp(
      140567
      ));

    cmd->addSupportedFeaturesAvp(avp);
  }
  cmd->addSupportedGadShapesAvp(
    new ts29172::avps::SupportedGadShapesAvp(
    4567
    ));
  cmd->addUserNameAvp(
    new rfc3588::avps::UserNameAvp(
    "UserNameAvp"
    ));
  cmd->addVelocityRequestedAvp(
    new ts29172::avps::VelocityRequestedAvp(
    ts29172::avps::VelocityRequestedAvp::VELOCITY_IS_NOT_REQUESTED
    ));
  {
    rfc3588::avps::VendorSpecificApplicationIDAvp * avp = new rfc3588::avps::VendorSpecificApplicationIDAvp();
    avp->addAcctApplicationIDAvp(
      new rfc3588::avps::AcctApplicationIDAvp(
      0x1000034
      ));
    avp->addVendorIDAvp(
      new rfc3588::avps::VendorIDAvp(
      5678
      ));

    cmd->addVendorSpecificApplicationIDAvp(avp);
  }
}

/*
* DMR_API_TEST_transmit_dmr_session_req -
*
* All interaction with the DMR module is through GCT messages. This function
* takes a DmrSessionReq object and encodes it into its corresponding serialized 
* messasge form and transmits it.
* 
* Note: If s7_log is running in the place of the DMR module as suggested
* then you can see the message printed out and compare it to the definition in
* the manual
*/
void DMR_API_TEST_transmit_dmr_session_req(IDmrContext * dmr_context, IDmrSessionReq * dmr_session_req)
{
  u16   msg_len;
  MSG * gct_msg;
  // start by finding out the serialized length
  msg_len = (u16) dmr_context->get_dmr_session_req_encoder()->calculate_length(dmr_session_req);
  // get a free message of suitable length from the GCT environment
  gct_msg = getm(0,0,0,msg_len);
  if(gct_msg == NULL)
  {
    /*
    * from a command line run gctload -t1 to check the GCT environment is 
    * running and to see how many free messages there are.
    * Note: Encoded Diameter commands may require large GCT messages
    */
    throw std::runtime_error("Could not get GCT MSG - have you started the GCT environment? Have you run out of free messages");
  }
  // encode the dmr_session_req object into the message
  dmr_context->get_dmr_session_req_encoder()->encode(dmr_session_req, gct_msg);
  // send the message - once sent then 
  if(GCT_send(gct_msg->hdr.dst, (HDR *)gct_msg) != 0)
  {
    /*
    * There was a problem sending the message - perhaps the destination 
    * module id has not been configured in the system.txt file?
    * We must release the message ourselves - if it has been successfully sent
    * then this is not required
    */
    relm((HDR*)gct_msg);
  }

}



/*
* DMR_API_TEST_receive_dmr_sesson_ind - Illustrates how to receive messages
*/
IDmrSessionInd * DMR_API_TEST_receive_dmr_sesson_ind(IDmrContext * dmr_context)
{
  MSG * rxed_msg;
  IDmrSessionInd * dmr_session_ind;

  /*
  * Under normal operation the DSI DMR module would send Diameter requests 
  * received from the network to our Modeule encapsulated in a DMR_SESSION_IND 
  * message. For simplicities sake we are going to create a DMR_SESSION_IND  
  * message and send it to ourselves. The reception of the message and processing
  * can then continue as if it were sent from the DMR module itself.
  */
  DMR_API_TEST_inject_dmr_session_ind(dmr_context);

  /*
  * This while loop will continue to wait for messages until it has received a
  * DMR_SESSION_IND message. Your application may receive other messages in
  * addition.
  */
  while(1)
  {
    /*
    * GCT_receive is a blocking call. GCT_grab is non blocking
    */
    rxed_msg = (MSG *)GCT_receive(MY_MODULE_ID);
    /*
    * On some systems GCT_receive may return when a Signal is received. In this
    * case NULL is returned
    */
    if(rxed_msg != NULL)
    {
      /*
      * The message header type field tells us the message type, the format of
      * all DSI DMR messages are defined in the DMR Programmer's Manual. Other
      * messages are defined in other manuals
      */
      switch(rxed_msg->hdr.type)
      {
      case DMR_MSG_SESSION_IND :

        // Now decode the Message to the class based form
        dmr_session_ind = dmr_context->get_dmr_session_ind_encoder()->decode(rxed_msg);
        // We have finished with the MSG so release it
        relm((HDR*)rxed_msg);

        return dmr_session_ind;

      default:
        /*
        * Normally you would perform some processing on other messages rather than
        * just freeing them
        */
        relm((HDR*)rxed_msg);
        break;
      }
    }
  }
}

/*
* DMR_API_TEST_process_dmr_session_ind - 
*
* This illustrates how to process a dmr_session_ind object once it 
* has been received and parsed
*/
int DMR_API_TEST_process_dmr_session_ind(IDmrSessionInd * dmr_session_ind)
{
  IDiameterCommand * dmtr_cmd;
  u8 * req_primitive_type;

  /*
  * The session id is used to tell you which session this relates to. There
  * may be many simultaneous sessions ongoing at once. Typically you would use
  * this ID to find, or create, your own session context objects.
  */
  u16 * session_id = dmr_session_ind->get_session_id();

  /*
  * The dmr_session_ind may contain one of a number of primitive types
  */
  req_primitive_type = dmr_session_ind->get_primitive_type();
  switch(*req_primitive_type)
  {
    /*
    * CLOSE indicates that this is the last message for the session and that
    * the DMR module has now freed all of its resources for the session.
    * Once our processing is complete we should free our session context 
    */
  case DMRSR_CLOSE:
    /*
    * The CLOSE may include a Diameter Command, perhaps an answer
    * to a previous request
    */
    dmtr_cmd = dmr_session_ind->get_diameter_command();

    // A NULL pointer is valid and indicates a Diameter Command is not present
    if(dmtr_cmd != NULL)
    {
      // We will now check the diameter command code
      switch(dmtr_cmd->get_command_code())
      {
        // Each Command Class contains a static const value with its command code
      case ts29172::ProvideLocationAnswer::STANDARD_COMMAND_CODE:
        // We then call a function to process a provide_location_answer command
        DMR_API_TEST_process_provide_location_answer(
          dynamic_cast<ts29172::ProvideLocationAnswer *>(dmtr_cmd)
          );
        break;

      }
      break;
    }

  case DMRSR_P_ABORT:
    /*
    * If the DMR module cannot satisfy a DMR_SESSION_REQ it may return a PROVIDER_ABORT indicating
    * the error reason. This closes the session
    */
    printf("P_ABORT received: reason = %d\n", *dmr_session_ind->get_provider_abort_reason());
    break;

  case DMRSR_NOTIFY:
    // The DMR module may Notify the User of some event without closing the session using NOTIFY
    printf("NOTIFY received: reason = %d\n", *dmr_session_ind->get_notify_reason());
    break;


    //The first primitive for a new session must be an OPEN.
  case DMRSR_OPEN:
    // Sessions with multiple transactions may use CONTINUE primities after OPEN and before CLOSE
  case DMRSR_CONTINUE:
  default:
    break;

  }
  return 0;
}

/*
* DMR_API_TEST_process_provide_location_answer
*
* This shows how to access the information contained within a specifc Diameter Command
*/
int DMR_API_TEST_process_provide_location_answer(ts29172::ProvideLocationAnswer * pla)
{
  IUnsigned32Avp * u32_avp;
  IUtf8StringAvp * string_avp;
  IEnumeratedAvp * enum_avp;
  ts29229::avps::SupportedFeaturesAvp * sf_avp;

  try
  {
    if((u32_avp = pla->getResultCodeAvp()) != NULL)
      std::cout << "Result Code = " << u32_avp->get_u32() << std::endl;

    if((string_avp = pla->getOriginHostAvp()) != NULL)
      std::cout << "Origin Host = " << string_avp->get_string() << std::endl;

    if((string_avp = pla->getOriginRealmAvp()) != NULL)
      std::cout << "Origin Realm = " << string_avp->get_string() << std::endl;

    if((enum_avp = pla->getAccuracyFulfilmentIndicatorAvp()) != NULL)
      std::cout << "Accuracy Fulfilment Indicator = " << enum_avp->get_s32() << std::endl;

    if((sf_avp = pla->getSupportedFeaturesAvp()) != NULL)
    {
      if((u32_avp = sf_avp->getVendorIDAvp()) != NULL)
        std::cout << "Vendor ID = " << u32_avp->get_u32() << std::endl;

      if((u32_avp = sf_avp->getFeatureListAvp()) != NULL)
        std::cout << "Feature List = " << u32_avp->get_u32() << std::endl;

      if((u32_avp = sf_avp->getFeatureListIDAvp()) != NULL)
        std::cout << "Feature List ID = " << u32_avp->get_u32() << std::endl;
    }

  }
  catch(std::exception &ex)
  {
    std::cout << ex.what() << std::endl;
  }
  return (0);
}


/*
* DMR_API_TEST_inject_dmr_session_ind
*
* Creates a DMR_MSG_SESSION_REQ and sends it to our message queue
* to simulate a message coming from the network via the DMR module
*/
void DMR_API_TEST_inject_dmr_session_ind(IDmrContext * dmr_context)
{
  MSG * gct_msg;
  u32 gct_msg_len;
  IDmrSessionInd * dmr_session_ind = dmr_context->get_dmr_session_ind_encoder()->build_dmr_session_ind();
  dmr_session_ind->set_session_id(0);
  dmr_session_ind->set_primitive_type(DMRSR_CLOSE);
  DMR_API_TEST_build_provide_location_answer(dmr_session_ind);

  gct_msg_len = dmr_context->get_dmr_session_ind_encoder()->calculate_length(dmr_session_ind);
  gct_msg = getm(0,0,0,(u16)gct_msg_len);
  dmr_context->get_dmr_session_ind_encoder()->encode(dmr_session_ind, gct_msg);
  gct_msg->hdr.dst = MY_MODULE_ID;
  gct_msg->hdr.src = 0x71;
  GCT_send(MY_MODULE_ID, (HDR *)gct_msg);
}

/*
 * DMR_API_TEST_build_provide_location_answer
 *
 * Builds a Provide Location Answer Diameter Command
 */
void DMR_API_TEST_build_provide_location_answer(IDmrSessionInd * dmr_session_ind)
{
  ts29172::ProvideLocationAnswer * cmd = new ts29172::ProvideLocationAnswer();

  dmr_session_ind->set_diameter_command(cmd);

  cmd->addSessionIDAvp(new avps::SessionIDAvp("sessionIdAvp"));
  cmd->addOriginHostAvp(new avps::OriginHostAvp("origin.host.avp"));
  cmd->addOriginRealmAvp(new avps::OriginRealmAvp("origin.realm.avp"));
  cmd->addResultCodeAvp(new avps::ResultCodeAvp(2000));
  cmd->addAuthSessionStateAvp(new avps::AuthSessionStateAvp(avps::AuthSessionStateAvp::STATE_MAINTAINED));
  cmd->addAccuracyFulfilmentIndicatorAvp(
    new ts29172::avps::AccuracyFulfilmentIndicatorAvp(
    ts29172::avps::AccuracyFulfilmentIndicatorAvp::REQUESTED_ACCURACY_FULFILLED
    ));
  {
    ts29229::avps::SupportedFeaturesAvp * sfa = new ts29229::avps::SupportedFeaturesAvp();
    sfa->addFeatureListAvp(new ts29229::avps::FeatureListAvp(45));
    sfa->addFeatureListIDAvp(new ts29229::avps::FeatureListIDAvp(56));
    sfa->addVendorIDAvp(new avps::VendorIDAvp(67));
    cmd->addSupportedFeaturesAvp(sfa);
  }
}

/*
 * DMR_API_TEST_get_new_session_id
 *
 * This is a simplistic function to return a new Session ID. More realistically
 * there might be a pool of stateful session objects which are 
 * returned to a free pool when the session is closed and from which 
 * new sessions (with corresponding session ids) can be allocated
 */
u16 DMR_API_TEST_get_new_session_id(void)
{
  static u32 outgoing_session_count = 0;
  return (u16)(outgoing_session_count++ % MAX_OUTGOING_SESSION_ID);
}



