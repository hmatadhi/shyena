/*
                Copyright (C) Dialogic Corporation 1994-2013. All Rights Reserved.

 Name:          tcap.h

 Description:   Header file for for use in conjunction
		with the TCAP interface library contained
		in the file tcap.c

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    25-Aug-94   SRG   - Initial code.
   B    31-Aug-94   SRG   - Released for evaluation.
   C    19-Oct-94   SRG   - cpt_present field removed from DLG_UABORT.
   D    30-Nov-94   SRG   - ASN_EDSC and TCAP_asn_locate added.
   E    20-Apr-98   SFP   - instance added to TCAP_CPT and TCAP_DLG
   F    29-Mar-00   JET   - Added handling for ANSI T.114 TCAP compatibility
                            Added protocol to dlg and cpt structures.
                            Permission to release parameter defition added.
   G    02-Feb-06   TB    - Include Intel Corp in file header
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
   -    14-May-13   CJM   - Add option to allow use with TCAP extended dialog IDs
 */


/*
 * Definitions for buffer sizes in the 'C' structured
 * representation of TCAP protocol primitives.
 *
 * Each value must allow space for the tag, length
 * and associated data to be stored.
 *
 * The user may need to change the values given in
 * order to support larger parameters or to reduce
 * the size of the structures if it is known that
 * certain parameters lengths will never be exceeded.
 *
 * The library functions ensure that the given xx_SIZE
 * is not exceeded.
 */
#define IV_SIZE         (4)     /* space for 'invoke_id' parameter */
#define OP_SIZE         (20)    /* space for 'operation' parameter */
#define PR_SIZE         (20)    /* space for 'parameter' parameter */
#define ER_SIZE         (20)    /* space for 'error' parameter */
#define PB_SIZE         (4)     /* space for 'problem' parameter */
#define AD_SIZE         (18)    /* space for 'orig/dest_addr' parameter */
#define AC_SIZE         (50)    /* space for 'ac_name' parameter */
#define UI_SIZE         (255)   /* space for 'user_info' parameter */
#define RP_SIZE         (1)     /* space for 'rel_perm' parameter */


/*
 * Definitions for error codes returned
 * from the library formatting functions:
 */
#define SPACE_ERROR     (1)
#define PTYPE_ERROR     (2)
#define FORMAT_ERROR    (3)


/*
 * Maximum parameter length in an MSG:
 */
#define TCP_MAX_PARAM_LEN  (320)


/*
 * Macro to take the 16 least significant bits of a Dialog ID
 * and return as a u16 type
 */
#define DID_16_LSB(did)              (u16)(did & 0xffff)


/*
 * Quality of service indicator octet definitions:
 * (to select more than one option, OR together options)
 */
#define QOSI_RET_OPT    (0x01)          /* Return Option */
#define QOSI_SEQ_CTRL   (0x02)          /* Sequence Control */
#define QOSI_SLS_KEY    (0x04)          /* SLS key present */
#define QOSI_PRIORITY   (0x08)          /* Message priority octet present */

/*
 * Protocol support
 * Used in the TCAP_CPT and TCAP_DLG structures to determine the protocol
 * specification being used.
 */
#define ITU_Q773        (0)
#define ANSI_T114       (1)

#define EXT_DID_ENABLED (1)


/********************************************************************
 *                                                                  *
 *          Structure definitions for Component Primitives          *
 *                                                                  *
 ********************************************************************/

typedef struct cpt_inv_id
{
  u16   len;
  u8    data[IV_SIZE];
} CPT_INV_ID;

typedef struct cpt_op
{
  u16   len;
  u8    data[OP_SIZE];
} CPT_OP;

typedef struct cpt_param
{
  u16   len;
  u8    data[PR_SIZE];
} CPT_PARAM;

typedef struct cpt_error
{
  u16   len;
  u8    data[ER_SIZE];
} CPT_ERROR;

typedef struct cpt_problem
{
  u16   len;
  u8    data[PB_SIZE];
} CPT_PROBLEM;

typedef struct cpt_invoke
{
  u16           class;          /* 1, 2, 3 or 4 */
  u16           timeout;        /* 0 .. 409 */
  CPT_INV_ID    invoke_id;
  CPT_INV_ID    linked_id;
  CPT_OP        operation;
  CPT_PARAM     param;
} CPT_INVOKE;

typedef struct cpt_rrl
{
  CPT_INV_ID    invoke_id;
  CPT_OP        operation;
  CPT_PARAM     param;
} CPT_RRL;

typedef struct cpt_rrnl
{
  CPT_INV_ID    invoke_id;
  CPT_OP        operation;
  CPT_PARAM     param;
} CPT_RRNL;

typedef struct cpt_uerror
{
  CPT_INV_ID    invoke_id;
  CPT_ERROR     error;
  CPT_PARAM     param;
} CPT_UERROR;

typedef struct cpt_ureject
{
  CPT_INV_ID    invoke_id;
  CPT_PROBLEM   problem;
} CPT_UREJECT;

typedef struct cpt_lreject
{
  CPT_INV_ID    invoke_id;
  CPT_PROBLEM   problem;
} CPT_LREJECT;

typedef struct cpt_rreject
{
  CPT_INV_ID    invoke_id;
  CPT_PROBLEM   problem;
} CPT_RREJECT;

typedef struct cpt_ucancel
{
  CPT_INV_ID    invoke_id;
} CPT_UCANCEL;

typedef struct cpt_lcancel
{
  CPT_INV_ID    invoke_id;
} CPT_LCANCEL;

typedef struct tcap_cpt
{
  u32   dialogue_id;            /* 32 bit value - see TCAP manual */
  u16   last_component;         /* either 0 or non-zero */
  u16   ptype;                  /* primitive type (TCPPT_xxx values) */
  int   instance;               /* Instance of TCAP handling this primitive */
  u8    protocol;               /* Is the component for Q773 or T114 TCAP */
  u8    ext_did;                /* Is Extended Dialog ID parameter required */
  union
  {
    CPT_INVOKE          invoke;
    CPT_RRL             rrl;
    CPT_RRNL            rrnl;
    CPT_UERROR          uerror;
    CPT_UREJECT         ureject;
    CPT_LREJECT         lreject;
    CPT_RREJECT         rreject;
    CPT_UCANCEL         ucancel;
    CPT_LCANCEL         lcancel;
  } u;
} TCAP_CPT;



/********************************************************************
 *                                                                  *
 *          Structure definitions for Dialogue Primitives           *
 *                                                                  *
 ********************************************************************/

typedef struct dlg_qos
{
  u8            indicator;
  u8            sls_key;
  u8            priority;
} DLG_QOS;

typedef struct dlg_addr
{
  u16           len;
  u8            data[AD_SIZE];
} DLG_ADDR;

typedef struct ac_name
{
  u16           len;
  u8            data[AC_SIZE];
} DLG_AC_NAME;

typedef struct usr_inf
{
  u16           len;
  u8            data[UI_SIZE];
} DLG_USR_INF;

typedef struct rel_perm
{
  u16           len;
  u8            data[RP_SIZE];
} DLG_REL_PERM;

typedef struct dlg_uni
{
  u8            cpt_present;            /* 0 or 1 */
  DLG_QOS       qos;
  DLG_ADDR      orig_addr;
  DLG_ADDR      dest_addr;
  DLG_AC_NAME   ac_name;
  DLG_USR_INF   user_info;
} DLG_UNI;

typedef struct dlg_begin
{
  u8            cpt_present;            /* 0 or 1 */
  DLG_QOS       qos;
  DLG_ADDR      orig_addr;
  DLG_ADDR      dest_addr;
  DLG_AC_NAME   ac_name;
  DLG_USR_INF   user_info;
  DLG_REL_PERM  rel_perm;
} DLG_BEGIN;

typedef struct dlg_continue
{
  u8            cpt_present;            /* 0 or 1 */
  DLG_QOS       qos;
  DLG_ADDR      orig_addr;
  DLG_AC_NAME   ac_name;
  DLG_USR_INF   user_info;
  DLG_REL_PERM  rel_perm;
} DLG_CONTINUE;

typedef struct dlg_end
{
  u8            cpt_present;            /* 0 or 1 */
  u8            termination;            /* 0 or 1 */
  DLG_QOS       qos;
  DLG_AC_NAME   ac_name;
  DLG_USR_INF   user_info;
  DLG_REL_PERM  rel_perm;
} DLG_END;

typedef struct dlg_uabort
{
  u8            abort_reason;
  DLG_QOS       qos;
  DLG_AC_NAME   ac_name;
  DLG_USR_INF   user_info;
  DLG_REL_PERM  rel_perm;
} DLG_UABORT;

typedef struct dlg_pabort
{
  u8            p_abort;
  DLG_QOS       qos;
} DLG_PABORT;

typedef struct dlg_notice
{
  u8            report_cause;
} DLG_NOTICE;

typedef struct tcap_dlg
{
  u32   dialogue_id;            /* 32 bit value - see TCAP manual */
  u16   ptype;                  /* primitive type (TCPPT_xxx values) */
  int   instance;               /* Instance of TCAP handling this primitive */
  u8    protocol;               /* Is the component for Q773 or T114 TCAP */
  u8    ext_did;                /* Is Extended Dialog ID parameter required */
  union
  {
    DLG_UNI             uni;
    DLG_BEGIN           begin;
    DLG_CONTINUE        cont;
    DLG_END             end;
    DLG_UABORT          uabort;
    DLG_PABORT          pabort;
    DLG_NOTICE          notice;
  } u;
} TCAP_DLG;


/*
 * Structure used in tcap.c to describe an ASN.1 element:
 */
typedef struct asn_edsc
{
  u16   tag_len;        /* length of tag */
  u16   len_len;        /* length of length encoding */
  u16   contents_len;   /* length of contents */
  u16   total_len;      /* total length of element */
  u8    *contents;      /* pointer to contents */
} ASN_EDSC;


/*
 * Prototypes for the functions in tcap.c:
 */
#ifdef LINT_ARGS
  int TCAP_component_to_msg(MSG *m, TCAP_CPT *component);
  int TCAP_msg_to_component(TCAP_CPT *component, MSG *m, u8 protocol, u8 ext_did);
  int TCAP_dialogue_to_msg(MSG *m, TCAP_DLG *dialogue);
  int TCAP_msg_to_dialogue(TCAP_DLG *dialogue, MSG *m, u8 protocol, u8 ext_did);
  void TCAP_erase_dialogue(TCAP_DLG *dlg);
  void TCAP_erase_component(TCAP_CPT *cpt);
  void TCAP_init_dialogue(TCAP_DLG *dlg, u8 protocol, u8 ext_did);
  void TCAP_init_component(TCAP_CPT *cpt, u8 protocol, u8 ext_did);
  int TCAP_locate_asn(u8 *dataptr, u16 datalen, ASN_EDSC *asne);
#else
  int TCAP_component_to_msg();
  int TCAP_msg_to_component();
  int TCAP_dialogue_to_msg();
  int TCAP_msg_to_dialogue();
  void TCAP_erase_dialogue();
  void TCAP_erase_component();
  void TCAP_init_dialogue();
  void TCAP_init_component();
  int TCAP_locate_asn();
#endif


