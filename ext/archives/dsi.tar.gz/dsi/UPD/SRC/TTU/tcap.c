/*
                Copyright (C) Dialogic Corporation 1994-2013. All Rights Reserved.

 Name:          tcap.c

 Description:   Library functions for interfacing with
		the Dialogic DSI TCAP module.

 Functions:     TCAP_component_to_msg   TCAP_msg_to_component
		TCAP_dialogue_to_msg    TCAP_msg_to_dialogue
		TCAP_erase_dialogue     TCAP_erase_component
		TCAP_locate_asn

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    25-Aug-94   SFP   - Initial code.
   B    31-Aug-94   SFP   - Released for evaluation.
   C    06-Sep-94   SRG   - abort_reason in P-abort indications now
			    defaults to TCPUABT_USER_DEFINED.
   D    02-Nov-94   SFP   - Corrections to parameter formatting for
			    dialogue requests.
			    lreject corrected to rreject/ureject in
			    param_to_rreject/param_to_ureject.
			    end corrected to uabort in uabort_to_param.
   D+   17-Nov-94   SRG   - param_to_end now explicitly initialises
			    the termination parameter.
			    2 bug fixes in ucancel_to_param.
   E    24-Nov-94   SFP	  - param_to_uabort will now recover application
			    context name (if present).
   E+   28-Nov-94   SFP   - param_to_lcancel now sets invoke_id->len to 3
			    on successful recovery. (previously defaulted
			    to zero). rrl/rrnl_to_param now checks for non
			    zero param and operation before adding a
			    'sequence of' tag.
   F    30-Nov-94   SRG   - ASN_locate_element renamed TCAP_asn_locate
			    and made public.
   G    27-Feb-97   MH    - Include string.h for memory utilities.
   H    20-Apr-98   SFP   - Added formatting and recovery of instance.
   I    29-Mar-00   JET   - Added handling for ANSI T.114 TCAP compatibility
   K    02-Feb-06   TB    - Include Intel Corp in file header
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.   
   -    14-May-13   CJM   - Add option to allow use with TCAP extended dialog IDs
                          - Correction to lengths tested when storing parameters
 */

#include <string.h>

#include "system.h"
#include "msg.h"
#include "sysgct.h"
#include "tcp_inc.h"
#include "tcap.h"

/*
 * Local definitions for Q773 TCAP tag values:
 */
#define TCAP_TAG_INVOKE         (0xa1)
#define TCAP_TAG_RRL            (0xa2)
#define TCAP_TAG_RE             (0xa3)
#define TCAP_TAG_REJECT         (0xa4)
#define TCAP_TAG_RRNL           (0xa7)
#define TCAP_TAG_INVOKEID       (0x02)
#define TCAP_TAG_LINKEDID       (0x80)
#define TCAP_TAG_LOCALOP        (0x02)
#define TCAP_TAG_GLOBALOP       (0x06)

/*
 * Local definitions for T114 TCAP tag values:
 */
#define TCAP_T114_TAG_INVOKE    (0xe9)
#define TCAP_T114_TAG_RRL       (0xea)
#define TCAP_T114_TAG_RE        (0xeb)
#define TCAP_T114_TAG_REJECT    (0xec)
#define TCAP_T114_TAG_CPTID     (0xcf)
#define TCAP_T114_TAG_NATOP     (0xd0)
#define TCAP_T114_TAG_PRIVOP    (0xd1)

/*
 * Values used for Q773 and T114 formatting:
 */
#define TCAP_TAG_SEQUENCE       (0x30)
#define TCAP_TAG_NULL           (0x05)
#define TCAP_TAG_EXT_VALUE      (0x1f)
#define TCAP_TAG_EXT_IND        (0x80)
#define TCAP_INDEFINITE_LEN     (0x80)

/*
 * Macros' for tag value manipulation:
 */
#define TCAP_TAG_CODE(t)   ((t) & 0x1f)
#define TCAP_TAG_CLASS(t)  ((t) & 0xc0)
#define TCAP_TAG_FORM(t)   ((t) & 0x20)
#define TCAP_TAG_EXT(t)    ((t) & 0x80)

/*
 * Macro to get space left in message m from position pointed to by pptr up
 * to max size of TCAP message.
 */
#define PARAM_SPACE_LEFT(m, pptr)     (TCP_MAX_PARAM_LEN - (pptr-get_param(m)))

/*
 * Other useful definitions:
 */
#define TERMINATOR      (0x00)          /* NLD terminator octet */
#define FPL_CLASS       (1)             /* NLD length of Class parameter */
#define FPL_TIMEOUT     (2)             /* NLD length of Timeout parameter */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  static int invoke_to_param(MSG *m, TCAP_CPT *cpt);
  static int param_to_invoke(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int rrl_to_param(MSG *m, TCAP_CPT *cpt);
  static int param_to_rrl(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int rrnl_to_param(MSG *m, TCAP_CPT *cpt);
  static int param_to_rrnl(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int uerror_to_param(MSG *m, TCAP_CPT *cpt);
  static int param_to_uerror(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int ucancel_to_param(MSG *m, TCAP_CPT *cpt);
  static int param_to_lcancel(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int param_to_lreject(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int param_to_rreject(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int param_to_ureject(TCAP_CPT *cpt, u8 *pptr, u16 len);
  static int ureject_to_param(MSG *m, TCAP_CPT *cpt);

  static int param_to_uni(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int uni_to_param(MSG *m, TCAP_DLG *dlg);
  static int param_to_begin(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int begin_to_param(MSG *m, TCAP_DLG *dlg);
  static int param_to_continue(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int continue_to_param(MSG *m, TCAP_DLG *dlg);
  static int param_to_end(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int end_to_param(MSG *m, TCAP_DLG *dlg);
  static int uabort_to_param(MSG *m, TCAP_DLG *dlg);
  static int param_to_uabort(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int param_to_pabort(TCAP_DLG *dlg, u8 *pptr, u16 len);
  static int param_to_notice(TCAP_DLG *dlg, u8 *pptr, u16 len);

  static int recover_invoke_id(u8 *pptr, u16 length, CPT_INV_ID *invoke_id, u8 protocol);
  static int recover_linked_id(u8 *pptr, u16 length, CPT_INV_ID *linked_id);
  static int recover_operation(u8 *pptr, u16 length, CPT_OP *operation, u8 protocol);
  static int recover_parameter(u8 *pptr, u16 length, CPT_PARAM *param);
  static int recover_error(u8 *pptr, u16 length, CPT_ERROR *param);
  static int recover_problem(u8 *pptr, u16 length, CPT_PROBLEM *param);

  static int format_qos(u8 *pptr, DLG_QOS *qos, MSG *m);
  static int recover_qos(DLG_QOS *qos, u8 *pptr, u16 plen);
  static int format_ext_did(u8 *pptr, u32 did, MSG *m);
  static int recover_ext_did(u32 *did, u8 *pptr, u16 plen);

  static u16 format_length(u8 *pptr, u16 component_length);
  static int copy_param(u8 *dest, u8 *src, u16 len);
#else
  static int invoke_to_param();
  static int param_to_invoke();
  static int rrl_to_param();
  static int param_to_rrl();
  static int rrnl_to_param();
  static int param_to_rrnl();
  static int uerror_to_param();
  static int param_to_uerror();
  static int ucancel_to_param();
  static int param_to_lcancel();
  static int param_to_lreject();
  static int param_to_rreject();
  static int param_to_ureject();
  static int ureject_to_param();

  static int param_to_uni();
  static int uni_to_param();
  static int param_to_begin();
  static int begin_to_param();
  static int param_to_continue();
  static int continue_to_param();
  static int param_to_end();
  static int end_to_param();
  static int param_to_uabort();
  static int uabort_to_param();
  static int param_to_pabort();
  static int param_to_notice();

  static int recover_invoke_id();
  static int recover_linked_id();
  static int recover_operation();
  static int recover_parameter();
  static int recover_error();
  static int recover_problem();

  static int format_qos();
  static int recover_qos();
  static int format_ext_did();
  static int recover_ext_did();

  static u16 format_length();
  static int copy_param();
#endif

/*
 * TCAP_component_to_msg converts the 'C' structured
 * representation of a component primitive request
 * to the format required by the TCAP module.
 *
 * Returns zero on success or an error code otherwise.
 */
int TCAP_component_to_msg(m, component)
  MSG           *m;             /* destination message */
  TCAP_CPT      *component;     /* structured component data to format */
{
  int   ret_val;                /* Return value */

  ret_val = PTYPE_ERROR;

  m->hdr.id = DID_16_LSB(component->dialogue_id);
  GCT_set_instance(component->instance, (HDR *)m);

  switch (component->ptype)
  {
    case TCPPT_TC_INVOKE :
      ret_val = invoke_to_param(m, component);
      break;

    case TCPPT_TC_RESULT_L :
      ret_val = rrl_to_param(m, component);
      break;

    case TCPPT_TC_RESULT_NL :
      ret_val = rrnl_to_param(m, component);
      break;

    case TCPPT_TC_U_ERROR :
      ret_val = uerror_to_param(m, component);
      break;

    case TCPPT_TC_U_CANCEL :
      ret_val = ucancel_to_param(m, component);
      break;

    case TCPPT_TC_U_REJECT :
      ret_val = ureject_to_param(m, component);
      break;

    default :
      break;
  }
  return(ret_val);
}

/*
 * TCAP_msg_to_component converts primitive indication
 * from the TCAP module into the 'C' structured
 * representation of a component primitive indication
 *
 * Returns zero on success or an error code otherwise.
 */
int TCAP_msg_to_component(component, m, protocol, ext_did)
  TCAP_CPT      *component;     /* structure to recover data to */
  MSG           *m;             /* message to recover data from */
  u8            protocol;       /* protocol of component to use */
  u8            ext_did;        /* extended DID required */
{
  int   ret_val;        /* Return value */
  u8    *pptr;          /* Pointer to primitive parameters data */
  u16   len;            /* Length of parameter data to be processed */
  int   plen;           /* Parameter length */

  ret_val = PTYPE_ERROR;

  len = m->len;

  /*
   * First set all fields in the component
   * structure to zero. Initialise to correct protocol.
   * This ensures that all parameter lengths are
   * zero and any optional fields are initialised
   * to known values.
   */
  TCAP_init_component(component, protocol, ext_did);

  pptr = get_param(m);
  component->dialogue_id = (u32)m->hdr.id;
  component->instance = GCT_get_instance((HDR*)m);

  /*
   * Find primitive type
   */
  if (len < 1)
    return(FORMAT_ERROR);
  component->ptype = *pptr++;
  len--;

  /*
   * If Extended Dialogue ID parameter is expected, it must be present and must be the first parameter.
   * Read the parameter and replace the DID set from MSG id field
   */
  if (component->ext_did)
  {
    plen = recover_ext_did(&component->dialogue_id, pptr, len);
    if (plen < 0)
      return(FORMAT_ERROR);
    pptr += plen;
    len -= plen;
  }

  switch (component->ptype)
  {
    case TCPPT_TC_INVOKE :
      ret_val = param_to_invoke(component, pptr, len);
      break;

    case TCPPT_TC_RESULT_L :
      ret_val = param_to_rrl(component, pptr, len);
      break;

    case TCPPT_TC_RESULT_NL :
      ret_val = param_to_rrnl(component, pptr, len);
      break;

    case TCPPT_TC_U_ERROR :
      ret_val = param_to_uerror(component, pptr, len);
      break;

    case TCPPT_TC_L_CANCEL :
      ret_val = param_to_lcancel(component, pptr, len);
      break;

    case TCPPT_TC_L_REJECT :
      ret_val = param_to_lreject(component, pptr, len);
      break;

    case TCPPT_TC_R_REJECT :
      ret_val = param_to_rreject(component, pptr, len);
      break;

    case TCPPT_TC_U_REJECT :
      ret_val = param_to_ureject(component, pptr, len);
      break;

    default :
      break;
  }
  return(ret_val);
}

/*
 * TCAP_dialogue_to_msg converts the 'C' structured
 * representation of a dialogue primitive request
 * to the format required by the TCAP module.
 *
 * Returns zero on success or an error code otherwise.
 */
int TCAP_dialogue_to_msg(m, dialogue)
  MSG           *m;             /* Message to format to */
  TCAP_DLG      *dialogue;      /* Structure containing data to format */
{
  int   ret_val;        /* Return value */

  ret_val = PTYPE_ERROR;

  m->hdr.id = DID_16_LSB(dialogue->dialogue_id);
  GCT_set_instance(dialogue->instance, (HDR*)m);

  switch (dialogue->ptype)
  {
    /*
     * Message types for ITU-T Q.773 and ANSI T.114
     *
     * TCPPTA_TC_UNI           = TCPPT_TC_UNI      Uni(directional)
     * TCPPTA_TC_QUERY         = TCPPT_TC_BEGIN    Query
     * TCPPTA_TC_CONVERSATION  = TCPPT_TC_CONTINUE Conversation
     * TCPPTA_TC_RESPONSE      = TCPPT_TC_END      Response
     * TCPPTA_TC_U_ABORT       = TCPPT_TC_U_ABORT  Abort (user)
     * TCPPTA_TC_P_ABORT       = TCPPT_TC_P_ABORT  Abort (protocol)
     * TCPPTA_TC_NOTICE        = TCPPT_TC_NOTICE   Notice
     */
    case TCPPT_TC_UNI :
      ret_val = uni_to_param(m, dialogue);
      break;

    case TCPPT_TC_BEGIN :
      ret_val = begin_to_param(m, dialogue);
      break;

    case TCPPT_TC_CONTINUE :
      ret_val = continue_to_param(m, dialogue);
      break;

    case TCPPT_TC_END :
      ret_val = end_to_param(m, dialogue);
      break;

    case TCPPT_TC_U_ABORT :
      ret_val = uabort_to_param(m, dialogue);
      break;

    default :
      break;
  }
  return(ret_val);
}

/*
 * TCAP_msg_to_dialogue converts primitive indication
 * from the TCAP module into the 'C' structured
 * representation of a dialogue primitive indication
 *
 * Returns zero on success or an error code otherwise.
 */
int TCAP_msg_to_dialogue(dialogue, m, protocol, ext_did)
  TCAP_DLG      *dialogue;      /* Structure to recover parameters to */
  MSG           *m;             /* Message to recover */
  u8            protocol;       /* protocol of component to use */
  u8            ext_did;        /* extended DID required */
{
  u8    *pptr;          /* Pointer to primitive parameters data */
  u16   len;            /* Length of parameter data to be processed */
  int   plen;           /* Parameter length */
  int   ret_val;        /* Return value */

  ret_val = PTYPE_ERROR;

  len = m->len;

  /*
   * First set all fields in the dialogue
   * structure to zero. This ensures that
   * all parameter lengths are zero and any
   * optional fields are initialised to known
   * values.
   */
  TCAP_init_dialogue(dialogue, protocol, ext_did);

  pptr = get_param(m);
  dialogue->dialogue_id = m->hdr.id;
  dialogue->instance = GCT_get_instance((HDR*)m);

  /*
   * Find primitive type
   */
  if (len < 1)
    return(FORMAT_ERROR);
  dialogue->ptype = *pptr++;
  len--;

  /*
   * If Extended Dialogue ID parameter is expected, it must be present and must be the first parameter.
   * Read the parameter and replace the DID set from MSG id field
   */
  if (dialogue->ext_did)
  {
    plen = recover_ext_did(&dialogue->dialogue_id, pptr, len);
    if (plen < 0)
      return(FORMAT_ERROR);
    pptr += plen;
    len -= plen;
  }

  switch (dialogue->ptype)
  {
    /*
     * Message types for ITU-T Q.773 and ANSI T.114
     *
     * TCPPTA_TC_UNI           = TCPPT_TC_UNI      Uni(directional)
     * TCPPTA_TC_QUERY         = TCPPT_TC_BEGIN    Query
     * TCPPTA_TC_CONVERSATION  = TCPPT_TC_CONTINUE Conversation
     * TCPPTA_TC_RESPONSE      = TCPPT_TC_END      Response
     * TCPPTA_TC_U_ABORT       = TCPPT_TC_U_ABORT  Abort (user)
     * TCPPTA_TC_P_ABORT       = TCPPT_TC_P_ABORT  Abort (protocol)
     * TCPPTA_TC_NOTICE        = TCPPT_TC_NOTICE   Notice
     */
    case TCPPT_TC_UNI :
      ret_val = param_to_uni(dialogue, pptr, len);
      break;

    case TCPPT_TC_BEGIN :
      ret_val = param_to_begin(dialogue, pptr, len);
      break;

    case TCPPT_TC_CONTINUE :
      ret_val = param_to_continue(dialogue, pptr, len);
      break;

    case TCPPT_TC_END :
      ret_val = param_to_end(dialogue, pptr, len);
      break;

    case TCPPT_TC_U_ABORT :
      ret_val = param_to_uabort(dialogue, pptr, len);
      break;

    case TCPPT_TC_P_ABORT :
      ret_val = param_to_pabort(dialogue, pptr, len);
      break;

    case TCPPT_TC_NOTICE :
      ret_val = param_to_notice(dialogue, pptr, len);
      break;

    default :
      ret_val = PTYPE_ERROR;
      break;
  }
  return(ret_val);
}

/*
 * TCAP_erase_dialogue sets all the contents
 * of a TCAP_DLG structure to zero.
 */
void TCAP_erase_dialogue(dlg)
  TCAP_DLG      *dlg;   /* dialogue structure to erase */
{
  memset((void *)dlg, 0, sizeof (TCAP_DLG));
}

/*
 * TCAP_erase_component sets all the contents
 * of a TCAP_CPT structure to zero.
 *
 * NOTE: This procedure has been replaced by TCAP_init_component which
 * allows the protocol to be set.
 */
void TCAP_erase_component(cpt)
  TCAP_CPT      *cpt;   /* component structure to erase */
{
  memset((void *)cpt, 0, sizeof (TCAP_CPT));
}

/*
 * TCAP_init_dialogue sets all the contents
 * of a TCAP_DLG structure to zero.
 */
void TCAP_init_dialogue(dlg, protocol, ext_did)
  TCAP_DLG      *dlg;      /* dialogue structure to erase */
  u8            protocol;  /* protocol specification to use */
  u8            ext_did;   /* extended DID required */
{
  memset((void *)dlg, 0, sizeof (TCAP_DLG));
  dlg->protocol = protocol;
  dlg->ext_did  = ext_did;
}

/*
 * TCAP_init_component sets all the contents
 * of a TCAP_CPT structure to zero.
 */
void TCAP_init_component(cpt, protocol, ext_did)
  TCAP_CPT      *cpt;      /* component structure to erase */
  u8            protocol;  /* protocol specification to use */
  u8            ext_did;   /* extended DID required */
{
  memset((void *)cpt, 0, sizeof (TCAP_CPT));
  cpt->protocol = protocol;
  cpt->ext_did  = ext_did;
}

/********************************************************************
 *                                                                  *
 *              Component Primitive handling functions              *
 *                                                                  *
 ********************************************************************/

/*
 * invoke_to_param packs an invoke component
 * from structured format to Q773 formatted binary
 * format required by the TCAP module.
 *
 * Returns zero on success.
 */
static int invoke_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_INVOKE	*invoke;	/* pointer to invoke data */
  u8    *pptr;                  /* current position in buffer */
  u8    *length_ptr;            /* location for COMPONENT NLD length */
  u16   component_length;       /* ASN length of component portion */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* Return value */

  ret_val = 0;
  pptr = get_param(m);
  invoke = &cpt->u.invoke;

  /*
   * Find lengths of all variable length components:
   */
  component_length = invoke->invoke_id.len +
		     invoke->linked_id.len +
		     invoke->operation.len +
		     invoke->param.len;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_INVOKE;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Class parameter:
   */
  *pptr++ = TCPPN_CLASS;
  *pptr++ = FPL_CLASS;
  *pptr++ = (u8)(invoke->class & 0xff);

  /*
   * NLD Timeout parameter:
   */
  *pptr++ = TCPPN_TIMEOUT;
  *pptr++ = FPL_TIMEOUT;
  *pptr++ = (u8)((invoke->timeout >> 8) & 0xff);
  *pptr++ = (u8)(invoke->timeout & 0xff);

  /*
   * NLD Component parameter:
   */
  *pptr++ = TCPPN_COMPONENT;
  length_ptr = pptr++;

  if (cpt->protocol == ANSI_T114)
    *pptr++ = (u8)TCAP_T114_TAG_INVOKE;
  else
    *pptr++ = (u8)TCAP_TAG_INVOKE;

  pptr += format_length(pptr, component_length);

  /*
   * If insufficient space in MSG for component
   * or component exceeds maximum length,
   * return error code:
   */
  if ( (component_length > 255) ||
       (component_length > (u16)PARAM_SPACE_LEFT(m, pptr)) )
    ret_val = SPACE_ERROR;
  else
  {
    /*
     * Append parameters to component:
     */
    pptr += copy_param(pptr, invoke->invoke_id.data, invoke->invoke_id.len);
    pptr += copy_param(pptr, invoke->linked_id.data, invoke->linked_id.len);
    pptr += copy_param(pptr, invoke->operation.data, invoke->operation.len);
    pptr += copy_param(pptr, invoke->param.data, invoke->param.len);

    /*
     * Fill in NLD length (of the 'component' parameter)
     * and terminator to indicate no more parameters:
     */
    *length_ptr = (u8)(pptr - length_ptr - 1);
    *pptr++ = TERMINATOR;
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_invoke recovers an invoke component
 * from the binary form used by the TCAP module
 * to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_invoke(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_INVOKE  *invoke;		/* pointer to invoke data */
  ASN_EDSC  asne;               /* structure to recover an ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  invoke = &cpt->u.invoke;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &invoke->invoke_id,
                                    cpt->protocol);
	  pptr += recover_linked_id(pptr, (u16)(eop-pptr), &invoke->linked_id);
	  pptr += recover_operation(pptr, (u16)(eop-pptr), &invoke->operation,
                                    cpt->protocol);
	  pptr += recover_parameter(pptr, (u16)(eop-pptr), &invoke->param);
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * rrl_to_param packs a return result last component
 * from structured format to Q773 formatted binary
 * format required by the TCAP module.
 *
 * Returns zero on success.
 */
static int rrl_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_RRL  *rrl;		/* pointer to rrl data */
  u8    *pptr;                  /* current position in buffer */
  u8    *length_ptr;            /* location for COMPONENT NLD length */
  u16   component_length;       /* ASN length of component portion */
  u16   result_len;             /* ASN length of result */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  pptr = get_param(m);
  rrl = &cpt->u.rrl;

  /*
   * Find lengths of all variable length components:
   */
  result_len = rrl->operation.len + rrl->param.len;

  /*
   * The operation and parameters (if both present) are
   * encapsulated in a sequence constructor.
   */
  if (result_len < 128)
    component_length = rrl->invoke_id.len + result_len + 2;
  else
    component_length = rrl->invoke_id.len + result_len + 3;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_RESULT_L;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Component parameter:
   */
  *pptr++ = TCPPN_COMPONENT;
  length_ptr = pptr++;

  if (cpt->protocol == ANSI_T114)
    *pptr++ = (u8)TCAP_T114_TAG_RRL;
  else
    *pptr++ = (u8)TCAP_TAG_RRL;

  pptr += format_length(pptr, component_length);

  /*
   * If insufficient space in MSG for component
   * or component exceeds maximum length,
   * return error code:
   */
  if ( (component_length > 255) ||
       (component_length > (u16)PARAM_SPACE_LEFT(m, pptr)) )
    ret_val = SPACE_ERROR;
  else
  {
    /*
     * Append parameters to component:
     */
    pptr += copy_param(pptr, rrl->invoke_id.data, rrl->invoke_id.len);
    if (result_len != 0)
    {
      *pptr++ = (u8)TCAP_TAG_SEQUENCE;
      pptr += format_length(pptr, result_len);
      pptr += copy_param(pptr, rrl->operation.data, rrl->operation.len);
      pptr += copy_param(pptr, rrl->param.data, rrl->param.len);
    }
    /*
     * Fill in NLD length (of the 'component' parameter)
     * and terminator to indicate no more parameters:
     */
    *length_ptr = (u8)(pptr - length_ptr - 1);
    *pptr++ = TERMINATOR;
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_rrl recovers a return result last
 * component from the binary form used by the
 * TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_rrl(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_RRL  *rrl;		/* pointer to rrl data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  rrl = &cpt->u.rrl;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &rrl->invoke_id,
                                    cpt->protocol);
	  if (*pptr == (u8)TCAP_TAG_SEQUENCE)
	  {
	    if (TCAP_locate_asn(pptr, (u16)(eop-pptr), &asne) == 0)
	    {
	      if (asne.total_len <= (OP_SIZE + PR_SIZE))
	      {
		pptr += (asne.tag_len + asne.len_len);
		pptr += recover_operation(pptr, (u16)(eop-pptr), &rrl->operation,
                                          cpt->protocol);
		pptr += recover_parameter(pptr, (u16)(eop-pptr), &rrl->param);
	      }
	    }
	  }
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * rrnl_to_param packs a return result not last
 * component from structured format to Q773
 * formatted binary format required by the
 * TCAP module.
 *
 * Note: no RRNL in ANSI TCAP
 *
 * Returns zero on success.
 */
static int rrnl_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_RRNL	*rrnl;		/* pointer to rrnl data */
  u8    *pptr;                  /* current position in buffer */
  u8    *length_ptr;            /* location for COMPONENT NLD length */
  u16   component_length;       /* ASN length of component portion */
  u16   result_len;             /* ASN length of result */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  pptr = get_param(m);
  rrnl = &cpt->u.rrnl;

  /*
   * Find lengths of all variable length components:
   */
  result_len = rrnl->operation.len + rrnl->param.len;

  if (result_len < 128)
    component_length = rrnl->invoke_id.len + result_len + 2;
  else
    component_length = rrnl->invoke_id.len + result_len + 3;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_RESULT_NL;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Component parameter:
   */
  *pptr++ = TCPPN_COMPONENT;
  length_ptr = pptr++;
  *pptr++ = (u8)TCAP_TAG_RRNL;
  pptr += format_length(pptr, component_length);

  /*
   * If insufficient space in MSG for component
   * or component exceeds maximum length,
   * return error code:
   */
  if ( (component_length > 255) ||
       (component_length > (u16)PARAM_SPACE_LEFT(m, pptr)) )
    ret_val = SPACE_ERROR;
  else
  {
    /*
     * Append parameters to component:
     */
    pptr += copy_param(pptr, rrnl->invoke_id.data, rrnl->invoke_id.len);
    if (result_len != 0)
    {
      *pptr++ = (u8)TCAP_TAG_SEQUENCE;
      pptr += format_length(pptr, result_len);
      pptr += copy_param(pptr, rrnl->operation.data, rrnl->operation.len);
      pptr += copy_param(pptr, rrnl->param.data, rrnl->param.len);
    }
    /*
     * Fill in NLD length (of the 'component' parameter)
     * and terminator to indicate no more parameters:
     */
    *length_ptr = (u8)(pptr - length_ptr - 1);
    *pptr++ = TERMINATOR;
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_rrnl recovers a return result not
 * last component from the binary form used
 * by the TCAP module to a structured form.
 *
 * Note: no RRNL in ANSI TCAP
 *
 * Returns zero on success.
 */
static int param_to_rrnl(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_RRNL *rrnl;		/* pointer to rrnl data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  rrnl = &cpt->u.rrnl;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &rrnl->invoke_id,
                                    cpt->protocol);
	  if (*pptr == (u8)TCAP_TAG_SEQUENCE)
	  {
	    if (TCAP_locate_asn(pptr, (u16)(eop-pptr), &asne) == 0)
	    {
	      if (asne.total_len <= (OP_SIZE + PR_SIZE))
	      {
		pptr += (asne.tag_len + asne.len_len);
		pptr += recover_operation(pptr, (u16)(eop-pptr), &rrnl->operation,
                                          cpt->protocol);
		pptr += recover_parameter(pptr, (u16)(eop-pptr), &rrnl->param);
	      }
	    }
	  }
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * uerror_to_param packs a return error
 * component from structured format to Q773
 * formatted binary format required by the
 * TCAP module.
 *
 * Returns zero on success.
 */
static int uerror_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_UERROR  *uerror;		/* pointer to uerror data */
  u8    *pptr;                  /* current position in buffer */
  u8    *length_ptr;            /* location for COMPONENT NLD length */
  u16   component_length;       /* ASN length of component portion */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  pptr = get_param(m);
  uerror = &cpt->u.uerror;

  /*
   * Find lengths of all variable length components:
   */
  component_length = uerror->invoke_id.len +
		     uerror->error.len +
		     uerror->param.len;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_U_ERROR;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Component parameter:
   */
  *pptr++ = TCPPN_COMPONENT;
  length_ptr = pptr++;

  if (cpt->protocol == ANSI_T114)
    *pptr++ = (u8)TCAP_T114_TAG_RE;
  else
    *pptr++ = (u8)TCAP_TAG_RE;

  pptr += format_length(pptr, component_length);

  /*
   * If insufficient space in MSG for component
   * or component exceeds maximum length,
   * return error code:
   */
  if ( (component_length > 255) ||
       (component_length > (u16)PARAM_SPACE_LEFT(m, pptr)) )
    ret_val = SPACE_ERROR;
  else
  {
    /*
     * Append parameters to component:
     */
    pptr += copy_param(pptr, uerror->invoke_id.data, uerror->invoke_id.len);
    pptr += copy_param(pptr, uerror->error.data, uerror->error.len);
    pptr += copy_param(pptr, uerror->param.data, uerror->param.len);

    /*
     * Fill in NLD length (of the 'component' parameter)
     * and terminator to indicate no more parameters:
     */
    *length_ptr = (u8)(pptr - length_ptr - 1);
    *pptr++ = TERMINATOR;
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_uerror recovers a return error
 * component from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_uerror(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_UERROR  *uerror;		/* pointer to uerror data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  uerror = &cpt->u.uerror;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &uerror->invoke_id,
                                    cpt->protocol);
	  pptr += recover_error(pptr, (u16)(eop-pptr), &uerror->error);
	  pptr += recover_parameter(pptr, (u16)(eop-pptr), &uerror->param);
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * ucancel_to_param packs a TC-U-CANCEL primitive
 * request from structured format to binary
 * format required by the TCAP module.
 *
 * Returns zero on success.
 */
static int ucancel_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_UCANCEL  *ucancel;	/* pointer to ucancel */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *pptr;                  /* current position in buffer */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = FORMAT_ERROR;
  ucancel = &cpt->u.ucancel;

  /*
   * Primitive component type:
   */
  pptr = get_param(m);
  *pptr++ = TCPPT_TC_U_CANCEL;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Invoke ID parameter:
   */
  if (TCAP_locate_asn(ucancel->invoke_id.data,
			 ucancel->invoke_id.len,
			 &asne) == 0)
  {
    /*
     * The invoke ID is encoded as a single
     * octet value.
     */
    if (asne.contents_len == 1)
    {
      if (cpt->protocol == ANSI_T114)
        *pptr++ = (u8) TCAP_T114_TAG_CPTID;
      else
        *pptr++ = (u8) TCAP_TAG_INVOKEID;

      *pptr++ = 1;
      *pptr++ = *asne.contents;
      *pptr++ = TERMINATOR;
      ret_val = 0;
    }
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_lcancel recovers a local cancel
 * component from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_lcancel(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_LCANCEL  *lcancel;	/* pointer to lcancel data */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  lcancel = &cpt->u.lcancel;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_INVOKE_ID :
	/*
	 * All invoke ID's issued by the TCAP module
	 * are encoded in a single octet.
	 */
        if (cpt->protocol == ANSI_T114)
          lcancel->invoke_id.data[0] = (u8) TCAP_T114_TAG_CPTID;
        else
          lcancel->invoke_id.data[0] = (u8) TCAP_TAG_INVOKEID;

        lcancel->invoke_id.data[1] = 1;
	lcancel->invoke_id.data[2] = *pptr++;
	lcancel->invoke_id.len = 3;
	break;

      case TCPPN_LAST_CPT :
        cpt->last_component = *pptr++;
        break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  /*
   * To be consistent with other component
   * primitive indications, set the 'last
   * component' parameter true (TC-L-CANCEL
   * component indications are not grouped).
   */
  cpt->last_component = 1;

  return(ret_val);
}

/*
 * param_to_lreject recovers a local reject
 * component from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_lreject(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_LREJECT  *lreject;	/* pointer to lreject data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  lreject = &cpt->u.lreject;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &lreject->invoke_id,
                                    cpt->protocol);
	  pptr += recover_problem(pptr, (u16)(eop-pptr), &lreject->problem);
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * param_to_rreject recovers a remote reject
 * component from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_rreject(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_RREJECT  *rreject;	/* pointer to rreject data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  rreject = &cpt->u.rreject;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &rreject->invoke_id,
                                    cpt->protocol);
	  pptr += recover_problem(pptr, (u16)(eop-pptr), &rreject->problem);
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}

/*
 * ureject_to_param packs a TC-U-REJECT primitive
 * request from structured format to binary
 * format required by the TCAP module.
 *
 * Returns zero on success.
 */
static int ureject_to_param(m, cpt)
  MSG           *m;     /* Message to format to */
  TCAP_CPT      *cpt;   /* Structure containaing data to format */
{
  CPT_UREJECT  *ureject;	/* pointer to ureject data */
  u8    *pptr;                  /* current position in buffer */
  u8    *length_ptr;            /* location for COMPONENT NLD length */
  u16   component_length;       /* ASN length of component portion */
  int   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  pptr = get_param(m);
  ureject = &cpt->u.ureject;

  /*
   * Find lengths of all variable length components:
   */
  component_length = ureject->invoke_id.len + ureject->problem.len;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_U_REJECT;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (cpt->ext_did)
  {
    plen = format_ext_did(pptr, cpt->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Component parameter:
   */
  *pptr++ = TCPPN_COMPONENT;
  length_ptr = pptr++;

  if (cpt->protocol == ANSI_T114)
    *pptr++ = (u8)TCAP_T114_TAG_REJECT;
  else
    *pptr++ = (u8)TCAP_TAG_REJECT;

  pptr += format_length(pptr, component_length);

  /*
   * If insufficient space in MSG for component
   * or component exceeds maximum length,
   * return error code:
   */
  if ( (component_length > 255) ||
       (component_length > (u16)PARAM_SPACE_LEFT(m, pptr)) )
    ret_val = SPACE_ERROR;
  else
  {
    /*
     * Append parameters to component:
     */
    pptr += copy_param(pptr, ureject->invoke_id.data, ureject->invoke_id.len);
    pptr += copy_param(pptr, ureject->problem.data, ureject->problem.len);

    /*
     * Fill in NLD length (of the 'component' parameter)
     * and terminator to indicate no more parameters:
     */
    *length_ptr = (u8)(pptr - length_ptr - 1);
    *pptr++ = TERMINATOR;
  }

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_ureject recovers a (remote) user
 * reject primitive indication from the binary
 * form used by the TCAP module to a structured
 * form.
 *
 * Returns zero on success.
 */
static int param_to_ureject(cpt, pptr, len)
  TCAP_CPT      *cpt;           /* structure to recover parameters to */
  u8            *pptr;          /* pointer to name of first parameter */
  u16           len;            /* total length of parameters */
{
  CPT_UREJECT  *ureject;	/* pointer to ureject data */
  ASN_EDSC asne;                /* structure to recover ASN.1 element */
  u8    *eop;                   /* pointer to byte after parameter */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  ureject = &cpt->u.ureject;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    eop = pptr + plen;
    switch(pname)
    {
      case TCPPN_LAST_CPT :
	if (plen == 1)
	  cpt->last_component = *pptr++;
	break;

      case TCPPN_COMPONENT :
	if (TCAP_locate_asn(pptr, plen, &asne) == 0)
	{
	  pptr += (asne.tag_len + asne.len_len);
	  pptr += recover_invoke_id(pptr, (u16)(eop-pptr), &ureject->invoke_id,
                                    cpt->protocol);
	  pptr += recover_problem(pptr, (u16)(eop-pptr), &ureject->problem);
	}
	break;
    }

    if (pptr != eop)
    {
      ret_val = FORMAT_ERROR;
      break;
    }
  }
  return(ret_val);
}


/********************************************************************
 *                                                                  *
 *              Dialogue Primitive handling functions               *
 *                                                                  *
 ********************************************************************/

/*
 * param_to_uni recovers a TC-UNI dialogue
 * indication from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_uni(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_UNI  *uni;		/* pointer to uni data */
  u8    pname;                  /* current parameter name */
  u16   plen;                   /* current parameter length */
  int   ret_val;                /* return value */

  ret_val = 0;
  uni = &dlg->u.uni;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_CPT_PRESENT :
	if (plen == 1)
	  uni->cpt_present = *pptr;
	break;

      case TCPPN_ORIG_ADDR :
	if (plen <= AD_SIZE)
	{
	  copy_param(uni->orig_addr.data, pptr, plen);
	  uni->orig_addr.len = plen;
	}
	break;

      case TCPPN_DEST_ADDR :
	if (plen <= AD_SIZE)
	{
	  copy_param(uni->dest_addr.data, pptr, plen);
	  uni->dest_addr.len = plen;
	}
	break;

      case TCPPN_QOS :
	if (recover_qos(&uni->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;

      case TCPPN_APPL_CONTEXT :
	if (plen <= AC_SIZE)
	{
	  copy_param(uni->ac_name.data, pptr, plen);
	  uni->ac_name.len = plen;
	}
	break;

      case TCPPN_USER_INFO :
	if (plen <= UI_SIZE)
	{
	  copy_param(uni->user_info.data, pptr, plen);
	  uni->user_info.len = plen;
	}
	break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * uni_to_param packs a TC-UNI dialogue request
 * from a structured form to the binary format
 * used by the TCAP module.
 *
 * Returns zero on success.
 */
static int uni_to_param(m, dlg)
  MSG  *m;              /* message to format parameters to */
  TCAP_DLG *dlg;        /* structure containing parameters to pack */
{
  DLG_UNI  *uni;	/* pointer to uni data */
  u8    *pptr;          /* current position in buffer */
  int   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  pptr = get_param(m);
  uni = &dlg->u.uni;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_UNI;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (dlg->ext_did)
  {
    plen = format_ext_did(pptr, dlg->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Quality of service parameter
   */
  plen = format_qos(pptr, &uni->qos, m);
  if (plen <= 0)
    ret_val = FORMAT_ERROR;
  else
    pptr += plen;

  /*
   * NLD Dest addr
   */
  if ( (plen = uni->dest_addr.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_DEST_ADDR;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uni->dest_addr.data, plen);
    }
  }

  /*
   * NLD Orig addr
   */
  if ( (plen = uni->orig_addr.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_ORIG_ADDR;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uni->orig_addr.data, plen);
    }
  }

  /*
   * NLD Appl context
   */
  if ( (plen = uni->ac_name.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_APPL_CONTEXT;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uni->ac_name.data, plen);
    }
  }

  /*
   * NLD User info
   */
  if ( (plen = uni->user_info.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_USER_INFO;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uni->user_info.data, plen);
    }
  }

  /*
   * NLD terminator
   */
  *pptr++ = TERMINATOR;

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_begin recovers a TC-BEGIN dialogue
 * indication from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_begin(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_BEGIN  *begin;	/* pointer to begin data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  begin = &dlg->u.begin;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_CPT_PRESENT :
	if (plen == 1)
	  begin->cpt_present = *pptr;
	break;

      case TCPPN_ORIG_ADDR :
	if (plen <= AD_SIZE)
	{
	  copy_param(begin->orig_addr.data, pptr, plen);
	  begin->orig_addr.len = plen;
	}
	break;

      case TCPPN_DEST_ADDR :
	if (plen <= AD_SIZE)
	{
	  copy_param(begin->dest_addr.data, pptr, plen);
	  begin->dest_addr.len = plen;
	}
	break;

      case TCPPN_QOS :
	if (recover_qos(&begin->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;

      case TCPPN_APPL_CONTEXT :
	if (plen <= AC_SIZE)
	{
	  copy_param(begin->ac_name.data, pptr, plen);
	  begin->ac_name.len = plen;
	}
	break;

      case TCPPN_USER_INFO :
	if (plen <= UI_SIZE)
	{
	  copy_param(begin->user_info.data, pptr, plen);
	  begin->user_info.len = plen;
	}
	break;

      case TCPPN_PERMISSION :
        if ((plen == RP_SIZE) && (dlg->protocol == ANSI_T114))
	{
          copy_param(begin->rel_perm.data, pptr, plen);
          begin->rel_perm.len = plen;
	}
        break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * begin_to_param packs a TC-BEGIN dialogue request
 * from a structured form to the binary format
 * used by the TCAP module.
 *
 * Returns zero on success.
 */
static int begin_to_param(m, dlg)
  MSG  *m;              /* message to pack parameters to */
  TCAP_DLG *dlg;        /* structure containing parameters to pack */
{
  DLG_BEGIN  *begin;	/* pointer to begin data */
  u8    *pptr;          /* current position in buffer */
  int   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  begin = &dlg->u.begin;
  pptr = get_param(m);

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_BEGIN;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (dlg->ext_did)
  {
    plen = format_ext_did(pptr, dlg->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Quality of service parameter
   */
  plen = format_qos(pptr, &begin->qos, m);
  if (plen <= 0)
    ret_val = FORMAT_ERROR;
  else
    pptr += plen;

  /*
   * NLD Dest addr
   */
  if ( (plen = begin->dest_addr.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_DEST_ADDR;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, begin->dest_addr.data, plen);
    }
  }

  /*
   * NLD Orig addr
   */
  if ( (plen = begin->orig_addr.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_ORIG_ADDR;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, begin->orig_addr.data, plen);
    }
  }

  /*
   * NLD Appl context
   */
  if ( (plen = begin->ac_name.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_APPL_CONTEXT;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, begin->ac_name.data, plen);
    }
  }

  /*
   * NLD User info
   */
  if ( (plen = begin->user_info.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_USER_INFO;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, begin->user_info.data, plen);
    }
  }

  /*
   * NLD Permission to release
   */
  if ( (plen = begin->rel_perm.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_PERMISSION;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, begin->rel_perm.data, plen);
    }
  }

  /*
   * NLD terminator
   */
  *pptr++ = TERMINATOR;

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_continue recovers a TC-CONTINUE
 * dialogue indication from the binary form
 * used by the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_continue(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_CONTINUE   *cont;	/* pointer to cont data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  cont = &dlg->u.cont;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_CPT_PRESENT :
	if (plen == 1)
	  cont->cpt_present = *pptr;
	break;

      case TCPPN_QOS :
	if (recover_qos(&cont->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;

      case TCPPN_APPL_CONTEXT :
	if (plen <= AC_SIZE)
	{
	  copy_param(cont->ac_name.data, pptr, plen);
	  cont->ac_name.len = plen;
	}
	break;

      case TCPPN_USER_INFO :
	if (plen <= UI_SIZE)
	{
	  copy_param(cont->user_info.data, pptr, plen);
	  cont->user_info.len = plen;
	}
        break;

      case TCPPN_PERMISSION :
        if ((plen == RP_SIZE) && (dlg->protocol == ANSI_T114))
	{
          copy_param(cont->rel_perm.data, pptr, plen);
          cont->rel_perm.len = plen;
	}
        break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * continue_to_param packs a TC-CONTINUE dialogue
 * request from a structured form to the binary
 * format used by the TCAP module.
 *
 * Returns zero on success.
 */
static int continue_to_param(m, dlg)
  MSG  *m;              /* message to pack parameters to */
  TCAP_DLG *dlg;        /* structure containing parameters to pack */
{
  DLG_CONTINUE  *cont;	/* pointer to cont data */
  u8    *pptr;          /* current position in buffer */
  int   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  cont = &dlg->u.cont;

  pptr = get_param(m);

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_CONTINUE;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (dlg->ext_did)
  {
    plen = format_ext_did(pptr, dlg->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Quality of service parameter
   */
  plen = format_qos(pptr, &cont->qos, m);
  if (plen <= 0)
    ret_val = FORMAT_ERROR;
  else
    pptr += plen;

  /*
   * NLD Orig addr
   */
  if ( (plen = cont->orig_addr.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_ORIG_ADDR;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, cont->orig_addr.data, plen);
    }
  }

  /*
   * NLD Appl context
   */
  if ( (plen = cont->ac_name.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_APPL_CONTEXT;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, cont->ac_name.data, plen);
    }
  }

  /*
   * NLD User info
   */
  if ( (plen = cont->user_info.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_USER_INFO;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, cont->user_info.data, plen);
    }
  }

  /*
   * NLD Permission to release
   */
  if ( (plen = cont->rel_perm.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_PERMISSION;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, cont->rel_perm.data, plen);
    }
  }

  /*
   * NLD terminator
   */
  *pptr++ = TERMINATOR;

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_end recovers a TC-END dialogue
 * indication from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_end(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_END  *end;	/* pointer to end data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  end = &dlg->u.end;

  /*
   * Receipt of END indication always
   * implies BASIC end.
   */
  end->termination = TCPEND_BASIC;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_CPT_PRESENT :
	if (plen == 1)
	  end->cpt_present = *pptr;
	break;

      case TCPPN_QOS :
	if (recover_qos(&end->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;

      case TCPPN_APPL_CONTEXT :
	if (plen <= AC_SIZE)
	{
	  copy_param(end->ac_name.data, pptr, plen);
	  end->ac_name.len = plen;
	}
	break;

      case TCPPN_USER_INFO :
	if (plen <= UI_SIZE)
	{
	  copy_param(end->user_info.data, pptr, plen);
	  end->user_info.len = plen;
	}
	break;

      case TCPPN_PERMISSION :
        if ((plen == RP_SIZE) && (dlg->protocol == ANSI_T114))
	{
          copy_param(end->rel_perm.data, pptr, plen);
          end->rel_perm.len = plen;
	}
        break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * end_to_param packs a TC-END dialogue
 * request from a structured form to the binary
 * format used by the TCAP module.
 *
 * Returns zero on success.
 */
static int end_to_param(m, dlg)
  MSG  *m;              /* message to pack parameters to */
  TCAP_DLG *dlg;        /* structure containing parameters to pack */
{
  DLG_END  *end;	/* pointer to end data */
  u8    *pptr;          /* current position in buffer */
  int   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;

  pptr = get_param(m);
  end = &dlg->u.end;

  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_END;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (dlg->ext_did)
  {
    plen = format_ext_did(pptr, dlg->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Quality of service parameter
   */
  plen = format_qos(pptr, &end->qos, m);
  if (plen <= 0)
    ret_val = FORMAT_ERROR;
  else
    pptr += plen;

  /*
   * NLD termination
   */
  if (PARAM_SPACE_LEFT(m, pptr) < 3)
    ret_val = FORMAT_ERROR;
  else
  {
    *pptr++ = TCPPN_TERMINATION;
    *pptr++ = 1;
    *pptr++ = end->termination;
  }

  /*
   * NLD Appl context
   */
  if ( (plen = end->ac_name.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_APPL_CONTEXT;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, end->ac_name.data, plen);
    }
  }

  /*
   * NLD User info
   */
  if ( (plen = end->user_info.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_USER_INFO;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, end->user_info.data, plen);
    }
  }

  /*
   * NLD Permission to release
   */
  if ( (plen = end->rel_perm.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_PERMISSION;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, end->rel_perm.data, plen);
    }
  }

  /*
   * NLD terminator
   */
  *pptr++ = TERMINATOR;

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_uabort recovers a TC-U-ABORT
 * dialogue indication from the binary form
 * used by the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_uabort(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_UABORT  *uabort;	/* pointer to uabort data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  uabort = &dlg->u.uabort;

  /*
   * Set abort_reason to 'User Defined'
   * which is the default if the abort_reason
   * parameter is not present:
   */
  uabort->abort_reason = (u8)TCPUABT_USER_DEFINED;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_ABORT_REASON :
	if (plen == 1)
	  uabort->abort_reason = *pptr;
	break;

      case TCPPN_QOS :
	if (recover_qos(&uabort->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;

      case TCPPN_USER_INFO :
	if (plen <= UI_SIZE)
	{
	  copy_param(uabort->user_info.data, pptr, plen);
	  uabort->user_info.len = plen;
	}
	break;

      case TCPPN_APPL_CONTEXT :
	if (plen <= AC_SIZE)
	{
	  copy_param(uabort->ac_name.data, pptr, plen);
	  uabort->ac_name.len = plen;
	}
	break;

      case TCPPN_PERMISSION :
        if ((plen == RP_SIZE) && (dlg->protocol == ANSI_T114))
	{
          copy_param(uabort->rel_perm.data, pptr, plen);
          uabort->rel_perm.len = plen;
	}
        break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * uabort_to_param packs a TC-U-ABORT dialogue
 * request from a structured form to the binary
 * format used by the TCAP module.
 *
 * Returns zero on success.
 */
static int uabort_to_param(m, dlg)
  MSG  *m;              /* message to pack parameters to */
  TCAP_DLG *dlg;        /* structure containing parameters to pack */
{
  DLG_UABORT  *uabort;	/* pointer to uabort data */
  u8    *pptr;          /* current position in buffer */
  int   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  uabort = &dlg->u.uabort;

  pptr = get_param(m);
  /*
   * Primitive component type:
   */
  *pptr++ = TCPPT_TC_U_ABORT;

  /*
   * Add Extended Dialogue ID parameter if required (must be first parameter)
   */
  if (dlg->ext_did)
  {
    plen = format_ext_did(pptr, dlg->dialogue_id, m);
    if (plen <= 0)
      return(FORMAT_ERROR);
    pptr += plen;
  }

  /*
   * NLD Quality of service parameter
   */
  plen = format_qos(pptr, &uabort->qos, m);
  if (plen <= 0)
    ret_val = FORMAT_ERROR;
  else
    pptr += plen;

  /*
   * NLD abort reason
   */
  if (PARAM_SPACE_LEFT(m, pptr) < 3)
    ret_val = FORMAT_ERROR;
  else
  {
    *pptr++ = TCPPN_ABORT_REASON;
    *pptr++ = 1;
    *pptr++ = uabort->abort_reason;
  }

  /*
   * NLD Appl context
   */
  if ( (plen = uabort->ac_name.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_APPL_CONTEXT;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uabort->ac_name.data, plen);
    }
  }

  /*
   * NLD User info
   */
  if ( (plen = uabort->user_info.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_USER_INFO;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uabort->user_info.data, plen);
    }
  }

  /*
   * NLD Permission to release
   */
  if ( (plen = uabort->rel_perm.len) != 0)
  {
    if ((plen + 2) > PARAM_SPACE_LEFT(m, pptr))
      ret_val = FORMAT_ERROR;
    else
    {
      *pptr++ = TCPPN_PERMISSION;
      *pptr++ = (u8)plen;
      pptr += copy_param(pptr, uabort->rel_perm.data, plen);
    }
  }

  /*
   * NLD terminator
   */
  *pptr++ = TERMINATOR;

  /*
   * Fill in the length of the complete message:
   */
  m->len = (u16)(pptr - get_param(m));
  return(ret_val);
}

/*
 * param_to_pabort recovers a TC-P-ABORT
 * dialogue indication from the binary form
 * used by the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_pabort(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_PABORT  *pabort;	/* pointer to pabort data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  pabort = &dlg->u.pabort;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_P_ABORT :
	if (plen == 1)
	  pabort->p_abort = *pptr;
	break;

      case TCPPN_QOS :
	if (recover_qos(&pabort->qos, pptr, plen) != 0)
	  ret_val = FORMAT_ERROR;
	break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}

/*
 * param_to_notice recovers a TC-NOTICE dialogue
 * indication from the binary form used by
 * the TCAP module to a structured form.
 *
 * Returns zero on success.
 */
static int param_to_notice(dlg, pptr, len)
  TCAP_DLG *dlg;        /* Structure to store recovered data */
  u8       *pptr;       /* Pointer to data to recover */
  u16      len;         /* Length of data to recover */
{
  DLG_NOTICE  *notice;	/* pointer to notice data */
  u8    pname;          /* current parameter name */
  u16   plen;           /* current parameter length */
  int   ret_val;        /* return value */

  ret_val = 0;
  notice = &dlg->u.notice;

  while ( (pname=*pptr++) != TERMINATOR )
  {
    plen = *pptr++;
    switch(pname)
    {
      case TCPPN_REPORT_CAUSE :
	if (plen == 1)
	  notice->report_cause = *pptr;
	break;
    }
    pptr += plen;
    if (ret_val)
      break;
  }
  return(ret_val);
}


/*********************************************************************
 *                                                                  *
 *         Q773/T114 component parameter recovery funtions          *
 *                                                                  *
 ********************************************************************/

/*
 * Recovers invoke_id from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_invoke_id(pptr, length, invoke_id, protocol)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_INV_ID *invoke_id;        /* structure to recover data into */
  u8    protocol;               /* protocok spec used to check tag */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */
  u8            tag_match;      /* invoke id tag has been matched */

  ret_val = 0;
  tag_match = 0;

  if (protocol == ANSI_T114)
  {
    if (*pptr == (u8)TCAP_T114_TAG_CPTID)
      tag_match = 1;
  }
  else
  {
    if ( (*pptr == (u8)TCAP_TAG_INVOKEID) ||
         (*pptr == (u8)TCAP_TAG_NULL) )
      tag_match = 1;
  }

  if (tag_match)
  {
    if (TCAP_locate_asn(pptr, length, &asne) == 0)
    {
      if (asne.total_len <= IV_SIZE)
      {
        invoke_id->len = asne.total_len;
        copy_param(invoke_id->data, pptr, asne.total_len);
      }
      ret_val = asne.total_len;
    }
  }

  return(ret_val);
}

/*
 * Recovers linked_id from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_linked_id(pptr, length, linked_id)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_INV_ID *linked_id;        /* structure to recover data into */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */

  ret_val = 0;
  if (*pptr == (u8)TCAP_TAG_LINKEDID)
  {
    if (TCAP_locate_asn(pptr, length, &asne) == 0)
    {
      if (asne.total_len <= IV_SIZE)
      {
	linked_id->len = asne.total_len;
	copy_param(linked_id->data, pptr, asne.total_len);
      }
      ret_val = asne.total_len;
    }
  }
  return(ret_val);
}

/*
 * Recovers operation from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_operation(pptr, length, operation, protocol)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_OP *operation;            /* structure to recover data into */
  u8    protocol;               /* protocok spec used to check tag */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */
  u8            tag_match;      /* has the operation code tag been matched */

  ret_val = 0;
  tag_match = 0;

  if (protocol == ANSI_T114)
  {
    if ( (*pptr == (u8)TCAP_T114_TAG_NATOP) ||
         (*pptr == (u8)TCAP_T114_TAG_PRIVOP) )
      tag_match = 1;
  }
  else
  {
    if ( (*pptr == (u8)TCAP_TAG_LOCALOP) ||
         (*pptr == (u8)TCAP_TAG_GLOBALOP) )
      tag_match = 1;
  }

  if (tag_match)
  {
    if (TCAP_locate_asn(pptr, length, &asne) == 0)
    {
      if (asne.total_len <= OP_SIZE)
      {
	operation->len = asne.total_len;
	copy_param(operation->data, pptr, asne.total_len);
      }
      ret_val = asne.total_len;
    }
  }
  return(ret_val);
}

/*
 * Recovers error from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_error(pptr, length, error)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_ERROR *error;             /* structure to recover data into */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */

  ret_val = 0;
  if (TCAP_locate_asn(pptr, length, &asne) == 0)
  {
    if (asne.total_len <= ER_SIZE)
    {
      error->len = asne.total_len;
      copy_param(error->data, pptr, asne.total_len);
    }
    ret_val = asne.total_len;
  }
  return(ret_val);
}

/*
 * Recovers parameter from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_parameter(pptr, length, param)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_PARAM *param;             /* structure to recover data into */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */

  ret_val = 0;
  if (TCAP_locate_asn(pptr, length, &asne) == 0)
  {
    if (asne.total_len <= PR_SIZE)
    {
      param->len = asne.total_len;
      copy_param(param->data, pptr, asne.total_len);
    }
    ret_val = asne.total_len;
  }
  return(ret_val);
}

/*
 * Recovers problem from ASN data into structure:
 *
 * Returns the total number of bytes
 * extracted from the ASN string.
 */
static int recover_problem(pptr, length, problem)
  u8    *pptr;                  /* pointer to ASN data */
  u16   length;                 /* length od ASN data */
  CPT_PROBLEM *problem;         /* structure to recover data into */
{
  ASN_EDSC      asne;           /* structure to recover ASN.1 element */
  int           ret_val;        /* return value */

  ret_val = 0;
  if (TCAP_locate_asn(pptr, length, &asne) == 0)
  {
    if (asne.total_len <= PB_SIZE)
    {
      problem->len = asne.total_len;
      copy_param(problem->data, pptr, asne.total_len);
    }
    ret_val = asne.total_len;
  }
  return(ret_val);
}


/********************************************************************
 *                                                                  *
 *           Dialogue primitive parameter handling functions        *
 *                                                                  *
 ********************************************************************/

/*
 * format_qos formats the TCAP quality of service
 * parameter from the structured form into binary
 * format required by the TCAP NLD format.
 *
 * Returns the number of octets used or 0 on error.
 */
static int format_qos(pptr, qos, m)
  u8  *pptr;            /* Pointer to format data to */
  DLG_QOS *qos;         /* Structure containing data to format */
  MSG *m;               /* Message being formatted */
{
  int  bytes_used;      /* current number of bytes used for formatting */

  /*
   * First determine the length of data to format
   * (At least 3 octets are required, name, length
   * and indicator octet);
   */
  bytes_used = 3;

  if (qos->indicator & (u8)QOSI_SLS_KEY)
    bytes_used++;
  if (qos->indicator & (u8)QOSI_PRIORITY)
    bytes_used++;

  if (PARAM_SPACE_LEFT(m, pptr) < bytes_used)
    bytes_used = 0;
  else
  {
    *pptr++ = TCPPN_QOS;
    *pptr++ = (u8)(bytes_used - 2);
    *pptr++ = qos->indicator;
    if (qos->indicator & (u8)QOSI_SLS_KEY)
      *pptr++ = qos->sls_key;
    if (qos->indicator & (u8)QOSI_PRIORITY)
      *pptr = qos->priority;
  }
  return(bytes_used);
}

/*
 * recover_qos recovers the TCAP quality of service
 * parameter from the binary form used by the TCAP
 * module to a structured form.
 *
 * Returns zero on success.
 */
static int recover_qos(qos, pptr, plen)
  DLG_QOS  *qos;        /* Structure to store recovered parameter */
  u8       *pptr;       /* Pointer to first octet of parameter */
  u16      plen;        /* Length of parameter data */
{
  int  ret_val;         /* return value */

  if (plen > 3)
    ret_val = -1;
  else
  {
    ret_val = 0;
    qos->indicator = *pptr++;
    if (--plen)
    {
      if (qos->indicator & (u8)QOSI_SLS_KEY)
	qos->sls_key = *pptr++;
      else
      {
	if (qos->indicator & (u8)QOSI_PRIORITY)
	  qos->priority = *pptr++;
	else
	  ret_val = -1;
      }
      if (--plen)
      {
	if (qos->indicator & (u8)QOSI_PRIORITY)
	  qos->priority = *pptr;
	else
	  ret_val = -1;
      }
    }
  }
  return(ret_val);
}

/*
 * format_ext_did copies the TCAP extended Dialogue ID parameter to 'pptr' pointer.
 *
 * Returns the length of data copied (6 octets)
 *         or -1 if no room
 */
static int format_ext_did(pptr, did, m)
  u8    *pptr;          /* Pointer to location in message buffer to store parameter */
  u32   did;            /* Dialogue ID to be formatted */
  MSG   *m;             /* Message being formatted */
{
  int bytes_required = 6;   /* parameter size (fixed) */

  /*
   * Check for enough room to format the parameter into the message
   */
  if (PARAM_SPACE_LEFT(m, pptr) < bytes_required)
    return(-1);

  /*
   * Format parameter: tag, length, data (most significant octets first)
   */
  *pptr++ = TCPPN_DID;
  *pptr++ = 4;
  *pptr++ = (u8)((did >> 24) & 0xff);
  *pptr++ = (u8)((did >> 16) & 0xff);
  *pptr++ = (u8)((did >> 8) & 0xff);
  *pptr++ = (u8)(did & 0xff);

  return(bytes_required);
}

/*
 * recover_ext_did recovers the TCAP Extended DID parameter
 * fron the message parameter area.
 *
 * Returns length of recovered parameter (6) on success,
 *         -1 on failure to recover
 */
static int recover_ext_did(did, pptr, plen)
  u32  *did;        /* Pointer for recovered DID parameter */
  u8   *pptr;       /* Pointer to first octet of parameter in message buffer */
  u16  plen;        /* Length of remaining data in message buffer (after pptr) */
{
  u32  rec_did = 0;         /* recovered did */
  int  bytes_required = 6;  /* parameter size (fixed) */
  int  ret_val = 0;         /* return value */

  /*
   * Check enough data in buffer to recover parameter
   */
  if (plen < bytes_required)
    return(-1);

  /*
   * Check parameter tag and length (fixed)
   */
  if (*pptr++ != TCPPN_DID)
    return(-1);
  if (*pptr++ != 4)
    return(-1);

  /*
   * Recover parameter data, stored most significant octets first
   */
  rec_did = *pptr++;
  rec_did <<= 8;
  rec_did |= *pptr++;
  rec_did <<= 8;
  rec_did |= *pptr++;
  rec_did <<= 8;
  rec_did |= *pptr++;

  /*
   * Return parameter data (via pointer) and buffer length used
   */
  *did = rec_did;

  return(bytes_required);
}

/********************************************************************
 *                                                                  *
 *                  General purpose local functions                 *
 *                                                                  *
 ********************************************************************/

/*
 * format_length formats the length of an ASN.1 element
 * according to ASN.1 encoding rules. The length
 * is encoded so that the first octet is placed at
 * pptr. The function only supports lengths in the
 * range 0 .. 255.
 *
 * Returns number of octets used. (zero on error).
 */
static u16 format_length(pptr, length)
  u8    *pptr;          /* length will be formatted at pptr */
  u16   length;         /* length value to encode */
{
  int   ret_val;        /* return value */

  if (length < 128)
  {
    /*
     * Use the short form of the length
     * (using 1 octet).
     */
    *pptr = (u8)length;
    ret_val = 1;
  }
  else
  {
    if (length < 255)
    {
      /*
       * use the long form of the length
       * (using 2 octets).
       */
      *pptr++ = (u8)0x81;
      *pptr   = (u8)length;
      ret_val = 2;
    }
    else
    {
      /*
       * Length greater than 255
       * not supported by TCAP:
       */
      ret_val = 0;
    }
  }
  return(ret_val);
}

/*
 * copy_param copies len bytes of data from
 * src to dest.
 *
 * Returns the length of data copied.
 */
static int copy_param(dest, src, len)
  u8    *dest;          /* Destination pointer */
  u8    *src;           /* Source pointer */
  u16   len;            /* Number of bytes to copy */
{
  u16 bytes_left;       /* number of bytes left to copy */

  bytes_left = len;
  while (bytes_left--)
  {
    *dest++ = *src++;
  }
  return(len);
}

/*
 * TCAP_locate_asn locates ASN.1 element from binary data,
 * and ensures that it is encoded according to ASN.1 rules.
 * The number of tag octets, number of length octets, number
 * of contents octets, total element length and a pointer to the
 * first contents octet are returned in the asne structure.
 *
 * Returns zero on success.
 */
int TCAP_locate_asn(dataptr, datalen, asne)
  u8            *dataptr;       /* Pointer to first octet (i.e. tag) */
  u16           datalen;        /* Length of valid data from dataptr */
  ASN_EDSC      *asne;          /* Used to return recovered information */
{
  u8    error_detected;         /* error detected flag */
  u16   bytes_left;             /* valid data left to recover */
  int   ret_val;                /* return value */

  error_detected = 0;
  bytes_left = datalen;
  ret_val = -1;

  /*
   * First count the number of octets in the tag:
   * (Note that the majority of tags will consist
   * of only a single octet).
   */
  if (bytes_left--)
  {
    asne->tag_len = 1;
    if (TCAP_TAG_CODE(*dataptr++) == (u8)TCAP_TAG_EXT_VALUE)
    {
      while (bytes_left--)
      {
	asne->tag_len++;
        if (TCAP_TAG_EXT(*dataptr++) != (u8)TCAP_TAG_EXT_IND)
	  break;
      }
    }

    /*
     * Recover length of contents:
     */
    if (bytes_left--)
    {
      if (*dataptr == (u8)TCAP_INDEFINITE_LEN)
      {
	/*
	 * The indefinite encoding of length
	 * is not supported for the encoding
	 * of TCAP primitive parameters.
	 */
	error_detected = 1;
      }
      else
      {
	if ((*dataptr & 0x80) == 0)
	{
	  /*
	   * Length is encoded in the short form,
	   * (it must be between 0 and 127 octets).
	   */
	  asne->len_len = 1;
	  asne->contents_len = *dataptr++;
	}
	else
	{
	  /*
	   * Length is encoded in the long form,
	   *
	   * Implementation Note :
	   * The only valid encoding of the long
	   * form for TCAP messages is for a single
	   * octet with a value between 128 and 255.
	   * Other forms are rejected.
	   */
	  if (bytes_left-- == 0)
	    error_detected = 0;
	  else
	  {
	    if (*dataptr++ == 0x81)
	    {
	      asne->len_len = 2;
	      asne->contents_len = *dataptr++;

	      /*
	       * If short length incorrectly encoded
	       * using the long form then reject
	       * element (See Table 1/Q.772):
	       */
	      if (asne->contents_len < 128)
		error_detected = 1;
	    }
	  }
	}
      }
    }

    if (!error_detected)
    {
      if (bytes_left >= asne->contents_len)
      {
	asne->contents = dataptr;
	asne->total_len = asne->tag_len + asne->len_len + asne->contents_len;
	ret_val = 0;
      }
    }
  }
  return(ret_val);
}


