/*
                Copyright (C) Dialogic Corporation 1994-2013. All Rights Reserved.

 Name:          ttu.c

 Description:   Example application program for interfacing
                to the Dialogic DSI TCAP module.

                The application receives incoming dialogues
                and issues responses in a manner designed
                to exercise TCAP functionality and illustrate
                the programming techniques involved.

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    26-Aug-94   SRG   - Initial code.
   B    31-Aug-94   SRG   - Released for evaluation.
   C    05-Sep-94   SRG   - RR-NL & RR-L now contain parameters. (NOTE
                            that parameters must be present if operation
                            is present!).
                            TTU module ID now 0x0d (APP0_TASK_ID)
   D    19-Oct-94   SRG   - cpt_present removed from U-ABORT and bug fix
                            in function TTU_dlg_ind to prevent accessing
                            the wrong union in a received message.
   D+   31-Oct-94   SRG   - TTU_n_state_req function added to allow TTU
                            to issue UIS/UOS requests. TTU no longer
                            activates/deactivates the link.
   D+   17-Nov-94   SRG   - Sense of termination (basic/pre-arranged)
                            corrected in TCAP_display_dialogue.
   E    24-Nov-94   SRG   - TCPSWE_NO_ICDLG changed to TCPSWE_NO_DLG.
   F    05-Jan-95   MH    - Set finish flag in sig_term() instead of calling
                            exit().
   F+   17-Jan-95   MH    - Use generic signals.
   F+   17-Jan-95   MH    - Deleted Unix headers
                          - Delete gct_unix.h
   G    27-Feb-97   MH    - Use command line options.
                          - Remove TAB characters.
                          - Removed TTU_issue_command (no longer used).
   H    20-Apr-98   SFP   - Added options and instance processing.
                            TTU_other_message modified to use standard message
                            printout format.
                            If options bit 0 set, does not issue Invoke/Continue
                            in response to Begin.
                            Added handling of operation code 4; responds with
                            Result-L, Invoke.
   I    29-Mar-00   JET   - ANSI mode option added. Handling of messages now
                            uses tags and formats appropriate to protocol type.
                            Supports ITU-T Q.773 or ANSI T.114.
   1	16-Jul-01   JER   - Removed call to GCT_grab().
   2    03-Feb-06   TB    - Include Intel Corp in file header
   3    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
   -    14-May-13   CJM   - Add option to allow use with TCAP extended dialog IDs
 */

#include <stdio.h>
#include <string.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "pack.h"       /* prototypes for packing functions */
#include "ss7_inc.h"	/* SS7 definitions */
#include "tcp_inc.h"    /* TCAP module definitions */
#include "scp_inc.h"    /* SCCP module definitions */
#include "tcap.h"       /* TCAP library header file */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  void ttu_ent(u8 ttu_mod_id, u8 ttu_ssn, u16 options);

  static int TTU_dlg_ind(MSG *m);
  static int TTU_cpt_ind(MSG *m);
  static int TTU_maint_ind(MSG *m);
  static int TTU_event_ind(MSG *m);
  static int TTU_other_message(MSG *m);
  static int TTU_send_continue(u32 dialogue_id, u16 instance);
  static int TTU_send_abort(u32 dialogue_id, u16 instance);
  static int TTU_send_end(u32 dialogue_id, u16 instance);
  static int TTU_send_invoke(u32 dialogue_id, u16 instance, s8 invoke_id);
  static int TTU_send_result_nl(u32 dialogue_id, u16 instance, s8 invoke_id);
  static int TTU_send_result_l(u32 dialogue_id, u16 instance, s8 invoke_id);
  static int TTU_send_u_error(u32 dialogue_id, u16 instance, s8 invoke_id);
  static int TTU_send_dialogue_req(TCAP_DLG *dlg);
  static int TTU_send_component_req(TCAP_CPT *cpt);
  static int TTU_n_state_req(u8 ssn, u8 format_id, u8 cong_level);
  static int TTU_send_msg(MSG *m);
  static int TTU_validate_invoke(TCAP_CPT *cpt);
  int TCAP_display_dialogue(TCAP_DLG *dlg);
  int TCAP_display_component(TCAP_CPT *cpt);
  static int show_tcap_data(char *text, u8 *ptr, u16 len);
  static int show_tcap_qos(DLG_QOS *qos);
  static int display_hex(u8 *ptr, u16 len);
  static u8  get_spec(void);
  static u8  get_ext_did(void);
#else
  void ttu_ent();
  static int TTU_dlg_ind();
  static int TTU_cpt_ind();
  static int TTU_maint_ind();
  static int TTU_event_ind();
  static int TTU_other_message();
  static int TTU_send_continue();
  static int TTU_send_abort();
  static int TTU_send_end();
  static int TTU_send_invoke();
  static int TTU_send_result_nl();
  static int TTU_send_result_l();
  static int TTU_send_u_error();
  static int TTU_send_dialogue_req();
  static int TTU_send_component_req();
  static int TTU_n_state_req();
  static int TTU_send_msg();
  static int TTU_validate_invoke();
  int TCAP_display_dialogue();
  int TCAP_display_component();
  static int show_tcap_data();
  static int show_tcap_qos();
  static int display_hex();
  static u8  get_spec();
  static u8  get_ext_did();
#endif

/*
 * Some useful macros.
 */
#define NO_RESPONSE             (0)
#define RESPONSE(mod_id)        (1 << ((mod_id) & 0x0f))
#define BIN2CH(b)               ((char)(((b)<10)?'0'+(b):'a'-10+(b)))

#define TTU_user_in_service(ssn)        TTU_n_state_req((ssn), 1, 0)
#define TTU_user_out_of_service(ssn)    TTU_n_state_req((ssn), 2, 0)
#define TTU_user_congestion(ssn, cong)  TTU_n_state_req((ssn), 7, (cong))

/*
 * Q.773 definitions:
 */
#define INVOKE_ID_TAG           (0x02)  /* Q.773 invoke id tag */
#define LOCAL_OP_TAG            (0x02)  /* Q.773 local operation tag */
#define LOCAL_ERR_TAG           (0x02)  /* Q.773 local error code tag */
#define OCTET_STRING_TAG        (0x04)  /* Q.773 primitive octet string tag */

/*
 * T1.114 definitions:
 */
#define T114_CPT_ID_TAG         (0xcf)  /* T114 component id tag */
#define T114_NAT_OP_TAG         (0xd0)  /* T114 local operation tag */
#define T114_ERR_TAG            (0xd4)  /* T114 local error code tag */
#define T114_SEQ_TAG            (0x30)  /* Seq tag */


/*
 * Constants used in this example application:
 */
        /* Number of incoming dialogues */
#define NUM_IC_DLGS     (16)
        /* First dialogue ID supported by this example */
#define MIN_IC_DLG_ID   (0x8000)
        /* Last dialogue ID supported by this example */
#define MAX_IC_DLG_ID   (MIN_IC_DLG_ID + NUM_IC_DLGS - 1)
        /* First Invoke id used in an o/g invoke for each dialogue */
#define OG_INV_ID1      (1)
        /* Second Invoke id used in an o/g invoke for each dialogue */
#define OG_INV_ID2      (2)
        /* Maximum MSG parameter trace length */
#define MAX_PARAM_LEN   (320)

/*
 * Command line options
 */
#define OPT_NO_BGN	(0x8000) /* Do not respond to Begin with Inv/Cont */
#define OPT_ANSI        (0x4000) /* Use ansi primitives */
#define OPT_EXT_DID     (0x0002) /* Compatibility with TCAP Extended Dialogue ID mode (TCPXF_EXT_DID option) */
#define OPT_NO_PRINT	(0x0001) /* Do not print primitives on the console */

/*
 * Definition of state machine used to handle
 * incoming dialogues. One instance exists
 * for each dialogue_id:
 */
typedef struct state_machine
{
  u8    state;                  /* current state */
  u8    finished;               /* final dialogue primitive received */
  u8    abort_pending;          /* we will abort once all cpts received */
  u8    end_pending;            /* we will end once all cpts received */
  u8    instance;               /* instance currently handling this dialogue */
} STATE_MACHINE;

#define STATE_IDLE      (0)     /* Idle */
#define STATE_UNI_RXD   (1)     /* Unstructured dialogue active */
#define STATE_BEGIN_RXD (2)     /* Structured dialogue active */

/*
 * Define local function to find Dialogues State Machine
 */
#ifdef LINT_ARGS
  static STATE_MACHINE *get_dlg_sm(u32 did);
#else
  static STATE_MACHINE *get_dlg_sm();
#endif

/*
 * Storage for TTU's module Id and Local sub-system number.
 */
static u8 ttu_mod_id;           /* The module id for TTU*/
static u8 ttu_ssn;              /* The sub-system number to be used by TTU */
static u16 ttu_options;         /* Options for TTU*/

#define ANSI_MODE()     (ttu_options & OPT_ANSI)    /* use ansi primitives */
#define ITU_MODE()      (!ANSI_MODE())              /* use itu primitives */

#define EXT_DID_MODE()  (ttu_options & OPT_EXT_DID) /* use extended DID parameter */


STATE_MACHINE state_machine[NUM_IC_DLGS];

/*
 * Main function for TCAP Test Utility (TTU):
 */
void ttu_ent(mod_id, ssn, options)
  u8  mod_id;
  u8  ssn;
  u16 options;
{
  u16 i;
  HDR *h;
  MSG *m;
  int finished;

  ttu_mod_id = mod_id;
  ttu_ssn = ssn;
  ttu_options = options;

  /*
   * Print banner so we know what's running:
   */
  printf("TTU TCAP Test Utility    Copyright (C) Dialogic Corporation 1994-2013. All Rights Reserved.\n");
  printf("===========================================================================================\n");
  printf("TTU module ID - 0x%02x \nTTU sub-system number - 0x%02x\n",
          ttu_mod_id, ttu_ssn);
  printf("Options set - 0x%04x \n\n", ttu_options);


  /*
   * Initialise the (per-dialogue) state machines:
   */
  for (i=0; i<NUM_IC_DLGS; i++)
    state_machine[i].state = STATE_IDLE;

  /*
   * Tell SCCP that this sub-system
   * is now in service:
   */
  TTU_user_in_service(ttu_ssn);

  /*
   * Now enter main loop, receiving messages as
   * they become available and processing accordingly:
   */
  finished = 0;
  while (!finished)
  {
    /*
     * GCT_receive will attempt to receive message
     * from the task's message queue and block until
     * a message is ready:
     */
    if ((h = GCT_receive(ttu_mod_id)) != 0)
    {
      m = (MSG *)h;
      switch (m->hdr.type)
      {
        case TCP_MSG_DLG_IND :
          TTU_dlg_ind(m);
          break;

        case TCP_MSG_CPT_IND :
          TTU_cpt_ind(m);
          break;

        case TCP_MSG_MAINT_IND :
          TTU_maint_ind(m);
          break;

        case TCP_MSG_ERROR_IND :
          TTU_event_ind(m);
          break;

        default :
          TTU_other_message(m);
          break;
      }

      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }
  TTU_user_out_of_service(ttu_ssn);
}

/*
 * Function to handle TCAP dialogue indications:
 */
static int TTU_dlg_ind(m)
  MSG *m;
{
  STATE_MACHINE *smac;          /* state machine for received dialogue id */
  TCAP_DLG      dlg;            /* structured form of received primitive */
  u32           dialogue_id;    /* dialogue_id of received primitive */

  /*
   * Recover the parameters from the MSG
   * into a 'C' structure:
   */
  if (TCAP_msg_to_dialogue(&dlg, m, get_spec(), get_ext_did()) != 0)
    printf("TTU: *** Dialogue recovery failure ***\n");
  else
  {
    /*
     * Display the dialogue primitive to the user:
     */
    if ((ttu_options & OPT_NO_PRINT) == 0)
    {
      printf("TTU: Dialogue ind, instance %02x:\n", dlg.instance);
      TCAP_display_dialogue(&dlg);
    }
    /*
     * Recover the dialogue id, check it is valid
     * and locate the appropriate state machine:
     */
    dialogue_id = dlg.dialogue_id;

    smac = get_dlg_sm(dialogue_id);
    if (!smac)
      printf("TTU: Unexpected dialogue_id=0x%08x\n", dialogue_id);
    else
    {
      smac->instance = dlg.instance;
      /*
       * Now handle the event depending on
       * the current state:
       */
      switch (smac->state)
      {
        case STATE_IDLE :
          /*
           * In the IDLE state expect only UNI or BEGIN,
           * if any other primitives received, issue U-ABORT.
           */
          switch (dlg.ptype)
          {
            case TCPPT_TC_UNI :
              /*
               * UNI received, we don't do anything with the
               * UNI itself but if it contains components we
               * enter the UNI_RXD state and await the components:
               */
              if (dlg.u.uni.cpt_present != 0)
                smac->state = STATE_UNI_RXD;
              break;

            case TCPPT_TC_BEGIN :
              /*
               * Initialise state machine flags:
               */
              smac->finished = 0;
              smac->abort_pending = 0;
              smac->end_pending = 0;

              /*
               * BEGIN received, if configured, immediately respond
               * with INVOKE and CONTINUE (and will use the timeout
               * to abort the dialogue if the sending user does
               * not tidy things up!)
               */
              if ((ttu_options & OPT_NO_BGN) == 0)
              {
                TTU_send_invoke(dlg.dialogue_id, smac->instance, OG_INV_ID1);
                TTU_send_continue(dlg.dialogue_id, smac->instance);
              }
              smac->state = STATE_BEGIN_RXD;
              break;

            default :
              /*
               * Unexpected dialogue primitive received,
               * issue U-ABORT:
               */
              TTU_send_abort(dlg.dialogue_id, smac->instance);
              break;
          }
          break;

        case STATE_UNI_RXD :
          /*
           * We don't expect any dialogue handling primitives
           * in this state so issue U-ABORT and return to IDLE:
           */
          TTU_send_abort(dlg.dialogue_id, smac->instance);
          smac->state = STATE_IDLE;
          break;

        case STATE_BEGIN_RXD :
          switch (dlg.ptype)
          {
            case TCPPT_TC_CONTINUE :
              /*
               * CONTINUE received, we don't do anything with
               * the CONTINUE itself but remain in this state
               * to receive components:
               */
              break;

            case TCPPT_TC_END :
              /*
               * TC-END received to terminate the dialogue.
               * We return to IDLE (as soon as all
               * components have been received):
               */
              if (dlg.u.end.cpt_present)
                smac->finished = 1;
              else
                smac->state = STATE_IDLE;
              break;

            case TCPPT_TC_U_ABORT :
            case TCPPT_TC_P_ABORT :
              /*
               * ABORT primitive received to terminate the
               * dialogue. Abort primitives do not contain
               * components so return to IDLE.
               */
              smac->state = STATE_IDLE;
              break;

            default :
              /*
               * Unexpected dialogue primitive received, issue
               * U-ABORT and return to IDLE:
               */
              TTU_send_abort(dlg.dialogue_id, smac->instance);
              smac->state = STATE_IDLE;
              break;
          }
          break;
      }
    }
  }
  return(0);
}

/*
 * Function to handle TCAP component indications:
 */
static int TTU_cpt_ind(m)
  MSG *m;
{
  STATE_MACHINE *smac;
  TCAP_CPT      cpt;
  u32           dialogue_id;
  s8            invoke_id;

  /*
   * Recover the parameters from the MSG
   * into a 'C' structure:
   */
  if (TCAP_msg_to_component(&cpt, m, get_spec(), get_ext_did()) != 0)
    printf("TTU: *** Component recovery failure ***\n");
  else
  {
    /*
     * Display the component to the user:
     */
    if ((ttu_options & OPT_NO_PRINT) == 0)
    {
      printf("TTU: Component ind, instance %02x:\n", cpt.instance);
      TCAP_display_component(&cpt);
    }
    /*
     * Recover the dialogue id, check it is valid
     * and locate the appropriate state machine:
     */
    dialogue_id = cpt.dialogue_id;

    smac = get_dlg_sm(dialogue_id);
    if (!smac)
      printf("TTU: Unexpected dialogue_id=0x%08x\n", dialogue_id);
    else
    {
      smac->instance = cpt.instance;

      /*
       * Now handle the event depending on
       * the current state:
       */
      switch (smac->state)
      {
        case STATE_IDLE :
          /*
           * Discard all components whilst in the IDLE state:
           */
          break;

        case STATE_UNI_RXD :
          /*
           * Remain in this state for as long as there
           * are more components to follow:
           */
          if (cpt.last_component)
            smac->state = STATE_IDLE;
          break;

        case STATE_BEGIN_RXD :
          switch (cpt.ptype)
          {
            case TCPPT_TC_INVOKE :
              /*
               * On receipt of an INVOKE we respond with
               * one of the following sequences depending
               * on the operation code:
               *        (a) RR-NL, RR-L, CONTINUE
               *        (b) RR-L, CONTINUE
               *        (c) U-ERR, CONTINUE
               *        (d) RR-L, INVOKE, CONTINUE
               */
              if (TTU_validate_invoke(&cpt) == 0)
              {
                invoke_id = (s8)cpt.u.invoke.invoke_id.data[2];

                if (ITU_MODE())
                {
                  /*
                   * Q773 TCAP dialogues
                   */
                  switch (cpt.u.invoke.operation.data[2])
                  {
                  case 1 :
                    TTU_send_result_nl(dialogue_id, smac->instance, invoke_id);
                    TTU_send_result_l(dialogue_id, smac->instance, invoke_id);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  case 2 :
                    TTU_send_result_l(dialogue_id, smac->instance, invoke_id);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  case 3 :
                    TTU_send_u_error(dialogue_id, smac->instance, invoke_id);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  case 4 :
                    TTU_send_result_l(dialogue_id, smac->instance, invoke_id);
                    TTU_send_invoke(dialogue_id, smac->instance, OG_INV_ID2);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  }
                }
                else
                {
                  /*
                   * T114 TCAP dialogues
                   *
                   * Operation data is made up of op code family octet
                   * and op code value octet. We'll just check the op code
                   * value (octet 3 of the operation data after tag, len and
                   * op code family). We are not using real op codes here.
                   */
                  switch (cpt.u.invoke.operation.data[3])
                  {
                  case 1 :
                    TTU_send_result_l(dialogue_id, smac->instance, invoke_id);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  case 2 :
                    TTU_send_u_error(dialogue_id, smac->instance, invoke_id);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  case 3 :
                    TTU_send_result_l(dialogue_id, smac->instance, invoke_id);
                    TTU_send_invoke(dialogue_id, smac->instance, OG_INV_ID2);
                    TTU_send_continue(dialogue_id, smac->instance);
                    break;
                  }
                }
              }
              else
              {
                printf("TTU: *** Invalid invoke data ***\n");
              }
              break;

            case TCPPT_TC_RESULT_NL :
              /*
               * We just discard any non-final results:
               */
              break;

            case TCPPT_TC_RESULT_L :
              /*
               * Final result received so prepare to
               * end the dialogue when all components
               * received:
               */
              smac->end_pending = 1;
              break;

            default :
              /*
               * On receipt of any other components
               * prepare to abort the dialogue once
               * all components received:
               */
              smac->abort_pending = 1;
              break;
          }

          /*
           * Now, if no more components to follow,
           * check to see if we are going to
           * terminate the dialogue:
           */
          if (cpt.last_component)
          {
            if (smac->finished)
              smac->state = STATE_IDLE;
            else
            {
              if (smac->abort_pending)
              {
                TTU_send_abort(dialogue_id, smac->instance);
                smac->state = STATE_IDLE;
              }
              else
              {
                if (smac->end_pending)
                {
                  TTU_send_end(dialogue_id, smac->instance);
                  smac->state = STATE_IDLE;
                }
              }
            }
          }
          break;
      }
    }
  }
  return(0);
}

/*
 * Function to handle TCAP Maintenance
 * Event indications:
 */
static int TTU_maint_ind(m)
  MSG *m;
{
  int   instance;

  instance = GCT_get_instance((HDR*)m);
  if ((ttu_options & OPT_NO_PRINT) == 0)
  {
    printf("TTU:I%02x ", instance);
    switch (m->hdr.status)
    {
      case TCPEV_CPT_REQ_DISCARD :       printf("TCPEV_CPT_REQ_DISCARD\n");      break;
      case TCPEV_DLG_REQ_DISCARD :       printf("TCPEV_DLG_REQ_DISCARD\n");      break;
      case TCPEV_DATA_LEN_ERR :          printf("TCPEV_DATA_LEN_ERR\n");         break;
      case TCPEV_UNREC_TYPE :            printf("TCPEV_UNREC_TYPE\n");           break;
      case TCPEV_UNREC_TID :             printf("TCPEV_UNREC_TID\n");            break;
      case TCPEV_SYNTAX_ERR :            printf("TCPEV_SYNTAX_ERR\n");           break;
      case TCPEV_BAD_REJ_RXD :           printf("TCPEV_BAD_REJ_RXD\n");          break;
      case TCPEV_DLG_TIM_TIMEOUT :       printf("TCPEV_DLG_TIM_TIMEOUT\n");      break;
      case TCPEV_EXCESSIVE_DLG_ABORTS :  printf("TCPEV_EXCESSIVE_DLG_ABORTS\n"); break;
      default : printf("TTU: *** Unknown Maint Event=0x%02x ***\n", m->hdr.status);
      break;
    }
  }
  return(0);
}

/*
 * Function to handle TCAP Software
 * Event indications:
 */
static int TTU_event_ind(m)
  MSG *m;
{
  int   instance;

  instance = GCT_get_instance((HDR*)m);
  if ((ttu_options & OPT_NO_PRINT) == 0)
  {
    printf("TTU:I%02x ", instance);
    switch (m->hdr.status)
    {
      case TCPSWE_NO_TCPT :       printf("TCPSWE_NO_TCPT\n");     break;
      case TCPSWE_NO_TISM :       printf("TCPSWE_NO_TISM\n");     break;
      case TCPSWE_NO_DLG :        printf("TCPSWE_NO_DLG\n");      break;
      case TCPSWE_NO_TCPM :       printf("TCPSWE_NO_TCPM\n");     break;
      case TCPSWE_TCPM_LOW :      printf("TCPSWE_TCPM_LOW\n");    break;
      case TCPSWE_BAD_MSG :       printf("TCPSWE_BAD_MSG\n");     break;
      case TCPSWE_TX_FMT_ERR :    printf("TCPSWE_TX_FMT_ERR\n");  break;
      case TCPSWE_ISM_ERR :       printf("TCPSWE_ISM_ERR\n");     break;
      case TCPSWE_BAD_NSAP_FMT :  printf("TCPSWE_BAD_NSAP_FMT\n"); break;
      case TCPSWE_DBUF_LOW:       printf("TCPSWE_DBUF_LOW\n");    break;
      case TCPSWE_NO_DBUF:        printf("TCPSWE_NO_DBUF\n");     break;
      case TCPSWE_DBUF_ABMT:      printf("TCPSWE_DBUF_ABMT\n");   break;
      default : printf("TTU: *** Unknown Software Event=0x%02x ***\n", m->hdr.status);
      break;
    }
  }
  return(0);
}

/*
 * Function to handle any other messages:
 */
static int TTU_other_message(m)
  MSG *m;
{
  HDR   *h;
  int   instance;
  u16   mlen;
  u8    *pptr;

  h = (HDR*)m;
  instance = GCT_get_instance(h);
  if ((ttu_options & OPT_NO_PRINT) == 0)
  {
    printf("TTU:I%02x M t%04x i%04x f%02x d%02x s%02x", instance, h->type,
            h->id, h->src, h->dst, h->status);

    if ((mlen = m->len) > 0)
    {
      if (mlen > MAX_PARAM_LEN)
        mlen = MAX_PARAM_LEN;
      printf(" p");
      pptr = get_param(m);
      while (mlen--)
      {
        printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
        pptr++;
      }
    }
    printf("\n");
  }
  return(0);
}

/*
 * Function to build a TC-CONTINUE dialogue
 * request message and send it to TCAP:
 */
static int TTU_send_continue(dialogue_id, instance)
  u32   dialogue_id;
  u16   instance;
{
  TCAP_DLG dlg;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_dialogue(&dlg, get_spec(), get_ext_did());
  dlg.dialogue_id = dialogue_id;
  dlg.instance = instance;
  dlg.ptype = TCPPT_TC_CONTINUE;
  dlg.u.cont.qos.indicator = QOSI_RET_OPT | QOSI_SEQ_CTRL;
  dlg.u.cont.orig_addr.len = 0;                 /* no orig_addr */
  dlg.u.cont.ac_name.len = 0;                   /* no ac_name */
  dlg.u.cont.user_info.len = 0;                 /* no user_info */
  TTU_send_dialogue_req(&dlg);
  return(0);
}

/*
 * Function to build a TC-ABORT dialogue
 * request message and send it to TCAP:
 */
static int TTU_send_abort(dialogue_id, instance)
  u32   dialogue_id;
  u16   instance;
{
  TCAP_DLG dlg;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_dialogue(&dlg, get_spec(), get_ext_did());
  dlg.dialogue_id = dialogue_id;
  dlg.instance = instance;
  dlg.ptype = TCPPT_TC_U_ABORT;
  dlg.u.uabort.qos.indicator = QOSI_RET_OPT | QOSI_SEQ_CTRL;
  dlg.u.uabort.abort_reason = 2;                   /* other user reason */
  dlg.u.uabort.ac_name.len = 0;                    /* no ac_name */
  dlg.u.uabort.user_info.len = 0;                  /* no user_info */
  TTU_send_dialogue_req(&dlg);
  return(0);
}

/*
 * Function to build a TC-END dialogue
 * request message and send it to TCAP:
 */
static int TTU_send_end(dialogue_id, instance)
  u32   dialogue_id;
  u16   instance;
{
  TCAP_DLG dlg;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_dialogue(&dlg, get_spec(), get_ext_did());
  dlg.dialogue_id = dialogue_id;
  dlg.instance = instance;
  dlg.ptype = TCPPT_TC_END;
  dlg.u.end.qos.indicator = QOSI_RET_OPT | QOSI_SEQ_CTRL;
  dlg.u.end.termination = TCPEND_BASIC;         /* basic end */
  dlg.u.end.ac_name.len = 0;                    /* no ac_name */
  dlg.u.end.user_info.len = 0;                  /* no user_info */
  TTU_send_dialogue_req(&dlg);
  return(0);
}

/*
 * Function to build a TC-INVOKE component
 * request message and send it to TCAP:
 */
static int TTU_send_invoke(dialogue_id, instance, invoke_id)
  u32   dialogue_id;
  u16   instance;
  s8    invoke_id;
{
  TCAP_CPT cpt;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_component(&cpt, get_spec(), get_ext_did());
  cpt.dialogue_id = dialogue_id;
  cpt.instance = instance;
  cpt.ptype = TCPPT_TC_INVOKE;
  /*
   * Set class 1 operation and a 30 second timeout
   */
  cpt.u.invoke.class = 1;
  cpt.u.invoke.timeout = 30;

  /*
   * Set invoke id to 1, using appropriate tag value
   */
  if (ITU_MODE())
    cpt.u.invoke.invoke_id.data[0] = INVOKE_ID_TAG;
  else
    cpt.u.invoke.invoke_id.data[0] = T114_CPT_ID_TAG;

  cpt.u.invoke.invoke_id.data[1] = 1;
  cpt.u.invoke.invoke_id.data[2] = (u8)invoke_id;
  cpt.u.invoke.invoke_id.len = 3;

  /*
   * no linked_id
   */
  cpt.u.invoke.linked_id.len = 0;

  /*
   * Fill appropriate tag and data values for op-code.
   * Different codes and tags are valid for ANSI
   */
  if (ITU_MODE())
  {
    cpt.u.invoke.operation.data[0] = LOCAL_OP_TAG;
    cpt.u.invoke.operation.data[1] = 1;
    cpt.u.invoke.operation.data[2] = 1;
    cpt.u.invoke.operation.len = 3;
  }
  else
  {
    /*
     * Set opcode tag to national op codes, op code family is report event,
     * opcode value is 1 (VM available)
     */
    cpt.u.invoke.operation.data[0] = T114_NAT_OP_TAG;
    cpt.u.invoke.operation.data[1] = 2;
    cpt.u.invoke.operation.data[2] = 0x0a;
    cpt.u.invoke.operation.data[3] = 1;
    cpt.u.invoke.operation.len = 4;
  }


  if (ITU_MODE())
  {
    /*
     * no parameters
     */
    cpt.u.invoke.param.len = 0;
  }
  else
  {
    /*
     * Parameter data is simply an empty sequence
     */
    cpt.u.invoke.param.data[0] = T114_SEQ_TAG;
    cpt.u.invoke.param.data[1] = 0;
    cpt.u.invoke.param.len = 2;
  }

  TTU_send_component_req(&cpt);
  return(0);
}

/*
 * Function to build a TC-RESULT-NL component
 * request message and send it to TCAP:
 */
static int TTU_send_result_nl(dialogue_id, instance, invoke_id)
  u32   dialogue_id;
  u16   instance;
  s8    invoke_id;
{
  TCAP_CPT cpt;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_component(&cpt, get_spec(), get_ext_did());
  cpt.dialogue_id = dialogue_id;
  cpt.instance = instance;
  cpt.ptype = TCPPT_TC_RESULT_NL;

  /*
   * Set invoke id to 1, using appropriate tag value
   */
  if (ITU_MODE())
    cpt.u.rrnl.invoke_id.data[0] = INVOKE_ID_TAG;
  else
    cpt.u.rrnl.invoke_id.data[0] = T114_CPT_ID_TAG;

  cpt.u.rrnl.invoke_id.data[1] = 1;
  cpt.u.rrnl.invoke_id.data[2] = (u8)invoke_id;
  cpt.u.rrnl.invoke_id.len = 3;

  /*
   * Fill appropriate tag and data values for op-code.
   * Different codes and tags are valid for ANSI
   */
  if (ITU_MODE())
  {
    cpt.u.rrnl.operation.data[0] = LOCAL_OP_TAG;
    cpt.u.rrnl.operation.data[1] = 1;
    cpt.u.rrnl.operation.data[2] = 1;
    cpt.u.rrnl.operation.len = 3;
  }
  else
  {
    /*
     * Set opcode tag to national op codes, op code family is report event,
     * opcode value is 1 (VM available)
     */
    cpt.u.rrnl.operation.data[0] = T114_NAT_OP_TAG;
    cpt.u.rrnl.operation.data[1] = 2;
    cpt.u.rrnl.operation.data[2] = 0x0a;
    cpt.u.rrnl.operation.data[3] = 1;
    cpt.u.rrnl.operation.len = 4;
  }

  /*
   * Example parameter data
   */
  cpt.u.rrnl.param.len = 7;
  cpt.u.rrnl.param.data[0] = OCTET_STRING_TAG;
  cpt.u.rrnl.param.data[1] = 5;
  cpt.u.rrnl.param.data[2] = (u8)'R';
  cpt.u.rrnl.param.data[3] = (u8)'R';
  cpt.u.rrnl.param.data[4] = (u8)'-';
  cpt.u.rrnl.param.data[5] = (u8)'N';
  cpt.u.rrnl.param.data[6] = (u8)'L';
  TTU_send_component_req(&cpt);
  return(0);
}

/*
 * Function to build a TC-RESULT-L component
 * request message and send it to TCAP:
 */
static int TTU_send_result_l(dialogue_id, instance, invoke_id)
  u32   dialogue_id;
  u16   instance;
  s8    invoke_id;
{
  TCAP_CPT cpt;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_component(&cpt, get_spec(), get_ext_did());
  cpt.dialogue_id = dialogue_id;
  cpt.instance = instance;
  cpt.ptype = TCPPT_TC_RESULT_L;

  /*
   * Set invoke id to 1, using appropriate tag value
   */
  if (ITU_MODE())
    cpt.u.rrl.invoke_id.data[0] = INVOKE_ID_TAG;
  else
    cpt.u.rrl.invoke_id.data[0] = T114_CPT_ID_TAG;

  cpt.u.rrl.invoke_id.data[1] = 1;
  cpt.u.rrl.invoke_id.data[2] = (u8)invoke_id;
  cpt.u.rrl.invoke_id.len = 3;

  /*
   * Fill appropriate tag and data values for op-code.
   * Different codes and tags are valid for ANSI
   */
  if (ITU_MODE())
  {
    cpt.u.rrl.operation.data[0] = LOCAL_OP_TAG;
    cpt.u.rrl.operation.data[1] = 1;
    cpt.u.rrl.operation.data[2] = 1;
    cpt.u.rrl.operation.len = 3;
  }
  else
  {
    /*
     * Set opcode tag to national op codes, op code family is report event,
     * opcode value is 1 (VM available)
     */
    cpt.u.rrl.operation.data[0] = T114_NAT_OP_TAG;
    cpt.u.rrl.operation.data[1] = 2;
    cpt.u.rrl.operation.data[2] = 0x0a;
    cpt.u.rrl.operation.data[3] = 1;
    cpt.u.rrl.operation.len = 4;
  }

  /*
   * Example parameter data
   */
  cpt.u.rrl.param.len = 6;
  cpt.u.rrl.param.data[0] = OCTET_STRING_TAG;
  cpt.u.rrl.param.data[1] = 4;
  cpt.u.rrl.param.data[2] = (u8)'R';
  cpt.u.rrl.param.data[3] = (u8)'R';
  cpt.u.rrl.param.data[4] = (u8)'-';
  cpt.u.rrl.param.data[5] = (u8)'L';
  TTU_send_component_req(&cpt);
  return(0);
}

/*
 * Function to build a TC-U-ERROR component
 * request message and send it to TCAP:
 */
static int TTU_send_u_error(dialogue_id, instance, invoke_id)
  u32   dialogue_id;
  u16   instance;
  s8    invoke_id;
{
  TCAP_CPT cpt;         /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  TCAP_init_component(&cpt, get_spec(), get_ext_did());
  cpt.dialogue_id = dialogue_id;
  cpt.instance = instance;
  cpt.ptype = TCPPT_TC_U_ERROR;

  /*
   * Set invoke id to 1, using appropriate tag value
   */
  if (ITU_MODE())
    cpt.u.uerror.invoke_id.data[0] = INVOKE_ID_TAG;
  else
    cpt.u.uerror.invoke_id.data[0] = T114_CPT_ID_TAG;

  cpt.u.uerror.invoke_id.data[1] = 1;
  cpt.u.uerror.invoke_id.data[2] = (u8)invoke_id;
  cpt.u.uerror.invoke_id.len = 3;

  /*
   * Set error code to 5
   */
  cpt.u.uerror.error.data[0] = T114_ERR_TAG;
  cpt.u.uerror.error.data[1] = 1;
  cpt.u.uerror.error.data[2] = 5;
  cpt.u.uerror.error.len = 3;

  /*
   * no parameters
   */
  cpt.u.uerror.param.len = 0;
  TTU_send_component_req(&cpt);
  return(0);
}


/*
 * Function to send a dialogue request primitive
 * to the TCAP module:
 *
 * Allocates a message (using the getm() function)
 * then using the TCAP library function TCAP_dialogue_to_msg()
 * converts the primitive parameters from 'C' structured
 * representation into the correct format for passing
 * to the TCAP module. Finally the new message is sent
 * to the TCAP module.
 *
 * Returns zero always.
 *
 */
static int TTU_send_dialogue_req(dlg)
  TCAP_DLG *dlg;
{
  MSG *m;               /* message sent to TCAP */

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm(TCP_MSG_DLG_REQ, DID_16_LSB(dlg->dialogue_id), NO_RESPONSE,
                                      TCP_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ttu_mod_id;
    m->hdr.dst = TCP_TASK_ID;

    /*
     * Use the library function to format the
     * parameter area of the message and
     * (if successful) send it to TCAP:
     */
    if (TCAP_dialogue_to_msg(m, dlg) != 0)
    {
      printf("TTU: *** failed to format dialogue request ***\n");
      relm(&m->hdr);
    }
    else
    {
      /*
       * Display the dialogue primitive to the user:
       */
      if ((ttu_options & OPT_NO_PRINT) == 0)
      {
        printf("TTU: Dialogue req: ");
        display_hex(get_param(m), m->len);
        printf("\n");
        TCAP_display_dialogue(dlg);
      }

      /*
       * and send to TCAP:
       */
      TTU_send_msg(m);
    }
  }
  return(0);
}

/*
 * Function to send a component request primitive
 * to the TCAP module:
 *
 * Allocates a message (using the getm() function)
 * then using the TCAP library function TCAP_component_to_msg()
 * converts the primitive parameters from 'C' structured
 * representation into the correct format for passing
 * to the TCAP module. Finally the new message is sent
 * to the TCAP module.
 *
 * Returns zero always.
 *
 */
static int TTU_send_component_req(cpt)
  TCAP_CPT *cpt;
{
  MSG *m;               /* message sent to TCAP */

  /*
   * Allocate a message to send:
   */
  if ((m = getm(TCP_MSG_CPT_REQ, DID_16_LSB(cpt->dialogue_id), NO_RESPONSE,
                                      TCP_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ttu_mod_id;
    m->hdr.dst = TCP_TASK_ID;

    /*
     * Use the library function to format the
     * parameter area of the message and
     * (if successful) send it to TCAP:
     */
    if (TCAP_component_to_msg(m, cpt) != 0)
    {
      printf("TTU: *** failed to format component request ***\n");
      relm(&m->hdr);
    }
    else
    {
      /*
       * Display the component to the user:
       */
      if ((ttu_options & OPT_NO_PRINT) == 0)
      {
        printf("TTU: Component req: ");
        display_hex(get_param(m), m->len);
        printf("\n");
        TCAP_display_component(cpt);
      }
      TTU_send_msg(m);
    }
  }
  return(0);
}

/*
 * Function to build and send a local
 * sub-system N-STATE request:
 *
 * Note that the mnemonics are not currently
 * defined!
 */
static int TTU_n_state_req(ssn, format_id, cong_level)
  u8    ssn;            /* local sub-system number */
  u8    format_id;      /* 1=UIS, 2=UOS, 7=Congestion */
  u8    cong_level;     /* congestion level 0, 1, 2 or 3 */
{
  MSG   *m;
  u8    *pptr;

  if ((m = getm(SCP_MSG_SCMG_REQ, ssn, RESPONSE(ttu_mod_id), 6)) != 0)
  {
    m->hdr.src = ttu_mod_id;
    m->hdr.dst = TCP_TASK_ID;
    pptr = get_param(m);
    memset((void *)pptr, 0, m->len);
    rpackbytes(pptr, 0, (u32)SCPMPT_NSTATE_REQ, 1);
    rpackbytes(pptr, 1, (u32)format_id, 1);
    if (format_id == 7)
      rpackbytes(pptr, 5, (u32)cong_level, 1);
    TTU_send_msg(m);
  }
  return(0);
}

/*
 * Function to send message. On failure the
 * message is released and the user notified:
 */
static int TTU_send_msg(m)
  MSG        *m;
{
  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    fprintf(stderr, "TTU: *** failed to send message ***\n");
    relm((HDR *)m);
  }
  return(0);
}

/*
 * Function to validate a TCAP invoke component.
 *
 * Returns zero on success, (-1) on fail
 */
static int TTU_validate_invoke(cpt)
  TCAP_CPT  *cpt; /* invoke structure to validate */
{
  int   ret_val;        /* Return value */

  ret_val = -1;

  if (ITU_MODE())
  {
    /*
     * Q.773 TCAP chosen
     * Check for correct op code tag and value
     * Check for correct invoke id tag and value
     */
    if ( (cpt->u.invoke.operation.len == 3) &&
         (cpt->u.invoke.operation.data[0] == LOCAL_OP_TAG) &&
         (cpt->u.invoke.operation.data[1] == 1) &&
         (cpt->u.invoke.invoke_id.len == 3) &&
         (cpt->u.invoke.invoke_id.data[0] == INVOKE_ID_TAG) &&
         (cpt->u.invoke.invoke_id.data[1] == 1) )
    {
      ret_val = 0;
    }
  }
  else
  {
    /*
     * T114 TCAP chosen
     * Check for correct op code tag and length, assuming a national op code
     * Check invoke id tag and value are correct
     */
    if ( (cpt->u.invoke.operation.len == 4) &&
         (cpt->u.invoke.operation.data[0] == T114_NAT_OP_TAG) &&
         (cpt->u.invoke.invoke_id.len == 3) &&
         (cpt->u.invoke.invoke_id.data[0] == T114_CPT_ID_TAG) &&
         (cpt->u.invoke.invoke_id.data[1] == 1) )
    {
      ret_val = 0;
    }
  }

  return(ret_val);
}

/********************************************************************
 *                                                                  *
 *     Functions to display primitive parameters to the user        *
 *                                                                  *
 ********************************************************************/

int TCAP_display_dialogue(dlg)
  TCAP_DLG      *dlg;
{

  printf("  dialogue_id = 0x%08x", dlg->dialogue_id);
  switch (dlg->ptype)
  {
    case TCPPT_TC_UNI :
      printf("  TC-UNI\n");
      show_tcap_qos(&dlg->u.uni.qos);
      if (dlg->u.uni.cpt_present)
        printf("  COMPONENT(S) PRESENT\n");
      show_tcap_data("orig_addr", dlg->u.uni.orig_addr.data,
                                  dlg->u.uni.orig_addr.len);
      show_tcap_data("dest_addr", dlg->u.uni.dest_addr.data,
                                  dlg->u.uni.dest_addr.len);
      show_tcap_data("ac_name", dlg->u.uni.ac_name.data,
                                dlg->u.uni.ac_name.len);
      show_tcap_data("user_info", dlg->u.uni.user_info.data,
                                  dlg->u.uni.user_info.len);
      break;

    case TCPPT_TC_BEGIN :
      printf("  TC-BEGIN/QUERY\n");
      show_tcap_qos(&dlg->u.begin.qos);
      if (dlg->u.begin.cpt_present)
        printf("  COMPONENT(S) PRESENT\n");
      show_tcap_data("orig_addr", dlg->u.begin.orig_addr.data,
                                  dlg->u.begin.orig_addr.len);
      show_tcap_data("dest_addr", dlg->u.begin.dest_addr.data,
                                  dlg->u.begin.dest_addr.len);
      show_tcap_data("ac_name", dlg->u.begin.ac_name.data,
                                dlg->u.begin.ac_name.len);
      show_tcap_data("user_info", dlg->u.begin.user_info.data,
                                  dlg->u.begin.user_info.len);

      if (ANSI_MODE())
      {
        show_tcap_data("permission", dlg->u.begin.user_info.data,
                                  dlg->u.begin.user_info.len);
      }
      break;

    case TCPPT_TC_CONTINUE :
      printf("  TC-CONTINUE/CONVERSATION\n");
      show_tcap_qos(&dlg->u.cont.qos);
      if (dlg->u.cont.cpt_present)
        printf("  COMPONENT(S) PRESENT\n");
      show_tcap_data("orig_addr", dlg->u.cont.orig_addr.data,
                                  dlg->u.cont.orig_addr.len);
      show_tcap_data("ac_name", dlg->u.cont.ac_name.data,
                                dlg->u.cont.ac_name.len);
      show_tcap_data("user_info", dlg->u.cont.user_info.data,
                                  dlg->u.cont.user_info.len);

      if (ANSI_MODE())
      {
        show_tcap_data("permission", dlg->u.cont.user_info.data,
                                  dlg->u.cont.user_info.len);
      }
      break;

    case TCPPT_TC_END :
      if (dlg->u.end.termination == TCPEND_PREARRANGED)
        printf("  TC-END/RESPONSE (Pre-arranged)\n");
      else
        printf("  TC-END/RESPONSE (Basic)\n");
      show_tcap_qos(&dlg->u.end.qos);
      if (dlg->u.end.cpt_present)
        printf("  COMPONENT(S) PRESENT\n");
      show_tcap_data("ac_name", dlg->u.end.ac_name.data,
                                dlg->u.end.ac_name.len);
      show_tcap_data("user_info", dlg->u.end.user_info.data,
                                  dlg->u.end.user_info.len);

      if (ANSI_MODE())
      {
        show_tcap_data("permission", dlg->u.end.user_info.data,
                                  dlg->u.end.user_info.len);
      }
      break;

    case TCPPT_TC_U_ABORT :
      printf("  TC-U-ABORT\n");
      show_tcap_qos(&dlg->u.uabort.qos);
      printf("  abort_reason = 0x%02x\n", dlg->u.uabort.abort_reason);
      show_tcap_data("ac_name", dlg->u.uabort.ac_name.data,
                                dlg->u.uabort.ac_name.len);
      show_tcap_data("user_info", dlg->u.uabort.user_info.data,
                                  dlg->u.uabort.user_info.len);
      break;

    case TCPPT_TC_P_ABORT :
      printf("  TC-P-ABORT\n");
      show_tcap_qos(&dlg->u.pabort.qos);
      printf("  p_abort = 0x%02x\n", dlg->u.pabort.p_abort);
      break;

    case TCPPT_TC_NOTICE :
      printf("  TC-NOTICE\n");
      show_tcap_qos(&dlg->u.pabort.qos);
      printf("  report_cause = 0x%02x\n", dlg->u.notice.report_cause);
      break;

    default :
      printf("TTU: *** Invalid dlg->ptype (=%u) ***\n", dlg->ptype);
      break;
  }
  return(0);
}

int TCAP_display_component(cpt)
  TCAP_CPT      *cpt;
{

  printf("  dialogue_id = 0x%08x", cpt->dialogue_id);
  if (cpt->last_component)
    printf("  (Last component)");
  switch (cpt->ptype)
  {
    case TCPPT_TC_INVOKE :
      printf("  TC-INVOKE\n");
      if (cpt->u.invoke.class)
        printf("  class = %u\n", cpt->u.invoke.class);
      if (cpt->u.invoke.timeout)
        printf("  timeout = %u\n", cpt->u.invoke.timeout);
      show_tcap_data("invoke_id", cpt->u.invoke.invoke_id.data,
                                  cpt->u.invoke.invoke_id.len);
      show_tcap_data("linked_id", cpt->u.invoke.linked_id.data,
                                  cpt->u.invoke.linked_id.len);
      show_tcap_data("operation", cpt->u.invoke.operation.data,
                                  cpt->u.invoke.operation.len);
      show_tcap_data("param", cpt->u.invoke.param.data,
                              cpt->u.invoke.param.len);
      break;

    case TCPPT_TC_RESULT_NL :
      printf("  TC-RESULT-NL\n");
      show_tcap_data("invoke_id", cpt->u.rrnl.invoke_id.data,
                                  cpt->u.rrnl.invoke_id.len);
      show_tcap_data("operation", cpt->u.rrnl.operation.data,
                                  cpt->u.rrnl.operation.len);
      show_tcap_data("param", cpt->u.rrnl.param.data,
                              cpt->u.rrnl.param.len);
      break;

    case TCPPT_TC_RESULT_L :
      printf("  TC-RESULT-L\n");
      show_tcap_data("invoke_id", cpt->u.rrl.invoke_id.data,
                                  cpt->u.rrl.invoke_id.len);
      show_tcap_data("operation", cpt->u.rrl.operation.data,
                                  cpt->u.rrl.operation.len);
      show_tcap_data("param", cpt->u.rrl.param.data,
                              cpt->u.rrl.param.len);
      break;

    case TCPPT_TC_U_ERROR :
      printf("  TC-U-ERROR\n");
      show_tcap_data("invoke_id", cpt->u.uerror.invoke_id.data,
                                  cpt->u.uerror.invoke_id.len);
      show_tcap_data("error", cpt->u.uerror.error.data,
                              cpt->u.uerror.error.len);
      show_tcap_data("param", cpt->u.uerror.param.data,
                              cpt->u.uerror.param.len);
      break;

    case TCPPT_TC_L_REJECT :
      printf("  TC-L-REJECT\n");
      show_tcap_data("invoke_id", cpt->u.lreject.invoke_id.data,
                                  cpt->u.lreject.invoke_id.len);
      show_tcap_data("problem", cpt->u.lreject.problem.data,
                                cpt->u.lreject.problem.len);
      break;

    case TCPPT_TC_R_REJECT :
      printf("  TC-R-REJECT\n");
      show_tcap_data("invoke_id", cpt->u.rreject.invoke_id.data,
                                  cpt->u.rreject.invoke_id.len);
      show_tcap_data("problem", cpt->u.rreject.problem.data,
                                cpt->u.rreject.problem.len);
      break;

    case TCPPT_TC_U_REJECT :
      printf("  TC-U-REJECT\n");
      show_tcap_data("invoke_id", cpt->u.ureject.invoke_id.data,
                                  cpt->u.ureject.invoke_id.len);
      show_tcap_data("problem", cpt->u.ureject.problem.data,
                                cpt->u.ureject.problem.len);
      break;

    case TCPPT_TC_U_CANCEL :
      printf("  TC-U-CANCEL\n");
      show_tcap_data("invoke_id", cpt->u.ucancel.invoke_id.data,
                                  cpt->u.ucancel.invoke_id.len);
      break;

    case TCPPT_TC_L_CANCEL :
      printf("  TC-L-CANCEL\n");
      show_tcap_data("invoke_id", cpt->u.lcancel.invoke_id.data,
                                  cpt->u.lcancel.invoke_id.len);
      break;

    default :
      printf("TTU: *** Invalid cpt->ptype (=%u) ***\n", cpt->ptype);
      break;
  }
  return(0);
}

/*
 * Function to display Quality of Service
 * perameter in text format:
 */
static int show_tcap_qos(qos)
  DLG_QOS       *qos;
{

  if (qos->indicator)
  {
    printf("  qos = ");
    if (qos->indicator & QOSI_RET_OPT)
      printf("RET_OPT, ");
    if (qos->indicator & QOSI_SEQ_CTRL)
      printf("SEQ_CTRL, ");
    if (qos->indicator & QOSI_SLS_KEY)
      printf("SLS_KEY=0x%02x, ", qos->sls_key);
    if (qos->indicator & QOSI_PRIORITY)
      printf("SLS_KEY=0x%02x, ", qos->priority);
    printf("\n");
  }
  return(0);
}

/*
 * Function to display parameter name (in text form)
 * and <len> bytes of hex data commencing from <ptr>:
 *
 * Returns zero always:
 */
static int show_tcap_data(text, ptr, len)
  char  *text;
  u8    *ptr;
  u16   len;
{

  if (len)
  {
    printf("  %s = ", text);
    display_hex(ptr, len);
    printf("\n");
  }
  return(0);
}

/*
 * Function to display hex data:
 */
static int display_hex(ptr, len)
  u8    *ptr;
  u16   len;
{
  while (len--)
    printf("%02x ", *ptr++);
  return(0);
}

/*
 * Function to return a pointer to the State Machine structure for a dialogue.
 *
 * Returns pointer to STATE_MACHINE structure for did or to NULL if did is invalid
 */
static STATE_MACHINE *get_dlg_sm(u32 did)
{
  if ((did < MIN_IC_DLG_ID) || (did > MAX_IC_DLG_ID))
    return(NULL);

  return(&state_machine[did - MIN_IC_DLG_ID]);
}

/*
 * Function to return the correct TCAP specification id for either ANSI or
 * ITU_T version of TCAP.
 */
static u8 get_spec(void)
{
  if (ITU_MODE())
    return(ITU_Q773);
  else
    return(ANSI_T114);
}

/*
 * Function to return the TCAP Extended Dialogue ID mode compatibility option (OPT_EXT_DID) status
 */
static u8 get_ext_did(void)
{
  if (EXT_DID_MODE())
    return(EXT_DID_ENABLED);
  return(0);
}

