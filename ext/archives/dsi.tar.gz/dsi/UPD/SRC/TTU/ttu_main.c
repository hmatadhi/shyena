/*
                   Copyright (C) Dialogic Corporation 1996-2006. All Rights Reserved.

 Name:          ttu_main.c

 Description:   Command line interface to ttu module.

 Functions:     main()

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   1     15-Dec-96  MH    - Initial code.
   2     20-Apr-98  SFP   - Options command line parameter added.
   3     29-Mar-00  JET   - ANSI mode option added
   4     02-Feb-06  TB    - Include Intel Corp in file header
   5     13-Dec-06  ML    - Change to use of Dialogic Corporation copyright.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"
#include "msg.h"
#include "ss7_inc.h"
#include "strtonum.h"

#ifdef LINT_ARGS
  void ttu_ent(u8 ttu_mod_id, u8 ttu_ssn, u16 options);
  static int read_cli_parameters(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *args);
#else
  void ttu_ent();
  static int read_cli_parameters();
  static void show_syntax();
  static int read_option();
#endif

#define CLI_EXIT_REQ            (-1)    /* Option requires immediate exit */
#define CLI_UNRECON_OPTION      (-2)    /* Unrecognised option */
#define CLI_RANGE_ERR           (-3)    /* Option value is out of range */

/*
 * Default values for TTU's command line options :
 */
#define DEFAULT_MODULE_ID       (0x0d)
#define DEFAULT_SSN             (0x66)
#define DEFAULT_OPTIONS         (0x0000)

static u8 ttu_mod_id;           /* The module id for TTU*/
static u8 ttu_ssn;              /* The sub-system number to be used by TTU */
static u16 ttu_options;         /* Options for TTU*/
static char *exe_name;          /* String holding program name */

/*
 * Main function for TTU
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

  ttu_mod_id = DEFAULT_MODULE_ID;
  ttu_ssn = DEFAULT_SSN;
  ttu_options = DEFAULT_OPTIONS;

  exe_name = argv[0];

  if ((cli_error = read_cli_parameters(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case CLI_UNRECON_OPTION :
        fprintf(stderr, "%s() : Unrecognised option : %s\n", exe_name,
                argv[failed_arg]);
        show_syntax();
        break;

      case CLI_RANGE_ERR :
        fprintf(stderr, "%s() : Parameter range error : %s\n", exe_name,
                argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }
    exit(0);
  }

  ttu_ent(ttu_mod_id, ttu_ssn, ttu_options);

  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr, "Syntax : ttu [-n<ttu_ssn> -m<ttu_id> -o<options>]\n");
  fprintf(stderr, "  -n  : ttu's local subsystem number (default=0x%x)\n",
	DEFAULT_SSN);
  fprintf(stderr, "  -m  : ttu's module ID (default=0x%02x)\n",
	DEFAULT_MODULE_ID);
  fprintf(stderr, "  -o  : options  (default=0x%04x)\n", DEFAULT_OPTIONS);
  fprintf(stderr, "Example: ttu -n0x90 -m0xef -o0x0001\n");
}

/*
 * Read in command line options a set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_cli_parameters(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;

  if (arg[0] != '-')
    return(CLI_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
    case 'v' :
      show_syntax();
      return(CLI_EXIT_REQ);

    case 'n' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ttu_ssn = (u8)temp_u32;
      break;

    case 'm' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ttu_mod_id = (u8)temp_u32;
      break;

    case 'o' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ttu_options = (u16)temp_u32;
      break;

    default :
      return(CLI_UNRECON_OPTION);
  }
  return(0);
}

