/*
    Copyright (C) 2014 Dialogic Inc. All rights reserved.

    Name:        CancelLocationRequestFactory.java

    Description: 
     
    Generates a Cancel Location Request for DTR.
 
    -----    ---------   -----      ------------------------------------
    Issue      Date       By         Changes
    -----    ---------   -----      ------------------------------------
             12-Nov-14    CJM       DTU file copied into DTR
 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.rfc3588.avps.DestinationHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationRealmAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.UserNameAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.ts29272.CancelLocationRequest;
import com.dialogic.signaling.diameter.ts29272.avps.CancellationTypeAvp;
import com.dialogic.signaling.diameter.ts29272.avps.CancellationTypeAvp.CancellationType;

import java.io.UnsupportedEncodingException;


public class CancelLocationRequestFactory {

    public static CancelLocationRequest BuildCancelLocationRequest(long imsi, String destHost, String destRealm) {

        CancelLocationRequest req;
        
        try {
            req = new CancelLocationRequest();
            req.setApplicationId(0x1000023);

            //req.addSessionIDAvp(new SessionIDAvp(Integer.toString(sessionID)));
            //req.addOriginHostAvp(new OriginHostAvp(origHost));
            //req.addOriginRealmAvp(new OriginRealmAvp(origRealm));

            req.addDestinationHostAvp(new DestinationHostAvp(destHost));
            req.addDestinationRealmAvp(new DestinationRealmAvp(destRealm));

            req.addUserNameAvp(new UserNameAvp(Long.toString(imsi)));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));
            req.addCancellationTypeAvp(new CancellationTypeAvp(CancellationType.MME_UPDATE_PROCEDURE));

        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
        return req;
    }
} //end CancelLocationRequestFactory class
