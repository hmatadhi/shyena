/*
 Copyright (C) 2014 Dialogic Inc. All rights reserved.

 Name:        DmrSessionIndEventListner.java

 Description:     

 Event Listner defining a DMR SESSION IND message.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   -      06-Nov-14   Copied from DTU

 */

package com.dialogic.signaling.dmr.dtr;

public interface DmrSessionIndEventListner {
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt);
}
