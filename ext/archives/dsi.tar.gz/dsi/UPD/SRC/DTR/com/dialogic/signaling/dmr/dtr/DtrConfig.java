/*
     Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

     Name:        DtrConfig.java

     Description:  
     Command line option handling for DTR. 
 
     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      26-Mar-12   Initial version
       2      13-Feb-14   Trace off mode
              12-Nov-14   Add Hss mode
              24-Feb-15   DTR now uses Code Issue class
 */

package com.dialogic.signaling.dmr.dtr;

public class DtrConfig {

    public short SrcMID = 0x2d;
    public short DstMID = 0x74;
    public int LossRate = 0;
    public int DelayRate = 0;
    public Boolean TraceOn = true;
    public Boolean LoopBack = false;
    public Boolean Quit = false;
    public Boolean HssMode = false;

    // Define range of allocated outgoing session IDs (for send CLR)(currently not configurable)
    public final int baseSessionID   = 0;
    public final int numberSessionID = 1024;
    
    private static String SrcMIDOption = "-m";
    private static String DstMIDOption = "-dmr";
    private static String LossRateOption = "-loss";
    private static String TraceOffOption = "-traceoff";
    private static String LoopBackOption = "-loop";
    private static String DelayRateOption = "-delay";
    private static String HssOption       = "-hss";

    public DtrConfig(String[] args) throws CommandLineException {
        Short tempShort;
        Integer tempInt;

        System.out.println("DSI DTR Diameter Test Responder Release " + DtrIssue.DtrCodeIssue);
        System.out.println("Part of the Dialogic(R) DSI Development Package");
        System.out.println("Copyright (C) 2012-2015 Dialogic Inc. All Rights Reserved.");
        System.out.println("");

        for (String s : args) {
            tempShort = parseModIdOption(s, SrcMIDOption);
            if (tempShort != null) {
                SrcMID = tempShort;
                continue;
            }

            tempShort = parseModIdOption(s, DstMIDOption);
            if (tempShort != null) {
                DstMID = tempShort;
                continue;
            }

            tempInt = parseUnsignedIntOption(s, LossRateOption);
            if (tempInt != null) {
                LossRate = tempInt;
                continue;
            }

            tempInt = parseUnsignedIntOption(s, DelayRateOption);
            if (tempInt != null) {
                DelayRate = tempInt;
                continue;
            }

            if (s.startsWith(TraceOffOption)) {
                TraceOn = false;
                continue;
            }
            
            if (s.startsWith(LoopBackOption)) {
                LoopBack = true;
                continue;
            }            

            if (s.startsWith(HssOption)) {
                HssMode = true;
                continue;
            }            

            if ((s.startsWith("-h")) || (s.startsWith("-?"))) {
                showHelp();
                throw new CommandLineException("");
            }
        }
        
        System.out.println("DTR module id: 0x" + String.format("%02x", SrcMID));
        System.out.println("DMR module id: 0x" + String.format("%02x", DstMID));

        if (LossRate != 0) {
            System.out.println("Loss Rate: (1 in " + LossRate + ")");
        }

        if (DelayRate != 0) {
            System.out.println("Delay Rate: (1 in " + DelayRate + ")");
        }

        if (HssMode != false) {
            System.out.println("Hss Mode enabled");
        }

        if (TraceOn == false) {
            System.out.println("Trace: Off");
        }
    }

    private void showHelp() {
        System.out.println("Syntax: dtr.jar [-m<> -dmr<> -lossrate<> -traceoff]");
        System.out.println("        DTR Receive Diameter Session Requests and Answers them");
        System.out.println("        ");
        System.out.println("Example:  java -jar dtr.jar -m0x2d");
        System.out.println();
        System.out.println("Options: " + SrcMIDOption + "[] DTR Module Id ");
        System.out.println("        Sets the module id for DTR");
        System.out.println();
        System.out.println("        " + DstMIDOption + "[] DMR Module Id ");
        System.out.println("        Sets the module id for the Diameter Module (DMR)");
        System.out.println();
        System.out.println("        " + LossRateOption + "[] Loss Rate ");
        System.out.println("        If set, the module will not respond to one in every");
        System.out.println("        <lossRate> messages");
        System.out.println();
        System.out.println("        " + DelayRateOption + "[] Delay Rate ");
        System.out.println("        If set, the module will insert a 10 msec delay");
        System.out.println("        every 1 in n ULR received.");
        System.out.println();
        System.out.println("        " + HssOption );
        System.out.println("        If set, the module monitors received ULRs,");
        System.out.println("        and if a IMSI from a previous ULR is received");
        System.out.println("        from a different origin host, a CLR is sent to");
        System.out.println("        the original origin host.");
        System.out.println();
        System.out.println("        " + TraceOffOption + " Turn Trace Off");
    }

    private Short parseModIdOption(String arg, String opt) throws CommandLineException {

        Short shortVal = null;

        if (arg.startsWith(opt)) {
            try {
                shortVal = Short.decode(arg.substring(opt.length())).shortValue();

                if ((shortVal <= 0) || (shortVal > 0xff)) {
                    // Not a valid mod id
                    throw new CommandLineException("Invalid value for module ids in option: " + opt);
                }

            } catch (CommandLineException cliEx) {
                throw cliEx;
            } catch (NumberFormatException ex) {
                throw new CommandLineException("Invalid data format for option: " + opt, ex);
            } catch (Exception ex) {
                throw new CommandLineException("Invalid data for option: " + opt + "," + ex.toString(), ex);
            }
        }
        return shortVal;
    }

    private Integer parseUnsignedIntOption(String arg, String opt) throws CommandLineException {

        Integer intVal = null;

        if (arg.startsWith(opt)) {
            try {
                intVal = Integer.decode(arg.substring(opt.length())).intValue();

                if (intVal < 0) {
                    // Don't want negative values
                    throw new CommandLineException("Invalid negative value in option: " + opt);
                }

            } catch (CommandLineException cliEx) {
                throw cliEx;
            } catch (NumberFormatException ex) {
                throw new CommandLineException("Invalid data format for option: " + opt, ex);
            } catch (Exception ex) {
                throw new CommandLineException("Invalid data for option: " + opt + "," + ex.toString(), ex);
            }
        }
        return intVal;
    }
}

class CommandLineException extends Exception {

    public CommandLineException(String message) {
        super(message);
    }

    public CommandLineException(String message, Exception ex) {
        super(message, ex);
    }
}
