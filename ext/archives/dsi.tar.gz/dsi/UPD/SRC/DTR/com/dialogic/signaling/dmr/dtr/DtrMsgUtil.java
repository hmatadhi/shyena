/*
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        DtrMsgUtil.java

     Description:    
     Utility Class for GCT Message Printing.
 
     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      28-Sep-12   Initial version
              06-Nov-14   Minor update
 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.gct.BBUtil;
import com.dialogic.signaling.gct.GctMsg;
import java.nio.ByteBuffer;

/**
 *
 * class DtrMsgUtil - defines traceMsg()
 */
public class DtrMsgUtil {

    static void traceMsg(String prefix, GctMsg gctmsg) {
        try {
            System.out.print(prefix
                    + "M-t" + String.format("%04x", gctmsg.getType())
                    + "-i" + String.format("%04x", gctmsg.getId())
                    + "-f" + String.format("%02x", gctmsg.getSrc())
                    + "-d" + String.format("%02x", gctmsg.getDst())
                    + "-s" + String.format("%02x", gctmsg.getStatus()));

            ByteBuffer buf = gctmsg.getParam();
            
            if (buf.hasRemaining()) {
                System.out.print("-p");

                while (buf.hasRemaining()) {
                    System.out.print(String.format("%02x", BBUtil.getU8(buf)));
                }
            }

            System.out.print("\n");

        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }
}
