/*
     
     Copyright (C) 2012 Dialogic Inc. All rights reserved.

     Name:        MEIdentityCheckAnswerFactory.java

     Description: 
     Builds an ECA Response.     

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      11-Feb-13   - Initial version


 */
package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.ResultCode;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.ResultCodeAvp;
import com.dialogic.signaling.diameter.ts29272.MEIdentityCheckAnswer;
import com.dialogic.signaling.dmr.user.DmrSessionInd;

public class MEIdentityCheckAnswerFactory {

    public static MEIdentityCheckAnswer BuildMEIdentityCheckAnswer(DtrConfig config, DmrSessionInd sessionInd) {

            MEIdentityCheckAnswer req = new MEIdentityCheckAnswer();

            // No need to add the sessionIDAvp manually, using the correct session identifier
            // will add it for you.
            //ula.addSessionIDAvp(new SessionIDAvp("0"));        

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));

            req.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            return req;
    }
}
