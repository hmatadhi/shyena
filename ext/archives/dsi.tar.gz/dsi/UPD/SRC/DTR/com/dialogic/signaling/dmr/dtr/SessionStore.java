/*
 Copyright (C) 2014 Dialogic Inc. All rights reserved.

 Name:        SessionStore.java

 Description:     

 Container for Session objects.
 Allows sessions to be created, found and removed.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   -      04-Nov-14   DTU code changed to add and remove from store
 */

package com.dialogic.signaling.dmr.dtr;

import java.util.ArrayList;


/**
 * class SessionStore
 */
public class SessionStore {

    static private ArrayList<Session> dmrSessions = new ArrayList<Session>();
    private SessionId  sessionIds;
    private DtrConfig  config;

    SessionStore(DtrConfig config) {
        // constructor
        sessionIds = new SessionId(config);  // local class
        this.config  = config;
    }

    @Override
    public String toString() {
        return ("SessionStore");
    }
    
    public int add(long imsi, int sessionID, int nc) throws AllSessionsActiveException {
        // allocates a new session id, create a new session, then adds it to the session store
        // returns new session id or -1
        int ret = -1;
        try {
            // Loop allocating ids until non-active (not stored) one found
            for (int i=0; i<sessionIds.size(); i++) {
                // get next session id
                int id = sessionIds.next();
                // If session id not already in store, create session and add it to store
                if (find(id) < 0) {
                    dmrSessions.add(new Session(id, imsi, nc, sessionID));
                    ret = id;
                    break;
                }
            }//end for
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        if (ret < 0)
            throw new AllSessionsActiveException("New session ID cannot be allocated since all sessions are in use.");
        return(ret);
    }

    public boolean remove(int id) throws SessionNotIdleException {
        // remove session from store
        boolean ret = false;
        int index = find(id);
        // If session id is in the store and has Idle state, remove it
        if (index >= 0) {
            if (dmrSessions.get(index).getState() != Session.State.IDLE)
                throw new SessionNotIdleException("Session could not be removed since not in IDLE state.");
            dmrSessions.remove(index);
            ret = true;
        }
        return(ret);
    }

    public Session get(int id) {
        int index = find(id);
        // If session id is in the store, return session
        if (index >= 0)
            return(dmrSessions.get(index));
        return(null);
    }

    public int numSessions() {
        // Return number of sessions in store
        return(dmrSessions.size());
    }

    private int find(int id) {
        // local function to search for a session id in the store
        for (int i=0; i<dmrSessions.size(); i++) {
            if (dmrSessions.get(i).getSessionId() == id)
                return(i);
        }
        return(-1);
    }


    // Wholly contained class to allocate new session ids
    // Session Ids are allocated from a fixed range.
    // This class has no knowledge of whether the session id are active or not.
    private class SessionId {
        private int minSid;
        private int maxSid;
        private int nextSid;
        
        SessionId(DtrConfig config) {
            // constructor
            minSid = config.baseSessionID;
            maxSid = config.baseSessionID + config.numberSessionID - 1;
            nextSid = minSid;
        }
        public int next() {
            // allocate next session id
            int id = nextSid;
            nextSid++;
            // when maximum id used, loop back to start
            if (nextSid > maxSid)
                nextSid = minSid;
            return(id);
        }
        public int size() {
            // returns maximum number of sessions available
            return(config.numberSessionID);
        }
    } //end SessionId class

} //end SessionStore class


// exception classes

class AllSessionsActiveException extends Exception {
    public AllSessionsActiveException(String message) {
        super(message);
    }
}

class SessionNotIdleException extends Exception {
    public SessionNotIdleException(String message) {
        super(message);
    }
}
