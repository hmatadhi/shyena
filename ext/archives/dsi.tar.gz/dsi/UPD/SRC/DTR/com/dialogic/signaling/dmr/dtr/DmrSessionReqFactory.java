/*
     
 Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

 Name:        DmrSessionReqFactory.java

 Description: 
 Generates Session Close Requests for DTR answers
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1      26-Mar-12   Initial version
 2      11-Sep-12   Updates to primitive types.
 3      19-Sep-13   Add Rx support
        04-Nov-14   Add build CLR
                    Add alternative ULA build
 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.DiameterCommand;
import com.dialogic.signaling.dmr.DmrContext;
import com.dialogic.signaling.dmr.user.DmrSessionInd;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;

public class DmrSessionReqFactory {

    // Build ULA
    public static DmrSessionReq BuildULASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = UpdateLocationAnswerFactory.BuildUpdateLocationAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }

    // Alternative build ULA
    public static DmrSessionReq BuildULASessionReq(int sessionID, int nc) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = nc;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = UpdateLocationAnswerFactory.BuildUpdateLocationAnswer();
        sessionCloseReq.sessionId = sessionID;

        return sessionCloseReq;
    }

    // Build AIA
    public static DmrSessionReq BuildAIASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = AuthenticationInformationAnswerFactory.BuildAuthenticationInformationAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build PUA
    public static DmrSessionReq BuildPUASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = PurgeUEAnswerFactory.BuildPurgeUEAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build NOA
    public static DmrSessionReq BuildNOASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = NotifyAnswerFactory.BuildNotifyAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build RSA
    public static DmrSessionReq BuildRSASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = ResetAnswerFactory.BuildResetAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }

    // Build CLR OPEN request
    public static DmrSessionReq BuildCLRSessionReq(int sessionID, int nc, PrimitiveType prim, DiameterCommand cmd) {
        DmrSessionReq sessionOpenReq = new DmrSessionReq();
        sessionOpenReq.networkContext = nc;
        sessionOpenReq.primitiveType = prim;
        sessionOpenReq.sessionId = sessionID;
        sessionOpenReq.diameterCommand = cmd;

        return sessionOpenReq;
    }    

    // Build CLA CLOSE
    public static DmrSessionReq BuildCLASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = CancelLocationAnswerFactory.BuildCancelLocationAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build DSA
    public static DmrSessionReq BuildDSASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = DeleteSubscriberDataAnswerFactory.BuildDeleteSubscriberDataAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build IDA
    public static DmrSessionReq BuildIDASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = InsertSubscriberDataAnswerFactory.BuildInsertSubscriberDataAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build ECA
    public static DmrSessionReq BuildECASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = MEIdentityCheckAnswerFactory.BuildMEIdentityCheckAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }

    // Build AAA
    public static DmrSessionReq BuildAAASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = AAAnswerFactory.BuildAAAnswer(dtrConfig, receivedSessionInd);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
    // Build CCA
    public static DmrSessionReq BuildCCASessionReq(DmrContext dmrContext, DtrConfig dtrConfig, DmrSessionInd receivedSessionInd, PrimitiveType prim) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = prim;
        sessionCloseReq.diameterCommand = CreditControlAnswerFactory.BuildCreditControlAnswer(dtrConfig, receivedSessionInd, prim);
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }

}
