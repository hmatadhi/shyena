/*
     Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

     Name:        Dtr.java

     Description: 
     
     Main Class for DTR Test Application.
     A command line application for responding to various Diameter Requests.

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      26-Mar-12   - Initial version
       2      09-Oct-12   - Trial Release version        
       -      04-Nov-14   - Added code version
              24-Feb-15   - Code version removed, DTR now uses Code Issue class
 */

package com.dialogic.signaling.dmr.dtr;

/**
 *
 * 
 */
public class Dtr {

    /**
     * Diameter Test Responder DTR
     * Processes the command line arguments then starts a loop to process received GCT messages.
     */
    public static void main(String[] args) {

        DtrConfig config;

        try {
            config = new DtrConfig(args);
        } catch (CommandLineException cliEx) {
            System.out.println(cliEx.getMessage() + "\n");
            return;
        }

        ReqRxer rxer = new ReqRxer(config);

        try {
            int msgCount = 0;
            while (true) {
                rxer.RxRequest();
                msgCount++;
                if ((config.DelayRate != 0)
                        && (msgCount % config.DelayRate == 0)) {
                    Thread.sleep(10);
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }
}
