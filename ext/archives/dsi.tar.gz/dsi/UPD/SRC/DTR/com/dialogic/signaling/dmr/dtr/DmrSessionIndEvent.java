/*
 Copyright (C) 2014 Dialogic Inc. All rights reserved.

 Name:        DmrSessionIndEvent.java

 Description:     

 Event defining a DMR SESSION IND message.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   -      06-Nov-14   Copied from DTU

 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.dmr.user.DmrSessionInd;

public class DmrSessionIndEvent extends java.util.EventObject {
    
    DmrSessionInd ind;

    public DmrSessionInd getInd() {
        return ind;
    }

    public void setInd(DmrSessionInd ind) {
        this.ind = ind;
    }
    
    public DmrSessionIndEvent(Object obj) {
        super(obj);
        ind = null;
    }      

    public DmrSessionIndEvent(Object obj, DmrSessionInd sessionInd) {
        super(obj);        
        ind = sessionInd;        
    }     
}
