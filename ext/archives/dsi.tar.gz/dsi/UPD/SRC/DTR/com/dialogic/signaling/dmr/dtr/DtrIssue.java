/*
 Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

 Name:        DtrIssue.java

 Description: DTR Source Code Issue and History
     
 Class that defines the current issue of the DTR code.
 Also documents changes made for the latest issue and all previous issues.
  
---------   ------------------------------------
  Date       Changes
---------   ------------------------------------

            - Trial Release Version
18-Oct-12   *** DTR Version 1.00 Release ****

            - Added support for Ro Interface example
            - Now supports ULA and CCA responses.
14-Nov-12   *** DTR Version 1.01 Release ****

            - Minor updates
06-Feb-13   *** DTR Version 1.02 Release ****

            - Added support for Rx interface example
27-Sep-13   *** DTR Version 1.03 Release ****

            - Added support for additional ULR command answers to:
               + AIR, PUR, NOR, RSR, CLR, IDR, DSR, ECR
13-Feb-14   *** DTR Version 1.04 Release ****

            - Added -hss mode to monitor origination of ULRs,
              when origin has changed sends CLR to previous MME host.
            - Dtr Code Issue moved to this java file,
              dtr_iss.txt file is now obsolete
24-Feb-15   *** DTR Version 1.05 Release ****

*/

package com.dialogic.signaling.dmr.dtr;

public final class DtrIssue {

    // Define latest DTR code issue in a string
    public static final String DtrCodeIssue = "1.05";

}
