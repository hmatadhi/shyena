/*
     
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        UpdateLocationAnswerFactory.java

     Description: 
     Builds an ULA response

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      26-Mar-12   - Initial version
       2      09-Oct-12   - Trial Release version
       -      04-Nov-14   - Added alternate ULA builder
 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.ResultCode;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.ResultCodeAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.VendorIDAvp;
import com.dialogic.signaling.diameter.ts29212.avps.AllocationRetentionPriorityAvp;
import com.dialogic.signaling.diameter.ts29212.avps.PriorityLevelAvp;
import com.dialogic.signaling.diameter.ts29212.avps.QoSInformationAvp;
import com.dialogic.signaling.diameter.ts29229.avps.FeatureListAvp;
import com.dialogic.signaling.diameter.ts29229.avps.FeatureListIDAvp;
import com.dialogic.signaling.diameter.ts29229.avps.SupportedFeaturesAvp;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationAnswer;
import com.dialogic.signaling.diameter.ts29272.avps.AccessRestrictionDataAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ApnConfigurationAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ApnConfigurationProfileAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ApnOIReplacementAvp;
import com.dialogic.signaling.diameter.ts29272.avps.EpsSubscribedQosProfileAvp;
import com.dialogic.signaling.diameter.ts29272.avps.GmlcNumberAvp;
import com.dialogic.signaling.diameter.ts29272.avps.HplmnOdbAvp;
import com.dialogic.signaling.diameter.ts29272.avps.IcsIndicatorAvp;
import com.dialogic.signaling.diameter.ts29272.avps.IcsIndicatorAvp.IcsIndicator;
import com.dialogic.signaling.diameter.ts29272.avps.LcsInfoAvp;
import com.dialogic.signaling.diameter.ts29272.avps.SubscriptionDataAvp;
import com.dialogic.signaling.diameter.ts29272.avps.UlaFlagsAvp;
import com.dialogic.signaling.dmr.user.DmrSessionInd;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class UpdateLocationAnswerFactory {

    // ULA flags - bit masks
    public static final long ULA_FLAG_SEPARATION_IND  = 1;         // When set, HSS stores SGSN number and MME number in separate memory, i.e. Rel-8 HSS (Bit 0)
    public static final long ULA_FLAG_MME_REG_FOR_SMS = (1 << 1);  // When set, indicates that the HSS has registered the MME for SMS (Bit 1)


    // Builds ULA response immediately after receiving the ULR
    public static UpdateLocationAnswer BuildUpdateLocationAnswer(DtrConfig config, DmrSessionInd sessionInd) {

        try {
            UpdateLocationAnswer req = new UpdateLocationAnswer();

            //req.addSessionIDAvp(new SessionIDAvp("0"));        
	    //req.addOriginHostAvp(new OriginHostAvp("node1.mms.dialogic.com"));
            //req.addOriginRealmAvp(new OriginRealmAvp("mms.dialogic.com"));

            //Note: Destinations and User Name are not part of ULA

            req.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            // Subscriber Data
            SubscriptionDataAvp sda = new SubscriptionDataAvp();
            sda.addAccessRestrictionDataAvp(new AccessRestrictionDataAvp((long) 0x55555));
            sda.addApnOIReplacementAvp(new ApnOIReplacementAvp("SubscriptionData.ApnOIReplacement"));
            sda.addHplmnOdbAvp(new HplmnOdbAvp((long) 7733623));
            sda.addIcsIndicatorAvp(new IcsIndicatorAvp(IcsIndicator.TRUE));

            ApnConfigurationProfileAvp acpa = new ApnConfigurationProfileAvp();
            sda.addApnConfigurationProfileAvp(acpa);
            ApnConfigurationAvp aca = new ApnConfigurationAvp();
            acpa.addApnConfigurationAvp(aca);
            EpsSubscribedQosProfileAvp esqpa = new EpsSubscribedQosProfileAvp();
            aca.addEpsSubscribedQosProfileAvp(esqpa);
            AllocationRetentionPriorityAvp arpa = new AllocationRetentionPriorityAvp();
            esqpa.addAllocationRetentionPriorityAvp(arpa);
            PriorityLevelAvp pla = new PriorityLevelAvp(1L);
            arpa.addPriorityLevelAvp(pla);

            LcsInfoAvp lcsia = new LcsInfoAvp();
            lcsia.addGmlcNumberAvp(new GmlcNumberAvp(ByteBuffer.wrap(new byte[]{(byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5})));
            sda.addLcsInfoAvp(lcsia);
            
            req.addSubscriptionDataAvp(sda);
            //End of subcriber data
            
            SupportedFeaturesAvp sfa = new SupportedFeaturesAvp();
            sfa.addFeatureListAvp(new FeatureListAvp((long) 834756));
            sfa.addFeatureListIDAvp(new FeatureListIDAvp((long) 65432));
            sfa.addVendorIDAvp(new VendorIDAvp((long) 10432));
            req.addSupportedFeaturesAvp(sfa);

            req.addUlaFlagsAvp(new UlaFlagsAvp((long) 6532));

            return req;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }

    // Builds simplified ULA response
    public static UpdateLocationAnswer BuildUpdateLocationAnswer() {

        try {
            UpdateLocationAnswer req = new UpdateLocationAnswer();

            //req.addSessionIDAvp(new SessionIDAvp(Integer.toString(sessionID)));
            //req.addOriginHostAvp(new OriginHostAvp(originHost));
            //req.addOriginRealmAvp(new OriginRealmAvp(originRealm));
			
            req.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));
            req.addUlaFlagsAvp(new UlaFlagsAvp(ULA_FLAG_SEPARATION_IND));

            return req;
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
    }
}
