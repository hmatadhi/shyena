/*

 Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

 Name:        ReqRxer.java

 Description: 
 Respond to individual Diameter requests and sends appropriate answers.

 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   1      26-Mar-12   - Initial version
   2      28-Sep-12   - Updates to match API changes
                      - Trace off mode
   3      19-Sep-13   - Add Rx support
          04-Nov-14   - Add Hss mode
          17-Dec-14   - Moved CLA processing to CLOSE

 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.DiameterCommand;

import com.dialogic.signaling.diameter.IAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyInfoAvp;
import com.dialogic.signaling.diameter.rfc4006.CreditControlAnswer;
import com.dialogic.signaling.diameter.rfc4006.CreditControlRequest;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationAnswer;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationRequest;
import com.dialogic.signaling.diameter.ts29211.AARequest;
import com.dialogic.signaling.diameter.ts29211.AAAnswer;
import com.dialogic.signaling.diameter.ts29209.avps.MediaComponentDescriptionAvp;
import com.dialogic.signaling.diameter.ts29209.avps.MediaSubComponentAvp;
import com.dialogic.signaling.diameter.ts29272.AuthenticationInformationAnswer;
import com.dialogic.signaling.diameter.ts29272.AuthenticationInformationRequest;
import com.dialogic.signaling.diameter.ts29272.PurgeUEAnswer;
import com.dialogic.signaling.diameter.ts29272.PurgeUERequest;
import com.dialogic.signaling.diameter.ts29272.NotifyAnswer;
import com.dialogic.signaling.diameter.ts29272.NotifyRequest;
import com.dialogic.signaling.diameter.ts29272.DeleteSubscriberDataAnswer;
import com.dialogic.signaling.diameter.ts29272.DeleteSubscriberDataRequest;
import com.dialogic.signaling.diameter.ts29272.InsertSubscriberDataAnswer;
import com.dialogic.signaling.diameter.ts29272.InsertSubscriberDataRequest;
import com.dialogic.signaling.diameter.ts29272.ResetAnswer;
import com.dialogic.signaling.diameter.ts29272.ResetRequest;
import com.dialogic.signaling.diameter.ts29272.MEIdentityCheckAnswer;
import com.dialogic.signaling.diameter.ts29272.MEIdentityCheckRequest;
import com.dialogic.signaling.diameter.ts29272.CancelLocationAnswer;
import com.dialogic.signaling.diameter.ts29272.CancelLocationRequest;

import com.dialogic.signaling.dmr.DmrContext;
import com.dialogic.signaling.dmr.user.DmrSessionInd;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import com.dialogic.signaling.encoder.EncoderException;
import com.dialogic.signaling.encoder.MsgEncoder;
import com.dialogic.signaling.gct.GctException;
import com.dialogic.signaling.gct.GctLib;
import com.dialogic.signaling.gct.GctMsg;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ListIterator;


public class ReqRxer {

    MsgEncoder DsrMS;
    DtrConfig Config;
    DmrContext dmrContext;
    long indicationCount = 0;
    static MmeStore mmeStore;
    static SessionStore sessionStore;

    public ReqRxer(DtrConfig config) {
        Config = config;

        try {
            dmrContext = new DmrContext();
            dmrContext.registerDiameterCommand(UpdateLocationRequest.class);
            dmrContext.registerDiameterCommand(UpdateLocationAnswer.class);
            dmrContext.registerDiameterCommand(AuthenticationInformationRequest.class);
            dmrContext.registerDiameterCommand(AuthenticationInformationAnswer.class);
            dmrContext.registerDiameterCommand(CreditControlRequest.class);
            dmrContext.registerDiameterCommand(CreditControlAnswer.class);
            dmrContext.registerDiameterCommand(AARequest.class);
            dmrContext.registerDiameterCommand(AAAnswer.class);
            dmrContext.registerDiameterCommand(PurgeUERequest.class);
            dmrContext.registerDiameterCommand(PurgeUEAnswer.class);
            dmrContext.registerDiameterCommand(NotifyRequest.class);            
            dmrContext.registerDiameterCommand(NotifyAnswer.class);
            dmrContext.registerDiameterCommand(CancelLocationRequest.class);
            dmrContext.registerDiameterCommand(CancelLocationAnswer.class);
            dmrContext.registerDiameterCommand(DeleteSubscriberDataRequest.class);
            dmrContext.registerDiameterCommand(DeleteSubscriberDataAnswer.class);
            dmrContext.registerDiameterCommand(InsertSubscriberDataRequest.class);
            dmrContext.registerDiameterCommand(InsertSubscriberDataAnswer.class);
            dmrContext.registerDiameterCommand(ResetRequest.class);
            dmrContext.registerDiameterCommand(ResetAnswer.class);
            dmrContext.registerDiameterCommand(MEIdentityCheckRequest.class);
            dmrContext.registerDiameterCommand(MEIdentityCheckAnswer.class);

            //Set the message source and dest module ids here.            
            dmrContext.setDmrTaskId((short)config.DstMID);
            dmrContext.setSrcTaskId((short)config.SrcMID);

            //Create a session store and a MME store
            sessionStore = new SessionStore(config);
            mmeStore = new MmeStore();

        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }

    public void RxRequest() throws IOException {
        GctMsg rxedMsg = GctLib.receive(Config.SrcMID);

        try {
            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR<<", rxedMsg);
            }

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (rxedMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                rxedMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback               

            if (rxedMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue()) {
                // For test purposes only, drop 1 in lossRate
                if (isToBeProcessed(indicationCount, Config.LossRate)) {
                    
                    ProcessSessionInd(rxedMsg);
                    
                } else {
                    // For test purposes only, drop this one
                    if (Config.TraceOn) {
                        System.out.println("Indication dropped, indications received: " + indicationCount);
                    }
                }
                indicationCount++;
            } else {
                System.out.println("Unexpected Message");
            }

        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } finally {
            try {
                GctLib.relm(rxedMsg);
            } catch (GctException gctEx) {
                System.out.println("Problem with message releasing: " + gctEx.getMessage());
            }
        }
    }

    public void ProcessSessionInd(GctMsg gctmsg) throws GctException, EncoderException {

        DmrSessionInd decodedInd = dmrContext.userApi.dmrSessionIndEncoder.decode(gctmsg);

        switch (decodedInd.primitiveType) {

            case OPEN:
                switch(decodedInd.diameterCommand.getCommandCode()) {
                    case (UpdateLocationRequest.StandardCommandCode):
                        processULR(decodedInd); break;
                    case (AuthenticationInformationRequest.StandardCommandCode):
                        processAIR(decodedInd); break;
                    case (CreditControlRequest.StandardCommandCode):
                        processCCR(decodedInd); break;
                    case (AARequest.StandardCommandCode):
                        processAAR(decodedInd); break;
                    case (PurgeUERequest.StandardCommandCode):
                        processPUR(decodedInd); break;
                    case (NotifyRequest.StandardCommandCode):
                        processNOR(decodedInd); break;
                    case (ResetRequest.StandardCommandCode):
                        processRSR(decodedInd); break;
                    case (CancelLocationRequest.StandardCommandCode):
                        if (decodedInd.diameterCommand.isRequest())
                            processCLR(decodedInd);
                        else
                            System.out.println("Unexpected CLA answer (OPEN)");
                        break;
                    case (InsertSubscriberDataRequest.StandardCommandCode):
                        processIDR(decodedInd); break;
                    case (DeleteSubscriberDataRequest.StandardCommandCode):
                        processDSR(decodedInd); break;
                    case (MEIdentityCheckRequest.StandardCommandCode):
                        processECR(decodedInd); break;
                    default:
                        System.out.println("Unexpected Command Code (OPEN)"); break;
                }
                break;

            case CONTINUE:
                switch(decodedInd.diameterCommand.getCommandCode()) {
                    case (CreditControlRequest.StandardCommandCode):
                        processCCR(decodedInd); break;
                    default:
                        System.out.println("Unexpected Command Code (CONTINUE)");
                        break;
                }
                break;
            case CLOSE:
               switch(decodedInd.diameterCommand.getCommandCode()) {
                    case (CancelLocationRequest.StandardCommandCode):
                        if (decodedInd.diameterCommand.isRequest() == false)
                            processCLA(decodedInd);
                        else
                            System.out.println("Unexpected CLR request (CLOSE)");
                        break;
                    default:
                        System.out.println("Unexpected Command Code (CLOSE)");
                        break;
                }
                break;
            case P_ABORT:
            case NOTIFY:
            case ABORT:
            case TERMINATE:
            case RE_AUTH:
            default:
                System.out.println("Unexpected Prim Type (" + decodedInd.primitiveType + ")");
                break;
        }
    }

    private Boolean isToBeProcessed(long count, long lossRate) {

        if ((count == 0) || (lossRate == 0)) {
            return (true);
        } else if ((count % Config.LossRate == 0)) {
            return (false);
        }
        return (true);
    }

    /** 
     * Process received ULR
     * If DTR configured for HSS mode and a previous ULR was received for this IMSI,
     * a CLR may be sent to the previous origin.
     * The code then expects a CLA to be received.
     */
    private void processULR(DmrSessionInd ind) {

        UpdateLocationRequest ulr = (UpdateLocationRequest) ind.diameterCommand;
        String originHost  = "";    // rxd origin host (for Hss mode)
        String originRealm = "";    // rxd origin realm (for Hss mode)
        String destHost  = "";      // rxd destination host
        String destRealm = "";      // rxd destination realm
        String userName = "";       // rxd user name (imsi) (for Hss mode)
        Boolean clrSent = false;    // flag whether a CLR was sent

        try {
            // read some AVPs
            if (ulr.getOriginHostAvp() != null)
                originHost = ulr.getOriginHostAvp().getString();
            if (ulr.getOriginRealmAvp() != null)
                originRealm = ulr.getOriginRealmAvp().getString();
            if (ulr.getDestinationHostAvp() != null)
                destHost = ulr.getDestinationHostAvp().getString();
            if (ulr.getDestinationRealmAvp() != null)
                destRealm = ulr.getDestinationRealmAvp().getString();
            if (ulr.getUserNameAvp() != null)
                userName = ulr.getUserNameAvp().getString();

            if (Config.TraceOn) {
                //Display it first
                System.out.println("Command code matches (ULR)");
                System.out.println("Origin Host:" + originHost);
                System.out.println("Origin Realm:" + originRealm);
                System.out.println("Dest Host:" + destHost);
                System.out.println("Dest Realm:" + destRealm);
                if (Config.HssMode)
                    // For HSS mode just show IMSI
                    System.out.println("User Name (IMSI):" + userName);
                else {
                    // Show Proxy Info AVPs
                    ListIterator<IAvp> li = ulr.listIterator();
                    while (li.hasNext()) {
                        ProxyInfoAvp pia = ulr.getProxyInfoAvp(li);

                        if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                            System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                        }
                    }
                    // Show Unknown AVPs
                    li = ulr.listIterator();
                    while (li.hasNext()) {
                        IAvp ua = ulr.getUnknownAvp(li);

                        if (ua != null) {
                            System.out.println("Unknown Avp:" + ua.getCode());
                        }
                    }
                }
            }
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Failed to recover AVP" + ex.toString());
        }

        try {
            // If Hss mode, check for CLR send required
            if (Config.HssMode)        
                clrSent = sendClr(userName, originHost, originRealm, ind);

            if (clrSent == false) {
                // If CLR was not sent, send ULA now (no need to create a new session for this)
                DmrSessionReq dmrSsnReq;
                
                // How the ULA is built depends on whether HSS mode is enabled
                if (Config.HssMode)
                    dmrSsnReq = DmrSessionReqFactory.BuildULASessionReq(ind.sessionId, ind.networkContext);
                else
                    dmrSsnReq = DmrSessionReqFactory.BuildULASessionReq(dmrContext, Config, ind);

                int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
                GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
                dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

                // Code to allow loopback testing on one box.
                if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                    gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
                }
                // End of loopback

                // Display ULA sent
                if (Config.HssMode)        
                    System.out.println("HSS mode: MME is unknown or same for this IMSI (no CLR required), sending ULA");

                if (Config.TraceOn) {
                    DtrMsgUtil.traceMsg("DTR>>", gctMsg);
                }
                GctLib.send((short) Config.DstMID, gctMsg);
            }
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode" + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }

    /**
     * Function to attempt to send a CLR message to the original MME
     *     The IMSI from the received ULR is searched for in the MME store,
     *     if found and the origin is different, a CLR is sent to the previous origin
     *     The CLRs origination AVPs are taken from the ULRs destination AVPs
     *     Note: that DTR does not check that received destination AVPs match
     *     a particular host (or that only one destination host is being addressed).
     */
    private Boolean sendClr(String userName, String originHost, String originRealm, DmrSessionInd ind) {
        Boolean sent = false;
        
        try {
            // the ULR originHost and userName (IMSI) must be defined (this should always be the case).
            if (originHost.isEmpty() || userName.isEmpty()) {
                System.out.println("HSS mode: Required AVPs are missing from received ULR, IMSI not checked for previous MME");
                return false;
            }

            // convert the User Name to a IMSI number
            long imsi = Long.parseLong(userName);

            // Look for the IMSI in the MME store (of previous ULRs)
            String curOriginHost = mmeStore.getMmeHost(imsi);
            
            if (curOriginHost.isEmpty()) {
                // if imsi is not in MME store, add it now
                mmeStore.storeMme(imsi, originHost, originRealm);
                return false;
            }
            if (originHost.equals(curOriginHost)) {
                // if the current and previous origin hosts are the same,
                // there is no need to send CLR
                // update the MME store record now (just in case the realm is different)
                mmeStore.storeMme(imsi, originHost, originRealm);
                return false;
            }

            // the origin has changed for this imsi, so send a CLR

            // retrieve previous origin realm
            String curOriginRealm = mmeStore.getMmeRealm(imsi);
                        
            // create a new session to send CLR/wait for CLA
            //   - store ULR sessionID and NC, so that the ULA can eventually be sent
            int sessionID = sessionStore.add(imsi, ind.sessionId, ind.networkContext);
          
            // Create CLR using previous origins as destinations and current destinations as origins
            DiameterCommand cmd = CancelLocationRequestFactory.BuildCancelLocationRequest(imsi, curOriginHost, curOriginRealm);
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildCLRSessionReq(sessionID, ind.networkContext, PrimitiveType.OPEN, cmd);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Display CLR sent
            System.out.println("HSS mode: Sending CLR to previous host for this IMSI (ULA not sent for now)");

            // send the CLR message
            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }
            GctLib.send((short)Config.DstMID, gctMsg);

            // set this session to 'pending CLA' state
            sessionStore.get(sessionID).setState(Session.State.WAIT_ANSWER);
                        
            // update MME store now with new origins now
            mmeStore.storeMme(imsi, originHost, originRealm);

            sent = true;

        } catch (AllSessionsActiveException nosEx) {
            System.out.println("Session store error: " + nosEx.getMessage());
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode" + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        return sent;
    }

    private void processAIR(DmrSessionInd ind) {

        AuthenticationInformationRequest req = (AuthenticationInformationRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (AIR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildAIASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processPUR(DmrSessionInd ind) {

        PurgeUERequest req = (PurgeUERequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (PUR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildPUASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processNOR(DmrSessionInd ind) {

        NotifyRequest req = (NotifyRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (NOR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildNOASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processRSR(DmrSessionInd ind) {

        ResetRequest req = (ResetRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (RSR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildRSASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processCLR(DmrSessionInd ind) {

        CancelLocationRequest req = (CancelLocationRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (CLR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildCLASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processCLA(DmrSessionInd ind) {

        CancelLocationAnswer cla = (CancelLocationAnswer) ind.diameterCommand;
        String originHost  = "";    // save the origin host for Hss mode
        String originRealm = "";    // save the origin realm for Hss mode

        try {
            // read some AVPs
            if (cla.getOriginHostAvp() != null)
                originHost = cla.getOriginHostAvp().getString();
            if (cla.getOriginRealmAvp() != null)
                originRealm = cla.getOriginRealmAvp().getString();

            if (Config.TraceOn) {
                // Display it first
                System.out.println("Command code matches (CLA)");
                System.out.println("Origin Host:" + originHost);
                System.out.println("Origin Realm:" + originRealm);
                if (cla.getResultCodeAvp() != null)
                    System.out.println("Result Code:" + cla.getResultCodeAvp().getLong());
            }
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Failed to recover AVP" + ex.toString());
        }

        try {
            // find session ID of received CLA message
            int sessionID = ind.sessionId;
            
            // If HSS mode, look for a session for the CLA (CLR was sent by this program)
            if (Config.HssMode == false)
                System.out.println("CLA received and ignored (not in HSS mode)");
            else {
                // If Hss mode, check for CLA expected
                if (originHost.isEmpty())
                    System.out.println("HSS mode: Received CLA has no origin host");
                else {
                    // Look for session ID in session store
                    Session session = sessionStore.get(sessionID);
                    if (session == null)
                        System.out.println("HSS mode: Received CLA session is unknown (" + String.format("%x", sessionID) + ")");
                    else {
                        // check session state (continue processing, even if wrong state)
                        if (session.getState() != Session.State.WAIT_ANSWER)
                            System.out.println("HSS mode: CLA session is not waiting for answer?");

                        // get IMSI from session store
                        long imsi = session.getImsi();
                        
                        // find new host from MME store
                        String newOriginHost = mmeStore.getMmeHost(imsi);

                        // display MME change details
                        System.out.println("HSS mode: MME re-location for IMSI " + Long.toString(imsi));
                        System.out.println("  from:" + originHost);
                        System.out.println("    to:" + newOriginHost);

                        // set session to Idle state
                        session.setState(Session.State.IDLE);
                        
                        // Get sessionID and NC from original rxd ULR
                        int origSessionID = session.getOrigSessionId();
                        int nc = session.getNc();

                        // Send ULA for original received ULR
                        DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildULASessionReq(origSessionID, nc);

                        int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
                        GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
                        dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

                        // Display CLA received
                        System.out.println("HSS mode: Received expected CLA, now sending ULA");

                        if (Config.TraceOn) {
                            DtrMsgUtil.traceMsg("DTR>>", gctMsg);
                        }
                        GctLib.send((short) Config.DstMID, gctMsg);
                        
                        // remove session from session store
                        sessionStore.remove(sessionID);
                    }
                }
            }
        } catch (SessionNotIdleException niEx) {
            System.out.println("Session store error: " + niEx.toString());
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }
 
    private void processDSR(DmrSessionInd ind) {

        DeleteSubscriberDataRequest req = (DeleteSubscriberDataRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (DSR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildDSASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processECR(DmrSessionInd ind) {

        MEIdentityCheckRequest req = (MEIdentityCheckRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (ECR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildECASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processIDR(DmrSessionInd ind) {

        InsertSubscriberDataRequest req = (InsertSubscriberDataRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (IDR)");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }

                //Example use of iterator
                ListIterator<IAvp> li = req.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = req.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = req.listIterator();

                while (li.hasNext()) {
                    IAvp ua = req.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildIDASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }
    
    private void processAAR(DmrSessionInd ind) {

        AARequest aar = (AARequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Command code matches (AAR)");

                if (aar.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + aar.getOriginHostAvp().getString());
                }
                if (aar.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + aar.getOriginRealmAvp().getString());
                }
                if (aar.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + aar.getDestinationRealmAvp().getString());
                }
                
                if (aar.getMediaComponentDescriptionAvp() != null) {
                    MediaComponentDescriptionAvp mcd = aar.getMediaComponentDescriptionAvp();
                    System.out.println("Media Component Description:");
                    if (mcd.getMediaComponentNumberAvp() != null)
                        System.out.println("  Media Component Number: " + mcd.getMediaComponentNumberAvp().getLong());

                    if (mcd.getMediaSubComponentAvp() != null)                     {                      
                        MediaSubComponentAvp msc = mcd.getMediaSubComponentAvp();
                        System.out.println("Media Sub Component:");

                        if (msc.getFlowNumberAvp() != null)
                            System.out.println("    Flow Number: " + msc.getFlowNumberAvp().getLong());
                        if (msc.getFlowStatusAvp() != null)
                            System.out.println("    Flow Status: " + msc.getFlowStatusAvp().getLong());
                        if (msc.getFlowUsageAvp() != null)
                            System.out.println("    Flow Usage: " + msc.getFlowUsageAvp().getLong());
                        if (msc.getMaxRequestedBandwidthULAvp() != null)
                            System.out.println("    Max Requested Bandwidth UL: " +  msc.getMaxRequestedBandwidthULAvp().getLong());
                        if (msc.getMaxRequestedBandwidthDLAvp() != null)
                            System.out.println("    Max Requested Bandwidth DL: " + msc.getMaxRequestedBandwidthDLAvp().getLong());
                    }
                }

                if (aar.getAFChargingIdentifierAvp() != null)
                    System.out.println("AF Charging Identifier:");
                
                if (aar.getSIPForkingIndicationAvp() != null) 
                    System.out.println("SIP Forking Indication: " + aar.getSIPForkingIndicationAvp().getLong());
                  

                //Example use of iterator
                ListIterator<IAvp> li = aar.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = aar.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = aar.listIterator();

                while (li.hasNext()) {
                    IAvp ua = aar.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildAAASessionReq(dmrContext, Config, ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }

    }

    
    private void processCCR(DmrSessionInd ind) {

        if (Config.TraceOn) {
            CreditControlRequest ccr = (CreditControlRequest) ind.diameterCommand;
            try {
                System.out.println("Command code matches (CCR)");

                if (ccr.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + ccr.getOriginHostAvp().getString());
                }
                if (ccr.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + ccr.getOriginRealmAvp().getString());
                }
                if (ccr.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + ccr.getDestinationHostAvp().getString());
                }
                if (ccr.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + ccr.getDestinationRealmAvp().getString());
                }
                //Example use of iterator
                ListIterator<IAvp> li = ccr.listIterator();

                while (li.hasNext()) {
                    ProxyInfoAvp pia = ccr.getProxyInfoAvp(li);

                    if ((pia != null) && (pia.getProxyHostAvp() != null)) {
                        System.out.println("Proxy Info(Host):" + pia.getProxyHostAvp().getString());
                    }
                }

                // Unknown AVP iterator example
                li = ccr.listIterator();

                while (li.hasNext()) {
                    IAvp ua = ccr.getUnknownAvp(li);

                    if (ua != null) {
                        System.out.println("Unknown Avp:" + ua.getCode());
                    }
                }

            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {

            PrimitiveType prim;

            // We want to continue the session only if it is the first answer
            if (ind.primitiveType == PrimitiveType.OPEN) {
                prim = PrimitiveType.CONTINUE;
            } else {
                prim = PrimitiveType.CLOSE;
            }


            DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildCCASessionReq(dmrContext, Config, ind, prim);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            // Code to allow loopback testing on one box.
            if ((Config.LoopBack) && (gctMsg.getType() == DmrContext.MsgType.DMR_MSG_SESSION_REQ.getValue())) {
                gctMsg.setType((int) DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue());
            }
            // End of loopback            

            if (Config.TraceOn) {
                DtrMsgUtil.traceMsg("DTR>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }
    }

    
}//end class ReqRxer
