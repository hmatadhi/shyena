/*
     
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        InsertSubscriberDataAnswerFactory.java

     Description: 
     Builds an IDA Response

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      11-Feb-13   - Initial version
       -      04-Nov-14   - Minor update

 */
package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.ResultCode;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.ResultCodeAvp;
import com.dialogic.signaling.diameter.ts29272.InsertSubscriberDataAnswer;
import com.dialogic.signaling.dmr.user.DmrSessionInd;

public class InsertSubscriberDataAnswerFactory {

    public static InsertSubscriberDataAnswer BuildInsertSubscriberDataAnswer(DtrConfig config, DmrSessionInd sessionInd) {

            InsertSubscriberDataAnswer req = new InsertSubscriberDataAnswer();

            // No need to add the sessionIDAvp manually, using the correct session identifier
            // will add it for you.
            //ula.addSessionIDAvp(new SessionIDAvp("0"));        

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));

            req.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            return req;
    }
}
