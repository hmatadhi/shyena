/*
     
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        CreditControlAnswerFactory.java

     Description: 
     Builds an CCA response.

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      26-Mar-12   - Initial version
       2      09-Oct-12   - Trial Release version
       -      04-Nov-14   - Minor update
 */

package com.dialogic.signaling.dmr.dtr;

import com.dialogic.signaling.diameter.ResultCode;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyInfoAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ResultCodeAvp;
import com.dialogic.signaling.diameter.rfc4006.CreditControlAnswer;
import com.dialogic.signaling.dmr.user.DmrSessionInd;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class CreditControlAnswerFactory {

    public static CreditControlAnswer BuildCreditControlAnswer(DtrConfig config, DmrSessionInd sessionInd, PrimitiveType prim) {

        try {
            CreditControlAnswer cca = new CreditControlAnswer();

            cca.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));

            ProxyInfoAvp pia = new ProxyInfoAvp();
            pia.addProxyHostAvp(new ProxyHostAvp("ProxyInfo.ProxyHost"));
            pia.addProxyStateAvp(new ProxyStateAvp(ByteBuffer.wrap(new byte[]{(byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5})));
            cca.addProxyInfoAvp(pia);

            return cca;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }
}
