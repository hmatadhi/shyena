/*
 Copyright (C) 2014 Dialogic Inc. All rights reserved.

 Name:        Session.java

 Description: 
     
 Models the whole Diameter session and the matching settings.
 It also holds the context information needed by the State objects
 and stores the current state of the session by storing 
 the singleton state object.
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   -      04-Nov-14   Adopt DTU code for new DTR functionality
 */

package com.dialogic.signaling.dmr.dtr;


/**
 * class Session
 * 
 * Stores details for a session.
 * These sessions are only created for new requests sent by DTR.
 * Currently these are only CLR requests.
 * The session stores data to process the received CLA and then send a ULA.
 */
public class Session {

    private int sessionId;         // ID for this session
    private long imsi;
    private int nc;
    private int origSession;       // original received request sessionID
    private State state;


    Session(int sessionId, long imsi, int nc, int origSession) {
        this.sessionId = sessionId;
        this.imsi = imsi;
        this.nc = nc;
        this.origSession = origSession;
        state = State.IDLE;
    }

    public enum State {
        IDLE,
        WAIT_ANSWER
    }

    public State getState() {
        return state;
    }

    public void setState(State newState) {
        state = newState;
    }

    public int getSessionId() {
        return sessionId;
    }
    
    public long getImsi() {
        return imsi;
    }
    
    public int getOrigSessionId() {
        return origSession;
    }
    
    public int getNc() {
        return nc;
    }

    @Override
    public String toString() {
        return ("Session");
    }
}
