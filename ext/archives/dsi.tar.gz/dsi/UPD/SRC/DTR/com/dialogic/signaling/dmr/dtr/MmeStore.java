/*
 Copyright (C) 2014 Dialogic Inc. All rights reserved.

 Name:        MmeStore.java

 Description:     

 Container storage for Mme objects.
 Stores record of previous sessions that used an IMSI and stores used origin host.
 Once IMSI records are added, they are not removed.
 
 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
   -      10-Nov-14   Created
 */

package com.dialogic.signaling.dmr.dtr;

import java.util.ArrayList;

/**
 * class MmeStore
 * 
 * Stores 'MME' entries for different imsi values.
 * Data stored is the imsi and the origin host and realm last used.
 * IMSI must be unique in store.
 * Allows origin host and realm that are associated with each imsi to be changed.
 * New entries are created as required, but never deleted.
 */
public class MmeStore {

    static private ArrayList<Mme> dmrMmes = new ArrayList<Mme>();

    MmeStore() {
        // constructor
    }

    @Override
    public String toString() {
        return ("MmeStore");
    }

    public String getMmeHost(long imsi) {
        int index = find(imsi);
        // If imsi is in the store, returns associated origin value
        if (index >= 0)
            return(dmrMmes.get(index).getHost());
        return("");
    }
    
    public String getMmeRealm(long imsi) {
        int index = find(imsi);
        // If imsi is in the store, returns associated origin value
        if (index >= 0)
            return(dmrMmes.get(index).getRealm());
        return("");
    }
    
    public boolean storeMme(long imsi, String host, String realm) {
        boolean ret = false;
        if (host.isEmpty() || realm.isEmpty())
            return(false);
        try {
                // Depending of whether imsi is in store, either update host/realm for existing imsi
                //    or create new mm record for new imsi
	        int index = find(imsi);
	        if (index < 0)
                    dmrMmes.add(new Mme(imsi, host, realm));
		else
                    dmrMmes.get(index).setMme(host, realm);
		ret = true;
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        return(ret);
    }

    public int numImsi() {
        // Return number of imsi's in store
        return(dmrMmes.size());
    }

    
    private int find(long imsi) {
        // local function to search for an imsi in the store
        // uses simple sequential array search for now
        // returns array index or -1 if not found
        for (int i=0; i<dmrMmes.size(); i++) {
            if (dmrMmes.get(i).getImsi() == imsi)
                return(i);
        }
        return(-1);
    }

    // Wholly contained class to hold data being stored in Mme Store
    //  - currently data is just the imsi, origin host and origin realm
    private class Mme {
        private long saveImsi = 0;
        private String saveHost = "";
        private String saveRealm = "";

        Mme(long imsi, String host, String realm) {
            // constructor
            saveImsi = imsi;
            saveHost = host;
            saveRealm = realm;
        }
        public long getImsi() {
            // get imsi used
            return(saveImsi);
        }
        public String getHost() {
            // get origin used
            return(saveHost);
        }
        public String getRealm() {
            // get origin used
            return(saveRealm);
        }
        public void setMme(String host, String realm) {
            // set new origin host/realm replacing previous values
            saveHost = host;
            saveRealm = realm;
        }
    } //end Mme class

} //end MmeStore class
