/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        CreditControlRequestFactory.java

 Description: 
     
 Generates a Session Request for DTU. 
 
 -----    ---------   -----      ------------------------------------
 Issue    Date        By         Changes
 -----    ---------   -----      ------------------------------------
 1       18-Dec-12   JTD        - Initial version


 */
package com.dialogic.signaling.dmr.dtu.requests;

import com.dialogic.signaling.diameter.rfc3588.avps.AuthApplicationIDAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationRealmAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.TerminationCauseAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.UserNameAvp;
import com.dialogic.signaling.diameter.rfc4006.CreditControlRequest;
import com.dialogic.signaling.diameter.rfc4006.avps.CCCorrelationIDAvp;
import com.dialogic.signaling.diameter.rfc4006.avps.CCRequestNumberAvp;
import com.dialogic.signaling.diameter.rfc4006.avps.CCRequestTypeAvp;
import com.dialogic.signaling.diameter.rfc4006.avps.ServiceContextIDAvp;
import com.dialogic.signaling.diameter.rfc4006.avps.ServiceIdentifierAvp;
import com.dialogic.signaling.dmr.dtu.DtuConfig;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class CreditControlRequestFactory {

    public static CreditControlRequest BuildCreditControlRequest(DtuConfig dtuConfig, CCRequestTypeAvp.CCRequestType ccReqType) {

        try {
            CreditControlRequest ccr = new CreditControlRequest();

            ccr.addCCRequestTypeAvp(new CCRequestTypeAvp(ccReqType));
            
            ccr.setApplicationId(0x4);

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));

            ccr.addDestinationRealmAvp(new DestinationRealmAvp(dtuConfig.DestRealm));
            ccr.addAuthApplicationIDAvp(new AuthApplicationIDAvp((long) 1234));           
            ccr.addServiceContextIDAvp(new ServiceContextIDAvp("461")); 
            ccr.addDestinationHostAvp(new DestinationHostAvp(dtuConfig.DestHost));
            ccr.addUserNameAvp(new UserNameAvp("user@dialogic.com"));          
            ccr.addCCCorrelationIDAvp(new CCCorrelationIDAvp((ByteBuffer.wrap(new byte[]{(byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5}))));            
            ccr.addServiceIdentifierAvp(new ServiceIdentifierAvp(432L));        
            
            //
            // We don't actually generate the update yet. Request numbers should be different within
            // session.
            //
            if (ccReqType == CCRequestTypeAvp.CCRequestType.INITIAL_REQUEST) {
                ccr.addCCRequestNumberAvp(new CCRequestNumberAvp(0L));
            } else if (ccReqType == CCRequestTypeAvp.CCRequestType.UPDATE_REQUEST) {
                ccr.addCCRequestNumberAvp(new CCRequestNumberAvp(1L));
            } else if (ccReqType == CCRequestTypeAvp.CCRequestType.TERMINATION_REQUEST) {
                ccr.addCCRequestNumberAvp(new CCRequestNumberAvp(2L));
                ccr.addTerminationCauseAvp(new TerminationCauseAvp(TerminationCauseAvp.TerminationCause.DIAMETER_LOGOUT));
            }            
            
            return ccr;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }
}
