/*
 Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

 Name:        DtuIssue.java

 Description: DTU Source Code Issue and History
     
 Class that defines the current issue of the DTU code.
 Also documents changes made for the latest issue and all previous issues.
  
---------   ------------------------------------
  Date       Changes
---------   ------------------------------------

            - Trial Release
18-Oct-12   *** DTU Version 1.00 Release ****

            - Added support for Ro Interface example
            - Now supports ULR and CCR commands.
27-Dec-12   *** DTU Version 1.01 Release ****

            - Minor updates
06-Feb-13   *** DTU Version 1.02 Release ****

            - Added support for Rx interface example
27-Sep-13   *** DTU Version 1.03 Release ****

            - Added support for additional ULR command requests:
               + AIR, PUR, NOR, RSR, CLR, IDR, DSR, ECR. 
13-Feb-14   *** DTU Version 1.04 Release ****

            - DTU now handles received CLR and sends CLA
            - Added -rptdelay option to add a delay between sending requests
            - DTU now requires GCT tick messages to be received
            - Dtu Code Issue moved to this java file,
              dtu_iss.txt file is now obsolete
24-Feb-15   *** DTU Version 1.05 Release ****

*/

package com.dialogic.signaling.dmr.dtu;

public final class DtuIssue {

    // Define latest DTU code issue in a string
    public static final String DtuCodeIssue = "1.05";

}
