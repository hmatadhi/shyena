/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        DmrSessionIndEventListner.java

 Description:     

 Event Listner defining a DMR SESSION IND message.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1        15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu.events;

import com.dialogic.signaling.dmr.dtu.Session;

public interface DmrSessionIndEventListner {
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt);    
}
