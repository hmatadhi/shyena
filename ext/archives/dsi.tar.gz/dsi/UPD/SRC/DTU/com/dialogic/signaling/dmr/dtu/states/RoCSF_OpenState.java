/*
     
     Copyright (C) 2012 Dialogic Inc. All rights reserved.

     Name:        RoCSF_OpenState.java

     Description: 
     
     Used by the CCR modes. This state models a service which has received 
     initial credit and is performing some functionality.
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      15-Nov-12    JTD       Initial version

 */
package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.diameter.DiameterCommand;
import com.dialogic.signaling.diameter.rfc4006.avps.CCRequestTypeAvp.CCRequestType;
import com.dialogic.signaling.dmr.dtu.DmrSessionReqFactory;
import com.dialogic.signaling.dmr.dtu.DtuMsgUtil;
import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.DtuUserSrvEventPrim;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import com.dialogic.signaling.dmr.dtu.requests.CreditControlRequestFactory;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import com.dialogic.signaling.encoder.EncoderException;
import com.dialogic.signaling.gct.GctException;
import com.dialogic.signaling.gct.GctLib;
import com.dialogic.signaling.gct.GctMsg;

public class RoCSF_OpenState extends DTU_SessionState {

    @Override
    public String toString() {
        return ("RoCSF_OpenState");
    }
   

    @Override
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt) {

        //Not expecing any Service Ind now command, so close things down!
        session.printlnDebug("Unexpected Service Ind");        
        this.setState(session, idleState);

    }

    @Override
    public void handleUserSrvEvent(Session session, UserSrvEvent evt) {


        if (evt.getEvtPrim().equals(DtuUserSrvEventPrim.SRV_COMPLETE)) {

            //Service has finished now
            session.printlnTrace("Srv finished now");

            //Send the request to confirm the credit
            sendCCRTerm(session);

            this.setState(session, roCSF_P_TermState);

        } else {
            //Not expecing that User Event, so close things down!
            session.printlnDebug("Unexpected User Srv Event Ind"); 
            this.setState(session, idleState);
        }

    }

    private void sendCCRTerm(Session session) {

        DiameterCommand cmd;
        cmd = CreditControlRequestFactory.BuildCreditControlRequest(session.getConfig(), CCRequestType.TERMINATION_REQUEST);
        DmrSessionReq dmrSsnReq = DmrSessionReqFactory.BuildSessionReq(session, PrimitiveType.CONTINUE, cmd);
       
        try {
            int dmrSessionReqLen = session.getContext().userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            session.getContext().userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            if (session.getConfig().TraceOn) {
                DtuMsgUtil.traceMsg("DTU>>", gctMsg);
            }
            GctLib.send((short) session.getConfig().DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode" + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } 
    }
}
