/*
     Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

     Name:        DtuMsgUtil.java

     Description: 
     
     Utility Class for GCT Messages.
 
     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      28-Sep-12   - Initial version
       2      05-Dec-12   - Exception handling tidy up
              24-Feb-15   - Added functions to send GCT messages to
                            start and stop timer ticks
 */
package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.gct.BBUtil;
import com.dialogic.signaling.gct.GctException;
import com.dialogic.signaling.gct.GctLib;
import com.dialogic.signaling.gct.GctMsg;
import java.nio.ByteBuffer;

/**
 * Utility Class for GCT Messages
 */
public class DtuMsgUtil {

    // Define Message Types for Timer module
    public static final int TIM_MSG_KEEP_TIME    = 0x7006;
    public static final int TIM_MSG_REMOVE_TIMER = 0x7007;
    public static final int TIM_MSG_TM_EXP       = 0xc002;

    // Define GCT Module ID for Timer module
    static final short TIMER_MID = 0x00;

    
    // Display tracing for a received message
    static public void traceMsg(String prefix, GctMsg gctmsg) {
        try {
            System.out.print(prefix
                    + "M-t" + String.format("%04x", gctmsg.getType())
                    + "-i" + String.format("%04x", gctmsg.getId())
                    + "-f" + String.format("%02x", gctmsg.getSrc())
                    + "-d" + String.format("%02x", gctmsg.getDst())
                    + "-s" + String.format("%02x", gctmsg.getStatus()));

            ByteBuffer buf = gctmsg.getParam();
            
            if (buf.hasRemaining()) {
                System.out.print("-p");

                while (buf.hasRemaining()) {
                    System.out.print(String.format("%02x", BBUtil.getU8(buf)));
                }
            }

            System.out.print("\n");

        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }        
    }
    
    // Sends GCT message to Timer module for Start of Send Ticks (to this module)
    static public void timerTicksStart(short DtuMID) {
        GctMsg sendMsg;
        
        try {
            int MSG_ID = 0;
            int MSG_RSP_REQ = 0;
            int KEEP_TIME_MSG_LENGTH = 8;

            //Get new GCT message
            sendMsg = GctLib.getm(TIM_MSG_KEEP_TIME, MSG_ID, MSG_RSP_REQ, KEEP_TIME_MSG_LENGTH);
            
        } catch (GctException gctEx) {
            System.out.println("Problem creating GCT Keep Time message:" + gctEx.getMessage());
            return;
        } 

        try {
            sendMsg.setSrc(DtuMID);
            sendMsg.setDst(TIMER_MID);

            //Assumes that the message data is initialised to zeros

            //Send the message
            GctLib.send(sendMsg);            

        } catch (GctException gctEx) {
            System.out.println("Problem with sending GCT Keep Time message:" + gctEx.getMessage());

            //Release the message
            try {
                GctLib.relm(sendMsg);
            } catch (GctException gctEx2) {
                System.out.println("GCT Keep Time message could not be released:" + gctEx2.getMessage());
            }
        }
    }
    
    // Sends GCT message to Timer module for Stop Sending Ticks
    static public void timerTicksStop(short DtuMID) {
        GctMsg sendMsg;
        
        try {
            int MSG_ID = 0;
            int MSG_RSP_REQ = 0;
            int REMOVE_TIMER_MSG_LENGTH = 4;

            //Get new GCT message
            sendMsg = GctLib.getm(TIM_MSG_REMOVE_TIMER, MSG_ID, MSG_RSP_REQ, REMOVE_TIMER_MSG_LENGTH);
            
        } catch (GctException gctEx) {
            System.out.println("Problem creating GCT Stop Ticks message:" + gctEx.getMessage());
            return;
        } 

        try {
            sendMsg.setSrc(DtuMID);
            sendMsg.setDst(TIMER_MID);

            //Assumes that the message data is initialised to zeros

            //Send the message
            GctLib.send(sendMsg);            

        } catch (GctException gctEx) {
            System.out.println("Problem with sending GCT Stop Ticks message:" + gctEx.getMessage());

            //Release the message
            try {
                GctLib.relm(sendMsg);
            } catch (GctException gctEx2) {
                System.out.println("GCT Stop Ticks message could not be released:" + gctEx2.getMessage());
            }
        }
    }

}