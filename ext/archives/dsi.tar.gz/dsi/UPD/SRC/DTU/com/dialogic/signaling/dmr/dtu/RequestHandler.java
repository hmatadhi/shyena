/*
     
 Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

 Name:        RequestHandler.java

 Description: 
     
 Class for send various Requests and processing received Answers
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1        26-Mar-12   - Initial version
 2        28-Sep-12   - Updated API changes.
 - Trace off mode added 
 3        05-Dec-12   - Exception handling tidy up
 4        19-Sep-13   - Add Rx support
          03-Dec-14   - Handle received CLR
          23-Feb-15   - Handle GCT Timer Tick messages
 */

package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.diameter.rfc4006.CreditControlAnswer;
import com.dialogic.signaling.diameter.rfc4006.CreditControlRequest;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationAnswer;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationRequest;
import com.dialogic.signaling.diameter.ts29211.AAAnswer;
import com.dialogic.signaling.diameter.ts29211.AARequest;
import com.dialogic.signaling.diameter.ts29272.AuthenticationInformationAnswer;
import com.dialogic.signaling.diameter.ts29272.AuthenticationInformationRequest;
import com.dialogic.signaling.diameter.ts29272.CancelLocationAnswer;
import com.dialogic.signaling.diameter.ts29272.CancelLocationRequest;
import com.dialogic.signaling.diameter.ts29272.DeleteSubscriberDataAnswer;
import com.dialogic.signaling.diameter.ts29272.DeleteSubscriberDataRequest;
import com.dialogic.signaling.diameter.ts29272.InsertSubscriberDataAnswer;
import com.dialogic.signaling.diameter.ts29272.InsertSubscriberDataRequest;
import com.dialogic.signaling.diameter.ts29272.MEIdentityCheckAnswer;
import com.dialogic.signaling.diameter.ts29272.MEIdentityCheckRequest;
import com.dialogic.signaling.diameter.ts29272.NotifyAnswer;
import com.dialogic.signaling.diameter.ts29272.NotifyRequest;
import com.dialogic.signaling.diameter.ts29272.PurgeUEAnswer;
import com.dialogic.signaling.diameter.ts29272.PurgeUERequest;
import com.dialogic.signaling.diameter.ts29272.ResetRequest;
import com.dialogic.signaling.dmr.DmrContext;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.DtuUserSrvEventPrim;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import com.dialogic.signaling.dmr.dtu.states.DTU_SessionState;
import com.dialogic.signaling.dmr.dtu.requests.CancelLocationAnswerFactory;
import com.dialogic.signaling.dmr.user.DmrSessionInd;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import com.dialogic.signaling.encoder.EncoderException;
import com.dialogic.signaling.encoder.MsgEncoder;
import com.dialogic.signaling.gct.GctException;
import com.dialogic.signaling.gct.GctLib;
import com.dialogic.signaling.gct.GctMsg;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class RequestHandler {

    MsgEncoder DsrMS;
    DtuConfig Config;
    DmrContext dmrContext;
    static SessionStore sessionStore;

    public RequestHandler(DtuConfig config) {
        Config = config;

        try {
            dmrContext = new DmrContext();
            dmrContext.registerDiameterCommand(UpdateLocationRequest.class);
            dmrContext.registerDiameterCommand(UpdateLocationAnswer.class);
            dmrContext.registerDiameterCommand(CreditControlRequest.class);
            dmrContext.registerDiameterCommand(CreditControlAnswer.class);
            dmrContext.registerDiameterCommand(AuthenticationInformationRequest.class);
            dmrContext.registerDiameterCommand(AuthenticationInformationAnswer.class);
            dmrContext.registerDiameterCommand(CancelLocationRequest.class);
            dmrContext.registerDiameterCommand(CancelLocationAnswer.class);
            dmrContext.registerDiameterCommand(DeleteSubscriberDataRequest.class);
            dmrContext.registerDiameterCommand(DeleteSubscriberDataAnswer.class);
            dmrContext.registerDiameterCommand(InsertSubscriberDataRequest.class);
            dmrContext.registerDiameterCommand(InsertSubscriberDataAnswer.class);
            dmrContext.registerDiameterCommand(MEIdentityCheckRequest.class);
            dmrContext.registerDiameterCommand(MEIdentityCheckAnswer.class);
            dmrContext.registerDiameterCommand(NotifyRequest.class);
            dmrContext.registerDiameterCommand(NotifyAnswer.class);
            dmrContext.registerDiameterCommand(PurgeUERequest.class);
            dmrContext.registerDiameterCommand(PurgeUEAnswer.class);
            dmrContext.registerDiameterCommand(ResetRequest.class);
            dmrContext.registerDiameterCommand(AARequest.class);
            dmrContext.registerDiameterCommand(AAAnswer.class);

            //Set the message source and dest module ids here.
            dmrContext.setDmrTaskId(config.DstMID);
            dmrContext.setSrcTaskId(config.SrcMID);

            sessionStore = new SessionStore(config);

        } catch (Exception ex) {
            System.out.println("Exception raised during creation of Request Handler:" + ex.toString());
        }
    }

    public Integer numActive() {
        return sessionStore.numActive();
    }

    public void startNewSession() {

        Session session = sessionStore.findIdle();

        if (session != null) {
            session.printlnTrace("Starting Session");
            session.setContext(dmrContext);
            session.setState(DTU_SessionState.startupState);
            session.handleUserSrvEvent(new UserSrvEvent(session, DtuUserSrvEventPrim.REQ_SRV, session.getSessionId()));
        } else {
            System.out.println("No idle session available");
        }
    }

    /**
     * Function to wait for the next GCT message that is received.
     *  Received DMR messages are processed.
     *  Other messages are ignored.
     *  Received GCT Tick messages are not traced
     *  Returns:
     *    0 = DMR message received
     *    1 = Tick message received
     *    2 = Message was not expected here (unrecognised)
     *   -1 = Error during message recovery
     */
    public int handleMsg() throws IOException {
        int retType = -1;
        
        GctMsg rxedMsg = GctLib.receive(Config.SrcMID);

        try {
            int msgType = rxedMsg.getType();

            // Trace the message (if not a GCT 'tick')
            if ((Config.TraceOn) && (msgType != DtuMsgUtil.TIM_MSG_TM_EXP)) {
                DtuMsgUtil.traceMsg("DTU<<", rxedMsg);
            }

            // Process the message according to its message type
            if (msgType == DmrContext.MsgType.DMR_MSG_SESSION_IND.getValue()) {
                handleSessionIndMsg(rxedMsg);
                retType = 0;
            } else if (msgType == DtuMsgUtil.TIM_MSG_TM_EXP) {
                retType = 1;
            } else {
                System.out.println("Unexpected Message Type received:" + String.format("0x%04x", rxedMsg.getType()));
                retType = 2;
            }
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } finally {
            try {
                GctLib.relm(rxedMsg);
            } catch (GctException gctEx) {
                System.out.println("Problem with message releasing: " + gctEx.getMessage());
            }
        }
        return(retType);
    }

    private void handleSessionIndMsg(GctMsg rxedMsg) {

        try {
            Session session = sessionStore.get(rxedMsg.getId());

            if ((session != null) && (session.getState() != DTU_SessionState.idleState)) {
                session.printlnTrace("Session Ind Received");

                try {
                    // Handle received message (session ID is from outgoing range)
                    DmrSessionInd decodedInd = session.getContext().userApi.dmrSessionIndEncoder.decode(rxedMsg);
                    session.handleDmrSessionIndEvent(new DmrSessionIndEvent(session, decodedInd));
                } catch (EncoderException eEx) {
                    System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
                }
            } else if (session == null) {
                try {
                    // Assume session ID from Incoming range and test for CLR received
                    ProcessIncomingSessionInd(rxedMsg);
                } catch (EncoderException eEx) {
                    System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
                }
            } else {
                System.out.println("Received session id(0x" + String.format("%04x", rxedMsg.getId()) + ") is Idle state");
            }
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }
    }

    public void handleLocalUserSrvEvent() {

        UserSrvEvent evt;

        try {
            if (!LocalUserEventQueue.getQueue().isEmpty()) {

                //Get the first event
                evt = LocalUserEventQueue.getQueue().remove(0);

                if (evt != null) {
                    Session session = sessionStore.get(evt.getSessionId());

                    if (session != null) {
                        session.printlnTrace("User Service Event being processed");
                        session.handleUserSrvEvent(evt);
                    }
                }
            }
        } catch (IndexOutOfBoundsException IOBEx) {
            System.out.println("Problem with local event queue handling");
        }
    }
    
    private void ProcessIncomingSessionInd(GctMsg gctmsg) throws GctException, EncoderException {

        // Decode the incoming message
        DmrSessionInd decodedInd = dmrContext.userApi.dmrSessionIndEncoder.decode(gctmsg);

        if (decodedInd.primitiveType != PrimitiveType.OPEN) {
            System.out.println("Incoming message has unexpected Prim Type");
        }
        else {
            // Only accept incoming CLR requests
            if (decodedInd.diameterCommand.getCommandCode() == CancelLocationRequest.StandardCommandCode &&
                decodedInd.diameterCommand.isRequest())
                processCLR(decodedInd);
            else
                System.out.println("Incoming message rejected since not a CLR");
        }
    }

    private void processCLR(DmrSessionInd ind) {

        CancelLocationRequest req = (CancelLocationRequest) ind.diameterCommand;

        if (Config.TraceOn) {
            //Display it first
            try {
                System.out.println("Incoming CLR received");

                if (req.getOriginHostAvp() != null) {
                    System.out.println("Origin Host:" + req.getOriginHostAvp().getString());
                }
                if (req.getOriginRealmAvp() != null) {
                    System.out.println("Origin Realm:" + req.getOriginRealmAvp().getString());
                }
                if (req.getDestinationHostAvp() != null) {
                    System.out.println("Dest Host:" + req.getDestinationHostAvp().getString());
                }
                if (req.getDestinationRealmAvp() != null) {
                    System.out.println("Dest Realm:" + req.getDestinationRealmAvp().getString());
                }
            } catch (UnsupportedEncodingException ex) {
                System.out.println("Failed to recover AVP" + ex.toString());
            }
        }

        //Let's build a reply
        try {
            DmrSessionReq dmrSsnReq = BuildCLASessionReq(ind);

            int dmrSessionReqLen = dmrContext.userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            dmrContext.userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            if (Config.TraceOn) {
                System.out.println("Sending CLA answer");
                DtuMsgUtil.traceMsg("DTU>>", gctMsg);
            }

            GctLib.send((short) Config.DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode handling: " + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        }
    }

    private DmrSessionReq BuildCLASessionReq(DmrSessionInd receivedSessionInd) {
        DmrSessionReq sessionCloseReq = new DmrSessionReq();
        sessionCloseReq.networkContext = receivedSessionInd.networkContext;
        sessionCloseReq.primitiveType = PrimitiveType.CLOSE;
        sessionCloseReq.diameterCommand = CancelLocationAnswerFactory.BuildCancelLocationAnswer();
        sessionCloseReq.sessionId = receivedSessionInd.sessionId;

        return sessionCloseReq;
    }
    
}
