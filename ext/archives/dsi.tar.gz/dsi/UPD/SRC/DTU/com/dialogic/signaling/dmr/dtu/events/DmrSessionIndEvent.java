/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        DmrSessionIndEvent.java

 Description:     

 Event defining a DMR SESSION IND message.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1        15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu.events;

import com.dialogic.signaling.dmr.user.DmrSessionInd;

public class DmrSessionIndEvent extends java.util.EventObject {
    
    DmrSessionInd ind;

    public DmrSessionInd getInd() {
        return ind;
    }

    public void setInd(DmrSessionInd ind) {
        this.ind = ind;
    }
    
    public DmrSessionIndEvent(Object obj) {
        super(obj);
        ind = null;
    }      

    public DmrSessionIndEvent(Object obj, DmrSessionInd sessionInd) {
        super(obj);        
        ind = sessionInd;        
    }     
}
