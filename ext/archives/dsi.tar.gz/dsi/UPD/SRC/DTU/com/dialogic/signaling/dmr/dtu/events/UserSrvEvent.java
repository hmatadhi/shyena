/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        UserSrvEvent.java

 Description:     

 Event defining a local internal User Event.
 These events are local to the application

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1        15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu.events;

public class UserSrvEvent extends java.util.EventObject {
    
    DtuUserSrvEventPrim evtPrim;
    Integer sessionId;

    public DtuUserSrvEventPrim getEvtPrim() {
        return evtPrim;
    }

    public Integer getSessionId() {
        return sessionId;
    }

    public DtuUserSrvEventPrim getUserEvent() {
        return evtPrim;
    }

    public void setUserEvent(DtuUserSrvEventPrim userPrim) {
        this.evtPrim = userPrim;
    }       

    public UserSrvEvent(Object obj, DtuUserSrvEventPrim userPrim, Integer sid) {
        super(obj);        
        evtPrim = userPrim;        
        sessionId = sid;
    }     
}
