/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        LocalUserEventQueue.java

 Description: 
     
 Defines a simple list of events to act as a internal event
 queue. The user events aren't used externally, they are just
 sent to match where events might be in a real system.
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1       15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import java.util.ArrayList;

public class LocalUserEventQueue {

    static private ArrayList<UserSrvEvent> srvEvents = new ArrayList<UserSrvEvent>();    

    public static ArrayList<UserSrvEvent> getQueue() {
        return srvEvents;
    }
    
    public Boolean add(UserSrvEvent evt) {        
        return (srvEvents.add(evt));
    }
    
    public UserSrvEvent remove() {        
        return (srvEvents.remove(0));
    }    
    
    
}
