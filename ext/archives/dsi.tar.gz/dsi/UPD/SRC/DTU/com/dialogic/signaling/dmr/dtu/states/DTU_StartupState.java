/*
     
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        DTU_StartupState.java

     Description: 
     
     Used by the all modes. This state kicks off a session and is controlled by
     the mode setting. A different next state will control the state machine 
     used by the rest of the session.
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      15-Nov-12    JTD       Initial version
       2      19-Sep-13    RAJ       Add Rx support
              03-Dec-14    CJM       Added comments
 */

package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.diameter.DiameterCommand;
import com.dialogic.signaling.diameter.rfc4006.avps.CCRequestTypeAvp.CCRequestType;
import com.dialogic.signaling.dmr.dtu.DmrSessionReqFactory;
import com.dialogic.signaling.dmr.dtu.DtuMsgUtil;
import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import com.dialogic.signaling.dmr.dtu.requests.CreditControlRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.AARequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.AuthenticationInformationRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.CancelLocationRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.DeleteSubscriberDataRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.InsertSubscriberDataRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.MEIdentityCheckRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.NotifyRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.PurgeUERequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.UpdateLocationRequestFactory;
import com.dialogic.signaling.dmr.dtu.requests.ResetRequestFactory;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import com.dialogic.signaling.encoder.EncoderException;
import com.dialogic.signaling.gct.GctException;
import com.dialogic.signaling.gct.GctLib;
import com.dialogic.signaling.gct.GctMsg;

/**
 *
 */
public class DTU_StartupState extends DTU_SessionState {

    @Override
    public String toString() {
        return ("Startup");
    }  

    @Override
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt) {
    }

    @Override
    public void handleUserSrvEvent(Session session, UserSrvEvent evt) {

        DiameterCommand cmd;
        DmrSessionReq dmrSsnReq;

        // Build the initial request
        switch (session.getConfig().Mode) {
            case CCR:
                cmd = CreditControlRequestFactory.BuildCreditControlRequest(session.getConfig(), CCRequestType.INITIAL_REQUEST);
                dmrSsnReq = DmrSessionReqFactory.BuildSessionReq(session, PrimitiveType.OPEN, cmd);
                break;
                
            case AAR:
                cmd = AARequestFactory.BuildAARequest(session.getConfig());
                dmrSsnReq = DmrSessionReqFactory.BuildSessionReq(session, PrimitiveType.OPEN, cmd);
                break;
                
            case ULR:
            default:
                cmd = null;
                if(session.getConfig().CmdType.equals("ULR"))
                  cmd = UpdateLocationRequestFactory.BuildUpdateLocationRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("AIR"))
                  cmd = AuthenticationInformationRequestFactory.BuildAuthenticationInformationRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("CLR"))
                  cmd = CancelLocationRequestFactory.BuildCancelLocationRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("DSR"))
                  cmd = DeleteSubscriberDataRequestFactory.BuildDeleteSubscriberDataRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("IDR"))
                  cmd = InsertSubscriberDataRequestFactory.BuildInsertSubscriberDataRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("ECR"))
                  cmd = MEIdentityCheckRequestFactory.BuildMEIdentityCheckRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("NOR"))
                  cmd = NotifyRequestFactory.BuildNotifyRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("RSR"))
                  cmd = ResetRequestFactory.BuildResetRequest(session.getConfig());
                else if(session.getConfig().CmdType.equals("PUR"))
                  cmd = PurgeUERequestFactory.BuildPurgeUERequest(session.getConfig());
                
                dmrSsnReq = DmrSessionReqFactory.BuildSessionReq(session, PrimitiveType.OPEN, cmd);
                break;
        }
        
        if(session.getConfig().PrxyFlag == false)
            cmd.setProxiableBit(false);

        try {
            int dmrSessionReqLen = session.getContext().userApi.dmrSessionReqEncoder.calculateLength(dmrSsnReq);
            GctMsg gctMsg = GctLib.getm(dmrSessionReqLen);
            session.getContext().userApi.dmrSessionReqEncoder.encode(dmrSsnReq, gctMsg);

            if (session.getConfig().TraceOn) {
                DtuMsgUtil.traceMsg("DTU>>", gctMsg);
            }
            GctLib.send((short) session.getConfig().DstMID, gctMsg);
        } catch (EncoderException eEx) {
            System.out.println("Problem with Encode/Decode" + eEx.getMessage());
        } catch (GctException gctEx) {
            System.out.println("Problem with message handling: " + gctEx.getMessage());
        } 

        // Move to the state that should handle the answer.
        switch (session.getConfig().Mode) {
            case CCR:
                super.setState(session, DTU_SessionState.roCSF_P_InitialState);
                break;
            case AAR:
            case ULR:
            default:
                super.setState(session, DTU_SessionState.authSL_PendingState);
                break;
        }
    }    
}
