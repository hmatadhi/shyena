/*
     
 Copyright (C) 2013 Dialogic Inc. All rights reserved.

 Name:        AARequestFactory.java

 Description: 
     
 Generates a Session Request for DTU. 
 
 -----    ---------   -----      ------------------------------------
 Issue    Date        By         Changes
 -----    ---------   -----      ------------------------------------
  1       23-Aug-13   RAJ        - Initial version


 */
package com.dialogic.signaling.dmr.dtu.requests;

import com.dialogic.signaling.diameter.rfc3588.avps.DestinationRealmAvp;
import com.dialogic.signaling.diameter.ts29211.AARequest;
import com.dialogic.signaling.diameter.ts29209.avps.MediaComponentDescriptionAvp;
import com.dialogic.signaling.diameter.ts29209.avps.MediaSubComponentAvp;
import com.dialogic.signaling.diameter.ts29209.avps.FlowNumberAvp;
import com.dialogic.signaling.diameter.ts29209.avps.FlowStatusAvp;
import com.dialogic.signaling.diameter.ts29209.avps.FlowUsageAvp;
import com.dialogic.signaling.diameter.ts29214.avps.MaxRequestedBandwidthULAvp;
import com.dialogic.signaling.diameter.ts29214.avps.MaxRequestedBandwidthDLAvp;
import com.dialogic.signaling.diameter.ts29214.avps.MediaComponentNumberAvp;
import com.dialogic.signaling.diameter.ts29214.avps.AFChargingIdentifierAvp;
import com.dialogic.signaling.diameter.ts29209.avps.SIPForkingIndicationAvp;


import com.dialogic.signaling.dmr.dtu.DtuConfig;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class AARequestFactory {

    public static AARequest BuildAARequest(DtuConfig dtuConfig) {

        try {
            AARequest aar = new AARequest();
            
            aar.setApplicationId(AARequest.StandardApplicationId);
            aar.addDestinationRealmAvp(new DestinationRealmAvp(dtuConfig.DestRealm));
            
            MediaComponentDescriptionAvp mcd = new MediaComponentDescriptionAvp(); {
            
                mcd.addMediaComponentNumberAvp(new MediaComponentNumberAvp((long) 1234));

                MediaSubComponentAvp msc = new MediaSubComponentAvp(); {
                    msc.addFlowNumberAvp(new FlowNumberAvp((long) 1234));
                    msc.addFlowStatusAvp(new FlowStatusAvp((long) 5674));
                    msc.addFlowUsageAvp(new FlowUsageAvp((long) 5674));
                    msc.addMaxRequestedBandwidthULAvp(new MaxRequestedBandwidthULAvp((long) 88));
                    msc.addMaxRequestedBandwidthDLAvp(new MaxRequestedBandwidthDLAvp((long) 44));
                }
                mcd.addMediaSubComponentAvp(msc);
            }
            aar.addMediaComponentDescriptionAvp(mcd);
            aar.addAFChargingIdentifierAvp(new AFChargingIdentifierAvp((ByteBuffer.wrap(new byte[]{(byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 6}))));
            aar.addSIPForkingIndicationAvp(new SIPForkingIndicationAvp(SIPForkingIndicationAvp.SIPForkingIndication.SINGLE_DIALOGUE.getValue()));
            
            //
            // Remaining parameters are optional...
            //
            return aar;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }
}
