/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        UserSrvEventListner.java

 Description:     

 Event Listner defining a local internal User Event.
 These events are local to the application

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1        15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu.events;

import com.dialogic.signaling.dmr.dtu.Session;


public interface UserSrvEventListner {
    public void handleUserSrvEvent(Session session, UserSrvEvent evt);    
}
