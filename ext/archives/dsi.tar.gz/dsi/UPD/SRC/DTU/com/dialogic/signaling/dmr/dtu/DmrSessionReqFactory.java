/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        DmrSessionReqFactory.java

 Description: 
     
 Generates Session Requests objects.
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1      26-Mar-12   - Initial version
 2      03-Oct-12   - Primitive value changes.

 */
package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.diameter.DiameterCommand;
import com.dialogic.signaling.dmr.user.DmrSessionReq;
import com.dialogic.signaling.dmr.user.PrimitiveType;

public class DmrSessionReqFactory {
    
    public static DmrSessionReq BuildSessionReq(Session session, PrimitiveType prim, DiameterCommand cmd) {
        DmrSessionReq sessionOpenReq = new DmrSessionReq();
        sessionOpenReq.networkContext = session.getConfig().NetworkContext;
        sessionOpenReq.primitiveType = prim;
        sessionOpenReq.sessionId = session.getSessionId();
        sessionOpenReq.diameterCommand = cmd;

        return sessionOpenReq;
    }    
}
