/*
     
 Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

 Name:        Session.java

 Description: 
     
 Models the whole Diameter session and the matching settings.
 It also holds the context information needed by the State objects
 and stores the current state of the session by storing 
 the singleton state object.
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1       15-Nov-12   - Initial version
 2       05-Dec-12   - Improved active count
 -       03-Nov-14   - Minor changes

 */

package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.dmr.DmrContext;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import com.dialogic.signaling.dmr.dtu.states.DTU_SessionState;

public final class Session {

    private Integer sessionId;
    private DTU_SessionState state;
    private DtuConfig config;
    private DmrContext context;
    static private Integer ActiveStateCount = 0;

    public static Integer getActiveStateCount() {
        return ActiveStateCount;
    }

    public DtuConfig getConfig() {
        return config;
    }

    public void setConfig(DtuConfig config) {
        this.config = config;
    }

    public DmrContext getContext() {
        return context;
    }

    public void setContext(DmrContext context) {
        this.context = context;
    }

    public DTU_SessionState getState() {
        return state;
    }

    public void setState(DTU_SessionState newState) {

        if (this.state != null) {
            if (this.state != newState) {

                // Active count is incremented if it is leaving idle,
                // count is decremented if it going back to idle.
                if (this.state == DTU_SessionState.idleState) {
                    ActiveStateCount++;
                } else if (newState == DTU_SessionState.idleState) {
                    ActiveStateCount--;
                }
            }
        }

        // Now we can set the state
        this.state = newState;
    }

    public Integer getSessionId() {
        return sessionId;
    }

    Session(Integer newSessionId, DtuConfig dtuConfig) {

        this.sessionId = newSessionId;
        this.setState(DTU_SessionState.idleState);
        this.config = dtuConfig;

    }

    public void handleUserSrvEvent(UserSrvEvent userSrv) {
        this.state.handleUserSrvEvent(this, userSrv);
    }

    public void handleDmrSessionIndEvent(DmrSessionIndEvent evt) {
        this.state.handleDmrSessionIndEvent(this, evt);
    }

    //
    // Debug and trace methods below.
    //

    public void printDebug(String outString) {
        System.out.print("Session [0x" + String.format("%04x] ", this.getSessionId()) + outString);
    }

    public void printTrace(String outString) {
        //Re-use the debug print, but only if trace is on.
        if (this.config.TraceOn) {
            this.printDebug(outString);
        }
    }

    public void printlnTrace(String outString) {
        //Re-use the debug print, but only if trace is on.
        if (this.config.TraceOn) {
            this.printDebug(outString + "\n");
        }
    }

    public void printlnDebug(String outString) {
        this.printDebug(outString + "\n");
    }
}
