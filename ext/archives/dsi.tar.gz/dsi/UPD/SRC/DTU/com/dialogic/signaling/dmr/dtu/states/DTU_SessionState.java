/*
     
     Copyright (C) 2012 Dialogic Inc. All rights reserved.

     Name:        DTU_SessionState.java

     Description: 
     
     Used by the all modes. This abstract state acts as a super-class to
     the others and defines the singleton objects used to make state changes.
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      15-Nov-12    JTD       Initial version

 */
package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEventListner;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEventListner;

public abstract class DTU_SessionState implements UserSrvEventListner, DmrSessionIndEventListner {
      
    static public final DTU_SessionState idleState = new DTU_IdleState();
    static public final DTU_SessionState startupState = new DTU_StartupState();    
    static public final DTU_SessionState authSL_PendingState = new AuthSL_PendingState();
    static public final DTU_SessionState roCSF_P_InitialState = new RoCSF_P_InitialState();
    static public final DTU_SessionState roCSF_P_TermState = new RoCSF_P_TermState();
    static public final DTU_SessionState roCSF_OpenState = new RoCSF_OpenState();
    
    protected DTU_SessionState() {
    }

    public void setState(Session session, DTU_SessionState newState) {
        
        if (session.getConfig().TraceOn) {
            System.out.print("Session [0x" + String.format("%04x]", session.getSessionId()));
            System.out.println(" State Change from [" + session.getState().toString() + "] to [" + newState.toString() + "]");           
        }

        session.setState(newState);
    }    
    
   
}
