/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        SessionStore.java

 Description:     

 Container for Session objects. Allows idle sessions to be found
 and other such helper functionality.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1        15-Nov-12   - Initial version
 2        05-Dec-12   - Improved active count


 */
package com.dialogic.signaling.dmr.dtu;

import com.dialogic.signaling.dmr.dtu.states.DTU_SessionState;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 */
public class SessionStore {

    static private ArrayList<Session> dmrSessions = new ArrayList<Session>();
    static Integer nextToUse = 0;
    private DtuConfig config;

    SessionStore(DtuConfig cliConfig) {
        config = cliConfig;

        for (int i = 0; i < config.MaxSsnNum; i++) {
            dmrSessions.add(new Session(i + config.BaseSsnNum, config));
        }
    }

    public Session get(Integer id) {

        if (this.isValid(id) == false) {
            return null;
        }

        return (dmrSessions.get(id - config.BaseSsnNum));
    }

    public Session findIdle() {

        Session session = null;

        //Look starting at the last used.
        Iterator<Session> iter = dmrSessions.listIterator(nextToUse);

        while (iter.hasNext()) {
            session = iter.next();
            if (session.getState() == DTU_SessionState.idleState) {
                if (iter.hasNext()) {
                    nextToUse++;
                } else {
                    nextToUse = 0;
                }

                // Found an idle one
                return (session);
            }
        }

        return session;
    }

    public Boolean isValid(Integer id) {
        if ((id < config.BaseSsnNum) || (id > (config.BaseSsnNum + config.MaxSsnNum - 1))) {
            return false;
        }

        return true;
    }

    public Integer numActive() {   
        return (Session.getActiveStateCount());
    }
}
