/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        RoCSF_P_TermState.java

 Description: 
     
 Used by the CCR modes. This state models a service which is pending
 confirmation of the CCR request (term).
 
 -----    ---------   -----      ------------------------------------
 Issue    Date        By         Changes
 -----    ---------   -----      ------------------------------------
 1      15-Nov-12    JTD       Initial version

 */
package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.diameter.rfc4006.CreditControlAnswer;
import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;

public class RoCSF_P_TermState extends DTU_SessionState {

    @Override
    public String toString() {
        return ("RoCSF_P_TermState");
    }

    @Override
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt) {

        switch (evt.getInd().primitiveType) {
            case CLOSE:
                if (evt.getInd().diameterCommand.getCommandCode() == CreditControlAnswer.StandardCommandCode) {
                    //All done now
                    session.printlnTrace("Success: Service Finished");
                    this.setState(session, idleState);
                } else {
                    //Not expecing this command, so close things down!
                    session.printlnDebug("Unexpected Command: Service Finished");
                    this.setState(session, idleState);
                }
                break;
            case OPEN:
            case CONTINUE:
            case P_ABORT:
            case NOTIFY:
            case ABORT:
            case TERMINATE:
            case RE_AUTH:
            default:
                //Not expecing this , so close things down!
                session.printlnDebug("Unexpected Primitive:Service Finished");
                this.setState(session, idleState);
                break;
        }


    }

    @Override
    public void handleUserSrvEvent(Session session, UserSrvEvent evt) {

        //Not expecing that User Event, so close things down!
        session.printlnDebug("Unexpected User Srv Event Ind");
        this.setState(session, idleState);
    }
}
