/*
     
 Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

 Name:        AuthSL_PendingState.java

 Description: 
     
 Used by the ULR mode. This state models waiting pending an answer to
 a ULR/AAR and checks for ULA/AAA.
 
 -----    ---------   -----      ------------------------------------
 Issue    Date        By         Changes
 -----    ---------   -----      ------------------------------------
 1      15-Nov-12    JTD       Initial version
 2      19-Sep-13    RAJ       Add Rx support
 -      07-Nov-14    CJM         Minor changes
 */

package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.diameter.ts29272.UpdateLocationAnswer;
import com.dialogic.signaling.diameter.ts29211.AAAnswer;
import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;
import com.dialogic.signaling.dmr.user.PrimitiveType;
import java.io.UnsupportedEncodingException;

/**
 *
 */
public class AuthSL_PendingState extends DTU_SessionState {

    @Override
    public String toString() {
        return ("AuthSL_PendingState");
    }

    @Override
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt) {

        session.printTrace("");
        if (evt.getInd().primitiveType == PrimitiveType.CLOSE)
        {
            if (evt.getInd().diameterCommand.getCommandCode() == UpdateLocationAnswer.StandardCommandCode) {
                UpdateLocationAnswer ula = (UpdateLocationAnswer) evt.getInd().diameterCommand;
                try {
                    session.printlnTrace("Command Code Matches");
                    if (ula.getOriginHostAvp() != null) {
                        session.printlnTrace("Origin Host:" + ula.getOriginHostAvp().getString());
                    }
                    if (ula.getOriginRealmAvp() != null) {
                        session.printlnTrace("Origin Realm:" + ula.getOriginRealmAvp().getString());;
                    }
                } catch (UnsupportedEncodingException ex) {
                    session.printlnTrace("Failed to recover AVP" + ex.toString());
                }
            } else if (evt.getInd().diameterCommand.getCommandCode() == AAAnswer.StandardCommandCode) {
                AAAnswer aaa = (AAAnswer) evt.getInd().diameterCommand;
                try {
                    session.printlnTrace("Command Code Matches");
                    if (aaa.getOriginHostAvp() != null) {
                        session.printlnTrace("Origin Host:" + aaa.getOriginHostAvp().getString());
                    }
                    if (aaa.getOriginRealmAvp() != null) {
                        session.printlnTrace("Origin Realm:" + aaa.getOriginRealmAvp().getString());;
                    }
                } catch (UnsupportedEncodingException ex) {
                    session.printlnTrace("Failed to recover AVP" + ex.toString());
                }
            } else {
              session.printlnTrace("Unexpected Command Code");
            }
        } else {
            session.printlnTrace("Unexpected Session Indication");
        }

        //Done, make it idleCount again
        this.setState(session, idleState);
    }

    @Override
    public void handleUserSrvEvent(Session session, UserSrvEvent evt) {
        //Do nothing.        
    }
}
