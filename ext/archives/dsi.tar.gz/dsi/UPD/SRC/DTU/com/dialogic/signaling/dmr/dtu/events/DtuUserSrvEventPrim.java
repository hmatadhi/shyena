/*
     
 Copyright (C) 2012 Dialogic Inc. All rights reserved.

 Name:        DtuUserSrvEventPrim.java

 Description:     

 Represent a simulated event primitive type value.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1        15-Nov-12   - Initial version

 */
package com.dialogic.signaling.dmr.dtu.events;

/**
 *
 */
public enum DtuUserSrvEventPrim {
    
    REQ_SRV(0),
    SRV_AUTH(1),
    SRV_COMPLETE(2),
    SRV_TERM(3);     
    
    private int eventPrim;

    private DtuUserSrvEventPrim(int prim) {        
        this.eventPrim = prim;
    }

    public int value() {
        return (eventPrim);
    }
}
