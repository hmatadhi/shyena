/*
     
 Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

 Name:        DtuMode.java

 Description: 
     
 Defines the modes for the DTU module - this controls the 
 commands requested.
 
 -----    ---------   ------------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
  1       15-Nov-12   - Initial version
  2       19-Sep-13   - Add Rx support
          03-Dec-14   - Added comments
 */

package com.dialogic.signaling.dmr.dtu;

/**
 * DtuMode is an enum class that defines the DTU mode.
 *   ULR - sends ULR or other messages types as defined by the -cmd option
 *   CCR - sends CCR
 *   AAR - sends AAR
 */
public enum DtuMode {
    ULR(0),
    CCR(1),
    AAR(2); 
    private int mode;

    private DtuMode(int mode) {        
        this.mode = mode;
    }

    public int value() {
        return (mode);
    }
}
