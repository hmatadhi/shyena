/*
     Copyright (C) 2013-2014 Dialogic Inc. All rights reserved.

     Name:        CancelLocationAnswerFactory.java

     Description: Builds an CLA Response

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
              03-Dec-14   - Source copied from DTR
 */

package com.dialogic.signaling.dmr.dtu.requests;

import com.dialogic.signaling.diameter.ResultCode;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.ResultCodeAvp;
import com.dialogic.signaling.diameter.ts29272.CancelLocationAnswer;

public class CancelLocationAnswerFactory {

    public static CancelLocationAnswer BuildCancelLocationAnswer() {

            CancelLocationAnswer req = new CancelLocationAnswer();

            // Session ID, Origin Host and Realm AVPs are set by the Diameter (DMR) module

            req.addResultCodeAvp(new ResultCodeAvp(ResultCode.DIAMETER_SUCCESS.getValue()));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            return req;
    }
}
