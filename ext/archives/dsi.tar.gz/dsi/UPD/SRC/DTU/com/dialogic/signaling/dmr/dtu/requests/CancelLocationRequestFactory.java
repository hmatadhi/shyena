/*
     
     Copyright (C) 2014 Dialogic Inc. All rights reserved.

     Name:        CancelLocationRequestFactory.java

     Description: 
     
     Generates a Cancel Location Request for DTU. 
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      21-Jan-14    HJM       Initial version


 */
package com.dialogic.signaling.dmr.dtu.requests;

import com.dialogic.signaling.diameter.rfc3588.avps.AuthApplicationIDAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationRealmAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.RouteRecordAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.UserNameAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.VendorIDAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.VendorSpecificApplicationIDAvp;
import com.dialogic.signaling.diameter.ts29272.AuthenticationInformationRequest;
import com.dialogic.signaling.diameter.ts29272.CancelLocationRequest;
import com.dialogic.signaling.diameter.ts29272.avps.NumberOfRequestedVectorsAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ReSynchronizationInfoAvp;
import com.dialogic.signaling.diameter.ts29272.avps.RequestedEutranAuthenticationInfoAvp;
import com.dialogic.signaling.dmr.dtu.DtuConfig;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class CancelLocationRequestFactory {

    public static CancelLocationRequest BuildCancelLocationRequest(DtuConfig dtuConfig) {

        try {
            CancelLocationRequest req = new CancelLocationRequest();
            req.setApplicationId(0x1000023);

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));
            req.addDestinationHostAvp(new DestinationHostAvp(dtuConfig.DestHost));
            req.addDestinationRealmAvp(new DestinationRealmAvp(dtuConfig.DestRealm));
            req.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            req.addUserNameAvp(new UserNameAvp(dtuConfig.Imsi));
            
            VendorSpecificApplicationIDAvp vendorSpecificApplicationID = new VendorSpecificApplicationIDAvp();
            vendorSpecificApplicationID.addAuthApplicationIDAvp(new AuthApplicationIDAvp((long)0x1000023));
            vendorSpecificApplicationID.addVendorIDAvp(new VendorIDAvp((long) 10415));
            req.addVendorSpecificApplicationIDAvp(vendorSpecificApplicationID);
            
            if(dtuConfig.RRec != null)
            {
                RouteRecordAvp rrAvp = new RouteRecordAvp(dtuConfig.RRec);
                req.addRouteRecordAvp(rrAvp);
            }       

            return req;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }
}
