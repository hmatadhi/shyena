/*
     
     Copyright (C) 2012 Dialogic Inc. All rights reserved.

     Name:        DTU_IdleState.java

     Description: 
     
     Used by the all modes. This state models an idle session.
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      15-Nov-12    JTD       Initial version

 */
package com.dialogic.signaling.dmr.dtu.states;

import com.dialogic.signaling.dmr.dtu.Session;
import com.dialogic.signaling.dmr.dtu.events.DmrSessionIndEvent;
import com.dialogic.signaling.dmr.dtu.events.UserSrvEvent;

public class DTU_IdleState extends DTU_SessionState {       
             
    @Override public String toString() {
        return ("Idle");
    }             
    
    @Override
    public void handleDmrSessionIndEvent(Session session, DmrSessionIndEvent evt) {
             
    }         
    
   @Override
    public void handleUserSrvEvent(Session session, UserSrvEvent evt) {              
    }    
}
