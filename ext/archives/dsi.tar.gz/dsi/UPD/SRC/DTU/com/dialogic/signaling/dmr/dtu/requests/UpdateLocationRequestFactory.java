/*
     
     Copyright (C) 2012-2014 Dialogic Inc. All rights reserved.

     Name:        UpdateLocationRequestFactory.java

     Description: 
     
     Generates an Update Location Request for DTU. 
 
     -----    ---------   -----      ------------------------------------
     Issue    Date        By         Changes
     -----    ---------   -----      ------------------------------------
       1      26-Mar-12    HJM       Initial version
       2      11-Oct-12    JTD       Clairfied session id handling
       3      15-Nov-12    JTD       Move to requests package
              03-Dec-14    CJM       Added comments
 */

package com.dialogic.signaling.dmr.dtu.requests;

import com.dialogic.signaling.diameter.rfc3588.avps.AuthApplicationIDAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.AuthSessionStateAvp.AuthSessionState;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.DestinationRealmAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyHostAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyInfoAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.ProxyStateAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.RouteRecordAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.UserNameAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.VendorIDAvp;
import com.dialogic.signaling.diameter.rfc3588.avps.VendorSpecificApplicationIDAvp;
import com.dialogic.signaling.diameter.rfc4004.avps.MipHomeAgentHostAvp;
import com.dialogic.signaling.diameter.rfc5447.avps.Mip6AgentInfoAvp;
import com.dialogic.signaling.diameter.ts29212.avps.RatTypeAvp;
import com.dialogic.signaling.diameter.ts29229.avps.FeatureListAvp;
import com.dialogic.signaling.diameter.ts29229.avps.SupportedFeaturesAvp;
import com.dialogic.signaling.diameter.ts29272.UpdateLocationRequest;
import com.dialogic.signaling.diameter.ts29272.avps.ActiveApnAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ContextIdentifierAvp;
import com.dialogic.signaling.diameter.ts29272.avps.ImeiAvp;
import com.dialogic.signaling.diameter.ts29272.avps.TerminalInformationAvp;
import com.dialogic.signaling.diameter.ts29272.avps.UESrvccCapabilityAvp;
import com.dialogic.signaling.diameter.ts29272.avps.UlrFlagsAvp;
import com.dialogic.signaling.dmr.dtu.DtuConfig;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class UpdateLocationRequestFactory {

    public static UpdateLocationRequest BuildUpdateLocationRequest(DtuConfig dtuConfig) {

        try {
            UpdateLocationRequest ulr = new UpdateLocationRequest();
            ulr.setApplicationId(0x1000023);

            // No need to add the sessionIDAvp manually, using the correct session identifier
            // will add it for you.
            //ulr.addSessionIDAvp(new SessionIDAvp("0"));

            // The Origin Host and Realm are set by the Diameter (DMR) module.
            //ulr.addOriginHostAvp(new OriginHostAvp("OriginHost"));
            //ulr.addOriginRealmAvp(new OriginRealmAvp("OriginRealm"));
            
            ulr.addDestinationHostAvp(new DestinationHostAvp(dtuConfig.DestHost));
            ulr.addDestinationRealmAvp(new DestinationRealmAvp(dtuConfig.DestRealm));
            ulr.addAuthSessionStateAvp(new AuthSessionStateAvp(AuthSessionState.NO_STATE_MAINTAINED));

            Mip6AgentInfoAvp mip6AgentInfoAvp = new Mip6AgentInfoAvp();

            MipHomeAgentHostAvp mipHomeAgentHost = new MipHomeAgentHostAvp();
            mipHomeAgentHost.addDestinationHostAvp(new DestinationHostAvp("ActiveApn.Mip6AgentInfo.MipHomeAgentHost.DestinationHost"));
            mipHomeAgentHost.addDestinationRealmAvp(new DestinationRealmAvp("ActiveApn.Mip6AgentInfo.MipHomeAgentHost.DestinationRealm"));
            mip6AgentInfoAvp.addMipHomeAgentHostAvp(mipHomeAgentHost);

            ActiveApnAvp activeApnAvp = new ActiveApnAvp();
            activeApnAvp.addContextIdentifierAvp(new ContextIdentifierAvp(12345L));
            activeApnAvp.addMip6AgentInfoAvp(mip6AgentInfoAvp);
            ulr.addActiveApnAvp(activeApnAvp);

            ProxyInfoAvp proxyInfo = new ProxyInfoAvp();
            proxyInfo.addProxyHostAvp(new ProxyHostAvp("ProxyInfo.ProxyHost"));
            proxyInfo.addProxyStateAvp(new ProxyStateAvp(ByteBuffer.wrap(new byte[]{(byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5})));
            ulr.addProxyInfoAvp(proxyInfo);

            ulr.addRatTypeAvp(new RatTypeAvp(RatTypeAvp.RatType.GERAN));

            ulr.addUESrvccCapabilityAvp(new UESrvccCapabilityAvp(UESrvccCapabilityAvp.UESrvccCapability.UE_SRVCC_SUPPORTED));
            ulr.addUlrFlagsAvp(new UlrFlagsAvp((long) 0x1234));
            ulr.addUserNameAvp(new UserNameAvp(dtuConfig.Imsi));
            
            TerminalInformationAvp termInfoAvp = new TerminalInformationAvp();
            termInfoAvp.addImeiAvp(new ImeiAvp(dtuConfig.Imei));
            ulr.addTerminalInformationAvp(termInfoAvp);
            
            SupportedFeaturesAvp supFeatAvp  = new SupportedFeaturesAvp();
            FeatureListAvp fla = new FeatureListAvp((long)0x12345678);
            supFeatAvp.addFeatureListAvp(fla);
            ulr.addSupportedFeaturesAvp(supFeatAvp);
            
            VendorSpecificApplicationIDAvp vendorSpecificApplicationID = new VendorSpecificApplicationIDAvp();
            vendorSpecificApplicationID.addAuthApplicationIDAvp(new AuthApplicationIDAvp((long)0x1000023));
            vendorSpecificApplicationID.addVendorIDAvp(new VendorIDAvp((long) 10415));
            ulr.addVendorSpecificApplicationIDAvp(vendorSpecificApplicationID);
            
            if(dtuConfig.RRec != null)
            {
                RouteRecordAvp rrAvp = new RouteRecordAvp(dtuConfig.RRec);
                ulr.addRouteRecordAvp(rrAvp);
            }       

            return ulr;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Couldn't Create AVP:" + ex.getMessage());
            return null;
        }
    }
}
