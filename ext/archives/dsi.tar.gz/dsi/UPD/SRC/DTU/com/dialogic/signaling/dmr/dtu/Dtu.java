/*
     
 Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

 Name:        Dtu.java

 Description: 
     
 Main Class for DTU Test Application.
 A command line application for generation of Diameter Requests.

 -----    ---------   -----------------------------------
 Issue    Date        Changes
 -----    ---------   ------------------------------------
 1      26-Mar-12   - Initial version
 2      28-Sep-12   - Syntax print
 3      05-Dec-12   - Correct session start-up 
 4      19-Sep-13   - Add Rx support
        03-Nov-14   - Added send delay option and code version
        20-Feb-15   - Moved DtuCodeIssue to new java class and file
                    - Changed DTU to use GCT Tick messages to allow real time delays
 */

package com.dialogic.signaling.dmr.dtu;

public class Dtu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        DtuConfig config;

        // Process and parse the command line options        
        try {
            config = new DtuConfig(args);
        } catch (CommandLineException cliEx) {
            System.out.println(cliEx.getMessage() + "\n");
            return;
        }

        //Request that GCT Timer module starts sending Tick messages to DTU
        try {
            DtuMsgUtil.timerTicksStart(config.SrcMID);
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return;
        }

        //Create a new top level handler for processing sessions.
        RequestHandler reqHandler = new RequestHandler(config);

        long startTimeMs = System.currentTimeMillis();
        int sessionCount = 0;

        try {
            //Loop adding new sessions as appropriate
            while (sessionCount < config.NumReq) {
                if (reqHandler.numActive() < config.MaxInFlight) {
                    // Send request
                    if (config.TraceOn) {
                        System.out.println("Active:" + reqHandler.numActive() + ":Start New");
                    }
                    reqHandler.startNewSession();
                    sessionCount++;

                    // If repeat delay is set, wait delay after send
                    int waitDelay = config.RepeatDelay * 10;
                    while (waitDelay > 0) {
                            //Process any pending messages from message passing environment 
                        switch(reqHandler.handleMsg())
                        {
                            case (0):
                            //Check for and process locally generated events
                            reqHandler.handleLocalUserSrvEvent();
                                break;
                            case (1):
                                //When GCT tick message received, decrement delay count
                                waitDelay--;
                                break;
                            default:
                                //Ignore errors or unrecognised msgs
                                break;
                        }
                    }
                } else {
                    // When maximum number of requests are inflight, wait for a received message
                    if (config.TraceOn) {
                        System.out.println("Active:" + reqHandler.numActive() + ":Process Old");
                    }
                    //Process any pending messages from message passing environment 
                    reqHandler.handleMsg();

                    //Check for and process locally generated events
                    reqHandler.handleLocalUserSrvEvent();
                }
            }

            if (config.TraceOn) {
                System.out.println("Processing remaining sessions");
            }

            //Waiting for outstanding sessions
            while (reqHandler.numActive() > 0) {
                reqHandler.handleMsg();
                reqHandler.handleLocalUserSrvEvent();
            }

            long elapsedTimeMs = System.currentTimeMillis() - startTimeMs;
            float sessionRate = sessionCount * 1000 / elapsedTimeMs;
            System.out.println("Num Sessions:" + sessionCount);
            System.out.println("ElapsedTime (ms):" + elapsedTimeMs);
            System.out.println("SessionRate: " + sessionRate);

        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            //Instruct GCT Timer module to stop sending Tick messages to DTU
            DtuMsgUtil.timerTicksStop(config.SrcMID);
        }
    }
}
