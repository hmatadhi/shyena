/*
     
     Copyright (C) 2012-2015 Dialogic Inc. All rights reserved.

     Name:        DtuConfig.java

     Description: 
     
     Utility Class for Command Line handling and syntax print.

     -----    ---------   ------------------------------------
     Issue    Date        Changes
     -----    ---------   ------------------------------------
       1      26-Mar-12   - Initial version
       2      28-Sep-12   - Minor printout update
                          - Trace off mode
                          - Syntax print
       3      05-Dec-12   - Set NC and Base Session id
       4      19-Sep-13   - Add Rx support
              03-Nov-14   - Added -rptdelay
                          - Updated syntax output
              20-Feb-15   - Moved DtuCodeIssue to new java class and file
 */

package com.dialogic.signaling.dmr.dtu;

public class DtuConfig {

    // Default Values
    public short SrcMID = (short) 0x1d;
    public short DstMID = (short) 0x74;
    public int NumReq = 1;
    public int MaxSsnNum = 1024;
    public int BaseSsnNum = 0;
    public int MaxInFlight = 1;
    public int NetworkContext = 0;
    public int RepeatDelay = 0;
    public DtuMode Mode = DtuMode.ULR;
    public String DestHost = "dmr02.lab.dialogic.com";
    public String DestRealm = "lab.dialogic.com";
    public Boolean TraceOn = true;
    public String Imsi = "123451234512345";
    public String RRec = null;
    public String Imei = "222223333344444";
    public String CmdType = "ULR";
    public Boolean PrxyFlag = true;
    
    // Run time options
    private final String SrcMIDOption = "-m";
    private final String DstMIDOption = "-dmr";
    private final String DestHostOption = "-dsth";
    private final String DestRealmOption = "-dstr";
    private final String ImsiOption = "-imsi";
    private final String RRecOption = "-rrec";
    private final String ImeiOption = "-imei";
    private final String NumReqOption = "-numreq";
    private final String MaxInFlightOption = "-maxin";
    private final String MaxSsnOption = "-maxssn";
    private final String BaseSsnOption = "-basessn";    
    private final String TraceOffOption = "-traceoff";
    private final String NCOption = "-nc";
    private final String ModeOption = "-mode"; 
    private final String CmdTypeOption = "-cmd";
    private final String PrxyFlagOption = "-prxy";
    private final String RepeatDelayOption = "-rptdelay";


    public DtuConfig(String[] args) throws CommandLineException {
        Short tempShort;
        Integer tempInt;

        System.out.println("DSI DTU Diameter Test Utility Release " + DtuIssue.DtuCodeIssue);
        System.out.println("Part of the Dialogic(R) DSI Development Package");
        System.out.println("Copyright (C) 2012-2015 Dialogic Inc. All Rights Reserved.");
        System.out.println("");

        for (String s : args) {
            
            tempInt = parseUnsignedIntOption(s, MaxInFlightOption);
            if (tempInt != null) {
                MaxInFlight = tempInt;
                continue;
            }

            tempInt = parseUnsignedIntOption(s, MaxSsnOption);
            if (tempInt != null) {
                MaxSsnNum = tempInt;
                continue;
            }

            tempInt = parseUnsignedIntOption(s, BaseSsnOption);
            if (tempInt != null) {
                BaseSsnNum = tempInt;
                continue;
            }     

            tempInt = parseUnsignedIntOption(s, RepeatDelayOption);
            if (tempInt != null) {
                RepeatDelay = tempInt;
                continue;
            }     

            tempInt = parseUnsignedIntOption(s, ModeOption);
            if (tempInt != null) {           
                Boolean found = false;
                for (DtuMode imode: DtuMode.values()){
                    if (imode.value() == tempInt) {                       
                        this.Mode = imode;
                        found = true;
                        break;
                    }
                }
                if (found == false)
                    throw new CommandLineException("Invalid mode");
                continue;
            } 
            
            tempShort = parseModIdOption(s, SrcMIDOption);
            if (tempShort != null) {
                SrcMID = tempShort;
                continue;
            }

            tempShort = parseModIdOption(s, DstMIDOption);
            if (tempShort != null) {
                DstMID = tempShort;
                continue;
            }

            if (s.startsWith(DestHostOption)) {
                DestHost = s.substring(DestHostOption.length());
                if (DestHost.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for destination host option: " + s);
                }
            }

            if (s.startsWith(DestRealmOption)) {
                DestRealm = s.substring(DestRealmOption.length());
                if (DestRealm.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for destination realm option: " + s);
                }
            }
            
            if (s.startsWith(ImsiOption)) {
                Imsi = s.substring(ImsiOption.length());
                if (Imsi.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for IMSI option: " + s);
                }
            }
            
            if (s.startsWith(ImeiOption)) {
                Imei = s.substring(ImeiOption.length());
                if (Imei.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for IMEI option: " + s);
                }
            }
            
            if (s.startsWith(RRecOption)) {
                RRec = s.substring(RRecOption.length());
                if (RRec.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for Route Record option: " + s);
                }
            }

            if (s.startsWith(CmdTypeOption)) {
                CmdType = s.substring(CmdTypeOption.length());
                if (CmdType.isEmpty()) {
                    throw new CommandLineException("Invalid empty value for Command Type option: " + s);
                }
            }

            tempInt = parseUnsignedIntOption(s, NumReqOption);
            if (tempInt != null) {
                NumReq = tempInt;
                continue;
            }                      
            
            tempInt = parseUnsignedIntOption(s, NCOption);
            if (tempInt != null) {
                NetworkContext = tempInt;
                continue;
            }            

            if (s.startsWith(TraceOffOption)) {
                TraceOn = false;
                continue;
            }

            if (s.startsWith(PrxyFlagOption)) {
                PrxyFlag = false;
                continue;
            }

            if ((s.startsWith("-h")) || (s.startsWith("-?"))) {
                showHelp();
                throw new CommandLineException("");
            }
        }    
           
        
        System.out.println("DTU module id: 0x" + String.format("%02x", SrcMID));
        System.out.println("DMR module id: 0x" + String.format("%02x", DstMID));
        System.out.println("NumReq: " + NumReq);
        System.out.println("MaxSsnNum: " + MaxSsnNum);
        System.out.println("BaseSsnNum: " + BaseSsnNum);        
        System.out.println("MaxInFlight: " + MaxInFlight);
        if (RepeatDelay > 0)
            System.out.println("Delay between senting requests (secs): " + RepeatDelay);
            
        /*
         * DestHost is not used for AAR, don't display the (defaulted) value.
         */ 
        if (this.Mode != DtuMode.AAR)
          System.out.println("Dest Host: " + DestHost);
        System.out.println("Dest Realm: " + DestRealm);
        System.out.println("Network Context: " + NetworkContext);        
        System.out.println("Mode: " + Mode.toString() + "(" + Mode.value() + ")");  
        if (!CmdType.equals("ULR")) {
            if (Mode != DtuMode.ULR)
                System.out.println("Command Type(" + CmdType + ") ignored");
            else
          System.out.println("Command Type: " + CmdType);  
        }
        if (PrxyFlag == false) {
            System.out.println("Prxy Flag: Off");
        }
        if (TraceOn == false) {
            System.out.println("Trace: Off");
        }
        System.out.println("");
    }

    private void showHelp() {
        System.out.println("Syntax: dtu.jar [-m<> -dmr<> -dsth<> -dstr<> ");
        System.out.println("                -numreq<> -maxin<> " + RepeatDelayOption + "<>");
        System.out.println("                -maxssn<> -basessn<> -nc<>");
        System.out.println("                -mode<> -cmd<> -imsi<> -imei<>");
        System.out.println("                -rrec<> -prxy -traceoff]");
        System.out.println("        DTU Sends Diameter Session Requests");
        System.out.println("Example:  java -jar dtu.jar -numreq1000");
        System.out.println();
        System.out.println("Options: " + SrcMIDOption + "[] DTU Module Id ");
        System.out.println("        Sets the module id for DTU");
        System.out.println();
        System.out.println("        " + DstMIDOption + "[] DMR Module Id ");
        System.out.println("        Sets the module id for the Diameter Module (DMR)");
        System.out.println();
        System.out.println("        " + DestHostOption + "[] Dest Host ");
        System.out.println("        " + DestRealmOption + "[] Dest Realm ");
        System.out.println("        Set the Destination Host and Realm addresses");
        System.out.println();
        System.out.println("        " + NumReqOption + "[] Number of requests ");
        System.out.println("        Sets the total number of Update Location Requests to send");
        System.out.println();
        System.out.println("        " + MaxInFlightOption + "[] Max sessions in flight ");
        System.out.println("        Sets the maximum number of session active at once");
        System.out.println();
        System.out.println("        " + RepeatDelayOption + "[] Repeat delay ");
        System.out.println("        Sets the time in seconds between sending requests (default 0)");
        System.out.println();
        System.out.println("        " + MaxSsnOption + "[] Max session");
        System.out.println("        Sets the maximum number of session ids to use");
        System.out.println();
        System.out.println("        " + BaseSsnOption + "[] Base session id");
        System.out.println("        Sets the base session id to use (default 0)");
        System.out.println();        
        System.out.println("        " + NCOption + "[] NetworkContext ");
        System.out.println("        Sets the Network Context value");
        System.out.println();
        System.out.println("        " + ModeOption + "[] Mode");
        System.out.println("        Sets the mode for the sessions to use:");   
        /*
         *  Iterate the DtuMode enum, printing the options
         */
        for (DtuMode smode: DtuMode.values()){
            System.out.println("        Send " + smode.toString() + ": Set mode to " + smode.value() 
                             + ((smode==DtuMode.ULR)?" (default)":""));        
        }
        System.out.println();
        System.out.println("        " + RRecOption + "[] Route Record Value");
        System.out.println("        Adds a Route Record AVP to the request");
        System.out.println();
        System.out.println("        " + ImsiOption + "[] IMSI Value");
        System.out.println("        Sets the value of the UserName Avp");   
        System.out.println();
        System.out.println("        " + ImeiOption + "[] IMEI Value");
        System.out.println("        Sets the value of the Imei Avp");   
        System.out.println();
        System.out.println("        " + CmdTypeOption + "[] Cmd Type");
        System.out.println("        Sets the command type, when " + ModeOption + " is set for ULR or not defined:");
        /*
         * Display Command types
         */
        System.out.println("        set to 'ULR' to send UpdateLocationRequest");
        System.out.println("        set to 'AIR' to send AuthenticationInformationRequest");
        System.out.println("        set to 'CLR' to send CancelLocationRequest");
        System.out.println("        set to 'DSR' to send DeleteSubscriberDataRequest");
        System.out.println("        set to 'IDR' to send InsertSubscriberDataRequest");
        System.out.println("        set to 'ECR' to send MEIdentityCheckRequest");
        System.out.println("        set to 'NOR' to send NotifyRequest");
        System.out.println("        set to 'RSR' to send ResetRequest");
        System.out.println("        set to 'PUR' to send PurgeUERequest");
        System.out.println();
        
        System.out.println("        " + PrxyFlagOption + " clears the Proxiable bit in requests");
        System.out.println();
        System.out.println("        " + TraceOffOption + " Turn Trace Off");
    }

    private Short parseModIdOption(String arg, String opt) throws CommandLineException {

        Short shortVal = null;

        if (arg.startsWith(opt)) {
            try {
                shortVal = Short.decode(arg.substring(opt.length())).shortValue();

                if ((shortVal <= 0) || (shortVal > 0xff)) {
                    // Not a valid mod id
                    throw new CommandLineException("Invalid value for module ids in option: " + opt);
                }

            } catch (CommandLineException cliEx) {
                throw cliEx;
            } catch (NumberFormatException ex) {
                throw new CommandLineException("Invalid data format for option: " + opt, ex);
            } catch (Exception ex) {
                throw new CommandLineException("Exception when processing data for option: " + opt + "," + ex.toString(), ex);
            }
        }
        return shortVal;
    }

    private Integer parseUnsignedIntOption(String arg, String opt) throws CommandLineException {

        Integer intVal = null;

        if (arg.startsWith(opt)) {
            try {
                intVal = Integer.decode(arg.substring(opt.length())).intValue();

                if (intVal < 0) {
                    // Don't want negative values
                    throw new CommandLineException("Invalid negative value in option: " + opt);
                }

            } catch (CommandLineException cliEx) {
                throw cliEx;
            } catch (NumberFormatException ex) {
                throw new CommandLineException("Invalid data format for option: " + opt, ex);
            } catch (Exception ex) {
                throw new CommandLineException("Exception when processing data for option: " + opt + "," + ex.toString(), ex);
            }
        }
        return intVal;
    }
}

class CommandLineException extends Exception {

    public CommandLineException(String message) {
        super(message);
    }

    public CommandLineException(String message, Exception ex) {
        super(message, ex);
    }
}


