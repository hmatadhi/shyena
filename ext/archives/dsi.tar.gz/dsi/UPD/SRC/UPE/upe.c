/*
		Copyright (C) Dialogic Corporation 1995-2006. All Rights Reserved.

 Name:          upe.c

 Description:   Example application for interfacing as a User Part
                directly with the Message Transfer Part running in
                the DataKinetics System7 software environment.

                The application receives MTP indications (MTP-PAUSE,
                MTP-RESUME and MTP-STATUS) and reports them to the
                user. It also receives MTP-TRANSFER indications,
                reports them to the user and loops back all messages
                to the MTP (using an MTP-TRANSFER request) after
                swapping the opc and the dpc.

                The example demonstrates the use of the library
                functions GCT_receive() & GCT_send() for inter-process
                communication, the functions getm() & relm() for
                message buffer allocation and release, and the outline
                structure of a user part process.

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   1    22-Jun-95   SRG   - Derived from STU.C, issue B.
   2    21-Apr-98   SFP   - Move main() to upe_main.c.
   3    18-Jul-01   ML    - Call to GCT_grab() to read and discard messages
                            pending in task input message queue is no
                            longer required.
                          - Support for 24-bit and 16-bit point codes.
   4    16-Sep-03   GNK   - Change copyright owner to Intel 
   5    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
 */

#include <stdio.h>
#include <stdlib.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "pack.h"       /* prototypes for packing functions */
#include "ss7_inc.h"    /* ss7 message & parameter definitions */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  static int UPE_mtp_pause(MSG *m);
  static int UPE_mtp_resume(MSG *m);
  static int UPE_mtp_status(MSG *m);
  static int UPE_mtp_transfer_ind(MSG *m);
  static int UPE_mtp_transfer_req(u8 *msu_data, u16 msu_len);
  static int UPE_other_message(MSG *m);
  static int UPE_send_msg(MSG *m);
  static int display_hex(u8 *ptr, u16 len);
#else
  static int UPE_mtp_pause();
  static int UPE_mtp_resume();
  static int UPE_mtp_status();
  static int UPE_mtp_transfer_ind();
  static int UPE_mtp_transfer_req();
  static int UPE_other_message();
  static int UPE_send_msg();
  static int display_hex();
#endif

/*
 * Some useful macros.
 */
#define NO_RESPONSE             (0)
#define RESPONSE(mod_id)        (1 << ((mod_id) & 0x0f))
#define CONF(i)                 ((i) & ~REQUEST)


/*
 * Module id of this process:
 * (used for inter-process communication)
 *
 * The value given here must be the same as
 * the value used as the module_id parameter
 * in the MTP_USER_PART entry in the config.txt
 * configuration file.
 */
u8  upe_module_id;

/*
 * The Service indicator for our user part:
 *
 * The MTP will send all indications for this
 * service indicator to this process. This value
 * must be the same as the service_indicator
 * parameter in the MTP_USER_PART entry in the
 * config.txt configuration file.
 */
u8  upe_si;

/*
 * Point code:
 *
 * The format of all requests sent to the MTP will
 * be based on this value.  Note: ensure that the
 * appropriate bit is set in the options field in
 * the MTP_CONFIG message. 
 */
u8  upe_pc_len;

/*
 * Main function for User Part Example (UPE):
 */
int upe_ent(module_id, si, pc_len)
  u8  module_id;
  u8  si;
  u8  pc_len;
{
  HDR *h;
  MSG *m;

  upe_module_id = module_id;
  upe_si = si;
  upe_pc_len = pc_len;

  /*
   * Print banner so we know what's running, and what
   * parameters are required in the configuration file:
   */
  printf("UPE: User Part Example.\n");
  printf("Copyright (C) Dialogic Corporation 1991-2006. All Rights Reserved.\n");
  printf("==================================================================\n");
  printf("%2d-bit point code selected.\n\n", upe_pc_len);  
  printf("Requires the following entry in config.txt:\n");
  printf("MTP_USER_PART 0x%02x 0x%02x\n\n", upe_si, upe_module_id);

  /*
   * Now enter main loop, receiving messages as
   * they become available and processing accordingly:
   */
  while (1)
  {
    /*
     * GCT_receive will attempt to receive message
     * from the task's message queue and block until
     * a message is ready:
     */
    if ((h = GCT_receive(upe_module_id)) != 0)
    {
      m = (MSG *)h;
      switch (m->hdr.type)
      {
        case MTP_MSG_PAUSE :
          UPE_mtp_pause(m);
          break;

        case MTP_MSG_RESUME :
          UPE_mtp_resume(m);
          break;

        case MTP_MSG_STATUS :
          UPE_mtp_status(m);
          break;

        case API_MSG_RX_IND :
          UPE_mtp_transfer_ind(m);
          break;

        default :
          UPE_other_message(m);
          break;
      }

      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }
}

/*
 * Function to handle MTP Pause indication:
 * Recover the point code from the message
 * and display to the user:
 */
static int UPE_mtp_pause(m)
  MSG *m;
{
  u32   dpc;

  dpc = runpackbytes(get_param(m), MTPMO_PAUSE_dpc, MTPMS_PAUSE_dpc);
  printf("MTP-PAUSE dpc=%lu\n", dpc);
  return(0);
}

/*
 * Function to handle MTP Resume indication:
 * Recover the point code from the message
 * and display to the user:
 */
static int UPE_mtp_resume(m)
  MSG *m;
{
  u32   dpc;

  dpc = runpackbytes(get_param(m), MTPMO_RESUME_dpc, MTPMS_RESUME_dpc);
  printf("MTP-RESUME dpc=%lu\n", dpc);
  return(0);
}

/*
 * Function to handle MTP Status indication:
 * Recover the point code and type of indication
 * from the message and display to the user:
 */
static int UPE_mtp_status(m)
  MSG *m;
{
  u32   dpc;

  dpc = runpackbytes(get_param(m), MTPMO_STATUS_dpc, MTPMS_STATUS_dpc);

  if (m->hdr.status == MTP_STATUS_UPU)
    printf("MTP-STATUS dpc=%lu (user part unavailable)\n", dpc);
  else
    printf("MTP-STATUS dpc=%lu (congestion)\n", dpc);

  return(0);
}

/*
 * Function to handle MTP Transfer indication:
 */
static int UPE_mtp_transfer_ind(m)
  MSG *m;
{
  u8    si;             /* recovered Service Indicator (SI) */
  u8    ssf;            /* recovered Sub-Service Field (SSF) */
  u8    sls;            /* recovered Signalling Link Selection (SLS) */
  u32   opc;            /* recovered Originating Point Code (OPC) */
  u32   dpc;            /* recovered Destination Point Ccode (DPC) */
  u8    *pptr;          /* pointer to parameter area of received message */

  /*
   * First display message to user:
   */
  pptr = get_param(m);
  printf("MTP-TRANSFER-IND: ");
  display_hex(pptr, m->len);
  printf("\n");

  /*
   * Recover MTP label parameters
   * from the message:
   */
  si = (u8)unpackbits(pptr, 0, 4);
  ssf = (u8)unpackbits(pptr, 4, 4);

  switch(upe_pc_len)
  {
    case 14 :
      dpc = unpackbits(pptr, 8, 14);
      opc = unpackbits(pptr, 22, 14);
      sls = (u8)unpackbits(pptr, 36, 4);
      break;
    case 16 :
      dpc = unpackbits(pptr, 8, 16);
      opc = unpackbits(pptr, 24, 16);
      sls = (u8)unpackbits(pptr, 40, 4);
      break;
    case 24 :
      dpc = unpackbits(pptr, 8, 24);
      opc = unpackbits(pptr, 32, 24);
      sls = (u8)unpackbits(pptr, 56, 5);
      break;
    default:
      break;
  }

  /*
   * If the message has a service indicator of upe_si
   * swap the opc and dpc and send a MTP transfer
   * request back to the MTP. Otherwise simply
   * discard the message:
   */
  if (si == upe_si)
  {
    /*
     * Overwrite the point codes to swap them around:
     */
    switch(upe_pc_len)
    {
      case 14 :
        packbits(pptr, 8, opc, 14);
        packbits(pptr, 22, dpc, 14);
        break;
      case 16 :
        packbits(pptr, 8, opc, 16);
        packbits(pptr, 24, dpc, 16);
        break;
      case 24 :
        packbits(pptr, 8, opc, 24);
        packbits(pptr, 32, dpc, 24);
        break;
      default:
        break;
    }

    /*
     * Send the resulting message as an
     * MTP TRANSFER REQUEST back to the MTP:
     */
    UPE_mtp_transfer_req(pptr, m->len);
  }
  return(0);
}

/*
 * Example function to send MTP TRANSFER REQUEST
 * to the MTP.
 */
static int UPE_mtp_transfer_req(msu_data, msu_len)
  u8    *msu_data;  /* Pointer to binary format MSU (commencing with SIO) */
  u16   msu_len;    /* Number of bytes of MSU data */
{
  MSG   *m;
  u8    *pptr;

  /*
   * Check msu_len is sensible:
   */
  if (msu_len <= 273)
  {
    /*
     * First allocate an MSG into which the message for
     * transmission can be built. Always use the library
     * function getm() for this purpose, (it in turn will
     * invoke GCT_getmem()).
     * The parameters for the getm function are m->hdr.type,
     * m->hdr.id, m->hdr.rsp_req and m->len (in that order).
     */
    if ((m = getm(API_MSG_TX_REQ, 0, NO_RESPONSE, msu_len)) != 0)
    {
      /*
       * Add our module_id as the source module
       * and MTP as the destination module:
       */
      m->hdr.src = upe_module_id;
      m->hdr.dst = MTP_TASK_ID;

      /*
       * Locate parameter area of MSG
       * and copy MSU data into it:
       */
      m->len = msu_len;
      pptr = get_param(m);
      while (msu_len--)
        *pptr++ = *msu_data++;

      /*
       * Send the message:
       */
      UPE_send_msg(m);
    }
  }
  return(0);
}

/*
 * Function to handle any other messages:
 */
static int UPE_other_message(m)
  MSG *m;
{
  printf("Rx MSG: type=0x%04x src=0x%02x status=0x%02x len=0x%04x\n",
	 m->hdr.type, m->hdr.src, m->hdr.status, m->len);
  return(0);
}

/*
 * Function to send message. On failure the
 * message is released and the user notified:
 */
static int UPE_send_msg(m)
  MSG        *m;
{

  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    fprintf(stderr, "upe: *** failed to send message ***\n");
    relm((HDR *)m);
  }
  return(0);
}

/*
 * Function to display hex data:
 */
static int display_hex(ptr, len)
  u8    *ptr;
  u16   len;
{
  while (len--)
    printf("%02x ", *ptr++);

  return(0);
}
