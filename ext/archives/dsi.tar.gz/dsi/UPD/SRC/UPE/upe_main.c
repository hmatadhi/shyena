/*
		Copyright (C) Dialogic Corporation 1998-2006. All Rights Reserved.

 Name:          upe_main.c

 Description:   main function for UPE example

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   1    21-Apr-98   SFP   - Derived from upe.c
   2    18-Jul-01   ML    - Support for 24-bit and 16-bit point codes
                          - Changed default module id from 0xef to 0x2d
   3    16-Sep-03   GNK   - Change copyright owner to Intel 
                          - Add Version information - for Binary releases.
                          - Modify usage to DPK standard.
                          - Change -c description to point code length (was 
                            point code)
   4    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"
#include "msg.h"
#include "ss7_inc.h"
#include "strtonum.h"


/*
 * Main function for User Part Example (UPE):
 */
#ifdef LINT_ARGS
  extern upe_ent(u8 module_id, u8 si, u8 pc_len);
  static int read_cli_parameters(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *args);
#else
  extern upe_ent();
  static int read_cli_parameters();
  static void show_syntax();
  static int read_option();
#endif

#define CLI_EXIT_REQ            (-1)    /* Option requires immediate exit */
#define CLI_UNRECON_OPTION      (-2)    /* Unrecognised option */
#define CLI_RANGE_ERR           (-3)    /* Option value is out of range */

/*
 * Default values for UPE's command line options:
 */
#define DEFAULT_MODULE_ID        (0x2d)
#define DEFAULT_SI               (0xa)
#define DEFAULT_PC_LEN           (14)

static u8  upe_mod_id;
static u8  upe_si;
static u8  upe_pc_len;

/*
 * Main function for User Part Example (UPE)
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

  upe_mod_id = DEFAULT_MODULE_ID;
  upe_si = DEFAULT_SI;
  upe_pc_len = DEFAULT_PC_LEN;

  if ((cli_error = read_cli_parameters(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case CLI_UNRECON_OPTION :
        fprintf(stderr, "upe() : Unrecognised option : %s\n", argv[failed_arg]);
        show_syntax();
        break;

      case CLI_RANGE_ERR :
        fprintf(stderr, "upe() : Parameter range error : %s\n",
                argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }
    exit(0);
  }

  upe_ent(upe_mod_id, upe_si, upe_pc_len);

  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr, "SS7 upe");
#ifdef OS_MAJREV
  fprintf(stderr, " V%d.%02d", OS_MAJREV, OS_MINREV);
#endif
  fprintf(stderr, "\n");
  fprintf(stderr, 
         "Copyright (C) Dialogic Corporation 1998-2006. All Rights Reserved.\n");
  fprintf(stderr, "\n");

  fprintf(stderr,
        "Syntax: upe [-m -s -c]\n");
  fprintf(stderr,
        "        -m  : module ID (default 0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,
        "        -s  : service indicator (default 0x%02x)\n", DEFAULT_SI);
  fprintf(stderr,
        "        -c  : point code length (default %2d)\n\n", DEFAULT_PC_LEN);
  fprintf(stderr,
        "Example: upe -m0xef -s0x5 -c14\n\n");
}

/*
 * Read in command line options a set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_cli_parameters(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;

  if (arg[0] != '-')
    return(CLI_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
    case 'v' :
      show_syntax();
      return(CLI_EXIT_REQ);

    case 'm' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      upe_mod_id = (u8)temp_u32;
      break;

    case 's' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      upe_si = (u8)temp_u32;
      break;

    case 'c' :
      if (strcmp(&arg[2], "14") == 0)
        upe_pc_len = DEFAULT_PC_LEN;
      else if (strcmp(&arg[2], "16") == 0)
        upe_pc_len = 16;
      else if (strcmp(&arg[2], "24") == 0)
        upe_pc_len = 24;
      else
        return(CLI_RANGE_ERR);
      break;
  }
  return(0);
}

