/*
                        Copyright (C) Dialogic Corporation 1995-2006. All Rights Reserved.

 Name:                  mtpsl.c          

 Description:           A very simple application to show how a signalling
                        link is activated or de-activated using the GCT API.
                
 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    02-Mar-95   MH   - Initial code.
   1    05-Mar-95   MH   - Up issue.
   2    20-Jan-97   MH   - Remove TAB characters and up-issue.
   3    21-Aug-06   RJ   - Correct some typos in comments.
   4    13-Dec-06   ML   - Change to use of Dialogic Corporation copyright.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Include Intel headers.
 */
#include "system.h"
#include "msg.h"
#include "ss7_inc.h"
#include "sysgct.h"

/*
 * Hard-code the module Id.
 */
#define OUR_MODULE_ID                        (0x3d)

int main(argc, argv)
  int argc;
  char *argv[];
{
  u16 linkset_id;
  u16 link_ref;
  HDR *hdr=NULL;
  MSG *m;
  u16 mtpsl_cmd;

  /*
   * Check for correct number of command line parameters.
   */
  if (argc != 4)
  {
    printf("MTPSL <cmd> <linkset_id> <link ref>\n");
    printf("cmd : ACT, DEACT\n");
    exit(0);
  }

  /*
   * Check for signalling link activation command.
   */
  if ( (strcmp(argv[1], "ACT") == 0) || (strcmp(argv[1], "act") == 0) )
    mtpsl_cmd = MTP_MSG_ACT_SL;

  /*
   * Check for signalling link deactivation command.
   */
  else if ( (strcmp(argv[1], "DEACT") == 0) || (strcmp(argv[1], "deact") == 0) )
    mtpsl_cmd = MTP_MSG_DEACT_SL;

  /*
   * Command not recognised.
   */
  else
  {
    printf("Illegal CMD %s (ACT/DEACT)\n", argv[1]);
    exit(0);
  }

  /*
   * Read the linkset and link arguments from the command line.
   */
  linkset_id = atoi(argv[2]);
  link_ref = atoi(argv[3]);

  /*
   * Make sure there are no un-read messages in the process message queue.
   * Note : It is essential to call either GCT_grab() or GCT_send() before 
   * calling getm()/relm() in order to intialise the IPC mechanism.
   */
  while ((hdr = GCT_grab(OUR_MODULE_ID)) != NULL)
    relm(hdr);

  /*
   * Allocate a MSG and send to MTP3
   */
  if ((m = getm(mtpsl_cmd, ((linkset_id << 8) + link_ref), 0, 0)) != 0)
  {
    m->hdr.src = OUR_MODULE_ID;
    m->hdr.dst = MTP_TASK_ID;

    /*
     * If GCT_send() fails the message must be released back to the system
     */
    if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
      relm((HDR *)m);
  }

  return(0);
}
