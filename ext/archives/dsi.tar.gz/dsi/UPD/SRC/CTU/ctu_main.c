/*
                Copyright (C) Dialogic Corporation 1995-2009. All Rights Reserved.

 Name:          ctu_main.c

 Description:   Console command line interface to ctu.

 Functions:     main()

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   1     22-Aug-95  MH    - Up Issue.
   2     29-Feb-96  MH    - Made generic instead of UNIX specific.
   3     26-Feb-97  MH    - GCT_init() removed.
   4     04-Nov-99  JB    - OPT_WAIT_RLC option removed.
   5     13-Jul-01  ML    - Changed default module ID, updated runtime
                            option descriptions and updated copyright year.
   6     17-Apr-02  ML    - Update copyright year.
   7     12-Mar-04  JER   - Update copyright.
   8     13-Dec-06  ML    - Change to use of Dialogic Corporation copyright.
   9     01-Dec-09  JLP   - Updated comment.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"
#include "msg.h"
#include "ss7_inc.h"
#include "strtonum.h"

#ifdef LINT_ARGS
  int ctu_ent(u8 our_mod_id, u8 cal_task_id, u16 options);
  static int read_cli_parameters(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *args);
#else
  int ctu_ent();
  static int read_cli_parameters();
  static void show_syntax();
  static int read_option();
#endif

/*
 * The function open_files() is only for internal
 * Dialogic standalone test purpose.
 */
#ifdef TEST_ONLY
  int open_files();
#endif

#define CLI_EXIT_REQ            (-1)    /* Option requires immediate exit */
#define CLI_UNRECON_OPTION      (-2)    /* Unrecognised option */
#define CLI_RANGE_ERR           (-3)    /* Option value is out of range */

/*
 * Default values for CTU's command line options:
 */
#define DEFAULT_MODULE_ID        (0x3d)
#define DEFAULT_USER_PART        (ISP_TASK_ID) /* default is ISUP */
#define DEFAULT_OPTIONS          (0x0010)      /* default is OPT_TR_RX_IND */

static u8 ctu_mod_id;
static u8 calling_process;
static u16 ctu_options;

/*
 * Main function for CAL Test Utility (CTU):
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

#ifdef TEST_ONLY
  open_files();
#endif

  ctu_mod_id = DEFAULT_MODULE_ID;
  ctu_options = DEFAULT_OPTIONS;
  calling_process = DEFAULT_USER_PART;

  if ((cli_error = read_cli_parameters(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case CLI_UNRECON_OPTION :
        fprintf(stderr, "ctu() : Unrecognised option : %s\n", argv[failed_arg]);
        show_syntax();
        break;

      case CLI_RANGE_ERR :
        fprintf(stderr, "ctu() : Parameter range error : %s\n", argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }
    exit(0);
  }

  ctu_ent(ctu_mod_id, calling_process, ctu_options);
  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr,"Syntax: ctu [-m -c -o]\n");
  fprintf(stderr,"  -m  : ctu's module ID (default = 0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,"  -c  : ctu's user part module (default = 0x%02x)\n", DEFAULT_USER_PART);
  fprintf(stderr,"  -o  : run-time options (default = 0x%04x)\n\n", DEFAULT_OPTIONS);
  fprintf(stderr,"Run-time options available:\n");
  fprintf(stderr,"  0x0001  : Display received message parameter buffer (OPT_TR_PARAM)\n");
  fprintf(stderr,"  0x0002  : Display primitive messages (OPT_TR_PRIM)\n");
  fprintf(stderr,"  0x0004  : Display call parameters (OPT_TR_CALL)\n");
  fprintf(stderr,"  0x0008  : Display transmit requests (OPT_TR_TX_REQ)\n");
  fprintf(stderr,"  0x0010  : Display received indications (OPT_TR_RX_IND)\n");
  fprintf(stderr,"  0x0100  : ANSI mode [LPA enabled] (OPT_ANSI)\n\n");
  fprintf(stderr,"Example: ctu -m0xef -c0x23 -o0x0017\n");
}

/*
 * Read in command line options a set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_cli_parameters(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;

  if (arg[0] != '-')
    return(CLI_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
    case 'v' :
      show_syntax();
      return(CLI_EXIT_REQ);

    case 'm' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ctu_mod_id = (u8)temp_u32;
      break;

    case 'o' :
      if (!strtonum(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ctu_options = (u16)temp_u32;
      break;

    case 'c' :
      /*
       * Allow user parts to be entered in text form
       * for backwards compatibility:
       */
      if (strcmp(&arg[2], "NUP") == 0)
        calling_process = 0x4a;
      else if (strcmp(&arg[2], "ISUP") == 0)
        calling_process = ISP_TASK_ID;
      else if (strcmp(&arg[2], "TUP") == 0)
        calling_process = 0x4a;
      else
      {
        if (!strtonum(&temp_u32, &arg[2]))
          return(CLI_RANGE_ERR);
        calling_process = (u8)temp_u32;
      }
      break;
  }
  return(0);
}
