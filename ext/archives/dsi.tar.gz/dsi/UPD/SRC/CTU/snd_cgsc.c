/*
		Copyright (C) Dialogic Corporation 1999-2006. All Rights Reserved.

 Name:          snd_cgsc.c

 Description:   Example function to use for initiating blocking and reset
 		by using a Circuit Group Supervision Control request.

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    04-Nov-99   SFP   - Initial code.
   1    12-Mar-04   JER   - changed copyright.
   2    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "ss7_inc.h"
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "digpack.h"    /* prototypes for address digit packing functions */
#include "pack.h"       /* prototypes for parameter packing functions */

#include "isp_inc.h"

/*
 * Definitions to ease the use of the circuit group supervision
 * functions.
 * Note that most refer to the ISUP protocol.
 */

/*
 * Definitions for ptype field in
 * ISP_MSG_CGSC_xxx message parameter fields:
 */
#define RESET_PTYPE		(ISP_GCSCC_RESET)
#define STOP_RESET_PTYPE	(ISP_GCSCC_STOP_RESET)
#define M_BLOCK_PTYPE		(ISP_GCSCC_M_BLOCK)
#define M_UNBLOCK_PTYPE		(ISP_GCSCC_M_UNBLOCK)
#define M_STOP_PTYPE		(ISP_GCSCC_M_STOP)
#define H_BLOCK_PTYPE		(ISP_GCSCC_H_BLOCK)
#define H_UNBLOCK_PTYPE		(ISP_GCSCC_H_UNBLOCK)
#define H_STOP_PTYPE		(ISP_GCSCC_H_STOP)
#define QUERY_PTYPE		(ISP_GCSCC_QUERY)

#define ALL_CIRCUITS_MASK 	(0xffffffff)

#define DEFAULT_USER_PART	(ISP_TASK_ID)
#define DEFAULT_MODULE_ID       (0xef)

/*
 * Function prototype
 */
#ifdef LINT_ARGS
static  int send_cgsc_req(u16 gid, u8 ptype, u32 cic_mask);
#else
static  int send_cgsc_req();
#endif

/*
 * Send_cgsc_req can be use to send CGSC request.
 * Note that this example refers to the ISUP protocol, as
 * shown with the #define used.
 *
 * Example of call of this CGSC function:
 * Application requests  reset of circuit group 1:
 *   send_cgsc_req(1, RESET_PTYPE, ALL_CIRCUITS_MASK)
 */
static int send_cgsc_req(gid, ptype, cic_mask)
  u16	gid;
  u8	ptype;
  u32 cic_mask;
{
  MSG     *m;
  u8	  *pptr;

  if ((m = getm(CAL_MSG_CGSC_REQ, gid, 0, 6)) != 0)
  {
    pptr = get_param(m);
    rpackbytes(pptr, ISPMO_CGSS_ptype, (u32)ptype, ISPMS_CGSS_ptype);
    rpackbytes(pptr, ISPMO_CGSS_cic_mask, cic_mask, ISPMS_CGSS_cic_mask);
    m->hdr.dst = DEFAULT_USER_PART;
    m->hdr.src = DEFAULT_MODULE_ID;
    if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
    {
      fprintf(stderr, "*** failed to send message ***\n");
      relm((HDR *)m);
    }
  }
  return(0);
}

