/*
                Copyright (C) Dialogic Corporation 1995-2006. All Rights Reserved.

 Name:          call.c

 Description:   Call control interface library functions.

 Functions:     CAL_req_to_msg    CAL_msg_to_ind
                CAL_erase_req     CAL_erase_ind
                CAL_init

-----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
-----  ---------  -----  ---------------------------------------------
   A    26-Jan-95   SFP   - Initial code.
   B    23-Aug-95   MH    - Deleted void from CAL_init parameter declaration.
   C    02-Feb-96   SFP   - Added support for Need (NUP) and Progress
                            primitives, also redir_num, redir_inf,
                            NUP_event_inf, NUP_fci parameters.
                            CAL_msg_to_ind modified to discard any
                            unrecognised parameters without returning an
                            error.
   D    12-Apr-96   SRG   - Added support for release response and release
                            confirmation.
   E    27-Feb-97   SRG   - memory.h changed to string.h.
   F    17-Apr-98   SFP   - GCT_get_instance now recovers message instance.
   G    04-Nov-99   JB    - Support for COT, CON message and SZD primitives
                               added.
        30-Jan-04   MH    - Change copyright to Intel.
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.        
 */

#include <string.h>     /* required for memset */
#include "msg.h"
#include "sysgct.h"
#include "system.h"
#include "call.h"

/*
 * Type definition for primitive parameter data :
 * (one of these structures is used for each
 * parameter that a primitive may include).
 */
typedef struct
{
  u8  name;
  u8  buflen;
  int lenoff;
  int bufoff;
} CALPT_PDATA;

/*
 * Define the maximum number of parameters that
 * a single primitive indication or request may
 * include.
 */
#define CAL_MAX_PARMS   (10)     /* Maximum no of parameters for a primitive */

/*
 * Parameter tables for each primitive
 * request/indication supported.
 */
static CALPT_PDATA setup_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA setup_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA alert_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA alert_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA release_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA release_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA release_resp_tab[CAL_MAX_PARMS];
static CALPT_PDATA release_conf_tab[CAL_MAX_PARMS];
static CALPT_PDATA setup_resp_tab[CAL_MAX_PARMS];
static CALPT_PDATA setup_conf_tab[CAL_MAX_PARMS];
static CALPT_PDATA info_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA progress_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA need_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA need_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA lpa_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA cot_ind_tab[CAL_MAX_PARMS];
static CALPT_PDATA cot_req_tab[CAL_MAX_PARMS];
static CALPT_PDATA cct_szd_ind_tab[CAL_MAX_PARMS];

#define PDATA_TAB_MAX  (16)    /* Highest primitive token included in table */

/*
 * Array of parameter tables ordered by
 * primitive indication type token value.
 * Primitives indication used: (1,IAM),(2,INF), (5,COT), (6,ACM),
 * (7,CON), (9,ANM), (12,REL), (16,RLC).
 */
static CALPT_PDATA *ind_ptable[PDATA_TAB_MAX+1] =
{
  (CALPT_PDATA*)0,   setup_ind_tab,     info_ind_tab,   /* 0,  1,  2  */
  (CALPT_PDATA*)0,   (CALPT_PDATA*)0,   cot_ind_tab,    /* 3,  4,  5  */
  alert_ind_tab,     setup_conf_tab,    (CALPT_PDATA*)0,/* 6,  7,  8  */
  setup_conf_tab,    (CALPT_PDATA*)0,   (CALPT_PDATA*)0,/* 9,  10, 11 */
  release_ind_tab,   (CALPT_PDATA*)0,   (CALPT_PDATA*)0,/* 12, 13, 14 */
  (CALPT_PDATA*)0,   release_conf_tab                   /* 15, 16     */
};

/*
 * Array of parameter tables ordered by
 * primitive request type token value.
 * Primitives request used: (1,IAM), (5, COT),(6,ACM),(7,CON),
 * (9,ANM), (12,REL), (16,RLC).
 */
static CALPT_PDATA *req_ptable[PDATA_TAB_MAX+1] =
{
  (CALPT_PDATA*)0,   setup_req_tab,     (CALPT_PDATA*)0,   /* 0,  1,  2  */
  (CALPT_PDATA*)0,   (CALPT_PDATA*)0,   cot_req_tab,       /* 3,  4,  5  */
  alert_req_tab,     setup_resp_tab,    (CALPT_PDATA*)0,   /* 6,  7,  8  */
  setup_resp_tab,    (CALPT_PDATA*)0,   (CALPT_PDATA*)0,   /* 9,  10, 11 */
  release_req_tab,   (CALPT_PDATA*)0,   (CALPT_PDATA*)0,   /* 12, 13, 14 */
  (CALPT_PDATA*)0,   release_resp_tab                      /* 15, 16     */
};

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  static CALPT_PDATA *locate_table(CALPT_PDATA *tlist, u8 pname, 
        u8 list_offset);
  static CALPT_PDATA *get_ind_ptable(u16 ptype);
  static CALPT_PDATA *get_req_ptable(u16 ptype);
  static int copy_param(u8 *dest, u8 *src, u8 len);
#else
  static CALPT_PDATA *locate_table();
  static CALPT_PDATA *get_ind_ptable();
  static CALPT_PDATA *get_req_ptable();
  static int copy_param();
#endif

/*
 * CAL_req_to_msg converts the 'C' structured
 * representation of a primitive request to the
 * format required by the protocol module.
 *
 * Returns zero on success.
 */
int CAL_req_to_msg(m, req)
  MSG        *m;                /* destination message */
  CALPT_REQ  *req;              /* structured primitive data to format */
{
  CALPT_PDATA *ptab;            /* parameter table */
  int   mlen;                   /* total param length */
  u8    plen;                   /* current parameter length */
  u8    *pptr;

  pptr = get_param(m);
  /*
   * Find first parameter descriptor for this primitive :
   */
  if ((ptab = get_req_ptable(req->ptype)) != 0)
  {
    mlen = 2;                    /* for type and terminator octet */
    *pptr++ = (u8)req->ptype;
    while (ptab->name != CALPPN_TERMINATOR)
    {
      plen = *((u8*)req+ptab->lenoff);
      if (plen > 0)
      {
        mlen += (plen + 2);
        if (mlen < CAL_MAX_PARAM_LEN)
        {
          *pptr++ = ptab->name;
          *pptr++ = plen;
          pptr+= copy_param(pptr, (u8*)req+ptab->bufoff, 
                *((u8*)req+ptab->lenoff));
        }
        else
        {
          mlen = -1;
          break;
        }
      }
      ptab++;
    }
    if (mlen > 0)
    {
      *pptr++ = CALPPN_TERMINATOR;
      m->hdr.id = (unsigned short)req->call_ref;
      GCT_set_instance((int)req->instance, (HDR*)m);
      m->len = (unsigned short)mlen;
      return(0);
    }
  }
  return(-1);
}

/*
 * CAL_msg_to_ind converts primitive indication
 * from the protocol module into the 'C' structured
 * representation of a primitive indication.
 *
 * Returns zero on success or an error code otherwise.
 */
int CAL_msg_to_ind(ind, m)
  CALPT_IND  *ind;        /* structure to recover data to */
  MSG        *m;          /* message to recover data from */
{
  CALPT_PDATA  *tab_start;
  CALPT_PDATA  *ptab;
  u8    plen;                  /* current parameter length */
  u8    *pptr;
  u8    *eop;
  u16   mlen;
  int   ret;

  ret = -1;

  ind->call_ref = m->hdr.id;
  ind->instance = (u8)GCT_get_instance((HDR*)m);

  mlen = m->len;
  if (mlen)
  {
    pptr = get_param(m);
    eop = pptr + mlen;
    ind->ptype = *pptr++;
    if ((tab_start = get_ind_ptable(ind->ptype)) != 0)
    {
      ptab = tab_start;
      while (pptr < eop)
      {
        if (*pptr == CALPPN_TERMINATOR)
        {
          if (++pptr == eop)
            ret = 0;
          break;
        }
        else
        {
          ptab = locate_table(tab_start, *pptr++, (u8)(ptab-tab_start));
          plen = *pptr++;
          /*
           * After the first unrecognised parameter is processed, ptab is 
           * reset to tab_start so that the offset passed to locate_table 
           * is still defined.  
           *
           * Skip over any unrecognised parameters :
           */
          if (ptab == 0)
            ptab = tab_start;
          else
          {
            if (plen <= ptab->buflen)
            {
              copy_param((u8*)ind+ptab->bufoff, pptr, plen);
              *((u8*)ind+ptab->lenoff) = plen;
            }
          }
          pptr += plen;
        }
      }
    }
  }
  return(ret);
}

/*
 * CAL_erase_ind sets all the contents
 * of a CALPT_IND structure to zero.
 */
int CAL_erase_ind(ind)
  CALPT_IND   *ind;   /* primitive structure to erase */
{
  memset((void *)ind, 0, sizeof (CALPT_IND));
  return(0);
}

/*
 * CAL_erase_req sets all the contents
 * of a CALPT_REQ structure to zero.
 */
int CAL_erase_req(req)
  CALPT_REQ   *req;   /* primitive structure to erase */
{
  memset((void *)req, 0, sizeof (CALPT_REQ));
  return(0);
}

/*
 * CAL_init initialises the tables of parameter name, buffer
 * offset, length offset and buffer size for the primitives
 * that the formatting and recovery functions are able to
 * recognise.
 *
 * Returns zero.
 */
int CAL_init()
{
  CALPT_REQ  req;
  CALPT_IND  ind;
  CALPT_PDATA *ptab;
  u8         i;

  for (i= 0; i< PDATA_TAB_MAX; i++)
  {
    if (req_ptable[i] != 0)
      memset((void*)req_ptable[i], 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  }

  ptab = setup_req_tab;
  ptab[0].name = CALPPN_NOCI;
  ptab[0].buflen = CALPL_NOCI;
  ptab[0].lenoff = (int)((u8*)&req.u.setup_req.noci.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.setup_req.noci.data - (u8*)&req);
  ptab[1].name = CALPPN_FCI;
  ptab[1].buflen = CALPL_FCI;
  ptab[1].lenoff = (int)((u8*)&req.u.setup_req.fci.len - (u8*)&req);
  ptab[1].bufoff = (int)((u8*)req.u.setup_req.fci.data - (u8*)&req);
  ptab[2].name = CALPPN_CPC;
  ptab[2].buflen = CALPL_CPC;
  ptab[2].lenoff = (int)((u8*)&req.u.setup_req.cpc.len - (u8*)&req);
  ptab[2].bufoff = (int)((u8*)req.u.setup_req.cpc.data - (u8*)&req);
  ptab[3].name = CALPPN_TMR;
  ptab[3].buflen = CALPL_TMR;
  ptab[3].lenoff = (int)((u8*)&req.u.setup_req.tmr.len - (u8*)&req);
  ptab[3].bufoff = (int)((u8*)req.u.setup_req.tmr.data - (u8*)&req);
  ptab[4].name = CALPPN_CALLED_NUM;
  ptab[4].buflen = CALPL_CALLED_NUM;
  ptab[4].lenoff = (int)((u8*)&req.u.setup_req.called_num.len - (u8*)&req);
  ptab[4].bufoff = (int)((u8*)req.u.setup_req.called_num.data - (u8*)&req);
  ptab[5].name = CALPPN_CALLING_NUM;
  ptab[5].buflen = CALPL_CALLING_NUM;
  ptab[5].lenoff = (int)((u8*)&req.u.setup_req.calling_num.len - (u8*)&req);
  ptab[5].bufoff = (int)((u8*)req.u.setup_req.calling_num.data - (u8*)&req);
  ptab[6].name = CALPPN_REDIR_INF;
  ptab[6].buflen = CALPL_REDIR_INF;
  ptab[6].lenoff = (int)((u8*)&req.u.setup_req.redir_inf.len - (u8*)&req);
  ptab[6].bufoff = (int)((u8*)req.u.setup_req.redir_inf.data - (u8*)&req);
  ptab[7].name = CALPPN_REDIR_NUM;
  ptab[7].buflen = CALPL_REDIR_NUM;
  ptab[7].lenoff = (int)((u8*)&req.u.setup_req.redir_num.len - (u8*)&req);
  ptab[7].bufoff = (int)((u8*)req.u.setup_req.redir_num.data - (u8*)&req);
  ptab[8].name = CALPPN_NUP_FCI;
  ptab[8].buflen = CALPL_NUP_FCI;
  ptab[8].lenoff = (int)((u8*)&req.u.setup_req.NUP_fci.len - (u8*)&req);
  ptab[8].bufoff = (int)((u8*)req.u.setup_req.NUP_fci.data - (u8*)&req);

  ptab = setup_resp_tab;
  ptab[0].name = CALPPN_BCI;
  ptab[0].buflen = CALPL_BCI;
  ptab[0].lenoff = (int)((u8*)&req.u.setup_resp.bci.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.setup_resp.bci.data - (u8*)&req);

  ptab = release_req_tab;
  ptab[0].name = CALPPN_CAUSEI;
  ptab[0].buflen = CALPL_CAUSEI;
  ptab[0].lenoff = (int)((u8*)&req.u.release_req.causei.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.release_req.causei.data - (u8*)&req);

  ptab = release_resp_tab;
  ptab[0].name = CALPPN_CAUSEI;
  ptab[0].buflen = CALPL_CAUSEI;
  ptab[0].lenoff = (int)((u8*)&req.u.release_resp.causei.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.release_resp.causei.data - (u8*)&req);

  ptab = cot_req_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_CONTI;
  ptab[0].buflen = CALPL_CONTI;
  ptab[0].lenoff = (int)((u8*)&req.u.cot_req.conti.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.cot_req.conti.data - (u8*)&req);

  ptab = need_req_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_NEED;
  ptab[0].buflen = CALPL_NEED;
  ptab[0].lenoff = (int)((u8*)&req.u.need_req.need.len - (u8*)&req);
  ptab[0].bufoff = (int)((u8*)req.u.need_req.need.data - (u8*)&req);

  for (i= 0; i< PDATA_TAB_MAX; i++)
  {
    if (ind_ptable[i] != 0)
      memset((void*)ind_ptable[i], 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  }

  ptab = setup_ind_tab;
  ptab[0].name = CALPPN_CALLED_NUM;
  ptab[0].buflen = CALPL_CALLED_NUM;
  ptab[0].lenoff = (int)((u8*)&ind.u.setup_ind.called_num.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.setup_ind.called_num.data - (u8*)&ind);
  ptab[1].name = CALPPN_CALLING_NUM;
  ptab[1].buflen = CALPL_CALLING_NUM;
  ptab[1].lenoff = (int)((u8*)&ind.u.setup_ind.calling_num.len - (u8*)&ind);
  ptab[1].bufoff = (int)((u8*)ind.u.setup_ind.calling_num.data - (u8*)&ind);
  ptab[2].name = CALPPN_FCI;
  ptab[2].buflen = CALPL_FCI;
  ptab[2].lenoff = (int)((u8*)&ind.u.setup_ind.fci.len - (u8*)&ind);
  ptab[2].bufoff = (int)((u8*)ind.u.setup_ind.fci.data - (u8*)&ind);
  ptab[3].name = CALPPN_CPC;
  ptab[3].buflen = CALPL_CPC;
  ptab[3].lenoff = (int)((u8*)&ind.u.setup_ind.cpc.len - (u8*)&ind);
  ptab[3].bufoff = (int)((u8*)ind.u.setup_ind.cpc.data - (u8*)&ind);
  ptab[4].name = CALPPN_TMR;
  ptab[4].buflen = CALPL_TMR;
  ptab[4].lenoff = (int)((u8*)&ind.u.setup_ind.tmr.len - (u8*)&ind);
  ptab[4].bufoff = (int)((u8*)ind.u.setup_ind.tmr.data - (u8*)&ind);
  ptab[5].name = CALPPN_NOCI;
  ptab[5].buflen = CALPL_NOCI;
  ptab[5].lenoff = (int)((u8*)&ind.u.setup_ind.noci.len - (u8*)&ind);
  ptab[5].bufoff = (int)((u8*)ind.u.setup_ind.noci.data - (u8*)&ind);
  ptab[6].name = CALPPN_REDIR_INF;
  ptab[6].buflen = CALPL_REDIR_INF;
  ptab[6].lenoff = (int)((u8*)&ind.u.setup_ind.redir_inf.len - (u8*)&ind);
  ptab[6].bufoff = (int)((u8*)ind.u.setup_ind.redir_inf.data - (u8*)&ind);
  ptab[7].name = CALPPN_REDIR_NUM;
  ptab[7].buflen = CALPL_REDIR_NUM;
  ptab[7].lenoff = (int)((u8*)&ind.u.setup_ind.redir_num.len - (u8*)&ind);
  ptab[7].bufoff = (int)((u8*)ind.u.setup_ind.redir_num.data - (u8*)&ind);
  ptab[8].name = CALPPN_NUP_FCI;
  ptab[8].buflen = CALPL_NUP_FCI;
  ptab[8].lenoff = (int)((u8*)&ind.u.setup_ind.NUP_fci.len - (u8*)&ind);
  ptab[8].bufoff = (int)((u8*)ind.u.setup_ind.NUP_fci.data - (u8*)&ind);

  ptab = alert_ind_tab;
  ptab[0].name = CALPPN_BCI;
  ptab[0].buflen = CALPL_BCI;
  ptab[0].lenoff = (int)((u8*)&ind.u.alert_ind.bci.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.alert_ind.bci.data - (u8*)&ind);

  ptab = setup_conf_tab;
  ptab[0].name = CALPPN_BCI;
  ptab[0].buflen = CALPL_BCI;
  ptab[0].lenoff = (int)((u8*)&ind.u.setup_conf.bci.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.setup_conf.bci.data - (u8*)&ind);

  ptab = release_ind_tab;
  ptab[0].name = CALPPN_CAUSEI;
  ptab[0].buflen = CALPL_CAUSEI;
  ptab[0].lenoff = (int)((u8*)&ind.u.release_ind.causei.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.release_ind.causei.data - (u8*)&ind);

  ptab = release_conf_tab;
  ptab[0].name = CALPPN_CAUSEI;
  ptab[0].buflen = CALPL_CAUSEI;
  ptab[0].lenoff = (int)((u8*)&ind.u.release_conf.causei.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.release_conf.causei.data - (u8*)&ind);

  ptab = info_ind_tab;
  ptab[0].name = CALPPN_SUBSQ_NUM;
  ptab[0].buflen = CALPL_SUBSQ_NUM;
  ptab[0].lenoff = (int)((u8*)&ind.u.info_ind.subsq_num.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.info_ind.subsq_num.data - (u8*)&ind);

  ptab = progress_ind_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_NUP_EVENT_INF;
  ptab[0].buflen = CALPL_NUP_EVENT_INF;
  ptab[0].lenoff = (int)((u8*)&ind.u.progress_ind.NUP_event_inf.len - 
        (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.progress_ind.NUP_event_inf.data - 
        (u8*)&ind);

  ptab = cot_ind_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_CONTI;
  ptab[0].buflen = CALPL_CONTI;
  ptab[0].lenoff = (int)((u8*)&ind.u.cot_ind.conti.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.cot_ind.conti.data - (u8*)&ind);

  ptab = cct_szd_ind_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_NOCI;
  ptab[0].buflen = CALPL_NOCI;
  ptab[0].lenoff = (int)((u8*)&ind.u.szd_ind.noci.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.szd_ind.noci.data - (u8*)&ind);

  ptab = need_ind_tab;
  memset((void*)ptab, 0, (CAL_MAX_PARMS * sizeof(CALPT_PDATA)));
  ptab[0].name = CALPPN_NEED;
  ptab[0].buflen = CALPL_NEED;
  ptab[0].lenoff = (int)((u8*)&ind.u.need_ind.need.len - (u8*)&ind);
  ptab[0].bufoff = (int)((u8*)ind.u.need_ind.need.data - (u8*)&ind);

  return(0);
}

/*
 * Local functions :
 */

/*
 * get_ind_ptable returns a pointer to
 * the first parameter descriptor for the
 * specified primitive indication.
 *
 * Returns zero if primitive not recognised.
 */
static CALPT_PDATA *get_ind_ptable(ptype)
 u16  ptype;     /* primitive type token */
{
  if (ptype <= PDATA_TAB_MAX)
    return(ind_ptable[ptype]);
  else
  {
    switch (ptype)
    {
      case  CALPN_CCT_SZE_IND : return(cct_szd_ind_tab);
      case  CALPN_PROGRESS_IND : return(progress_ind_tab);
      case  CALPN_NEED_IND     : return(need_ind_tab);
    }
  }
  return((CALPT_PDATA*)0);
}

/*
 * get_req_ptable returns a pointer to
 * the first parameter descriptor for the
 * specified primitive request.
 *
 * Returns zero if primitive not recognised.
 */
static CALPT_PDATA *get_req_ptable(ptype)
 u16  ptype;     /* primitive type token */
{
  if (ptype <= PDATA_TAB_MAX)
    return(req_ptable[ptype]);
  else
  {
    switch (ptype)
    {
      case  CALPN_LPA_REQ : return(lpa_req_tab);
      case  CALPN_NEED_REQ : return(need_req_tab);
    }
  }
  return((CALPT_PDATA*)0);
}

/*
 * copy_param copies len bytes of data from
 * src to dest.
 *
 * Returns the length of data copied.
 */
static int copy_param(dest, src, len)
  u8    *dest;          /* Destination pointer */
  u8    *src;           /* Source pointer */
  u8    len;            /* Number of bytes to copy */
{
  u16 bytes_left;       /* number of bytes left to copy */

  bytes_left = len;
  while (bytes_left--)
    *dest++ = *src++;
  return(len);
}

/*
 * Locate table searches for an entry with the parameter
 * name set to pname from the current offset in a list
 * of parameter tables to the end, and then from the
 * start to the current offset.
 *
 * Returns a pointer to entry if found, otherwise zero.
 */
static CALPT_PDATA *locate_table(ptab, pname, offset)
  CALPT_PDATA *ptab; /* First table in list */
  u8  pname;        /* Primitive parameter name to find in list */
  u8  offset;   /* current position in table */
{
  u8  i;

  for (i = offset; i < CAL_MAX_PARMS; i++)
  {
    if (ptab[i].name == pname)
      return(ptab + i);
  }
  for (i = 0; i < offset; i++)
  {
    if (ptab[i].name == pname)
      return(ptab + i);
  }
  return((CALPT_PDATA*)0);
}

