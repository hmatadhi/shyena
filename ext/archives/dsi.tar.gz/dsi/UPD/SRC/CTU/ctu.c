/*
                Copyright (C) Dialogic Corporation 1995-2009. All Rights Reserved.

 Name:          ctu.c

 Description:   Example application program for the
                call control interface.

                The application receives incoming calls
                and issues responses in a manner designed
                to exercise the call processing functionality
                and illustrate the programming techniques
                involved.

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    21-Feb-95   SFP   - Initial code.
   B    24-Feb-95   SFP   - Initial release to customer as example code.
   C    07-Mar-95   SFP   - Removed reference to nup_inc.h and changed
                            OUR_MODULE_ID from 0x3d to 0xef.
   D    28-Jun-95   MH    - Use ISP_TASK_ID not NUP_TASK_ID
   E    03-Aug-95   MH    - Use CAL_TASK_ID
   F    22-Aug-95   MH    - Specify CTU's module Id and CAL_TASK_ID
                            parameters on the command line.
   G    20-Sep-95   SFP   - CTU_cal_ind now clears the 'ind' structure
                            (using CAL_erase_ind) to ensure that all
                            parameter lengths are initialised to zero.
                            CTU_save_setup_ind now truncates called and
                            calling address if necessary before storing
                            in the call structure.
                            print_ptype added.
                            CAUSEV_NULL corrected from 0x2f to 0x1f.
                            CAUSEV_SCT  corrected from 0x30 to 0x10.
                            CTU_release_req now sets the extension indicator
                            in the cause value to indicate 'last octet'.
   H    02-Feb-96   SFP   - signal.h no longer included.
                            Now prints out Call porgress and need.
                            OPT_TR_TX_REQ and OPT_TR_RX_IND added.
   I    12-Apr-96   SRG   - NUM_CIRCUITS increased from 256 to 512.
                            CTU_other_message now prints out hdr.id.
                            Coding standard in cause indicators changed
                            from 2 (National Standard) to 0 (Q.763).
                            Run-time option OPT_WAIT_RLC added to
                            determine whether a response is issued on
                            receipt of Release_ind and whether CTU
                            waits in state STATE_WAIT_IDLE until
                            Release_conf is received.
   J    27-Feb-97   SRG   - memory.h changed to string.h.
   K    17-Apr-98   SFP   - printing of release confirmation and instance
                            added.
                            Now recovers instance from received primitive and
                            sends any response to that instance.
                            CTU_other_message displays message in standard
                            format.
   L    04-Nov-99    JB   - REJECT_CPC definition change from 0xe1 to 0x0c and
                            OG_CPC definition change from 0xe2 to 0x0a.
                          - CAUSEV_SUBIC removed and replaced by cause value
                            CAUSEV_NULL to release the call.
                          - All members of CTU_CALL structure now initialized
                            in ctu_ent() and set back in CTU_call_idle().
                          - Support for continuity check procedure added.
                          - CTU_lpa_req()function added.
   1    13-Jul-01    ML   - Call to GCT_grab() to read and discard messages
                            pending in task input message queue is no
                            longer required.
                          - Changed all instance variables to u16.
   2    17-Apr-02    ML   - NUM_CIRCUITS increased from 512 to 4096.
   3    12-Mar-04    MH   - Remove code that used the most significant
                            bit of the call Id  to determine if the call was
                            incoming or outgoing.
   4    21-Aug-06    RJ   - when configured for ANSI, CTU will now respond with
                            CALPN_SETUP_RESP_ANM, instead of 
                            CALPN_SETUP_RESP_CON.
                          - Corrected checks against CONT_ON_THIS_CCT.
                          - Corrected checking of MAX_CID.
                          - Replace tabs with spaces.
   5    13-Dec-06    ML   - Change to use of Dialogic Corporation copyright.
   6    30-Nov-09   JLP   - NUM_CIRCUITS increased from 4096 to 65536.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "digpack.h"    /* prototypes for address digit packing functions */
#include "pack.h"       /* prototypes for parameter packing functions */
#include "call.h"       /* CAL library header file */

/*
 * Some useful macros.
 */
#define NO_RESPONSE             (0)
#define RESPONSE(mod_id)        (1 << ((mod_id) & 0x0f))
#define BIN2CH(b)               ((char)(((b)<10)?'0'+(b):'a'-10+(b)))


#define INVALID_CID(c)          ((c) > MAX_CID)
#define ODD_NDIG_BIT            (0x80)

#define CONTI_COT_SUCCESS       (0x01)  /* continuity indicators indicating */
                                        /* success */
#define CONTI_COT_FAILURE       (0x00)  /* continuity indicators indicating */
                                        /* failure */
#define BIT_CD                  (0x0c)
#define CONT_ON_THIS_CCT        (0x04)  /* Noci value corresponding to COT */
                                        /* request on this circuit */
#define COT_ON_PREV             (0x08)  /* Noci value corresponding to COT */
                                        /* request on previous circuit */

/*
 * Definition of message type for primitive requests
 * and indications to the call processing module
 */
#define CAL_MSG_TX_REQ          (0xc700)
#define CAL_MSG_RX_IND          (0x8701)

/*
 * Constants used in this example application:
 */
        /* Number of circuits supported */
#define NUM_CIRCUITS            (65536)
        /* Last logical circuit ID supported by this example */
#define MAX_CID                 (NUM_CIRCUITS - 1)
        /* Maximum number of digits in a single address */
#define MAX_ADDR_LEN            (0x28)
        /* Calling party category that will cause IC to be rejected */
#define REJECT_CPC              (0x0c)
        /* Calling party category used for outgoing calls */
#define OG_CPC                  (0x0a)
        /* Cause value - Null */
#define CAUSEV_NULL             (0x1f)
        /* Cause value - Subscriber Call Termination */
#define CAUSEV_SCT              (0x10)
        /* Minimum number of address digits accepted for address compete */
#define MIN_ADDR_DIGITS         (8)
        /* Maximum MSG parameter trace length */
#define MAX_PARAM_LEN           (320)

/*
 * command line option values:
 */
#define OPT_TR_PARAM        (0x0001) /* Trace received message param buf */
#define OPT_TR_PRIM         (0x0002) /* Trace primitive message parameters */
#define OPT_TR_CALL         (0x0004) /* Trace call parameters */
#define OPT_TR_TX_REQ       (0x0008) /* Trace transmit request */
#define OPT_TR_RX_IND       (0x0010) /* Trace receive indication */
#define OPT_ANSI            (0x0100) /* ANSI specifications */

/*
 * Per logical circuit resource (used for
 * storing the call state and setup information).
 */
typedef struct ctu_call
{
  u8 a_digits[MAX_ADDR_LEN];    /* received A-party digits */
  u8 n_adig;                    /* number of stored A-party digits */
  u8 apr;                       /* calling party presentation restricted */
  u8 si;                        /* calling party screening indicator */
  u8 b_digits[MAX_ADDR_LEN];    /* received B-party digits */
  u8 n_bdig;                    /* number of stored B-party digits */
  u8 cpc;                       /* calling party category */
  u8 state;                     /* state */
  u16 instance;                 /* instance handling this call */
  u8 noci;                      /* nature of connection indicators */
} CTU_CALL;

/*
 * Array of per call resources, one for each
 * logical circuit that we can support.
 */
static CTU_CALL call_data[NUM_CIRCUITS];

/*
 * run-time options flags
 */
static u16 ctu_options;
static u8 ctu_module_id;
static u8 ctu_calling_process;

/*
 * main program loop termination flag
 */
int finished;

/*
 * lookup array for printing address characters
 */
static digprint[16] =
{
  '0', '1', '2', '3','4', '5', '6', '7',
  '8', '9', 'a', 'b', 'c', 'd', 'e', '.'
};

/*
 * CTU state definitions
 */
#define STATE_IDLE              (0)     /* Idle */
#define STATE_IC_SETUP          (1)     /* IC Setup */
#define STATE_IC_ACTIVE         (2)     /* IC Active */
#define STATE_OG_SETUP          (3)     /* OG Setup */
#define STATE_OG_ALERTING       (4)     /* OG Alerting */
#define STATE_WAIT_IDLE         (5)     /* Waiting for circuit to go idle */
#define STATE_IC_WAIT_COT_CHECK (6)        /* Waiting for continuity check */
#define STATE_IC_CCT_SEIZED     (7)        /* Circuit seizure */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  static int CTU_cal_ind(MSG *m);
  static int CTU_incoming_call(CTU_CALL *call, u16 cid);
  static int CTU_szd_call(CTU_CALL *call, u16 cid, CALPT_SZD_IND *szd_ind);
  static int CTU_other_message(MSG *m);
  static int CTU_setup_req(CTU_CALL *call, u16 cid);
  static int CTU_alert_req(u16 cid, u16 instance);
  static int CTU_setup_resp(u16 cid, u16 instance);
  static int CTU_release_req(u16 cid, u16 instance, u8 causev);
  static int CTU_release_resp(u16 cid, u16 instance);
  static int CTU_send_req(CALPT_REQ *req);
  static int CTU_cot_req(u16 cid, u16 instance, u8 conti);
  static int CTU_lpa_req(u16 cid, u16 instance);
  static int CTU_save_setup_ind(CTU_CALL *call, CALPT_SETUP_IND *setup_ind);
  static int CTU_save_info_ind(CTU_CALL *call, CALPT_INFO_IND *info_ind);
  static int CTU_call_idle(CTU_CALL *call);
  static int address_complete(u8 *digits, u8 ndig);
  static int CTU_send_msg(MSG *m);
  static int CTU_display_req(CALPT_REQ *req, MSG *m);
  static int CTU_display_ind(CALPT_IND *ind, MSG *m);
  static int show_binary_data(char *text, u8 *ptr, u16 len);
  static int display_hex(u8 *ptr, u16 len);
  static int show_ptype(u8 ptype, char *text);
  static int print_call(char *textdesc, CTU_CALL *call, u16 cid);
#else
  static int CTU_cal_ind();
  static int CTU_incoming_call();
  static int CTU_szd_call();
  static int CTU_other_message();
  static int CTU_setup_req();
  static int CTU_alert_req();
  static int CTU_setup_resp();
  static int CTU_release_req();
  static int CTU_release_resp();
  static int CTU_send_req();
  static int CTU_cot_req();
  static int CTU_lpa_req();
  static int CTU_save_setup_ind();
  static int CTU_save_info_ind();
  static int CTU_call_idle();
  static int address_complete();
  static int CTU_send_msg();
  static int CTU_display_req();
  static int CTU_display_ind();
  static int show_binary_data();
  static int display_hex();
  static int show_ptype();
  static int print_call();
#endif

int ctu_ent(our_mod_id, cal_task_id, options)
  u8 our_mod_id;
  u8 cal_task_id;
  u16 options;
{
  HDR *h;
  MSG *m;
  CTU_CALL *call;
  int i;

  ctu_options = options;
  ctu_module_id = our_mod_id;
  ctu_calling_process = cal_task_id;

  /*
   * Print banner so we know what's running:
   */
  printf("CTU: Example application and CAL interface  (C) Dialogic Corporation 1995-2009. All Rights Reserved.\n");
  printf("====================================================================================================\n\n");
  printf("CTU mod ID - 0x%02x; User Part module Id 0x%x\n", ctu_module_id, ctu_calling_process);

  /*
   * Intialise the CAL library recovery functions
   */
  CAL_init();

  /*
   * Initialise the (per-logical circuit) resources:
   */
  for (i=0; i<NUM_CIRCUITS; i++)
  {
    call = &call_data[i];
    call->state = STATE_IDLE;
    call->n_bdig = 0;
    call->n_adig = 0;
    call->cpc = 0;
    call->apr = 0;
    call->si = 1;
    call->instance = 0;
    call->noci = 0;
  }

  /*
   * Now enter main loop, receiving messages as
   * they become available and processing accordingly:
   */
  finished = 0;
  while (!finished)
  {
    /*
     * GCT_receive will attempt to receive message
     * from the tasks message queue and block until
     * a message is ready:
     */
    if ((h = GCT_receive(ctu_module_id)) != 0)
    {
      m = (MSG *)h;

      switch (m->hdr.type)
      {
        case CAL_MSG_RX_IND :
          CTU_cal_ind(m);
          break;

        default :
          CTU_other_message(m);
          break;
      }

      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }
  return(0);
}

/*
 * CTU_cal_ind handles call control indications
 *
 * Always returns zero.
 */
static int CTU_cal_ind(m)
  MSG *m;                       /* received message containing indication */
{
  CTU_CALL      *call;          /* per logical circuit call data for */
  CALPT_IND     ind;            /* structured form of received primitive */
  u16           cid;            /* logical circuit id of received primitive */

  /*
   * Recover the parameters from the MSG
   * into a 'C' structure:
   */
  CAL_erase_ind(&ind);
  if (CAL_msg_to_ind(&ind, m) != 0)
  {
    printf("CTU: *** Primitive indication recovery failure - m=0x%04p ***\n",m);
  }
  else
  {
    CTU_display_ind(&ind, m);
    /*
     * Recover the logical circuit id, check it is
     * valid and locate the appropriate call resource:
     */
    cid = (u16)ind.call_ref;
    if (INVALID_CID(cid))
      printf("Unexpected cid=0x%04x\n", cid);
    else
    {
      call = &call_data[cid];
      /*
       * Retrieve the instance that originated this
       * primitive (this may have changed since the
       * previous primitive).
       * Note that the nature of connection indicators
       * value is stored in CTU_save_setup_ind or
       * CTU_szd_call as necessary.
       */
      call->instance = ind.instance;
      /*
       * Now handle the event depending on the current state:
       */
      switch (call->state)
      {
        case STATE_IDLE :
          switch (ind.ptype)
          {
            case CALPN_SETUP_IND :
              /*
               * A new call is being setup on this (Idle) circuit.
               * Save the address information from the primitive
               * and determine if we have a complete address.
               * If the nature of connection indicators (noci) indicates
               * "continuity check requested on this circuit" then
               * the suitable procedure to connect a loop back can
               * be performed there.
               */
              CTU_save_setup_ind(call, &ind.u.setup_ind);
              if ((ind.u.setup_ind.noci.data[0] & BIT_CD) == CONT_ON_THIS_CCT)  
              {
                /*
                 * The procedure to connect a loop back can take place here.
                 */
                call->state = STATE_IC_WAIT_COT_CHECK;
              }
              else
              {
                if (address_complete(call->b_digits, call->n_bdig))
                {
                  /*
                   * Process the incoming call :
                   */
                  CTU_incoming_call(call, cid);
                }
                else
                  call->state = STATE_IC_SETUP;
              }
              break;

            case CALPN_RELEASE_IND :
              /*
               * Unexpected release indication so
               * return release response:
               */
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            case CALPN_CCT_SZE_IND :
              CTU_szd_call(call, cid, &ind.u.szd_ind);
              call->state = STATE_IC_CCT_SEIZED;
              break;

            default :
              /*
               * Unexpected primitive:
               * ignored instead of issuing Release request
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - IDLE STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_IC_CCT_SEIZED :
          switch (ind.ptype)
          {
            case CALPN_SETUP_IND :
              /*
               * A new call is being setup on this (Idle) circuit.
               * Save the address information from the primitive
               * and determine if we have a complete address.
               * If the nature of connection indicators (noci) indicates
               * "continuity check requered on this circuit" then
               * the suitable procedure to connect a loop back can
               * be performed there.
               */
              CTU_save_setup_ind(call, &ind.u.setup_ind);
              if ((ind.u.setup_ind.noci.data[0] & BIT_CD) == CONT_ON_THIS_CCT)  
              {
                /*
                 * The procedure to connect a loop back can take place here.
                 *
                 */
                call->state = STATE_IC_WAIT_COT_CHECK;
              }
              else
              {
                if (address_complete(call->b_digits, call->n_bdig))
                {
                  /*
                   * Process the incoming call :
                   */
                  CTU_incoming_call(call, cid);
                }
                else
                  call->state = STATE_IC_SETUP;
              }
              break;

            case CALPN_COT_IND :
              /*
               * Cot report indication failure.
               * Stay in the same state (because the call will be release
               * by the call processing module).
               */
              if (ind.u.cot_ind.conti.data[0] & CONTI_COT_SUCCESS)
              {
                /*
                 * The protocol module should never send a COT success
                 * to the application (CTU) in that state.
                 */
               }
              else
              {
                /*
                 * The procedure to disconnect a loop back can take place here.
                 */
              }
              break;

            case CALPN_RELEASE_IND :
              /*
               * If the nature of connection indicators (noci) indicates
               * "continuity check requested on this circuit" then
               * the suitable procedure to connect a loop back can
               * be performed there.
               */
              if ((ind.u.szd_ind.noci.data[0] & BIT_CD) == CONT_ON_THIS_CCT)
              {
                /*
                 * The procedure to disconnect a loop back can take place here.
                 */
              }
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive:
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - IC_SETUP STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_IC_WAIT_COT_CHECK :
          switch (ind.ptype)
          {
            case CALPN_INFO_IND :
              /*
               * Append the received address digits to those
               * already stored. Stay in the same state.
               */
              CTU_save_info_ind(call, &ind.u.info_ind);
              break;

            case CALPN_COT_IND :
              /*
               * The procedure to disconnect a loop back can take place here.
               *
               * Cot report indication received. If success indicated and
               * all digits have been received, process the incoming call.
               * Otherwise wait for more digits.
               * Note: Stay in the same state if the cot report indication
               * reported a failure (because the call will be released by the
               * call processing module).
               */
              if (ind.u.cot_ind.conti.data[0] & CONTI_COT_SUCCESS)
              {
                if (address_complete(call->b_digits, call->n_bdig))
                {
                  /*
                   * Process the incoming call :
                   */
                  CTU_incoming_call(call, cid);
                }
                else
                  call->state = STATE_IC_SETUP;
              }
              break;

            case CALPN_RELEASE_IND :
                /*
                 * The procedure to disconnect a loop back can take place here.
                 */
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive:
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - IC_WAIT_COT_CHECK STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_IC_SETUP :
          switch (ind.ptype)
          {
            case CALPN_INFO_IND :
              /*
               * Append the received address digits to those
               * already stored and check to see if we now
               * have a complete called party address.
               */
              CTU_save_info_ind(call, &ind.u.info_ind);
              if (address_complete(call->b_digits, call->n_bdig))
              {
                /*
                 * Process the incoming call :
                 */
                CTU_incoming_call(call, cid);
              }
              break;

            case CALPN_RELEASE_IND :
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive:
               * ignored instead of issuing Release request
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - IC_SETUP STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_IC_ACTIVE :
          switch (ind.ptype)
          {
            case CALPN_RELEASE_IND :
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive :
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - IC ACTIVE STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_OG_SETUP :
          switch (ind.ptype)
          {
            case CALPN_ALERT_IND :
              call->state = STATE_OG_ALERTING;
              break;

            case CALPN_RELEASE_IND :
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            case CALPN_SETUP_CONF_ANM :
            case CALPN_SETUP_CONF_CON :
              /*
               * Need to handle both type of setup_confirmation because
               * ANSI permits ANM in that state.
               */
              CTU_release_req((u16)(cid), call->instance, (u8)CAUSEV_SCT);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive:
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - OG SETUP STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_OG_ALERTING :
          switch (ind.ptype)
          {
            case CALPN_SETUP_CONF_ANM :
              CTU_release_req((u16)cid, call->instance, (u8)CAUSEV_SCT);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            case CALPN_RELEASE_IND :
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            default :
              /*
               * Unexpected primitive:
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - OG ALERTING STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;

        case STATE_WAIT_IDLE :
          switch (ind.ptype)
          {
            case CALPN_RELEASE_IND :
              CTU_release_resp(cid, call->instance);
              CTU_call_idle(call);
              call->state = STATE_WAIT_IDLE;
              break;

            case CALPN_RELEASE_CONF :
              call->state = STATE_IDLE;
              break;

            case CALPN_CCT_SZE_IND :
              CTU_szd_call(call, cid, &ind.u.szd_ind);
              call->state = STATE_IC_CCT_SEIZED;
              break;

            default :
              /*
               * Unexpected primitive:
               */
              printf("CTU: *** Primitive unexpected or unrecognised - ignored - WAIT_IDLE STATE -\t ptype=0x%04x \t***\n", ind.ptype);
              break;
          }
          break;
      }
    }
  }
  return(0);
}

/*
 * CTU_other_message handles any other messages
 *
 * Always returns zero.
 */
static int CTU_other_message(m)
  MSG *m;                       /* received message */
{
  HDR   *h;
  int   instance;
  u16   mlen;
  u8    *pptr;

  h = (HDR*)m;
  instance = GCT_get_instance(h);
  printf("CTU:I%02x M t%04x i%04x f%02x d%02x s%02x", instance, h->type, h->id, h->src, h->dst, h->status);

  if ((mlen = m->len) > 0)
  {
    if (mlen > MAX_PARAM_LEN)
      mlen = MAX_PARAM_LEN;
    printf(" p");
    pptr = get_param(m);
    while (mlen--)
    {
      printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
      pptr++;
    }
  }
  printf("\n");
  return(0);
}
/*
 *  CTU_szd_call handle incoming circuit seized.
 *
 * Always returns zero.
 */
static int CTU_szd_call(call, cid, szd_ind)
  CTU_CALL          *call;      /* per call data structure */
  u16                cid;       /* logical circuit id */
  CALPT_SZD_IND *szd_ind;       /* structured form of received primitive */
{
  CTU_CALL *og_call;            /* Outgoing call data structure */

  print_call("IC_CCT_SZD", call, cid);

  /*
   * Saves the nature of connection indicators (noci) parameter
   * from the circuit seized indication
   */
  call->noci = (u8)(szd_ind->noci.data[0]);
  og_call = &call_data[cid];

  /*
   * If continuity check indicator in the incoming call set
   * to "continuity check required on this circuit" then the
   * OG noci is set to "continuity check performed on
   * previous circuit".
   * The original reminding part of the noci is kept unchanged.
   */
  if ((call->noci & BIT_CD) == CONT_ON_THIS_CCT)  
  {
    og_call->noci = (u8)((call->noci & ~BIT_CD)| COT_ON_PREV);
    /*
     * The procedure to connect a loop back can take place here.
     */
    if (ctu_options & OPT_ANSI)
    {
      CTU_lpa_req(cid, call->instance);
    }
  }
  return(0);
}

/*
 * CTU_incoming_call checks to see if the calling party category (cpc)
 * value for an incoming call matches that for the calls that we will
 * answer. If so the call is accepted by completing the call setup
 * (issuing an Alerting Request followed by a Setup Response).
 * An outgoing call is then started on the next logical circuit.
 *
 * Always returns zero.
 */
static int CTU_incoming_call(call, cid)
  CTU_CALL  *call;              /* per call data structure */
  u16        cid;               /* logical circuit id */
{
  CTU_CALL *og_call;

  print_call("IC", call, cid);

  /*
   * Check to see if the cpc value matches
   * that for calls that we will answer.
   */
  if (call->cpc == REJECT_CPC)
  {
    CTU_release_req(cid, call->instance, CAUSEV_NULL);
    CTU_call_idle(call);
    call->state = STATE_WAIT_IDLE;
  }
  else
  {
    /*
     * Complete the incoming call setup:
     */
    CTU_alert_req(cid, call->instance);
    CTU_setup_resp(cid, call->instance);
    call->state = STATE_IC_ACTIVE;

    /*
     * If the next logical circuit is valid, and
     * the call state is Idle, start a new (outgoing)
     * call on that circuit. Otherwise use the first
     * logical circuit id.
     */
    if (++cid > MAX_CID)
      cid = 0;
    og_call = &call_data[cid];
    if (og_call->state == STATE_IDLE)
    {
      /*
       * Use the called address, calling address, calling party category (cpc),
       * presentation restricted (apr), screening indicator (si), and
       * instance values from the incoming call.
       */
      memcpy((void*)og_call->a_digits, (void*)call->a_digits, call->n_adig);
      og_call->n_adig = call->n_adig;
      memcpy((void*)og_call->b_digits, (void*)call->b_digits, call->n_bdig);
      og_call->n_bdig = call->n_bdig;
      og_call->cpc = call->cpc;
      og_call->apr = call->apr;
      og_call->si = call->si;
      og_call->instance = call->instance;

      /*
       * If continuity check indicator in the incoming call set to
       * "continuity check required on this circuit" then the OG nature
       * of connection indicators (noci) is set to "continuity check
       * performed on previous circuit" and the cot request is sent.
       * The rest of the noci is kept unchanged.
       */
      if ((call->noci & BIT_CD) == CONT_ON_THIS_CCT)
      {
        og_call->noci = (u8)((call->noci & ~BIT_CD)| COT_ON_PREV);
        CTU_setup_req(og_call, (u16)cid);
        CTU_cot_req((u16)cid, (u16)og_call->instance, 
                (u8)CONTI_COT_SUCCESS);
      }
      else
      {
        /*
         * Continuity check indicator set to "continuity check
         * not required on this circuit".
         */
        CTU_setup_req(og_call, (u16)cid);
      }
      print_call("OG", og_call, cid);
      og_call->state = STATE_OG_SETUP;
    }
  }
  return(0);
}

/*
 * CTU_setup_req builds a Setup request message
 * and sends it to the call processing module.
 *
 * Always returns zero.
 */
static int CTU_setup_req(call, cid)
  CTU_CALL *call;               /* call data */
  u16   cid;                    /* logical circuit id used to make call */
{
  CALPT_REQ  req;               /* structured form of primitive */
  CALPT_SETUP_REQ  *setup_req;

  CAL_erase_req(&req);
  setup_req = &req.u.setup_req;
  /*
   * Build up the structured primitive:
   */
  req.call_ref = cid;
  req.instance = call->instance;
  req.ptype = CALPN_SETUP_REQ;
  setup_req->called_num.len = (u8)(2 + ((call->n_bdig+1) >> 1));
  /*
   * Set naoi = National (Significant) Number.
   */
  setup_req->called_num.data[0] = 0x03;
  if (call->n_bdig & 1)
    setup_req->called_num.data[0] |= ODD_NDIG_BIT;
  /*
   * Set numbering plan = E.163/E.164
   */
  setup_req->called_num.data[1] = 0x10;
  pack_digits(setup_req->called_num.data+2, 0, call->b_digits, call->n_bdig);

  /*
   * Add the (optional) calling number
   */
  if (call->n_adig)
  {
    setup_req->calling_num.len = (u8)(2 + ((call->n_adig+1)>>1));
    setup_req->calling_num.data[0] = 0x03;
    if (call->n_adig & 1)
      setup_req->calling_num.data[0] |= ODD_NDIG_BIT;
    setup_req->calling_num.data[1] = 
        (u8)(0x10 + ((call->apr & 3) << 2)+(call->si & 3));
    pack_digits(setup_req->calling_num.data+2, 0, call->a_digits, call->n_adig);
  }

  setup_req->cpc.len = 1;
  setup_req->cpc.data[0] = call->cpc;
  setup_req->noci.len = 1;
  setup_req->noci.data[0] = call->noci;

  CTU_send_req(&req);

  return(0);
}

/*
 * CTU_alert_req builds an Alert request message
 * and sends it to the call processing module
 *
 * Always returns zero.
 */
static int CTU_alert_req(cid, instance)
  u16   cid;                   /* Logical circuit ID to send request */
  u16   instance;              /* Instance to send request for */
{
  CALPT_REQ req;               /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  CAL_erase_req(&req);
  req.call_ref = cid;
  req.instance = instance;
  req.ptype = CALPN_ALERT_REQ;
  CTU_send_req(&req);
  return(0);
}

/*
 * CTU_setup_resp builds a Setup response message
 * and sends it to the call processing module.
 *
 * Always returns zero.
 */
static int CTU_setup_resp(cid, instance)
  u16   cid;                    /* Logical circuit ID to send request */
  u16   instance;               /* Instance to send request for */
{
  CALPT_REQ  req;               /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  CAL_erase_req(&req);
  req.call_ref = cid;
  req.instance = instance;
  req.ptype = CALPN_SETUP_RESP_ANM;
  CTU_send_req(&req);
  return(0);
}

/*
 * CTU_release_req builds a Release request message
 * and sends it to the call processing module.
 */
static int CTU_release_req(cid, instance, causev)
  u16   cid;                   /* Logical circuit ID to send request */
  u16   instance;              /* Instance to send request for */
  u8    causev;                /* cause value to encode */
{
  CALPT_REQ  req;              /* structured form of primitive */
  CALPT_RELEASE_REQ *release_req;

  /*
   * Build up the structured primitive:
   */
  CAL_erase_req(&req);
  release_req = &req.u.release_req;
  req.call_ref = cid;
  req.instance = instance;
  req.ptype = CALPN_RELEASE_REQ;
  release_req->causei.len = 2;
  /*
   * Set the first cause indicators octet to
   * indicate 'no EXT1', and coding standard
   * of 0 (Q.763).
   */
  release_req->causei.data[0] = 0x80;
  /*
   * Set the extension indicator to
   * indicate 'last octet' :
   */
  release_req->causei.data[1] = (u8)(causev | 0x80);

  CTU_send_req(&req);
  return(0);
}

/*
 * CTU_release_resp builds a Release response message
 * and sends it to the call processing module.
 *
 * Always returns zero.
 */
static int CTU_release_resp(cid, instance)
  u16   cid;                    /* Logical circuit ID to send request */
  u16   instance;               /* Instance to send request for */
{
  CALPT_REQ  req;               /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  CAL_erase_req(&req);
  req.call_ref = cid;
  req.instance = instance;
  req.ptype = CALPN_RELEASE_RESP;
  CTU_send_req(&req);
  return(0);
}

/*
 * CTU_lpa_req builds a Loop Back Acknowledgement
 * request message and sends it to the call processing module.
 *
 * Always returns zero.
 */
static int CTU_lpa_req(cid, instance)
  u16   cid;                    /* Logical circuit ID to send request */
  u16   instance;               /* Instance to send request for */
{
  CALPT_REQ  lpa;               /* structured form of primitive */

  /*
   * Build up the structured primitive:
   * Note: LPA message does not have any parameters.
   */
  CAL_erase_req(&lpa);
  lpa.call_ref = cid;
  lpa.instance = instance;
  lpa.ptype = CALPN_LPA_REQ;
  CTU_send_req(&lpa);
  return(0);
}

/*
 * CTU_cot_req builds a Continuity report request message
 * and sends it to the call processing module.
 *
 * Always returns zero.
 */
static int CTU_cot_req(cid, instance, conti)
  u16  cid;                     /* Logical circuit ID to send request */
  u16  instance;                /* Instance to send request for */
  u8   conti;                   /* continuity indicators */
{
  CALPT_REQ  cot_req;           /* structured form of primitive */

  /*
   * Build up the structured primitive:
   */
  CAL_erase_req(&cot_req);
  cot_req.call_ref = cid;
  cot_req.instance = instance;
  cot_req.ptype = CALPN_COT_REQ;
  cot_req.u.cot_req.conti.len = 1;
  cot_req.u.cot_req.conti.data[0] = conti;
  CTU_send_req(&cot_req);
  return(0);
}

/*
 * CTU_send_req allocates a message (using the
 * getm() function) then using the CAL library function
 * CAL_req_to_msg() converts the primitive parameters
 * from the 'C' structured representation into the correct
 * format for passing to the call processing module.
 * The formatted message is then sent.
 *
 * Always returns zero.
 */
static int CTU_send_req(req)
  CALPT_REQ  *req;              /* structured primitive request to send */
{
  MSG *m;                       /* message sent to CAL */

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)CAL_MSG_TX_REQ, req->call_ref, NO_RESPONSE,
                                      CAL_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ctu_module_id;
    m->hdr.dst = ctu_calling_process;

    /*
     * Use the library function to format the
     * parameter area of the message and
     * (if successful) send it:
     */
    if (CAL_req_to_msg(m, req) != 0)
    {
      printf("CTU: *** failed to format primitive request ***\n");
      relm(&m->hdr);
    }
    else
    {
      CTU_display_req(req, m);
      /*
       * and send to the call processing module:
       */
      CTU_send_msg(m);
    }
  }
  return(0);
}

/*
 * CTU_save_setup_ind saves the call setup parameters
 * (called address, calling address (if present) and
 * cpc) from a Setup indication and stores them in a
 * call data structure.
 *
 * Always returns zero.
 */
static int CTU_save_setup_ind(call, setup_ind)
  CTU_CALL       *call;         /* per call data structure */
  CALPT_SETUP_IND *setup_ind;   /* structured form of setup indication */
{
  u8  ndig;

  /*
   * recover the called address digits from the
   * packed form to bcd (one digit per octet).
   */
  ndig = (u8)((setup_ind->called_num.len - 2) << 1);
  if ((setup_ind->called_num.data[0] & ODD_NDIG_BIT) && (ndig > 0))
    ndig--;
  if (ndig > MAX_ADDR_LEN)
    ndig = MAX_ADDR_LEN;
  unpack_digits(call->b_digits, setup_ind->called_num.data+2, 0, ndig);
  call->n_bdig = ndig;

  /*
   * recover the calling address digits (if present)
   * and store the presentation restricted indicator
   * and the screening indicator.
   */
  if (setup_ind->calling_num.len)
  {
    ndig = (u8)((setup_ind->calling_num.len - 2) << 1);
    if ((setup_ind->calling_num.data[0] & ODD_NDIG_BIT) && (ndig > 0))
      ndig--;
    if (ndig > MAX_ADDR_LEN)
      ndig = MAX_ADDR_LEN;
    unpack_digits(call->a_digits, setup_ind->calling_num.data+2, 0, ndig);
    call->n_adig = ndig;
    call->apr = (u8)(setup_ind->calling_num.data[1] & 0x0c);
    call->si = (u8)(setup_ind->calling_num.data[1] & 0x03);
  }

  /*
   * Store the nature of connection indicators (noci).
   */
  call->noci = (u8)(setup_ind->noci.data[0]);

  /*
   * Store the Calling Party Category (cpc)
   */
  call->cpc = setup_ind->cpc.data[0];

  return(0);
}

/*
 * CTU_save_info_ind saves the call setup parameters
 * (subsequent address) from an Info indication and
 * stores them in a call data structure.
 *
 * Always returns zero.
 */
static int CTU_save_info_ind(call, info_ind)
  CTU_CALL       *call;         /* per call data structure */
  CALPT_INFO_IND *info_ind;     /* structured form of info indication */
{
  u8  ndig;

  /*
   * append the address digits from the
   * packed form to those already stored.
   */
  ndig = (u8)((info_ind->subsq_num.len - 1) << 1);
  if ((info_ind->subsq_num.data[0] & ODD_NDIG_BIT) && (ndig > 0))
    ndig--;
  if ((ndig + call->n_bdig) > MAX_ADDR_LEN)
    ndig = (u8)(MAX_ADDR_LEN - call->n_bdig);
  unpack_digits(call->b_digits + call->n_bdig, info_ind->subsq_num.data+1, 0, ndig);
  call->n_bdig += ndig;

  return(0);
}

/*
 * CTU_call_idle deletes any saved call data.
 *
 * Always returns zero.
 */
static int CTU_call_idle(call)
  CTU_CALL *call;               /* call resource to set idle */
{
  call->n_bdig = 0;
  call->n_adig = 0;
  call->cpc = 0;
  call->apr = 0;
  call->si = 1;
  call->instance = 0;
  call->noci = 0;
  return(0);
}

/*
 * address_complete checks to see if the supplied
 * (unpacked) digits are a compete address. This is
 * true if
 * 1. The maximum number of address digits have been received, or
 * 2. The address digits contain the ST (end of dialing) digit.
 *
 * Returns zero if the address is NOT complete.
 */
static int address_complete(digits, ndig)
  u8  *digits;
  u8  ndig;
{
  u8   i;
  int  ret_val;

  if (ndig >= MIN_ADDR_DIGITS)
  {
    ret_val = 1;
  }
  else
  {
    ret_val = 0;
    for (i = 0; i < ndig; i++)
    {
      if ((*digits++ & 0xf) == 0xf)
      {
        ret_val = -1;
        break;
      }
    }
    printf("CTU: *** Address incomplete, minimum %d digits needed. ***\nCTU: *** Waiting for more digit(s).  ***  \n", MIN_ADDR_DIGITS);
  }
  return(ret_val);
}


/*
 * CTU_send_msg sends a MSG. On failure the
 * message is released and the user notified.
 *
 * Always returns zero.
 */
static int CTU_send_msg(m)
  MSG        *m;                /* MSG to send */
{

  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    fprintf(stderr, "CTU: *** failed to send message ***\n");
    relm((HDR *)m);
  }
  return(0);
}

/********************************************************************
 *                                                                  *
 *     Functions to display primitive parameters to the user        *
 *                                                                  *
 ********************************************************************/

/*
 * CTU_display_req displays the parameters
 * of a CAL request to the console.
 *
 * Always returns zero.
 */
static int CTU_display_req(req, m)
  CALPT_REQ      *req;          /* structured request data */
  MSG            *m;            /* MSG structure */
{
  u8  ptype;

  if (ctu_options & OPT_TR_TX_REQ)
    printf("CTU Tx: Inst = 0x%02x cid = 0x%04x ", req->instance, req->call_ref);

  if (ctu_options & OPT_TR_PARAM)
    display_hex(get_param(m), m->len);

  if (ctu_options & OPT_TR_TX_REQ)
    printf("\n");

  if (ctu_options & OPT_TR_PRIM)
  {
    ptype = (u8)req->ptype;
    switch (ptype)
    {
      case CALPN_SETUP_REQ :
        show_ptype(ptype, "Setup request");
        show_binary_data("called_num", req->u.setup_req.called_num.data,
                                    req->u.setup_req.called_num.len);
        show_binary_data("calling_num", req->u.setup_req.calling_num.data,
                                     req->u.setup_req.calling_num.len);
        show_binary_data("cpc", req->u.setup_req.cpc.data,
                             req->u.setup_req.cpc.len);
        break;

      case CALPN_RELEASE_REQ :
        show_ptype(ptype, "Release request");
        show_binary_data("causei", req->u.release_req.causei.data,
                                 req->u.release_req.causei.len);
        break;

      case CALPN_ALERT_REQ :
        show_ptype(ptype, "Alerting request"); 
        break;
      case CALPN_LPA_REQ :
        show_ptype(ptype, "Loop Back request"); 
        break;
      case CALPN_SETUP_RESP_ANM :
        show_ptype(ptype, "Setup response");
        break;
      case CALPN_SETUP_RESP_CON :
        show_ptype(ptype, "Setup response");
        break;
      case CALPN_RELEASE_RESP :
        show_ptype(ptype, "Release response");
        break;
      case CALPN_COT_REQ :
        show_ptype(ptype, "Continuity report request");
        break;

      default :
        printf("*** Unrecognised primitive type ***\n");
        break;
    }
  }
  return(0);
}

/*
 * CTU_display_ind displays the parameters
 * of a CAL indication to the console.
 *
 * Always returns zero.
 */
static int CTU_display_ind(ind, m)
  CALPT_IND      *ind;          /* structured indication data */
  MSG            *m;            /* MSG structure */
{
  u8  ptype;

  if (ctu_options & OPT_TR_RX_IND)
    printf("CTU Rx: inst = 0x%02x cid = 0x%04x ", ind->instance, ind->call_ref);

  if (ctu_options & OPT_TR_PARAM)
    display_hex(get_param(m), m->len);

  if (ctu_options & OPT_TR_RX_IND)
    printf("\n");

  if (ctu_options & OPT_TR_PRIM)
  {
    ptype = (u8)ind->ptype;
    switch (ptype)
    {
      case CALPN_SETUP_IND :
        show_ptype(ptype, "Setup indication");

        show_binary_data("called_num", ind->u.setup_ind.called_num.data,
                         ind->u.setup_ind.called_num.len);
        show_binary_data("calling_num", ind->u.setup_ind.calling_num.data,
                         ind->u.setup_ind.calling_num.len);
        show_binary_data("cpc", ind->u.setup_ind.cpc.data,
                         ind->u.setup_ind.cpc.len);
        break;

      case CALPN_INFO_IND :
        show_ptype(ptype, "Info indication");
        show_binary_data("subsq_num", ind->u.info_ind.subsq_num.data,
                         ind->u.info_ind.subsq_num.len);
        break;

      case CALPN_COT_IND :
        show_ptype(ptype, "Continuity report indication");
        show_binary_data("conti", ind->u.cot_ind.conti.data,
                         ind->u.cot_ind.conti.len);
        break;
      case CALPN_ALERT_IND :
        show_ptype(ptype, "Alerting indication");
        show_binary_data("bci", ind->u.alert_ind.bci.data,
                         ind->u.alert_ind.bci.len);
        break;

      case CALPN_SETUP_CONF_ANM :
        show_ptype(ptype, "Setup confirmation");
        show_binary_data("bci", ind->u.setup_conf.bci.data,
                         ind->u.setup_conf.bci.len);
        break;

      case CALPN_SETUP_CONF_CON :
        show_ptype(ptype, "Setup connection confirmation");
        show_binary_data("bci", ind->u.setup_conf.bci.data,
                         ind->u.setup_conf.bci.len);
        break;

      case CALPN_RELEASE_IND :
        show_ptype(ptype, "Release indication");
        show_binary_data("causei", ind->u.release_ind.causei.data,
                         ind->u.release_ind.causei.len);
        break;

      case CALPN_RELEASE_CONF :
        show_ptype(ptype, "Release confirmation");
        break;

      case CALPN_PROGRESS_IND :
        show_ptype(ptype, "Progress indication");
        if (ind->u.progress_ind.NUP_event_inf.len)
        {
          show_binary_data("NUP_event_inf",
                           ind->u.progress_ind.NUP_event_inf.data,
                           ind->u.progress_ind.NUP_event_inf.len);
        }
        break;

      case CALPN_NEED_IND :
        show_ptype(ptype, "Need indication");
        show_binary_data("need", ind->u.need_ind.need.data,
                         ind->u.need_ind.need.len);
        break;

      case CALPN_CCT_SZE_IND :
        show_ptype(ptype, "Circuit seized indication");
        show_binary_data("noci", ind->u.szd_ind.noci.data,
                         ind->u.szd_ind.noci.len);
        break;
      default :
        printf("*** Unrecognised primitive type ***\n");
        break;
    }
  }
  return(0);
}


/*
 * show_binary_data displays parameter name (in text form)
 * and <len> bytes of hex data commencing from <ptr> to
 * the console.
 *
 * Always returns zero.
 */
static int show_binary_data(text, ptr, len)
  char  *text;                  /* parameter nme text */
  u8    *ptr;                   /* pointer to first byte of data */
  u16   len;                    /* length of data */
{
  if (len)
  {
    printf("  %12s = ", text);
    display_hex(ptr, len);
    printf("\n");
  }
  return(0);
}

/*
 * display_hex displays hex data.
 *
 * Always returns zero.
 */
static int display_hex(ptr, len)
  u8    *ptr;                   /* first byte of data to display */
  u16   len;                    /* lenght of data to display */
{
  while (len--)
    printf("%02x ", *ptr++);
  return(0);
}

/*
 * show_ptype displays a primitive text name string
 * to the console.
 *
 * Always returns zero.
 */
static int show_ptype(ptype, text)
  u8    ptype;
  char  *text;                  /* parameter nme text */
{
  printf("  %12s = (%02x) %s\n", "ptype", ptype, text);
  return(0);
}


/*
 * print_call prints the call parameters
 * to the console.
 *
 * Always returns zero.
 */
static int print_call(textdesc, call, cid)
  char      *textdesc;          /* null terminated text descriptor */
  CTU_CALL  *call;              /* structured call parameters */
  u16       cid;                /* logical circuit id */
{
  u8  i;

  if (ctu_options & OPT_TR_CALL)
  {
    printf("CTU %s: (cid = 0x%04x) ", textdesc, cid);
    {
      if (call->n_adig)
      {
        printf("[calg->");
        for (i = 0; i < call->n_adig; i++)
          printf("%c", digprint[call->a_digits[i] & 0x0f]);
        printf("]");
        printf(" (prs_rst = %01d) ", call->apr);
        printf(" (scr_ind = %01d) ", call->si);
        printf(" (noci = %01d) ", call->noci);
      }
    }
    printf("[cald->");
    for (i = 0; i < call->n_bdig; i++)
      printf("%c", digprint[call->b_digits[i] & 0x0f]);
    printf("]");
    printf(" cpc = 0x%02x\n", call->cpc);
  }
  return(0);
}
