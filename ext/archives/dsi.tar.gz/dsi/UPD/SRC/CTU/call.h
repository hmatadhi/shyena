/*
		Copyright (C) Dialogic Corporation 1995-2006. All Rights Reserved.

 Name:          call.h

 Description:   Header file for use in conjunction
		with the call-control interface library
		contained in the file call.c

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    06-Feb-95   SFP   - Initial code.
   A+   14-feb-95   SFP   - CALPPN_TERMINATOR and CALPPN_MAX added.
   B    23-Aug-95   MH    - Add proto for CAL_int().
   C    05-Feb-96   SFP   - Definitions added for primitives:
			    need_req, cpg_ind and need_ind.
			    Parameter name and length definitions added for
			    redir_inf, redir_num, need, NUP_fci.
   D    13-Apr-96   SRG   - CALPN_RELEASE_RESP, CALPN_RELEASE_CONF,
			    CALPT_RELEASE_RESP & CALPT_RELEASE_CONF added.
   E    17-Apr-98   SFP   - instance added to CALPT_IND and CALPT_REQ.
   F    04-Nov-99   JB    - Messages and parameters definition now refer
   			    to those in Ccp_inc.h.
                          - CALPN_CON_REQ added.  
                          - CALPPN_REDIR_NUM definition corrected.
   1    13-Jul-01   ML    - changed instance to u16 in strcutures CALPT_REQ
                            and CALPT_IND.
   2    12-Mar-04   JER   - Changed copyright.                          
   3    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
 */

#include "ccp_inc.h"
 
/*
 * Definitions for buffer sizes in the 'C' structured
 * representation of call control protocol primitives.
 *
 * The library functions ensure that the given size
 * CALPL_xxx is not exceeded.
 */
#define CALPL_CALLED_NUM    (16)    /* space for called party number */
#define CALPL_CALLING_NUM   (10)    /* space for calling party number */
#define CALPL_CAUSEI        (4)     /* space for cause indicators */
#define CALPL_SUBSQ_NUM     (15)    /* space for subsequent number */
#define CALPL_FCI           (2)     /* space for forward call indicators */
#define CALPL_BCI           (2)     /* space for backward call indicators */
#define CALPL_CPC           (1)     /* space for calling party category */
#define CALPL_TMR           (1)     /* space for trans. medium requirement */
#define CALPL_NOCI          (1)     /* space for nature of connection ind */
#define CALPL_CONTI         (1)     /* space for continuity indicators */
#define CALPL_REDIR_INF     (2)     /* space for redirection information */
#define CALPL_REDIR_NUM     (10)    /* space for redirecting number */
#define CALPL_NUP_FCI       (1)     /* space for NUP forward call ind */
#define CALPL_NUP_EVENT_INF (1)     /* space for NUP event information */
#define CALPL_NEED          (48)    /* space for NUP nodal end to end data */

/*
 * Primitive type tokens for requests:
 */
#define CALPN_SETUP_REQ         (CCPT_IAM)     /* Setup request */
#define CALPN_COT_REQ           (CCPT_COT)     /* continuity report request */
#define CALPN_ALERT_REQ         (CCPT_ACM)     /* Alert request */
#define CALPN_CON_REQ  	        (CCPT_CON)     /* Connect request */
#define CALPN_SETUP_RESP_ANM    (CCPT_ANM)     /* Setup response (ANM)*/
#define CALPN_SETUP_RESP_CON    (CCPT_CON)     /* Setup response (CON) */
#define CALPN_RELEASE_REQ       (CCPT_REL)     /* Release request */
#define CALPN_RELEASE_RESP      (CCPT_RLC)     /* Release response */
#define CALPN_LPA_REQ      	(CCPT_LPA)     /* Loop back acknowledgement request */
#define CALPN_NEED_REQ          (CCPT_NEED)    /* (NUP) need request */

/*
 * Primitive type tokens for indications:
 */
#define CALPN_SETUP_IND         (CCPT_IAM)     /* Setup indication */
#define CALPN_INFO_IND          (CCPT_SAM)     /* Info indication */
#define CALPN_BINFO_CONF        (CCPT_INF)     /* Backwards info confirmation */
#define CALPN_COT_IND           (CCPT_COT)     /* continuity report indication */
#define CALPN_ALERT_IND         (CCPT_ACM)     /* Alert indication */
#define CALPN_SETUP_CONF_ANM    (CCPT_ANM)     /* Setup confirmation (ANM) */
#define CALPN_SETUP_CONF_CON    (CCPT_CON)     /* Setup confirmation (CON) */
#define CALPN_RELEASE_IND       (CCPT_REL)     /* Release indication */
#define CALPN_RELEASE_CONF      (CCPT_RLC)     /* Release confirmation */
#define CALPN_PROGRESS_IND      (CCPT_CPG)     /* Call progress indication */
#define CALPN_NEED_IND          (CCPT_NEED)    /* (NUP) need indication */
#define CALPN_CCT_SZE_IND       (CCPT_SZE)     /* Circuit seized indication */

/*
 * Parameter name tokens
 */
#define CALPPN_TERMINATOR	(CCPN_eoop)	   	/* End of parameters token */
#define CALPPN_TMR              (CCPN_tmr)     	   	/* Transmission medium requirement */
#define CALPPN_CALLED_NUM       (CCPN_called_num)  	/* Called party number */
#define CALPPN_SUBSQ_NUM        (CCPN_subsq_num)   	/* Subsequent number */
#define CALPPN_NOCI             (CCPN_noci)    	   	/* Nature of connection indicators */
#define CALPPN_FCI              (CCPN_fci)    	   	/* Forward call indicators */
#define CALPPN_CPC              (CCPN_cpc)     	   	/* Calling party's category */
#define CALPPN_CALLING_NUM      (CCPN_calling_num) 	/* Calling party number */
#define CALPPN_REDIR_NUM        (CCPN_redirecting_num)  /* Redirecting numer */
#define CALPPN_CONTI            (CCPN_conti)    	/* continuity indicators */
#define CALPPN_BCI              (CCPN_bci)    		/* Backward call indicators */
#define CALPPN_REDIR_INF        (CCPN_redirection_inf)  /* Redirection information */
#define CALPPN_CAUSEI           (CCPN_causei) 		/* Cause indicators */
#define CALPPN_NEED             (CCPN_need)   		/* Nodal end to end data */
#define CALPPN_NUP_EVENT_INF    (CCPN_nup_event_inf)   	/* NUP event information */
#define CALPPN_NUP_FCI          (CCPN_nup_fci)         	/* NUP forward call indicators */
#define CALPPN_MAX              (253)   		/* Maximum parameter token value */

/*
 * Definitions for error codes returned
 * from the library formatting functions:
 */
#define SPACE_ERROR     (1)
#define PTYPE_ERROR     (2)
#define FORMAT_ERROR    (3)

/*
 * Maximum parameter length in an MSG:
 */
#define CAL_MAX_PARAM_LEN  (320)

/********************************************************************
 *                                                                  *
 *          Structure Definitions for Primitive Parameters          *
 *                                                                  *
 ********************************************************************/

typedef struct calpt_called_num
{
  u8    len;
  u8    data[CALPL_CALLED_NUM];
} CALPT_CALLED_NUM;                     /* Called party number */

typedef struct calpt_calling_num
{
  u8    len;
  u8    data[CALPL_CALLING_NUM];
} CALPT_CALLING_NUM;                    /* Calling party number */

typedef struct calpt_causei
{
  u8    len;
  u8    data[CALPL_CAUSEI];
} CALPT_CAUSEI;                         /* Cause indicators */

typedef struct calpt_subsq_num
{
  u8    len;
  u8    data[CALPL_SUBSQ_NUM];
} CALPT_SUBSQ_NUM;                      /* Subsequent number */

typedef struct calpt_fci
{
  u8    len;
  u8    data[CALPL_FCI];
} CALPT_FCI;                            /* Forward call indicators */

typedef struct calpt_bci
{
  u8    len;
  u8    data[CALPL_BCI];
} CALPT_BCI;                            /* Backward call indicators */

typedef struct calpt_cpc
{
  u8    len;
  u8    data[CALPL_CPC];
} CALPT_CPC;                            /* Calling party's category */

typedef struct calpt_tmr
{
  u8    len;
  u8    data[CALPL_TMR];
} CALPT_TMR;                            /* Transmission medium requirement */

typedef struct calpt_noci
{
  u8    len;
  u8    data[CALPL_NOCI];
} CALPT_NOCI;                           /* Nature of connection indicators */

typedef struct calpt_redir_inf
{
  u8    len;
  u8    data[CALPL_REDIR_INF];
} CALPT_REDIR_INF;                      /* Redirection information */

typedef struct calpt_redir_num
{
  u8    len;
  u8    data[CALPL_REDIR_NUM];
} CALPT_REDIR_NUM;                      /* Redirecting number */

typedef struct calpt_NUP_fci
{
  u8    len;
  u8    data[CALPL_NUP_FCI];
} CALPT_NUP_FCI;                        /* NUP forward call indicators */

typedef struct calpt_need
{
  u8    len;
  u8    data[CALPL_NEED];
} CALPT_NEED;                           /* Nodal end to end data */

typedef struct calpt_NUP_event_inf
{
  u8    len;
  u8    data[CALPL_NUP_EVENT_INF];
} CALPT_NUP_EVENT_INF;                  /* NUP event information */

typedef struct calpt_conti
{
  u8    len;
  u8    data[CALPL_CONTI];
} CALPT_CONTI;                          /* continuity indicators data */

/********************************************************************
 *                                                                  *
 *          Structure Definitions for Primitive Requests            *
 *                                                                  *
 ********************************************************************/

typedef struct calpt_alert_req          /* Alerting request */
{
  CALPT_BCI     bci;                      /* Backward call indicators */
} CALPT_ALERT_REQ;

typedef struct calpt_release_req        /* Release request */
{
  CALPT_CAUSEI  causei;                   /* Cause indicators */
} CALPT_RELEASE_REQ;

typedef struct calpt_release_resp       /* Release response */
{
  CALPT_CAUSEI  causei;                   /* Cause indicators */
} CALPT_RELEASE_RESP;

typedef struct calpt_setup_req          /* Setup request */
{
  CALPT_CALLED_NUM  called_num;           /* Called party number */
  CALPT_CALLING_NUM calling_num;          /* Calling party number */
  CALPT_FCI     fci;                      /* Forward call indicators */
  CALPT_CPC     cpc;                      /* Calling party category */
  CALPT_TMR     tmr;                      /* Transmission medium requirement */
  CALPT_NOCI    noci;                     /* Nature of connection indicators */
  CALPT_REDIR_INF  redir_inf;             /* Redirection information */
  CALPT_REDIR_NUM  redir_num;             /* Redirecting number */
  CALPT_NUP_FCI    NUP_fci;               /* NUP forward call indicators */
} CALPT_SETUP_REQ;

typedef struct calpt_setup_resp         /* Setup response */
{
  CALPT_BCI     bci;                      /* Backward call indicators */
} CALPT_SETUP_RESP;

typedef struct calpt_need_req           /* NEED request */
{
  CALPT_NEED    need;                     /* Nodal end to end data */
} CALPT_NEED_REQ;

typedef struct calpt_cot_req            /* COT request */
{
  CALPT_CONTI    conti;                   /* Continuity indicators */
} CALPT_COT_REQ;

typedef struct calpt_req                /* Primitive request (whith parameters)*/
{
  u16   call_ref;                         /* 16 bit value - see manual */
  u16   ptype;                            /* primitive type */
  u16   instance;			  /* instance handling this primitive */
  union
  {
    CALPT_ALERT_REQ     alert_req;
    CALPT_RELEASE_REQ   release_req;
    CALPT_RELEASE_RESP  release_resp;
    CALPT_SETUP_REQ     setup_req;
    CALPT_SETUP_RESP    setup_resp;
    CALPT_COT_REQ       cot_req;
    CALPT_NEED_REQ      need_req;
  } u;
} CALPT_REQ;


/********************************************************************
 *                                                                  *
 *          Structure Definitions for Primitive Indications         *
 *                                                                  *
 ********************************************************************/

typedef struct calpt_alert_ind          /* Alerting indication */
{
  CALPT_BCI     bci;                      /* Backward call indicators */
} CALPT_ALERT_IND;

typedef struct calpt_info_ind           /* Information indication */
{
  CALPT_SUBSQ_NUM  subsq_num;             /* Subsequent number */
} CALPT_INFO_IND;

typedef struct calpt_progress_ind       /* Call progress indication */
{
  CALPT_NUP_EVENT_INF  NUP_event_inf;     /* NUP event information */
} CALPT_PROGRESS_IND;

typedef struct calpt_release_ind        /* Release indication */
{
  CALPT_CAUSEI  causei;                   /* Cause indicators */
} CALPT_RELEASE_IND;

typedef struct calpt_release_conf       /* Release confirmation */
{
  CALPT_CAUSEI  causei;                   /* Cause indicators */
} CALPT_RELEASE_CONF;

typedef struct calpt_setup_ind          /* Setup indication */
{
  CALPT_CALLED_NUM  called_num;           /* Called party number */
  CALPT_CALLING_NUM calling_num;          /* Calling party number */
  CALPT_FCI     fci;                      /* Forward call indicators */
  CALPT_CPC     cpc;                      /* Calling party category */
  CALPT_TMR     tmr;                      /* Transmission medium requirement */
  CALPT_NOCI    noci;                     /* Nature of connection indicators */
  CALPT_REDIR_INF  redir_inf;             /* Redirection information */
  CALPT_REDIR_NUM  redir_num;             /* Redirecting number */
  CALPT_NUP_FCI    NUP_fci;               /* NUP forward call indicators */
} CALPT_SETUP_IND;

typedef struct calpt_setup_conf         /* Setup confirmation */
{
  CALPT_BCI     bci;                      /* Backward call indicators */
} CALPT_SETUP_CONF;

typedef struct calpt_need_ind           /* NEED indication */
{
  CALPT_NEED    need;                     /* Nodal end to end data */
} CALPT_NEED_IND;

typedef struct calpt_cot_ind            /* COT indication */
{
  CALPT_CONTI    conti;                     /* continuity indicators */
} CALPT_COT_IND;

typedef struct calpt_sze_ind            /* Circuit seized indication */
{
  CALPT_NOCI    noci;                     /* continuity indicators */
} CALPT_SZD_IND;

typedef struct calpt_ind                /* Primitive indication */
{
  u16   call_ref;                         /* 16 bit value - see manual */
  u16   ptype;                            /* primitive type */
  u16   instance;			  /* instance handling this primitive */
  union
  {
    CALPT_ALERT_IND     alert_ind;
    CALPT_INFO_IND      info_ind;
    CALPT_RELEASE_IND   release_ind;
    CALPT_RELEASE_CONF  release_conf;
    CALPT_SETUP_IND     setup_ind;
    CALPT_SETUP_CONF    setup_conf;
    CALPT_NEED_IND      need_ind;
    CALPT_PROGRESS_IND  progress_ind;
    CALPT_COT_IND	cot_ind;
    CALPT_SZD_IND	szd_ind;
  } u;
} CALPT_IND;


/********************************************************************
 *                                                                  *
 *          Prototypes for the functions in call.c                  *
 *                                                                  *
 ********************************************************************/

#ifdef LINT_ARGS
  int CAL_init(void);
  int CAL_req_to_msg(MSG *m, CALPT_REQ *req);
  int CAL_msg_to_ind(CALPT_IND *ind, MSG *m);
  int CAL_erase_req(CALPT_REQ *req);
  int CAL_erase_ind(CALPT_IND *ind);
#else
  int CAL_init();
  int CAL_req_to_msg();
  int CAL_msg_to_ind();
  int CAL_erase_req();
  int CAL_erase_ind();
#endif

