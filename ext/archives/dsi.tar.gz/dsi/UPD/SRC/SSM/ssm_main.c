/*
                Copyright (C) Dialogic Corporation 1991-2007. All Rights Reserved.

 Name:          ssm_main.c

 Description:   Command line interface to SCCP subsystem monitor(SSM) module.

 Functions:     main()

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   1    01-Aug-01   YTA   - Initial code.
   2    08-Feb-06   TB    - Added Intel Corp in file header
   3    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.  
   4    16-Aug-07   ML    - Correct -v display option.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system.h"
#include "msg.h"
#include "ss7_inc.h"
#include "strtonum.h"

#ifdef LINT_ARGS
  void ssm_ent(u8 ssm_mod_id, u8 ssm_ssn, u8 ssm_lss, u8 ssm_rss, u32 ssm_rsp,
               u8 ssm_config, u8 ssm_version, u8 ssm_rsp_present);
  static int read_cli_parameters(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *args);
#else
  void ssm_ent();
  static int read_cli_parameters();
  static void show_syntax();
  static int read_option();
#endif

#define CLI_EXIT_REQ            (-1)    /* Option requires immediate exit */
#define CLI_UNRECON_OPTION      (-2)    /* Unrecognised option */
#define CLI_RANGE_ERR           (-3)    /* Option value is out of range */

/*
 * Default values for SSM's command line options :
 */
#define DEFAULT_MODULE_ID       (0x0d)
#define DEFAULT_SSN             (0xfc)
#define DEFAULT_RSP             (0x0003)
#define DEFAULT_RSS             (0xfb)
#define DEFAULT_LSS             (0xfa)
#define ARG_LEN                 (3)

static u32 ssm_rsp;                     /* Remote signalling point */
static u8 ssm_mod_id;                   /* SSM Module Id */
static u8 ssm_ssn;                      /* SSM subsystem number */
static u8 ssm_lss;                      /* Local subsystem number */
static u8 ssm_rss;                      /* Remote subsystem number */
static u8 ssm_config;                   /* Flag determining whether SSM will */
                                        /* configure itself as subsystem */
static u8 ssm_version;                  /* Flag determining if SCCP version */
                                        /* will be retrieved */
static u8 ssm_rsp_present;              /* Flag indicating if rsp is present */

static char *exe_name;                  /* Pointer to parameter list */

/*
 * Main function for SSM
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;  /* holds index of unrecognised arguments */
  int cli_error;   /* if unrecognised parameters, holds error value */

  ssm_mod_id = DEFAULT_MODULE_ID;
  ssm_ssn = DEFAULT_SSN;
  ssm_lss = DEFAULT_LSS;
  ssm_rss = DEFAULT_RSS;
  ssm_rsp = DEFAULT_RSP;
  ssm_config = 0;
  ssm_version = 0;
  ssm_rsp_present = 0;
  exe_name = argv[0];

  if ((cli_error = read_cli_parameters(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case CLI_UNRECON_OPTION :
        fprintf(stderr, "%s() : Unrecognised option : %s\n", exe_name,
                argv[failed_arg]);
        show_syntax();
        break;

      case CLI_RANGE_ERR :
        fprintf(stderr, "%s() : Parameter range error : %s\n", exe_name,
                argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }
    exit(0);
  }

  ssm_ent(ssm_mod_id, ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_config,
          ssm_version, ssm_rsp_present);

  return(0);
}

/*
 *   Displays the correct syntax and parameters to run SSM
 */
static void show_syntax()
{
  fprintf(stderr,
    "Syntax : ssm [-m<SSM module id> -n<SSM subsystem number> -lss<local subsystem number>\n");
  fprintf(stderr,
    "              -rss<remote subsystem number> -rsp<remote signalling point> -c -v -h ]\n");
  fprintf(stderr, " -m   : ssm module ID (default=0x%02x)\n",
	DEFAULT_MODULE_ID);
  fprintf(stderr, " -n   : ssm subsystem number (default=0x%02x)\n",
	DEFAULT_SSN);
  fprintf(stderr, " -lss : local subsystem number (default=0x%02x)\n",
	DEFAULT_MODULE_ID);
  fprintf(stderr, " -rss : remote subsystem number (default=0x%02x)\n",
	DEFAULT_MODULE_ID);
  fprintf(stderr, " -rsp : remote signalling point (default=0x%08x)\n",
    DEFAULT_RSP);
  fprintf(stderr, " -c   : self configure SSM as subsystem\n");
  fprintf(stderr, " -v   : display SCCP version info\n");
  fprintf(stderr, " -h   : display list of options\n");
  fprintf(stderr,
          "Example: ssm -m0x2d -n0xfc -lss0xfa -rss0xfb -rsp0x0003\n");
}

/*
 * Read in command line options and set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_cli_parameters(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;            /* holds error value for unrecognised parameters */
  int i;                /* index to pointer array */

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;         /* destination for string to u32 conversion*/

  if (arg[0] != '-')
    return(CLI_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
      show_syntax();
      return(CLI_EXIT_REQ);

    case 'n' :
      if (strtou32(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ssm_ssn = (u8)temp_u32;
      break;

    case 'm' :
      if (strtou32(&temp_u32, &arg[2]))
        return(CLI_RANGE_ERR);
      ssm_mod_id = (u8)temp_u32;
      break;

    case 'c' :
      ssm_config = 1;
      break;

    case 'v' :
      ssm_version = 1;      
      show_syntax();
      return(CLI_EXIT_REQ);

    default :
      if (strncmp(&arg[1], "lss", ARG_LEN) == 0)
      {
        if (strtou32(&temp_u32, &arg[4]))
          return (CLI_RANGE_ERR);
        ssm_lss = (u8)temp_u32;
      }
      else
      {
        if (strncmp(&arg[1], "rss", ARG_LEN) == 0)
        {
          if (strtou32(&temp_u32, &arg[4]))
            return (CLI_RANGE_ERR);
          ssm_rss = (u8)temp_u32;
        }
        else
        {
          if (strncmp(&arg[1], "rsp", ARG_LEN) == 0)
          {
            if (!strtonum(&temp_u32, &arg[4]))
              return (CLI_RANGE_ERR);
            ssm_rsp = temp_u32;
            ssm_rsp_present = 1;
          }
        }
      }
      break;
  }
  return(0);
}

