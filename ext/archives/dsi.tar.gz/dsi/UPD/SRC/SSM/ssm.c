/*
                Copyright (C) Dialogic Corporation 1991-2006. All Rights Reserved.

 Name:          ssm.c

 Description:   SCCP subsystem monitor that will monitor the state of
                signalling points and subsystems.  In addition the monitor
                will setup concerned relationships between point codes and
                subsystems.

 Functions:     ssm_ent

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   1    01-Aug-01   YTA   - Initial code.
   2    08-Feb-06   TB    - Added Intel Corp in file header
   3    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
 */

#include <stdio.h>
#include <string.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "pack.h"       /* prototypes for packing functions */
#include "ss7_inc.h"    /* SS7 definitions */
#include "scp_inc.h"    /* SCCP module definitions */
#include "asciibin.h"   /* Prototypes for functions in asciibin.c */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  void ssm_ent(u8 ssm_mod_id, u8 ssm_ssn, u8 ssm_lss, u8 ssm_rss, u32 ssm_rsp,
               u8 ssm_config, u8 ssm_version, u8 ssm_rsp_present);
  static int SSM_initialise(u8 ssm_ssn, u8 ssm_lss, u8 ssm_rss, u32 ssm_rsp,
                            u8 ssm_rsp_present);
  static int SSM_main_process(MSG *m);

  static int SSM_n_state_req(u8 ssn, u8 format_id, u8 cong_level);
  static int SSM_send_msg(MSG *m);
  static int SSM_display_message(MSG *m);
  static int SSM_read_sccp(u8 ssm_module_id);
  static int SSM_module_version(u8 ssm_module_id);
  static int SSM_config_res (u8 ssm_module_id, u8 ssm_ssn);
  static int SSM_add_concerned (u8 ssm_module_id, u8 ssm_ssn, u8 ssm_lss,
                                u8 ssm_rss, u32 ssm_rsp, u8 ssm_rsp_present);

#else
  void ssm_ent();
  static int SSM_initialise();
  static int SSM_main_process();
  static int SSM_n_state_req();
  static int SSM_send_msg();
  static int SSM_display_message();
  static int SSM_read_sccp();
  static int SSM_module_version();
  static int SSM_config_res();
  static int SSM_add_concerned();
#endif

#define SSM_user_in_service(ssn)        SSM_n_state_req((ssn), 1, 0)
#define SSM_user_out_of_service(ssn)    SSM_n_state_req((ssn), 2, 0)

/*
 * Define parameter length
 */
#define MAX_PARAM_LEN   (320)

/*
 * Message type values for confirmation messages
 */
#define SCP_MSG_CNF_SSR_CONFIRM (SCP_MSG_CNF_SSR & ~REQUEST)
#define GEN_MSG_MOD_IDENT_CONFIRM (GEN_MSG_MOD_IDENT & ~REQUEST)
#define SCP_MSG_R_SSR_STATS_CONFIRM (SCP_MSG_R_SSR_STATS & ~REQUEST)
#define SCP_MSG_ADD_CONC_CONFIRM (SCP_MSG_ADD_CONC & ~REQUEST)

/*
 * Subsystem and signalling point state definitions
 */
#define SSMMT_SSA (1)
#define SSMMT_SSP (2)
#define SSMMT_SSC (7)
#define SSMMT_SPA (128)
#define SSMMT_SPP (129)
#define SSMMT_SPC (130)

/*
 * Macro to ensure that messages sent from SSM have return confirmations
 */
#define RESPONSE(mod_id) (unsigned short)(1 << ((mod_id) & 0x0f))

/*
 * Storage for SSM's module Id and Local sub-system number.
 */
static u32 ssm_rsp;                     /* Remote sig. pt. code */
static u8 ssm_mod_id;                   /* SSM module id */
static u8 ssm_ssn;                      /* SSM subsystem number */
static u8 ssm_lss;                      /* Local subsystem. number */
static u8 ssm_rss;                      /* Remote Subsystem. number */
static u8 ssm_config;                   /* Flag determining if SSM will */
                                        /* configure itself as a subsystem */
static u8 ssm_version;                  /* Flag determining if SCCP version */
                                        /* will be retrieved */
static u8 ssm_rsp_present;              /* Flag indicating if rsp is present */
/*
 * Main function for SCCP subsystem monitor (SSM)
 */
void ssm_ent(mod_id, ssn, lss, rss, rsp, config, version, rsp_present)
  u8  mod_id;        /* Holds the SSM module id */
  u8  ssn;           /* Holds the SSM subsystem number */
  u8  lss;           /* Holds the lss number */
  u8  rss;           /* Holds the rss number */
  u32  rsp;          /* Holds the rsp number */
  u8  config;        /* Flag whose value determines wheter SSM should */
                     /* configure itself as a subsystem */
  u8  version;       /* Flag whose value determines whether SCCP version */
                     /* info. is to be retrieved */
  u8 rsp_present;    /* Flag indicating if rsp is present */
{
  HDR *h;            /* Message header */
  MSG *m;            /* Message header, plus body */
  int finished;      /* Flag used to terminate SSM */
  u8 config_ok;      /* Flag indicating if SSM needs to be configured as a */
                     /* subsystem */

  ssm_mod_id = mod_id;
  ssm_ssn = ssn;
  ssm_lss = lss;
  ssm_rss = rss;
  ssm_rsp = rsp;
  ssm_config = config;
  ssm_version = version;
  ssm_rsp_present = rsp_present;
  config_ok = 1;

  /*
   * Print banner so we know what's running:
   */
  printf("SSM - SCCP Subsystem Monitor  (C) Dialogic Corporation 1991-2006. All Rights Reserved.\n");
  printf("======================================================================================\n");

  /*
   * If requested, a message is sent to configure SSM as a subsystem
   */
  if (ssm_config)
  {
    config_ok = 0;

    SSM_config_res(ssm_mod_id, ssm_ssn);
  }
  else
    SSM_initialise(ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_rsp_present);

  /*
   * Now enter main loop, receiving messages as
   * they become available and processing accordingly:
   */
  finished = 0;
  while (!finished)
  {
    /*
     * GCT_receive will attempt to receive message
     * from the tasks message queue and block until
     * a message is ready:
     */
    if ((h = GCT_receive(ssm_mod_id)) != 0)
    {
      if (!config_ok)
      {
        /*
         * SSM must be configured as subsystem
         */
        if (h->type == SCP_MSG_CNF_SSR_CONFIRM)
        {
          config_ok = 1;
          printf ("SSM: Monitor configured as subsystem\n");

          /*
           * The Monitor is now a configured subsystem and is put into an
           * allowed state
           */
          SSM_user_in_service(ssm_ssn);

          SSM_initialise(ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_rsp_present);
        }
        relm(h);
      }
      else
      {
        /*
         * SSM already configured as subsystem, or unecessary to configure as subsystem
         */
        m = (MSG *)h;

        SSM_main_process(m);
      }
    }
  }
  SSM_user_out_of_service(ssm_ssn);
}

static int SSM_initialise(ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_rsp_present)
  u8 ssm_ssn;            /* SSM subsystem number */
  u8 ssm_lss;            /* lss number */
  u8 ssm_rss;            /* rss number */
  u32 ssm_rsp;           /* rsp number */
  u8 ssm_rsp_present;    /* Flag indicating if rsp is present */
{
  /*
   * Retrieve the initial status of subsystems and point codes
   */
  SSM_read_sccp(ssm_mod_id);

  /*
   * Setup necessary concerned relationships so SSM will be informed of state
   * changes
   */
  SSM_add_concerned(ssm_mod_id, ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_rsp_present);

  if (ssm_version)
  {
    /*
     * Send GEN_MSG_MOD_IDENT to retrieve version info. on
     * module under test
     */
    SSM_module_version(ssm_mod_id);
  }
  return (0);
}

/*
 * Function called to handle processing of any message received after SSM has
 * been configured as a subsystem (if requested)
 *
 * Function always returns 0
 */
static int SSM_main_process(m)
  MSG *m;            /* Message header, plus body */
{
  u32 affect_pc;     /* Point code  returned in indication received */
  HDR *h;            /* Message header */
  char mod_text[24]; /* Array to hold module version description */
  u8 ss_state;       /* Flag to indicate state of subsystem */
  u8 sp_state;       /* Flag to indicate state of signalling pt. */
  u8 affect_ssn;     /* Subsystem number returned in indications received */
  u8 major_rev;      /* Major revision number */
  u8 minor_rev;      /* Minor revision number */
  u8 status;         /* Status of lss, rss or rsp */
  u8 conc_type;      /* Concerned resource type - lss, rss or rsp */
  u8 ssr_type;       /* Resource type lss, rss or rsp */
  u8 state_ind;      /* Point code or subsystem state indicator */

  h = &m->hdr;

  switch (h->type)
  {
    case SCP_MSG_SCMG_IND :
      state_ind = (u8)runpackbytes(get_param(m), 0, 1);
      /*
       * Messages indicating the state of subsystems/signalling points will
       * have the below message type
       */
      if (state_ind == SCPMPT_NSTATE_IND)
      {
        /*
         * Subsystem status message
         */
        ss_state = (u8)runpackbytes(get_param(m), 1, 1);
        affect_ssn = (u8)runpackbytes(get_param(m), 2, 1);
        affect_pc = (u32)runpackbytes(get_param(m), 3, 4);

        printf ("SSM: subsystem 0x%02x at pt. code 0x%08x - ",
                affect_ssn, affect_pc);
        switch (ss_state)
        {
          case SSMMT_SSA :
            printf("ALLOWED\n");
            break;

          case SSMMT_SSP :
            printf("PROHIBITED\n");
            break;

          default:
            printf("Subsystem in unknown state\n");
            break;
        }
      }
      else
      {
        if (state_ind == SCPMPT_NPCSTATE_IND)
        {
          /*
           * Remote signalling point status message
           */
          sp_state = (u8)runpackbytes(get_param(m), 1, 1);
          affect_pc = (u32)runpackbytes(get_param(m), 3, 4);

          printf ("SSM: pt. code 0x%08x - ", affect_pc);
          switch (sp_state)
          {
            case SSMMT_SPA :
              printf("ALLOWED\n");
              break;

            case SSMMT_SPP :
              printf("PROHIBITED\n");
              break;

            case SSMMT_SPC :
              printf("CONGESTED\n");
              break;

            default:
              printf("Point code in unknown state\n");
              break;
          }
        }
        else
          /*
           * If not a N-STATE or N-PCSTATE indication
           */
          SSM_display_message(m);
      }
      break;

    case GEN_MSG_MOD_IDENT_CONFIRM :
      /*
       * Confirmation for a message sent to retrieve SCCP
       * version information
       */
      major_rev = (u8)runpackbytes(get_param(m), GENMO_MOD_IDENT_maj_rev,
                                   GENMS_MOD_IDENT_maj_rev);
      minor_rev = (u8)runpackbytes(get_param(m), GENMO_MOD_IDENT_min_rev,
                                   GENMS_MOD_IDENT_min_rev);
      memcpy (mod_text, get_param(m) + GENMO_MOD_IDENT_text, GENMS_MOD_IDENT_text);
      printf("SSM: V%d.%02d  - %s\n" , major_rev, minor_rev, mod_text);
      break;

    case SCP_MSG_R_SSR_STATS_CONFIRM :
      /*
       * Confirmation for a statistics message sent to retrieve initial
       * status of subsystems/signalling points
       */
      status = (u8)runpackbytes(get_param(m), SCPMO_RS_SSR_state,
                                SCPMS_RS_SSR_state);
      ssr_type = (u8)runpackbytes(get_param(m), SCPMO_RS_SSR_ssr_type,
                                  SCPMS_RS_SSR_ssr_type);
      /*
       * Check for local subsystem
       */
      switch (ssr_type)
      {
        case SCP_SSRT_LSS :
          /*
           * Check for local subsystem
           */
          printf ("SSM: Local subsystem 0x%02x at local pt. code : ",
                  ssm_lss);
          break;

        case SCP_SSRT_RSS :
          /*
           * Check for remote subsystem
           */
          printf ("SSM: Remote subsystem 0x%02x at PC 0x%08x : ",
                   ssm_rss, ssm_rsp);
          break;

        default:
          /*
           * Check for remote point code
           */
          printf ("SSM: Remote point code 0x%08x : ",
                  ssm_rsp);
          break;
      }

      if (status == SCPSSRS_PROHIBITED)
        printf ("status PROHIBITED\n");
      else
        printf ("status ALLOWED\n");
      break;

    case SCP_MSG_ADD_CONC_CONFIRM :
      /*
       * Confirmation to a message sent to create a concerned relationship
       * between the monitor and lss, rss or rsp, and also between lss and rsp.
       * The ssr_type is the subsystem resource to be monitored.
       */
      ssr_type = (u8)runpackbytes(get_param(m), SCPMO_ADD_CONC_ssr_type,
                                  SCPMS_ADD_CONC_ssr_type);
      /*
       * Check for local subsystem
       */
      switch (ssr_type)
      {
        case SCP_SSRT_LSS :
          conc_type = (u8)runpackbytes(get_param(m),
                                       SCPMO_ADD_CONC_conc_type,
                                       SCPMS_ADD_CONC_conc_type);
          /*
           * Checks confirmation message for concerned relationship
           * between monitor and local subsystem or between local subsystem
           * and remote signalling point.
           * The conc_type is either the monitor or RSP
           */
          if (conc_type == SCP_SSRT_RSP)
          {
            /*
             * Check if rsp concerned about lss
             */
            if (h->status == 0)
            {
              printf ("SSM: Remote pt. code 0x%08x is concerned about",
                      ssm_rsp);
              printf (" local subsystem 0x%02x\n", ssm_lss);
            }
            else
            {
              printf ("SSM: Remote pt. code 0x%08x not concerned about",
                      ssm_rsp);
              printf (" local subsystem - error 0x%02x\n", h->status);
            }
          }
          else
          {
            /*
             * Check if SSM concerned about local subsystem
             */
            if (h->status == 0)
              printf ("SSM: SSM is concerned about local subsystem 0x%02x\n",
                      ssm_lss);
            else
            {
              printf ("SSM: SSM is not concerned about local subsystem");
              printf (" 0x%02x - error 0x%02x\n", ssm_lss, h->status);
            }
          }
          break;

        case SCP_SSRT_RSS :
          /*
           * Check if SSM concerned about rss
           */
          if (h->status == 0)
            printf ("SSM: SSM is concerned about remote subsystem 0x%02x\n",
                    ssm_rss);
          else
          {
            printf ("SSM: SSM is not concerned about remote subsystem");
            printf (" 0x%02x - error 0x%02x\n", ssm_rss, h->status);
          }
          break;

        default:
          /*
           * Check if SSM concerned about rsp
           */
          if (h->status == 0)
             printf ("SSM: SSM is concerned about remote pt. code 0x%08x\n",
                      ssm_rsp);
          else
          {
             printf ("SSM: SSM is not concerned about remote pt.");
             printf (" code 0x%08x - error 0x%02x\n", ssm_rsp, h->status);
          }
          break;
      }
      break;

    default  :
      SSM_display_message(m);
      break;
  }
  /*
   * Once we have finished processing the message
   * it must be released to the pool of messages.
   */
  relm(h);

  return(0);
}

/*
 * Function called to send a UIS or UOS to TCAP
 *
 * Function always returns 0
 */
static int SSM_n_state_req (ssn, format_id, cong_level)
  u8    ssn;            /* local sub-system number */
  u8    format_id;      /* 1=UIS, 2=UOS, 7=Congestion */
  u8    cong_level;     /* congestion level 0, 1, 2 or 3 */
{
  MSG   *m;             /* Pointer to message structure */
  u8    *pptr;          /* Pointer to parameter area of message structure */

  if ((m = getm(SCP_MSG_SCMG_REQ, ssn, RESPONSE(ssm_mod_id), 8)) != 0)
  {
    m->hdr.src = ssm_mod_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void *)pptr, 0, m->len);
    rpackbytes(pptr, 0, SCPMPT_NSTATE_REQ, 1);
    rpackbytes(pptr, 1, format_id, 1);

    /*
     * Subsystem congested
     */
    if (format_id == SSMMT_SSC)
      rpackbytes(pptr, 5, cong_level, 1);

    /*
     * Display UIS or UOS message
     */
    SSM_display_message(m);
    SSM_send_msg(m);
  }
  return(0);
}

/*
 * Function to send message. On failure the
 * message is released and the user notified:
 *
 * Function always returns 0
 */
static int SSM_send_msg(m)
  MSG *m;
{
  HDR *h;       /* Message header */

  h = &m->hdr;

  if (GCT_send(h->dst, h) != 0)
  {
    fprintf(stderr, "SSM: *** failed to send message ***\n");
    relm(h);
  }
  return(0);
}

/*
 * Function to print the message sent for a UIS or a UOS
 *
 * Function always returns 0
 */
static int SSM_display_message(m)
  MSG *m;           /* Pointer to message structure */
{
  HDR   *h;         /* Message header */
  int   instance;   /* Message instance value */
  u16   mlen;       /* Message length */
  char  hexstr[3];  /* Holds hex number as chars. */
  u8    *pptr;      /* Pointer to the parameter area */

  h = &m->hdr;

  instance = GCT_get_instance(h);
  printf("SSM: I%04x M t%04x i%04x f%02x d%02x s%02x", instance, h->type,
         h->id, h->src, h->dst, h->status);

  if ((mlen = m->len) > 0)
  {
    if (mlen > MAX_PARAM_LEN)
      mlen = MAX_PARAM_LEN;
    /*
     * Print parameter area
     */
    printf(" p");
    pptr = get_param(m);
    memset(hexstr, '\0', 3);
    while (mlen--)
    {
      bintoasc(hexstr, *pptr);
      printf("%s", hexstr);
      pptr++;
    }
    printf("\n");
  }
  return(0);
}

/*
 * Send GEN_MSG_MOD_IDENT to retrieve info. regarding module version
 * and module identity
 *
 * Function always returns 0
 */
static int SSM_module_version(ssm_module_id)
  u8 ssm_module_id;  /* SSM module id */
{
  MSG *m;            /* Message structure */
  u8  *pptr;         /* Pointer to parameter area */

  if ((m = getm(GEN_MSG_MOD_IDENT, 0, RESPONSE(ssm_module_id),
                GENML_MOD_IDENT)) != 0)
  {
    m->hdr.src = ssm_module_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void*)pptr, 0, m->len);
    SSM_send_msg(m);
  }
  return (0);
}

/*
 * To be concerned about a resource, that resource must
 * be first configured.
 *
 * Function always returns 0
 */
static int SSM_config_res (ssm_module_id, ssm_ssn)

  u8 ssm_module_id;    /* SSM module id */
  u8 ssm_ssn;          /* SSM subsystem number */
{
  MSG *m;              /* Message structure */
  u8  *pptr;           /* Pointer to paraameter area */

  /*
   * The '-c' parameter in the command line causes monitor
   * to configure itself as a subsystem
   */
  printf ("SSM: Trying to configure monitor as subsystem\n");

  if ((m = getm(SCP_MSG_CNF_SSR, 0, RESPONSE(ssm_module_id),
                SCPML_CNF_SSR)) != 0)
  {
    m->hdr.src = ssm_module_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void*)pptr, 0, m->len);
    /*
     * Format parameter area
     */
    rpackbytes(pptr, SCPMO_CNF_SSR_cnf_ver, 0, SCPMS_CNF_SSR_cnf_ver);
    rpackbytes(pptr, SCPMO_CNF_SSR_ssr_type, SCP_SSRT_LSS,
               SCPMS_CNF_SSR_ssr_type);
    rpackbytes(pptr, SCPMO_CNF_SSR_module_id, ssm_module_id,
               SCPMS_CNF_SSR_module_id);
    rpackbytes(pptr, SCPMO_CNF_SSR_mult_ind, 1, SCPMS_CNF_SSR_mult_ind);
    rpackbytes(pptr, SCPMO_CNF_SSR_spc, 0x00000000, SCPMS_CNF_SSR_spc);
    rpackbytes(pptr, SCPMO_CNF_SSR_ssn, ssm_ssn, SCPMS_CNF_SSR_ssn);
    rpackbytes(pptr, SCPMO_CNF_SSR_mgmt_id, 0, SCPMS_CNF_SSR_mgmt_id);
    rpackbytes(pptr, SCPMO_CNF_SSR_ssr_flags, 0x0000,
               SCPMS_CNF_SSR_ssr_flags);
    rpackbytes(pptr, SCPMO_CNF_SSR_pc_mask, 0x00000000,
               SCPMS_CNF_SSR_pc_mask);

    SSM_send_msg(m);
  }
  return (0);
}

/*
 * If present, lss. rss, and rsp are added as concerned
 * resources
 *
 * Function always returns 0
 */
static int SSM_add_concerned (ssm_module_id, ssm_ssn, ssm_lss, ssm_rss, ssm_rsp, ssm_rsp_present)
  u8 ssm_module_id;      /* SSM module id */
  u8 ssm_ssn;            /* SSM subsystem number */
  u8 ssm_lss;            /* lss number */
  u8 ssm_rss;            /* rss number */
  u32 ssm_rsp;           /* rsp number */
  u8 ssm_rsp_present;    /* Flag indicating if rsp is present */
{
  MSG *m;                /* Message structure */
  u8  *pptr;             /* Pointer to parameter area */

  if (ssm_lss != 0)
  {
    if ((m = getm(SCP_MSG_ADD_CONC, 0, RESPONSE(ssm_module_id),
                  SCPML_ADD_CONC)) != 0)
    {
      /*
       * Message to cause SSM to be concerned about local subsystem
       */
      m->hdr.src = ssm_module_id;
      m->hdr.dst = SCP_TASK_ID;
      pptr = get_param(m);
      memset((void*)pptr, 0, m->len);

      /*
       * Format parameter area
       */
      rpackbytes(pptr, SCPMO_ADD_CONC_cnf_ver, 0, SCPMS_ADD_CONC_cnf_ver);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_type, SCP_SSRT_LSS,
                 SCPMS_ADD_CONC_ssr_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_spc, 0x00000000,
                 SCPMS_ADD_CONC_ssr_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_ssn, ssm_lss,
                 SCPMS_ADD_CONC_ssr_ssn);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_type, SCP_SSRT_LSS,
                 SCPMS_ADD_CONC_conc_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_spc, 0x00000000,
                 SCPMS_ADD_CONC_conc_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_ssn, ssm_ssn,
                 SCPMS_ADD_CONC_conc_ssn);

      SSM_send_msg(m);
    }
  }

  if (ssm_rss != 0)
  {
    if ((m = getm(SCP_MSG_ADD_CONC, 0, RESPONSE(ssm_module_id),
                  SCPML_ADD_CONC)) != 0)
    {
      /*
       * Message to cause SSM to be concerned about remote subsystem
       */
      m->hdr.src = ssm_module_id;
      m->hdr.dst = SCP_TASK_ID;
      pptr = get_param(m);
      memset((void*)pptr, 0, m->len);

      /*
       * Format parameter area
       */
      rpackbytes(pptr, SCPMO_ADD_CONC_cnf_ver, 0, SCPMS_ADD_CONC_cnf_ver);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_type, SCP_SSRT_RSS,
                 SCPMS_ADD_CONC_ssr_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_spc, ssm_rsp,
                 SCPMS_ADD_CONC_ssr_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_ssn, ssm_rss,
                 SCPMS_ADD_CONC_ssr_ssn);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_type, SCP_SSRT_LSS,
                 SCPMS_ADD_CONC_conc_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_spc, 0x00000000,
                 SCPMS_ADD_CONC_conc_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_ssn, ssm_ssn,
                 SCPMS_ADD_CONC_conc_ssn);

      SSM_send_msg(m);
    }
  }

  if (ssm_rsp_present)
  {
    if ((m = getm(SCP_MSG_ADD_CONC, 0, RESPONSE(ssm_module_id),
                  SCPML_ADD_CONC)) != 0)
    {
      /*
       * Message to cause SSM to be concerned about remote signalling point
       */
      m->hdr.src = ssm_module_id;
      m->hdr.dst = SCP_TASK_ID;
      pptr = get_param(m);
      memset((void*)pptr, 0, m->len);
      /*
       * Format parameter area
       */
      rpackbytes(pptr, SCPMO_ADD_CONC_cnf_ver, 0, SCPMS_ADD_CONC_cnf_ver);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_type, SCP_SSRT_RSP,
                 SCPMS_ADD_CONC_ssr_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_spc, ssm_rsp,
                 SCPMS_ADD_CONC_ssr_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_ssn, 0,
                 SCPMS_ADD_CONC_ssr_ssn);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_type, SCP_SSRT_LSS,
                 SCPMS_ADD_CONC_conc_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_spc, 0x00000000,
                 SCPMS_ADD_CONC_conc_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_ssn, ssm_ssn,
                 SCPMS_ADD_CONC_conc_ssn);

      SSM_send_msg(m);
    }
  }

  if (ssm_rsp_present)
  {
    if ((m = getm(SCP_MSG_ADD_CONC, 0, RESPONSE(ssm_module_id),
                  SCPML_ADD_CONC)) != 0)
    {
      /*
       * Message to cause local subsystem to be concerned about
       * the remote signalling point
       */
      m->hdr.src = ssm_module_id;
      m->hdr.dst = SCP_TASK_ID;
      pptr = get_param(m);
      memset((void*)pptr, 0, m->len);
      /*
       * Format parameter area
       */
      rpackbytes(pptr, SCPMO_ADD_CONC_cnf_ver, 0, SCPMS_ADD_CONC_cnf_ver);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_type, SCP_SSRT_LSS,
                 SCPMS_ADD_CONC_ssr_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_spc, 0,
                 SCPMS_ADD_CONC_ssr_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_ssr_ssn, ssm_lss,
                 SCPMS_ADD_CONC_ssr_ssn);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_type, SCP_SSRT_RSP,
                 SCPMS_ADD_CONC_conc_type);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_spc, ssm_rsp,
                 SCPMS_ADD_CONC_conc_spc);
      rpackbytes(pptr, SCPMO_ADD_CONC_conc_ssn, 0,
                 SCPMS_ADD_CONC_conc_ssn);

      SSM_send_msg(m);
    }
  }
  return (0);
}

/*
 * Function to send a statistics message to SCCP to retrieve the initial status
 * of the lss, rss and rss
 *
 * Function always returns 0
 */
static int SSM_read_sccp(ssm_module_id)
  u8 ssm_module_id;     /* Module id of monitor */
{
  MSG *m;               /* Message structure */
  u8  *pptr;            /* Pointer to parameter area */

  if ((m = getm(SCP_MSG_R_SSR_STATS, 0, RESPONSE(ssm_module_id),
                SCPML_RS_SSR)) != 0)
  {
    /*
     * Get stats. for remote signalling point
     */
    m->hdr.src = ssm_module_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void*)pptr, 0, m->len);
    /*
     * Format parameter area
     */
    rpackbytes(pptr, SCPMO_RS_SSR_version, 0, SCPMS_RS_SSR_version);
    rpackbytes(pptr, SCPMO_RS_SSR_ssr_type, SCP_SSRT_RSP,
               SCPMS_RS_SSR_ssr_type);
    rpackbytes(pptr, SCPMO_RS_SSR_spc, ssm_rsp, SCPMS_RS_SSR_spc);
    rpackbytes(pptr, SCPMO_RS_SSR_ssn, 0, SCPMS_RS_SSR_ssn);

    SSM_send_msg(m);
  }

  if ((m = getm(SCP_MSG_R_SSR_STATS, 0, RESPONSE(ssm_module_id),
                SCPML_RS_SSR)) != 0)
  {
    /*
     * Get stats. for remote subsystem
     */
    m->hdr.src = ssm_module_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void*)pptr, 0, m->len);
    /*
     * Format parameter area
     */
    rpackbytes(pptr, SCPMO_RS_SSR_version, 0, SCPMS_RS_SSR_version);
    rpackbytes(pptr, SCPMO_RS_SSR_ssr_type, SCP_SSRT_RSS,
               SCPMS_RS_SSR_ssr_type);
    rpackbytes(pptr, SCPMO_RS_SSR_spc, ssm_rsp, SCPMS_RS_SSR_spc);
    rpackbytes(pptr, SCPMO_RS_SSR_ssn, ssm_rss, SCPMS_RS_SSR_ssn);

    SSM_send_msg(m);
  }

  if ((m = getm(SCP_MSG_R_SSR_STATS, 0, RESPONSE(ssm_module_id),
                SCPML_RS_SSR)) != 0)
  {
    /*
     * Get stats. for local subsystem
     */
    m->hdr.src = ssm_module_id;
    m->hdr.dst = SCP_TASK_ID;
    pptr = get_param(m);
    memset((void*)pptr, 0, m->len);
    /*
     * Format parameter area
     */
    rpackbytes(pptr, SCPMO_RS_SSR_version, 0, SCPMS_RS_SSR_version);
    rpackbytes(pptr, SCPMO_RS_SSR_ssr_type, SCP_SSRT_LSS,
               SCPMS_RS_SSR_ssr_type);
    rpackbytes(pptr, SCPMO_RS_SSR_spc, 0, SCPMS_RS_SSR_spc);
    rpackbytes(pptr, SCPMO_RS_SSR_ssn, ssm_lss, SCPMS_RS_SSR_ssn);

    SSM_send_msg(m);
  }
  return(0);
}
