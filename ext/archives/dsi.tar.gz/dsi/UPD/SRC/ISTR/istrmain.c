/*
                   Copyright (C) Dialogic Corporation 1999-2006. All Rights Reserved.

 Name:          istrmain.c

 Description:   Console command line interface to istr.
                Provided as example IS41 user code.

 Functions:     main()

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A     06-Sep-99  JET   - Initial code based on MTR.
   B     15-Feb-00  JET   - Addition of display options '-o'.
                          - Allow multiple simultaneous dialogues to be
                            supported.
   1     13-Dec-06  ML    - Change to use of Dialogic Corporation copyright.

 */

#include <stdio.h>
#include <string.h>

#include "system.h"
#include "ss7_inc.h"
#include "is41_inc.h"
#include "strtonum.h"

#ifdef LINT_ARGS
  static int read_cli_parameters(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *arg);

  extern int ISTR_ent(u8 istr_mod_id, u8 istr_is41_id, u16 istr_base_dlg_id,
                      u16 istr_num_dlg_ids, u16 options);
#else
  static int read_cli_parameters();
  static void show_syntax();
  static int read_option();

  extern int ISTR_ent();
#endif

#define CLI_EXIT_REQ            (-1)    /* Option requires immediate exit */
#define CLI_UNRECON_OPTION      (-2)    /* Unrecognised option */
#define CLI_RANGE_ERR           (-3)    /* Option value is out of range */

/*
 * Default values for ISTR's command line options:
 */
#define DEFAULT_MODULE_ID         (0x2d)         /* Default module id of istr */
#define DEFAULT_IS41_ID           (IS41_TASK_ID) /* Default module id of IS41 */
#define DEFAULT_NUM_DLGS          (0x0400)       /* Def num of dlgids to use */
#define DEFAULT_BASE_DLG_ID       (0x8000)       /* Default is41 base dlg id */
#define DEFAULT_OPTIONS           (0x001f)       /* Default display options */


static u8  istr_mod_id;           /* Module id of istr */
static u8  istr_is41_id;          /* Module id of IS41 */
static u16 istr_base_dlg_id;      /* Lowest IS41 dialogue id to use*/
static u16 istr_num_dlg_ids;      /* Number of IS41 dialogue ids to use */
static u16 istr_options;          /* stores options to be passed to istr_ent*/


/*
 * Program name
 */
static char *program;             /* String storing application name */

/*
 * Main function for IS41 Test Utility (ISTR):
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

  istr_mod_id = DEFAULT_MODULE_ID;
  istr_is41_id = DEFAULT_IS41_ID;
  istr_base_dlg_id = DEFAULT_BASE_DLG_ID;
  istr_num_dlg_ids = DEFAULT_NUM_DLGS;
  istr_options = DEFAULT_OPTIONS;

  program = argv[0];

  if ((cli_error = read_cli_parameters(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case CLI_UNRECON_OPTION :
	fprintf(stderr, "%s: Unrecognised option : %s\n", program, argv[failed_arg]);
	show_syntax();
        break;

      case CLI_RANGE_ERR :
	fprintf(stderr, "%s: Parameter range error : %s\n", program, argv[failed_arg]);
	show_syntax();
	break;

      default :
	break;
    }
  }
  else
    ISTR_ent(istr_mod_id, istr_is41_id, istr_base_dlg_id, istr_num_dlg_ids, istr_options);

  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr,
        "Syntax: %s [-m<ISTR mod id> -u<IS41 mod id> -o<options>]\n", program);
  fprintf(stderr,
        "  -m  : ISTR's module ID (default=0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,
	"  -u  : IS41 module ID (default=0x%02x)\n", DEFAULT_IS41_ID);
  fprintf(stderr,
        "  -b  : base IS-41 dialogue id (default=0x%04x)\n",
        DEFAULT_BASE_DLG_ID);
  fprintf(stderr,
        "  -n  : number of og IS-41 dialogue ids (default=0x%04x)\n",
        DEFAULT_NUM_DLGS);
  fprintf(stderr,
        "  -o  : Output display options (default=0x%04x)\n", DEFAULT_OPTIONS);

}

/*
 * Read in command line options and set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_cli_parameters(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;

  if (arg[0] != '-')
    return(CLI_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
    case 'v' :
      show_syntax();
      return(CLI_EXIT_REQ);

    case 'm' :
      if (!strtonum(&temp_u32, &arg[2]))
	return(CLI_RANGE_ERR);
      istr_mod_id = (u8)temp_u32;
      break;

    case 'u' :
      if (!strtonum(&temp_u32, &arg[2]))
	return(CLI_RANGE_ERR);
      istr_is41_id = (u8)temp_u32;
      break;

    case 'b' :
      if (!strtonum(&temp_u32, &arg[2]))
	return(CLI_RANGE_ERR);
      istr_base_dlg_id = (u16)temp_u32;
      break;

    case 'n' :
      if (!strtonum(&temp_u32, &arg[2]))
	return(CLI_RANGE_ERR);
      istr_num_dlg_ids = (u16)temp_u32;
      break;

    case 'o' :
      if (!strtonum(&temp_u32, &arg[2]))
	return(CLI_RANGE_ERR);
      istr_options = (u16)temp_u32;
      break;

  }
  return(0);
}
