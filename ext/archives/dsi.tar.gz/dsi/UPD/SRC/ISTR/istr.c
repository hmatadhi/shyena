/*
                   Copyright (C) Dialogic Corporation 1999-2006. All Rights Reserved.

 Name:          istr.c

 Description:   Example code for a simple responder to ISTU (IS41 test utility)

                This program responds to an IS-41 Delivery Point-To-Point
                Short Message received from the DataKinetics IS-41 protocol
                module. (Acting as the servicing MSC).

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A     06-Sep-99  JET   - Initial code based on MTR.
   B     15-Feb-00  JET   - Addition of display options '-o'.
                          - Allow multiple simultaneous dialogues to be
                            supported.
   1     13-Dec-06   ML   - Change to use of Dialogic Corporation copyright.
 */

#include <stdio.h>

#include "system.h"
#include "msg.h"
#include "sysgct.h"
#include "is41_inc.h"

/*
 * main program loop termination flag
 */
int finished;

/*
 * Display options
 */
#define ISTR_TRACE_TX           (0x0001)  /* Trace messages sent */
#define ISTR_TRACE_RX           (0x0002)  /* Trace messages received */
#define ISTR_TRACE_ERROR        (0x0004)  /* Trace errors */
#define ISTR_TRACE_BEARER_DATA  (0x0008)  /* Display received bearer data */
#define ISTR_TRACE_DISPLAY      (0x0010)  /* Trace progress of program */

/*
 * ISTR state definitions
 */
#define ISTR_S_IDLE	        (0)     /* Idle */
#define ISTR_S_WAIT_SMS_IND	(1)	/* Wait for forward SMS indication */
#define ISTR_S_WAIT_DELIMITER   (2)     /* Wait for IS41 Delimiter Indication */

#define NUM_OF_DLG_IDS          (0x800) /* Number of OG dialogue ids */

#define MAX_PARAM_LEN           (320)   /* Max length of MSG param area */

/*
 * Local macros.
 */
#define NO_RESPONSE             (0)
#define BIN2CH(b)               ((char)(((b)<10)?'0'+(b):'a'-10+(b)))
/*
 *  SET_STATE and GET_STATE allow easy access to the array of state data.
 * The dialogue id (did) is used to get the correct index into the array.
 */
#define GET_STATE(did)          (ISTR_state[did - ISTR_base_did])
#define SET_STATE(did, state)   (ISTR_state[did - ISTR_base_did] = state)

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
  static int ISTR_disp_msg(char *prefix, MSG *m);
  static int ISTR_disp_trace(char *text);
  static int ISTR_send_msg(u16 instance, MSG *m);
  static int ISTR_process_is41_msg(MSG *m);
  static int ISTR_send_OpenResponse(u16 ISTR_is41_inst, u16 dlg_id, u8 result);
  static int ISTR_send_SMS_DPTP_Response(u16 ISTR_is41_inst, u16 dlg_id, u8 invoke_id);
  static int ISTR_send_Close(u16 ISTR_is41_inst, u16 dlg_id, u8 method);
  static int ISTR_send_Abort(u16 ISTR_is41_inst, u16 dlg_id, u8 reason);
  static int ISTR_get_invoke_id(u8 *pptr, u16 plen);
  static int ISTR_display_bearer_data(u8 *pptr, u16 plen);
#else
  static int ISTR_disp_msg();
  static int ISTR_disp_trace();
  static int ISTR_send_msg();
  static int ISTR_process_is41_msg();
  static int ISTR_send_OpenResponse();
  static int ISTR_send_SMS_DPTP_Response();
  static int ISTR_send_Close();
  static int ISTR_send_Abort();
  static int ISTR_get_invoke_id();
  static int ISTR_display_bearer_data(u8 *pptr, u16 plen);
#endif

/*
 * Static data:
 */
static u8  ISTR_state[NUM_OF_DLG_IDS];  /* Current state */
static u16 ISTR_base_did;               /* Lowest IS41 dialogue id to use*/
static u16 ISTR_num_dids;               /* Number of IS41 dialogue ids to use */
static u8  ISTR_invoke_id;              /* Forward SM invoke id */
static u16 ISTR_is41_inst;              /* Instance of MAP being used */
static u8  ISTR_mod_id;                 /* Module id of this task */
static u8  ISTR_is41_id;                /* Module id for all MAP requests */
static u16 ISTR_options;                /* ISTR display options */

/*
 * ISTR_ent
 *
 * Waits in a continuous loop responding to any received
 * forward SM request with a forward SM response.
 *
 * Never returns.
 */
int ISTR_ent(istr_id, is41_id, base_did, num_dids, options)
  u8  istr_id;	/* Module id for this task */
  u8  is41_id;  /* Module ID for MAP */
  u16 base_did; /* Base IS41 dialogue id */
  u16 num_dids; /* Number of IS41 dialogue ids to use*/
  u16 options;  /* Display options */
{
  HDR *h;		/* received message */
  MSG *m;		/* received message */
  u16 i;                /* loop counter used to initialise state data*/

  ISTR_mod_id = istr_id;
  ISTR_is41_id = is41_id;
  ISTR_base_did = base_did;
  ISTR_num_dids = num_dids;
  ISTR_options = options;

  /*
   * Make sure we don't try to initialise too many dlg ids.
   */
  if (ISTR_num_dids > NUM_OF_DLG_IDS)
    ISTR_num_dids = NUM_OF_DLG_IDS;

  /*
   * Print banner so we know what's running.
   */
  printf("ISTR Responder (C) Dialogic Corporation 1999-2006. All Rights Reserved.\n");
  printf("=======================================================================\n\n");
  printf("ISTR mod Id - 0x%02x; IS41 module Id - 0x%x\n", ISTR_mod_id, ISTR_is41_id);
  printf("Base dlg Id - 0x%04x; Num dlg Ids - 0x%04x\n", ISTR_base_did, ISTR_num_dids);

  /*
   * Now enter main loop, receiving messages as they
   * become available and processing accordingly.
   */
  finished = 0;

  for (i = ISTR_base_did; i < (ISTR_base_did + ISTR_num_dids); i++)
    SET_STATE(i, ISTR_S_IDLE);

  while (!finished)
  {
    /*
     * GCT_receive will attempt to receive messages
     * from the task's message queue and block until
     * a message is ready.
     */
    if ((h = GCT_receive(ISTR_mod_id)) != 0)
    {
      m = (MSG *)h;
      if (ISTR_options & ISTR_TRACE_RX)
        ISTR_disp_msg("ISTR Rx:", m);

      switch (m->hdr.type)
      {
	case IS41_MSG_DLG_IND:
	case IS41_MSG_SRV_IND:
          ISTR_process_is41_msg(m);
	  break;
        default:
          ISTR_disp_trace("*** Unexpected message received ***");
          break;
      }

      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }
  return(0);
}

/*
 * ISTR_process_is41_msg
 *
 * Processes a received IS41 primitive message.
 *
 * Always returns zero.
 */
static int ISTR_process_is41_msg(m)
  MSG *m;	/* Received message */
{
  u16  dlg_id;      /* Dialogue id */
  u8   ptype;       /* Message parameter type*/
  u8   *pptr;       /* MSG parameter area */
  u8   send_abort;  /* set to 1 if abort required */
  int  invoke_id;   /* Invoke Id of received message */

  pptr = get_param(m);
  ptype = *pptr;

  dlg_id = m->hdr.id;
  send_abort = 0;

  switch (GET_STATE(dlg_id))
  {
    /*
     *  Dialogue is idle we are waiting for open
     */
    case ISTR_S_IDLE :
      switch (m->hdr.type)
      {
        case IS41_MSG_DLG_IND :
          switch (ptype)
          {
            case IS41DT_OPEN_IND :
              ISTR_disp_trace("Received Open Indication");

              /*
               * Save dialogue id and instance:
               */
              ISTR_is41_inst = (u16)GCT_get_instance((HDR*)m);
              SET_STATE(dlg_id, ISTR_S_WAIT_SMS_IND);
             break;

            default :
              send_abort = 1;
              break;
          }
          break;

        default :
          send_abort = 1;
          break;
      }
      break;

    /*
     * Dialogue is open, waiting for the short message to be received
     */
    case ISTR_S_WAIT_SMS_IND :
      switch (m->hdr.type)
      {
        case IS41_MSG_SRV_IND :
          switch (ptype)
          {
            case IS41ST_SMS_DPTP_IND :
              ISTR_disp_trace("Received Short Message Point-To-Point Indication");
              /*
               * Recover invoke id. If is recovered correctly wait for the
               * delimit.
               */
              invoke_id = ISTR_get_invoke_id(get_param(m), m->len);
              if (invoke_id != -1)
              {
                ISTR_invoke_id = (u8)invoke_id;
                SET_STATE(dlg_id, ISTR_S_WAIT_DELIMITER);
              }
              ISTR_display_bearer_data(get_param(m), m->len);
              break;

            default :
              send_abort = 1;
              break;
          }
          break;

        default :
          send_abort = 1;
          break;
      }
      break;

    /*
     * The short message has already been received we now expect to receive
     * the delimit. This indicates all components in TCAP Begin have been
     * received. We can now process the message.
     */
    case ISTR_S_WAIT_DELIMITER :
      switch (m->hdr.type)
      {
        case IS41_MSG_DLG_IND :
          switch (ptype)
          {
            case IS41DT_DELIMITER_IND :
              ISTR_disp_trace("Received delimiter Indication");
              ISTR_send_OpenResponse(ISTR_is41_inst, dlg_id, IS41RS_DLG_ACC);
              ISTR_send_SMS_DPTP_Response(ISTR_is41_inst, dlg_id, ISTR_invoke_id);
              ISTR_send_Close(ISTR_is41_inst, dlg_id, IS41RM_normal_release);
              SET_STATE(dlg_id, ISTR_S_IDLE);
              send_abort = 0;
              break;

            default :
              send_abort = 1;
              break;
          }
          break;

        default :
          send_abort = 1;
          break;
      }
      break;
  }
  /*
   * If an error has been encountered, send abort
   */
  if (send_abort)
  {
    ISTR_send_Abort(ISTR_is41_inst, dlg_id, IS41UR_procedure_error);
    SET_STATE(dlg_id, ISTR_S_IDLE);
  }
  return(0);
}

/******************************************************************************
 *
 * Functions to send primitive requests to the IS41 module
 *
 ******************************************************************************/
/*
 * ISTR_send_OpenResponse
 *
 * Sends an open response to IS41
 *
 * Always returns zero.
 */
static int ISTR_send_OpenResponse(instance, dlg_id, result)
  u16 instance;        /* Destination instance */
  u16 dlg_id;          /* Dialogue id */
  u8  result;          /* Result (accepted/rejected) */
{
  MSG  *m;             /* Message to send */
  u8   *pptr;          /* Parameter area of message being sent */

  ISTR_disp_trace("Sending Open Response");

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_DLG_REQ, dlg_id, NO_RESPONSE,
	   		      MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ISTR_mod_id;
    m->hdr.dst = ISTR_is41_id;

    /*
     * Format the parameter area of the message
     *
     * Primitive type = Open response
     * Parameter name = result
     * Parameter length = 1
     * Parameter value
     * Parameter name = terminator
     */
    pptr = get_param(m);
    pptr[0] = IS41DT_OPEN_RSP;
    pptr[1] = IS41PN_result;
    pptr[2] = 0x01;
    pptr[3] = result;
    pptr[4] = 0x00;
    m->len = 5;
    ISTR_send_msg(instance, m);
  }
  return(0);
}

/*
 * ISTR_send_SMS_DPTP_Response
 *
 * Sends a Delivery Point to Point short message response to IS41.
 *
 * Always returns zero.
 */
static int ISTR_send_SMS_DPTP_Response(instance, dlg_id, invoke_id)
  u16 instance;        /* Destination instance */
  u16 dlg_id;          /* Dialogue id */
  u8  invoke_id;       /* Invoke_id */
{
  MSG  *m;             /* Message to send */
  u8   *pptr;          /* Parameter area of message being sent */

  ISTR_disp_trace("Sending Delivery Point-To-Point SMS Response");

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_SRV_REQ, dlg_id, NO_RESPONSE,
				      MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ISTR_mod_id;
    m->hdr.dst = ISTR_is41_id;

    /*
     * Format the parameter area of the message
     *
     * Primitive type = DPTP SM response
     * Parameter name = invoke ID
     * Parameter length = 1
     * Parameter value
     * Parameter name = terminator
     *
     */
    pptr = get_param(m);
    pptr[0] = IS41ST_SMS_DPTP_RSP;
    pptr[1] = IS41PN_invoke_id;
    pptr[2] = 0x01;
    pptr[3] = invoke_id;
    pptr[4] = 0x00;
    m->len = 5;
    ISTR_send_msg(instance, m);
  }
  return(0);
}

/*
 * ISTR_send_MapClose
 *
 * Sends a Close message to IS41.
 *
 * Always returns zero.
 */
static int ISTR_send_Close(instance, dlg_id, method)
  u16 instance;        /* Destination instance */
  u16 dlg_id;          /* Dialogue id */
  u8  method;          /* Release method */
{
  MSG  *m;             /* Message to send */
  u8   *pptr;          /* Parameter area of message being sent */

  ISTR_disp_trace("Sending Close Request");

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_DLG_REQ, dlg_id, NO_RESPONSE,
				      MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ISTR_mod_id;
    m->hdr.dst = ISTR_is41_id;

    /*
     * Format the parameter area of the message
     *
     * Primitive type = Close Request
     * Parameter name = release method
     * Parameter length = 1
     * Parameter value
     * Parameter name = terminator
     *
     */
    pptr = get_param(m);
    pptr[0] = IS41DT_CLOSE_REQ;
    pptr[1] = IS41PN_release_method;
    pptr[2] = 0x01;
    pptr[3] = method;
    pptr[4] = 0x00;
    m->len = 5;
    ISTR_send_msg(instance, m);
  }
  return(0);
}

/*
 * ISTR_send_Abort
 *
 * Sends an abort message to IS41.
 *
 * Always returns zero.
 */
static int ISTR_send_Abort(instance, dlg_id, reason)
  u16 instance;        /* Destination instance */
  u16 dlg_id;          /* Dialogue id */
  u8  reason;          /* user reason for abort */
{
  MSG  *m;             /* Message to send */
  u8   *pptr;          /* Parameter area of message being sent */

  ISTR_disp_trace("Sending User Abort Request");

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_DLG_REQ, dlg_id, NO_RESPONSE,
				      MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = ISTR_mod_id;
    m->hdr.dst = ISTR_is41_id;

    /*
     * Format the parameter area of the message
     *
     * Primitive type = Close Request
     * Parameter name = user reason
     * Parameter length = 1
     * Parameter value
     * Parameter name = terminator
     */
    pptr = get_param(m);
    pptr[0] = IS41DT_U_ABORT_REQ;
    pptr[1] = IS41PN_user_rsn;
    pptr[2] = 0x01;
    pptr[3] = reason;
    pptr[4] = 0x00;
    m->len = 4;
    ISTR_send_msg(instance, m);
  }
  return(0);
}

/*
 * ISTR_send_msg sends a MSG. On failure the
 * message is released and the user notified.
 *
 * Always returns zero.
 */
static int ISTR_send_msg(instance, m)
  u16   instance;       /* Destination instance */
  MSG	*m;		/* MSG to send */
{
  GCT_set_instance((unsigned int)instance, (HDR*)m);

  /*
   *  Only display message if option is set
   */
  if (ISTR_options & ISTR_TRACE_TX)
    ISTR_disp_msg("ISTR Tx:", m);

  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    /*
     * The message could not be sent so tell the user and free the message
     */
    fprintf(stderr, "*** failed to send message ***\n");
    relm((HDR *)m);
  }
  return(0);
}


/******************************************************************************
 *
 * Functions to recover parameters from received IS41 format primitives
 *
 ******************************************************************************/


/*
 * ISTR_get_invoke_id
 *
 * recovers the invoke id parameter from a parameter array
 *
 * Returns the recovered value or -1 if not found.
 */
static int ISTR_get_invoke_id(pptr, plen)
  u8  *pptr;	/* First byte of received primitive data (type octet) */
  u16 plen;	/* length of primitive data */
{
  int  invoke_id;  /* Stores recovered Invoke id of component message */
  u8   ptype;      /* Recovered parameter type */

  /*
   * Skip past primitive type
   */
  pptr++;
  plen --;
  invoke_id = -1;

  while (plen)
  {
    ptype = *pptr++;
    plen = *pptr++;

    if (ptype == IS41PN_invoke_id)
    {
      /*
       * Verify that invoke ID length is 1 octet
       */
      if (plen == 1)
      {
        invoke_id = (int)*pptr;
        break;
      }
    }
    /*
     * Advance to next parameter
     */
    pptr += plen;
  }
  return(invoke_id);
}

/*
 * ISTR_display_bearer_data
 *
 * Displays any recovered bearer data
 *
 * Returns 0.
 */
static int ISTR_display_bearer_data(pptr, plen)
  u8  *pptr;	/* First byte of received primitive data (type octet) */
  u16 plen;	/* length of primitive data */
{
  u8   ptype;   /* Recovered parameter type */

  if (!(ISTR_options & ISTR_TRACE_BEARER_DATA))
    return(0);

  /*
   * Skip past primitive type
   */
  pptr++;
  plen --;

  while (plen)
  {
    ptype = *pptr++;
    plen = *pptr++;

    if (ptype == IS41PN_SMSbearerdata)
    {
      if (plen > 0)
      {
        printf("Bearer Data [");
        while (plen--)
        {
          printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
          pptr++;
        }
        printf("]\n");
        break;
      }
    }
    /*
     * Advance to next parameter
     */
    pptr += plen;
  }
  return(0);
}

/*
 * ISTR_disp_msg
 *
 * Traces (prints) any message as hexadecimal to the console.
 *
 * Always returns zero.
 */
static int ISTR_disp_msg(prefix, m)
  char *prefix;          /* String prefix to command line display*/
  MSG  *m;               /* received message */
{
  HDR   *h;              /* Header of message to trace */
  int   instance;        /* Instance of module message is sent from */
  u16   mlen;            /* Length of traced message */
  u8    *pptr;           /* Parameter area of traced message */

  h = (HDR*)m;
  instance = GCT_get_instance(h);
  printf("%s I%04x M t%04x i%04x f%02x d%02x s%02x", prefix, instance, h->type,
          h->id, h->src, h->dst, h->status);

  if ((mlen = m->len) > 0)
  {
    if (mlen > MAX_PARAM_LEN)
      mlen = MAX_PARAM_LEN;
    printf(" p");
    pptr = get_param(m);
    while (mlen--)
    {
      printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
      pptr++;
    }
  }
  printf("\n");
  return(0);
}

/*
 * ISTR_disp_trace
 *
 * Traces internal progress to the console.
 *
 * Always returns zero.
 */
static int ISTR_disp_trace(text)
  char *text; /* Text for tracing progress of program */
{
  if (ISTR_options & ISTR_TRACE_DISPLAY)
    printf("ISTR: %s\n",text);

  return(0);
}




