/*
                Copyright (C) Dialogic Corporation 1997-2015. All Rights Reserved.

 Name:          mtu.c

 Description:   Example application program for the MAP user interface.

                The application opens a dialogue, sends a service request,
                and handles the response in a manner designed to exercise
                the MAP functionality and illustrate the programming
                techniques involved.

 Functions:     main

 -----  ---------  ---------------------------------------------
 Issue    Date                       Changes
 -----  ---------  ---------------------------------------------

   A    23-Sep-97   - Initial code.
   B    19-Jan-98   - Prevents IMSI and SMSC address nibbles being swapped.
   C    20-Mar-98   - Added Version 1 functionality.
   D    21-Aug-98   - Temporary fix added so that correct SM RP UI
                      contents may be sent.
   E    11-Nov-98   - Added missing function declarations.
   F    13-Jan-99   - Included additional required parameters in the
                      the MAP-FORWARD-SHORT-MESSAGE-Req SMS-DELIVER.
                    - 'finished' variable made static.
   G    16-Feb-00   - Changed response to receipt of provider errors.
                      Now ignores all but provider error == no response,
                      to which it replies with MAP_CLOSE.  **NOTE** this
                      is different to the 09.02 SDLs.
   1    16-Jul-01   - Removed call to GCT_grab().
   2    10-Aug-01   - Added support for Send-IMSI and Send routing info
                      for GPRS. Also ability to generate multiple
                      dialogues.
   3    19-Dec-01   - Change to ensure dialogue is aborted if no reply
                      to a service invoke is received.
   4    20-Jan-06   - Include reference to Intel Corporation in file header
   5    21-Aug-06   - Operation timeout in MTU_send_imsi() reduced to 15
                      seconds from 60.
   6    13-Dec-06   - Change to use of Dialogic Corporation copyright.   
   7    30-Sep-09   - Support for additional MAP services, e.g. USSD.
   8    02-Dec-09   - Minor fixes to dialogue id's.
   9    05-Apr-11   - Corrected setting of messages to send in SMS tx.
                    - Updated setting of TP-OA parameter.
   10   25-Sep-14   - Network Context support
   11   09-Dec-14   - Add control of adding extra dest digits. 
        06-Feb-15   - Combined branches to form new release
        30-Jun-15   - QOS can now have up to 2 additional octets
        13-Jul-15   - For consistency use PI_BYTES bits for MAPPN_nc and MAPPN_qos
 */

#include "mtu.h"

/*
 * MTU state definitions
 */
#define MTU_IDLE                (0)     /* Idle */
#define MTU_WAIT_OPEN_CNF       (1)     /* Wait for Open confirmation */
#define MTU_WAIT_SERV_CNF       (2)     /* Wait for MT SMS confirm */
#define MTU_WAIT_CLOSE_IND      (3)     /* Wait for Close ind */

/*
 * Prototypes for local functions:
 */
static u16 MTU_alloc_dlg_id(u16 *dlg_id);
static MTU_DLG *MTU_get_dlg_data(u16 dlg_id);
static u8 MTU_alloc_invoke_id(void);
static int MTU_display_msg(char *prefix, MSG *m);
static int MTU_display_recvd_msg(MSG *m);
static int MTU_display_sent_msg(MSG *m);
static int MTU_forward_sm(u16 dlg_id, u8 invoke_id);
static int MTU_MT_forward_sm(u16 dlg_id, u8 invoke_id);
static int MTU_process_uss_req (u16 dlg_id, u8 invoke_id);  /* USSD */ 
static int MTU_open_dlg(u8 service, MTU_BCDSTR *imsi);
static int MTU_other_message(MSG *m);
static void MTU_release_dlg_id(u16 dlg_id);
static void MTU_release_invoke_id(u8 invoke_id, MTU_DLG *dlg);
static int MTU_send_dlg_req(MTU_MSG *dlg_req);
static int MTU_send_imsi(u16 dlg_id, u8 invoke_id);
static int MTU_send_msg(MSG *m);
static int MTU_sri_gprs(u16 dlg_id, u8 invoke_id);
static int MTU_sri_sm(u16 dlg_id, u8 invoke_id);
static int MTU_send_srv_req(MTU_MSG *srv_req);
static int MTU_smac(MSG *m);
static int MTU_wait_open_cnf(MTU_MSG *ind, MTU_DLG *dlg);
static int MTU_wait_serv_cnf(MTU_MSG *ind, MTU_DLG *dlg);
static int MTU_wait_close_ind(MTU_MSG *ind, MTU_DLG *dlg);
static int MTU_Send_UnstructuredSSRequestRSP (u16 dlg_id, u8 invoke_id); /* USSD */

/*
 * Application context for shortMsgRelayContext-v1
 */
static u8 shortMsgRelayContextv1[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  21,           /* short msg relay */
  01            /* version 1 */
};

/*
 * Application context for shortMsgRelayContext-v2
 */
static u8 shortMsgRelayContextv2[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  25,           /* short msg relay */
  02            /* version 2 */
};

/*
 * Application context for imsiRetrievalContext-v2
 */
static u8 imsiRetrievalContextv2[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  26,           /* imsi retrieval */
  02            /* version 2 */
};

/*
 * Application context for gprsLocationInfoRetrievalContext-v3
 */
static u8 gprsLocationInfoRetrievalContextv3[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  33,           /* gprs location info retrieval */
  03            /* version 3 */
};

/* new application context shortMsgMT-RelayContext */
static u8 shortMsgMTRelayContext[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  25,           /* map-ac shortMsgMT-Relay */
  03            /* version 3 */
};

/* new application context shortMsgMT-GatewayContext */
static u8 shortMsgGatewayContext[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  20,           /* map-ac shortMsgGateway */
  03            /* version 3 */
};

/* new application context networkUnstructuredSsContext-v2 */
static u8 networkUnstructuredSsContext[AC_LEN] =
{
  06,           /* object identifier */
  07,           /* length */
  04,           /* CCITT */
  00,           /* ETSI */
  00,           /* Mobile domain */
  01,           /* GSM network */
  00,           /* application contexts */
  19,           /* map-ac networkUnstructuredSs */
  02            /* version 2 */
};

/*
 * Default Service Centre address. Note that if there are an odd number of
 * digits, then f should be added to the end of the digits as a filler.
 */
MTU_OASTR DEFAULT_SC_ADDR =
{
  4,                    /* type of address = service centre address */
  5,                    /* number of bytes of digits in the string */
  2,                    /* nature of address = national significant number */
  1,                    /* numbering plan indicator = ISDN/telephony numbering plan */
  {
    0x21, 0x43, 0x65, 0x87, 0xf9
  }                     /* digits, packed in BCD format */
};

/*
 * Default msisdn. Note that if there are an odd number of
 * digits, then f should be added to the end of the digits as a filler.
 */
MTU_ADDSTR DEFAULT_MSISDN =
{
  6,                    /* number of bytes of digits in the string */
  2,                    /* nature of address = national significant number */
  1,                    /* numbering plan indicator = ISDN/telephony numbering plan */
  {
    0x44, 0x83, 0x15, 0x32, 0x54, 0xf6
  }                     /* digits, packed in BCD format */
};

/*
 * Default GGSN number.
 */
MTU_ADDSTR DEFAULT_GGSN_NUMBER =
{
  6,                    /* number of bytes of digits in the string */
  2,                    /* nature of address = national significant number */
  1,                    /* numbering plan indicator = ISDN/telephony numbering plan */
  {
    0x44, 0x79, 0x15, 0x32, 0x54, 0xf6
  }                     /* digits, packed in BCD format */
};



/*
 * Static data
 */
static int finished;                     /* program finishes when this is set */
static MTU_DLG dlg_data[NUM_OF_DLG_IDS]; /* Dialogue data */
static CL_ARGS mtu_args;                 /* Command line arguments */
static u16 mtu_dlg_id;                   /* current dialogue ID */
static u16 mtu_active;                   /* number of dialogues active */
static u32 mtu_dlg_count;                /* counts number of dialogues opened */


/*
 * mtu_ent opens a dialogue with the servicing MSC and forwards the short
 * message. It then waits for messages and processes them appropriately
 * until a MAP-CLOSE-IND is received or an error occurs.
 *
 * Always returns zero.
 */
int mtu_ent(cl_args)
  CL_ARGS *cl_args;     /* structure containing all command-line arguments */
{
  HDR *h;               /* received message */
  MSG *m;               /* received message */
  MTU_BCDSTR imsi;      /* IMSI */
  int i;                /* dialogue loop counter */
  u8 service;           /* service to use for the dialogue */

  /*
   * Initialise static data
   */
  mtu_args.mtu_mod_id = cl_args->mtu_mod_id;
  mtu_args.mtu_map_id = cl_args->mtu_map_id;
  mtu_args.nc = cl_args->nc;  
  mtu_args.qos = cl_args->qos; 
  mtu_args.qos_size = cl_args->qos_size;
  mtu_args.qos_present = cl_args->qos_present;
  mtu_args.dest_add_digits  = cl_args->dest_add_digits;
  mtu_args.map_version = cl_args->map_version;
  mtu_args.mode = cl_args->mode;
  mtu_args.options = cl_args->options;
  mtu_args.base_dlg_id = cl_args->base_dlg_id;
  mtu_args.num_dlg_ids = cl_args->num_dlg_ids;
  mtu_args.max_active = cl_args->max_active;
  mtu_args.imsi = cl_args->imsi;
  mtu_args.service_centre = cl_args->service_centre;
  mtu_args.dest_address = cl_args->dest_address;
  mtu_args.orig_address = cl_args->orig_address;
  mtu_args.message = cl_args->message;
  mtu_args.msisdn = cl_args->msisdn;
  mtu_args.ggsn_number = cl_args->ggsn_number;
  mtu_args.ussd_string = cl_args->ussd_string;

  mtu_dlg_id = mtu_args.base_dlg_id;
  mtu_active = 0;
  mtu_dlg_count = 0;

  imsi.num_bytes = 0;

  /*
   * Make sure all the dialogues are idle to start with
   */
  for (i=0; i<mtu_args.num_dlg_ids; i++)
    dlg_data[i].state = MTU_IDLE;

  /*
   * Print banner so we know what's running.
   */
  printf(
  "MTU MAP Test Utility  Copyright (C) Dialogic Corporation 1997-2015. All Rights Reserved.\n");
  printf(
  "===============================================================\n\n");
  printf("MTU mod ID 0x%02x; MAP module Id 0x%x; Network Context 0x%x\n",
         mtu_args.mtu_mod_id, mtu_args.mtu_map_id, mtu_args.nc);
  printf("mode %d - ", mtu_args.mode);

  switch (mtu_args.mode)
  {
    case MTU_FORWARD_SM:
      printf("Forward Short Message\n\n");
      break;
    case MTU_SEND_IMSI:
      printf("Send IMSI\n\n");
      break;
    case MTU_SI_SRIGPRS:
      printf("Send IMSI and Send routing info for GPRS\n\n");
      break;
    case MTU_SRI_GPRS:
      printf("Send routing info for GPRS\n\n");
      break;
    case MTU_MT_FORWARD_SM:
      printf("Forward MT Short Message\n\n");
      break;
    case MTU_SRI_SM:
      printf("Send routing info for Short Message (v3)\n\n");
      break;
    case MTU_PROCESS_USS_REQ:
      printf("Send ProcessUnstructuredSS-Request (v2)\n\n");  /* USSD */ 
      break;

  }

  /*
   * Determine the service to be used for this dialogue. When using multiple
   * dialogues the mode may be set to MTU_SI_SRIGPRS which causes
   * the service to alternate between MTU_SEND_IMSI and MTU_SRI_GPRS.
   * Always start with MTU_SENDI_IMSI.
   */
    if (mtu_args.mode == MTU_SI_SRIGPRS)
      service = MTU_SEND_IMSI;
    else
      service = mtu_args.mode;

  /*
   * If multiple dialogues have been requested, open dialogues up to the
   * maximum that can be simultaneously active and keep on opening new
   * dialogues as they are closed. Otherwise, just open one dialogue.
   */
  if (mtu_args.max_active == 0)
  {
    /*
     * Only a single dialogue was requested
     */

    if (MTU_open_dlg(service, &imsi) != 0)
      MTU_disp_err("Failed to open dialogue");

    finished = 0;
    while (!finished)
    {
      /*
       * Receive messages as they become available and
       * process accordingly.
       *
       * GCT_receive will attempt to receive messages
       * from the task's message queue and block until
       * a message is ready.
       */
      if ((h = GCT_receive(mtu_args.mtu_mod_id)) != 0)
      {
        m = (MSG *)h;
        switch (m->hdr.type)
        {
          case MAP_MSG_DLG_IND:
          case MAP_MSG_SRV_IND:
            if (mtu_args.options & MTU_TRACE_RX)
              MTU_display_recvd_msg(m);
            MTU_smac(m);
            break;

          default:
            /*
             * Under normal operation we don't expect to receive anything
             * else but if we do report the messages.
             */
            if (mtu_args.options & MTU_TRACE_RX)
              MTU_display_recvd_msg(m);
            MTU_disp_err("Unexpected message type");
            break;
        }
        /*
         * Once we have finished processing the message
         * it must be released to the pool of messages.
         */
        relm(h);
      }
    } /* end while */
  }
  else
  {
    /*
     * Multiple dialogues
     */
    while (1)
    {
      if (mtu_active < mtu_args.max_active)
      {
        if (MTU_open_dlg(service, &imsi) != 0)
          MTU_disp_err("Failed to open dialogue");
      }

      /*
       * Receive messages as they become available and
       * process accordingly.
       *
       * GCT_receive will attempt to receive messages
       * from the task's message queue and block until
       * a message is ready.
       */
      if ((h = GCT_receive(mtu_args.mtu_mod_id)) != 0)
      {
        m = (MSG *)h;
        switch (m->hdr.type)
        {
          case MAP_MSG_DLG_IND:
          case MAP_MSG_SRV_IND:
            if (mtu_args.options & MTU_TRACE_RX)
              MTU_display_recvd_msg(m);
            MTU_smac(m);
            break;

          default:
            /*
             * Under normal operation we don't expect to receive anything
             * else but if we do, report the messages.
             */
            if (mtu_args.options & MTU_TRACE_RX)
              MTU_display_recvd_msg(m);
            MTU_disp_err("Unexpected message type");
            break;
        }

        /*
         * Once we have finished processing the message
         * it must be released to the pool of messages.
         */
        relm(h);
      }
    } /* end while */
  }
  return(0);
} /* end of mtu_ent() */

/*
 * MTU_display_msg - displays sent and received messages
 *
 * Always returns zero.
 */
static int MTU_display_msg(prefix, m)
  char * prefix;        /* string prefix to command line display */
  MSG *m;               /* received message */
{
  HDR *h;               /* header of message to trace */
  int instance;         /* instance of module message is sent from */
  u16 mlen;             /* length of traced message */
  u8 *pptr;             /* parameter are of trace message */

  h = (HDR *)m;
  instance = GCT_get_instance(h);
  printf("%s I%04x M t%04x i%04x f%02x d%02x s%02x" , prefix, instance,
         h->type, h->id, h->src, h->dst, h->status);

  if ((mlen = m->len) > 0)
  {
    if (mlen > MTU_MAX_PARAM_LEN)
      mlen = MTU_MAX_PARAM_LEN;
    printf(" p");
    pptr = get_param(m);
    while (mlen--)
    {
      printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
      pptr++;
    }
  }
  printf("\n");

  return(0);
} /* end of MTU_display_msg() */

/*
 * MTU_display_recvd_message - displays received messages
 *
 * Always returns zero.
 */
static int MTU_display_recvd_msg(m)
  MSG *m;               /* received message */
{

  switch (m->hdr.type)
  {
    case MAP_MSG_DLG_IND:
      switch (*(get_param(m)))
      {
        case MAPDT_OPEN_IND:
          printf("MTU Rx: received Open Indication\n");
          break;
        case MAPDT_CLOSE_IND:
          printf("MTU Rx: received Close Indication\n");
          break;
        case MAPDT_DELIMITER_IND:
          printf("MTU Rx: received Delimiter Indication\n");
          break;
        case MAPDT_U_ABORT_IND:
          printf("MTU Rx: received U Abort Indication\n");
          break;
        case MAPDT_P_ABORT_IND:
          printf("MTU Rx: received P Abort Indication\n");
          break;
        case MAPDT_NOTICE_IND:
          printf("MTU Rx: received Notice Indication\n");
          break;
        case MAPDT_OPEN_CNF:
          printf("MTU Rx: received Open Confirmation\n");
          break;
        default:
          printf("MTU Rx: received dialogue indication\n");
          break;
      }
      break;

    case MAP_MSG_SRV_IND:
      switch (*(get_param(m)))
      {
        case MAPST_SND_RTIGPRS_CNF:
          printf("MTU Rx: received Send Routing Info for GPRS Confirmation\n");
          break;
        case MAPST_SEND_IMSI_CNF:
          printf("MTU Rx: received Send IMSI Confirmation\n");
          break;
        case MAPST_FWD_SM_CNF:
          printf("MTU Rx: received Forward Short Message Confirmation\n");
          break;
        case MAPST_MT_FWD_SM_CNF:
          printf("MTU Rx: received MT Forward Short Message Confirmation\n");
          break;
        case MAPST_SND_RTISM_CNF:
          printf("MTU Rx: received Send Routing Info for SMS Confirmation\n");
          break;
        case MAPST_UNSTR_SS_REQ_IND:
          printf("MTU Rx: received UnstructuredSS-Request Indication\n");
          break;
        case MAPST_PRO_UNSTR_SS_REQ_CNF:
          printf("MTU Rx: received ProcessUnstructured-Request-Confirmation\n");
          break;
        default:
          printf("MTU Rx: received service indication\n");
          break;
      }
      break;
  }

  MTU_display_msg("MTU Rx:", m);
  return(0);
}

/*
 * MTU_display_sent_message - displays sent messages
 *
 * Always returns zero.
 */
static int MTU_display_sent_msg(m)
  MSG *m;               /* received message */
{

  switch (m->hdr.type)
  {
    case MAP_MSG_DLG_REQ:
      switch (*(get_param(m)))
      {
        case MAPDT_OPEN_REQ:
          printf("MTU Tx: sending Open Request\n");
          break;
        case MAPDT_OPEN_RSP:
          printf("MTU Tx: sending Open Response\n");
          break;
        case MAPDT_CLOSE_REQ:
          printf("MTU Tx: sending Close Request\n");
          break;
        case MAPDT_DELIMITER_REQ:
          printf("MTU Tx: sending Delimiter Request\n");
          break;
        case MAPDT_U_ABORT_REQ:
          printf("MTU Tx: sending U Abort Request\n");
          break;
        default:
          printf("MTU Tx: sending dialogue request\n");
          break;
      }
      break;

    case MAP_MSG_SRV_REQ:
      switch (*(get_param(m)))
     {
        case MAPST_SND_RTIGPRS_REQ:
          printf("MTU Tx: sending Send Routing Info for GPRS Request\n");
          break;
        case MAPST_SEND_IMSI_REQ:
          printf("MTU Tx: sending Send IMSI Request\n");
          break;
        case MAPST_FWD_SM_REQ:
          printf("MTU Tx: sending Forward Short Message Request\n");
          break;
        case MAPST_MT_FWD_SM_REQ:
          printf("MTU Tx: sending Forward Short Message Request\n");
          break;
        case MAPST_PRO_UNSTR_SS_REQ_REQ:
          printf("MTU Tx: sending ProcessUnstructured-Request Req\n");
          break;
        case MAPST_UNSTR_SS_REQ_RSP:
          printf("MTU Tx: sending UnstructuredSSRequestRSP\n");
          break;
        case MAPST_SND_RTISM_REQ:
          printf("MTU Tx: sending Send Routing Info for SMS Request\n");
          break;                  
        default:
          printf("MTU Tx: sending service request\n");
          break;
     }
     break;
  }

  MTU_display_msg("MTU Tx:", m);
  return(0);
}

/*
 * MTU_open_dlg opens a dialogue by sending:
 *
 *   MAP-OPEN-REQ
 *   service primitive request
 *   MAP-DELIMITER-REQ
 *
 * Returns zero if the dialogue was successfully opened.
 *         -1   if the dialogue could not be opened.
 */
static int MTU_open_dlg(service, imsi)
  u8 service;           /* service to use for this dialogue */
  MTU_BCDSTR *imsi;     /* IMSI */
{
  MTU_MSG req;          /* structured form of request message */
  MTU_DLG *dlg;         /* dialogue data structure */
  int i,j;              /* loop counters */
  u16 dlg_id;           /* dialogue ID */
  static int numberend;
  char temp_destaddr[256];
  char temp_idx[256];
  char temp;


  /*
   * First allocate a dialogue ID for the dialogue. This dialogue ID is used
   * in all messages sent to and from MAP associated with this dialogue.
   */
  if (MTU_alloc_dlg_id(&dlg_id) != 0)
    return(-1);

  /*
   * Increment the dialogue counter and display count every 1000 dialogues
   */
  mtu_dlg_count++;
  if (((mtu_dlg_count % 1000) == 0) && (mtu_args.options & MTU_TRACE_STATS))
    fprintf(stderr, "Number of dialogues opened = %d\n", mtu_dlg_count);

  /*
   * Get a pointer to the data associated with this dialogue id and store
   * the service to be used for this dialogue.
   */
  dlg = MTU_get_dlg_data(dlg_id);
  dlg->service = service;
  /*
   * Open the dialogue by sending MAP-OPEN-REQ.
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPDT_OPEN_REQ;
  
  if(mtu_args.nc !=0)
  {
    req.nc = mtu_args.nc;
    bit_set(req.pi, MAPPN_nc);
  }

  /*
   * Copy the appropriate application context into the message structure
   */
  bit_set(req.pi, MAPPN_applic_context);

  switch (service)
  {
    case MTU_SEND_IMSI:
      /*
       * Send IMSI
       */
      for (i=0; i<AC_LEN; i++)
        req.applic_context[i] = imsiRetrievalContextv2[i];
      break;

    case MTU_SRI_GPRS:
      /*
       * Send routing info for GPRS
       */
      for (i=0; i<AC_LEN; i++)
        req.applic_context[i] = gprsLocationInfoRetrievalContextv3[i];
      break;

    case MTU_MT_FORWARD_SM:
      /*
       * MT Forward short message
       */
      for (i=0; i<AC_LEN; i++)
            req.applic_context[i] = shortMsgMTRelayContext[i];
      break;
          
    case MTU_SRI_SM:
      /*
       * Send Routing Information For SM
       */
      for (i=0; i<AC_LEN; i++)
          req.applic_context[i] = shortMsgGatewayContext[i];
      break;
    
     case MTU_PROCESS_USS_REQ:
      /*
       * Send ProcessUnstructuredSS-Request
       */
      for (i=0; i<AC_LEN; i++)
          req.applic_context[i] = networkUnstructuredSsContext[i];
      break;

    case MTU_FORWARD_SM:
    default:
      /*
       * Forward short message
       */
      switch (mtu_args.map_version)
      {
        case MTU_MAPV1:
          for (i=0; i<AC_LEN; i++)
            req.applic_context[i] = shortMsgRelayContextv1[i];
          break;
        default:
          for (i=0; i<AC_LEN; i++)
            req.applic_context[i] = shortMsgRelayContextv2[i];
          break;
      }
      break;
  }

 

  strncpy(temp_destaddr, mtu_args.dest_address, 255);

  if (mtu_args.dest_add_digits != 0)
  {
    /* 
     * Append 6 digits i.e. 000000 to 999999 
     */
    numberend++; 
    if(numberend>999999)
      numberend = 0;

    sprintf(temp_idx,"%0.6u",numberend);
    
    /* swap the pairs of digits - there is always an even number (6) */
    i = 0;  
    while (temp_idx[i] != '\0')
    {
      temp = temp_idx[i];
      temp_idx[i] = temp_idx[i+1];
      temp_idx[i+1] = temp;
      i+=2;
    }

    /* append to the existing address */
    strncat(temp_destaddr, temp_idx, 255);
  }

  if (mtu_args.options & MTU_TRACE_TX)
    fprintf(stderr, "Dest: %s\n", &temp_destaddr);

  /*
   * Copy the destination address parameter into the MAP-OPEN-REQ,
   * converting from ASCII to hex, and packing into BCD format.
   */
  bit_set(req.pi, MAPPN_dest_address);

  i = 0;
  j = 0;
  while ((temp_destaddr[j] != '\0') && (i < MAX_ADDR_LEN))
  {
    req.dest_address.data[i] = (hextobin(temp_destaddr[j])) << 4;

    if (mtu_args.dest_address[j+1] != '\0')
    {
      req.dest_address.data[i++] |= hextobin(temp_destaddr[j+1]);
      j += 2;
    }
    else
    {
      i++;
      break;
    }
  }
  req.dest_address.num_bytes = i;

  /*
   * Copy the origination address parameter into the MAP-OPEN-REQ, converting
   * from ASCII to hex, and packing into BCD format.
   */
  bit_set(req.pi, MAPPN_orig_address);

  i = 0;
  j = 0;
  while ((mtu_args.orig_address[j] != '\0') && (i < MAX_ADDR_LEN))
  {
    req.orig_address.data[i] = (hextobin(mtu_args.orig_address[j])) << 4;

    if (mtu_args.dest_address[j+1] != '\0')
    {
      req.orig_address.data[i++] |= hextobin(mtu_args.orig_address[j+1]);
      j += 2;
    }
    else
    {
      i++;
      break;
    }
  }
  req.orig_address.num_bytes = i;

  MTU_send_dlg_req(&req);

  /*
   * Send the appropriate service primitive request. First, allocate an invoke
   * ID. This invoke ID is used in all messages to and from MAP associated with
   * this request.
   */
  dlg->invoke_id = MTU_alloc_invoke_id();

  switch (service)
  {
    case MTU_SEND_IMSI:
      /*
       * Send IMSI
       */
      MTU_send_imsi(dlg_id, dlg->invoke_id);
      break;

    case MTU_SRI_GPRS:
      /*
       * Send routing info for GPRS
       */
      dlg->imsi = *imsi;
      MTU_sri_gprs(dlg_id, dlg->invoke_id);
      break;
        
    case MTU_MT_FORWARD_SM:
      /*
       * Forward short message
       */
      MTU_MT_forward_sm(dlg_id, dlg->invoke_id);
      break;
    
    case MTU_SRI_SM:
      /*
       * Send Routing Information For SM
       */
      MTU_sri_sm(dlg_id, dlg->invoke_id);
      break;

    case MTU_PROCESS_USS_REQ:   /* USSD */ 
      /*
       * Send ProcessUnstructuredSS-Request
       */
      MTU_process_uss_req(dlg_id, dlg->invoke_id);
      break;

    case MTU_FORWARD_SM:
    default:
      /*
       * Forward short message
       */
      MTU_forward_sm(dlg_id, dlg->invoke_id);
      break;
  }

  /*
   * Now send MAP-DELIMITER-REQ to indicate that no more requests will be sent
   * (for now).
   */
  req.type = MAPDT_DELIMITER_REQ;
  memset((void *)req.pi, 0, PI_BYTES);
  
  if(mtu_args.qos_present)
  {
    req.qos = mtu_args.qos;
    req.qos_size = mtu_args.qos_size;
    bit_set(req.pi, MAPPN_qos);
  }
  
  MTU_send_dlg_req(&req);

  /*
   * Set state to wait for the MAP-OPEN-CNF which indicates whether or not
   * the dialogue has been accepted.
   */
  dlg->state = MTU_WAIT_OPEN_CNF;

  return(0);
} /* end of MTU_open_dlg() */

/*
 * MTU_send_imsi sends the Send IMSI service primitive request.
 *
 * Always returns zero.
 */
static int MTU_send_imsi(dlg_id, invoke_id)
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_MSG req;          /* structured form of request message */
  int i,j;              /* loop counters */

  /*
   * The following parameters are set in the MAP-SEND-IMSI-Req:
   *    msisdn - contains the mobile subscriber's ISDN number
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_SEND_IMSI_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /*
   * MSISDN
   */

  bit_set(req.pi, MAPPN_msisdn);

  if (strlen(mtu_args.msisdn) != 0)
  {
    /*
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.msisdn.noa = 2;
    req.msisdn.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the MSISDN in ascii form and pack it into the data
     * buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.msisdn[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.msisdn.digits[i] = hextobin(mtu_args.msisdn[j]);
      if (mtu_args.msisdn[++j] != '\0')
      {
        req.msisdn.digits[i++] |= (hextobin(mtu_args.msisdn[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.msisdn.digits[i++] |= 0xf0;
        break;
      }
    }

    req.msisdn.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default MSISDN
     * into the message structure.
     */
    req.msisdn = DEFAULT_MSISDN;
  }

  /*
   * Operation timeout - 15 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 15;

  MTU_send_srv_req(&req);

  return(0);
} /* end of MTU_send_imsi() */

/*
 * MTU_sri_gprs sends the Send Routing Info for GPRS service request.
 *
 * Always returns zero.
 */
static int MTU_sri_gprs(dlg_id, invoke_id)
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_DLG *dlg;         /* dialogue data structure */
  MTU_MSG req;          /* structured form of request message */
  int i,j;              /* loop counters */

  dlg = MTU_get_dlg_data(dlg_id);

  /*
   * The following parameters are set in the
   * MAP-SEND-ROUTING-INFO-FOR-GPRS-Req:
   *    IMSI - International Mobile Subscriber Identity
   *    GGSN number - Gateway GPRS Support Node number
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_SND_RTIGPRS_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /*
   * Copy the IMSI. If one is present in dialogue data (because it was
   * requested by a previous dialogue) use that. Otherwise use the IMSI
   * provided on command line converting from ASCII to hex and packing
   * into BCD format. The last digit is set to 'f' if there is an odd
   * number of digits.
   */
  bit_set(req.pi, MAPPN_imsi);

  i = 0;
  j = 0;

  if (dlg->imsi.num_bytes > 0)
    req.imsi = dlg->imsi;
  else
  {
    while ((mtu_args.imsi[j] != '\0') && (i < MAX_BCDSTR_LEN))
    {
      req.imsi.data[i] = hextobin(mtu_args.imsi[j]);

      if (mtu_args.imsi[++j] != '\0')
      {
        req.imsi.data[i++] |= (hextobin(mtu_args.imsi[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.imsi.data[i++] |= 0xf0;
        break;
      }
    }
    req.imsi.num_bytes = i;
  }


  /*
   * GGSN number
   */

  bit_set(req.pi, MAPPN_ggsn_number);

  if (strlen(mtu_args.ggsn_number) != 0)
  {
    /*
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.ggsn_num.noa = 2;
    req.ggsn_num.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the MSISDN in ascii form and pack it into the data
     * buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.ggsn_number[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.ggsn_num.digits[i] = hextobin(mtu_args.ggsn_number[j]);
      if (mtu_args.ggsn_number[++j] != '\0')
      {
        req.ggsn_num.digits[i++] |= (hextobin(mtu_args.ggsn_number[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.ggsn_num.digits[i++] |= 0xf0;
        break;
      }
    }

    req.ggsn_num.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default MSISDN
     * into the message structure.
     */
    req.ggsn_num = DEFAULT_GGSN_NUMBER;
  }


  /*
   * Operation timeout - 15 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 15;

  MTU_send_srv_req(&req);

  return(0);
} /* end of MTU_sri_gprs() */

/*
 * MTU_forward_sm sends the Forward Short Message service request.
 *
 * Always returns zero.
 */
static int MTU_forward_sm(dlg_id, invoke_id)
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_MSG req;         /* structured form of request message */
  int i,j;              /* loop counters */
  u8 da_len;           /* length of formatted u-data */
  u8 num_da_chars;     /* number of formatted*/
  u8 num_semi_oct;     /* number of encoded useful semi-octets */

  /*
   * The following parameters are set in the MAP-FORWARD-SHORT-MESSAGE-Req:
   *    sm_rp_da - contains the international mobile subscriber id entered on
   *               the command line
   *    sm_rp_oa - contains the service centre address (defaulted)
   *    sm_rp_ui - contains the short message entered on the command line
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_FWD_SM_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /*
   * Copy the IMSI, converting from ASCII to hex and packing into BCD format.
   */
  bit_set(req.pi, MAPPN_sm_rp_da);
  req.sm_rp_da.data[0] = 0;     /* indicates IMSI */
  i = 2;
  j = 0;

  /*
   * Take the destination address in ascii form and pack it into
   * the data buffer in BCD form, packing the last octet if needed.
   */
  while ((mtu_args.imsi[j] != '\0') && (i < MAX_BCDSTR_LEN))
  {
    req.sm_rp_da.data[i] = hextobin(mtu_args.imsi[j]);

    if (mtu_args.imsi[++j] != '\0')
    {
      req.sm_rp_da.data[i++] |= (hextobin(mtu_args.imsi[j])) << 4;
      j++;
    }
    else
    {
      /*
       * pack the spare 4 bits with 1111
       */
      req.sm_rp_da.data[i++] |= 0xf0;
      break;
    }
  }

  /*
   * number of bytes of imsi
   */
  req.sm_rp_da.data[1] = i - 2;

  req.sm_rp_da.num_bytes = i;


  /*
   * SM-RP-OA 2-12oct
   */
  bit_set(req.pi, MAPPN_sm_rp_oa);

  if (strlen(mtu_args.service_centre) != 0)
  {
    /*
     * toa, type of address = service centre address
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.sm_rp_oa.toa = 4;
    req.sm_rp_oa.noa = 2;
    req.sm_rp_oa.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the originating address in ascii form and pack it into
     * the data buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.service_centre[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.sm_rp_oa.digits[i] = hextobin(mtu_args.service_centre[j]);
      if (mtu_args.service_centre[++j] != '\0')
      {
        req.sm_rp_oa.digits[i++] |= (hextobin(mtu_args.service_centre[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.sm_rp_oa.digits[i++] |= 0xf0;
        break;
      }
    }

    req.sm_rp_oa.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default service centre
     * address into the message structure.
     */
    req.sm_rp_oa = DEFAULT_SC_ADDR;
  }

  /*
   * SM-RP-UI Signal info
   */

  bit_set(req.pi, MAPPN_sm_rp_ui);

  /*
   * TP-MTI (SMS-DELIVER = 0x00)
   * TP-MMS (no more msgs = 0x1)
   * 2 reserved bits
   * TP-SRI (optional=yes)
   * TP-UDHI (optional=no)
   * TP-RP (reply path not set)
   */
  
  req.sm_rp_ui.data[0]=0; /* clear it first */

  bits_to_byte(req.sm_rp_ui.data, 0x00, 0, 2); 
  bit_to_byte(req.sm_rp_ui.data, 0x1, 2);
  /* bit 3 reserved */
  /* bit 4 reserved */
  bit_to_byte(req.sm_rp_ui.data, 0x1, 5);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 6); 
  bit_to_byte(req.sm_rp_ui.data, 0x0, 7);
  
  req.sm_rp_ui.num_bytes = 1;

  /*
   * TP-OA (get values from the SM-RP-OA, format is slightly different)
   *
   * Sub-fields:
   *   Address length in number of useful semi-octets (1 octet)
   *     (twice the number of octets minus one if a filler is used)
   *
   *   Type of address (1 octet)
   *     (NPI bits 0-3, Type of number bits 4-6, 
   *      Bit 7 - set for no extension)
   *
   *   Address Value (req.sm_rp_oa.num_dig_bytes octets)
   *     (same format as in SM-RP-OA)
   *
   */
  if (req.sm_rp_oa.digits[req.sm_rp_ui.num_bytes - 1] & 0xf0)
    num_semi_oct = (req.sm_rp_oa.num_dig_bytes * 2) - 1;
  else
    num_semi_oct = (req.sm_rp_oa.num_dig_bytes * 2);

  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = (u8)num_semi_oct;
  
  bits_to_byte(&req.sm_rp_ui.data[req.sm_rp_ui.num_bytes], req.sm_rp_oa.npi, 0, 4);
  bits_to_byte(&req.sm_rp_ui.data[req.sm_rp_ui.num_bytes], (0x8 | req.sm_rp_oa.toa), 4, 4);
  req.sm_rp_ui.num_bytes++;

  for (i=0; i<req.sm_rp_oa.num_dig_bytes; i++)
    req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = req.sm_rp_oa.digits[i];

  /*
   * TP-PID (=voice telephone)
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = 0x04;

  /*
   * TP-DCS (= default alphabet)
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = 0x00;

  /*
   * TP-SCTS always 7octs
   */
  MTU_get_scts(&req.sm_rp_ui.data[req.sm_rp_ui.num_bytes]);

  req.sm_rp_ui.num_bytes +=8; /* 7 octets for the TP-SCTS and 1 for the TP-UDL*/

  /*
   *TP-UDL, TP-UD
   */
  num_da_chars = MTU_str_to_def_alph(mtu_args.message,
                                     &req.sm_rp_ui.data[req.sm_rp_ui.num_bytes],
                                     &da_len,
                                     MAX_DATA_LEN - req.sm_rp_ui.num_bytes);
  /*
   * fill in the TP-UDL, the number of formated default alphabet characters
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes - 1] = (u8)num_da_chars;

  req.sm_rp_ui.num_bytes += da_len;

  /*
   * Operation timeout - 60 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 60;

  MTU_send_srv_req(&req);

  return(0);
} /* end of MTU_forward_sm() */

/*
 * MTU_MT_forward_sm sends the Forward Short Message service request.
 *
 * Always returns zero.
 */
static int MTU_MT_forward_sm(dlg_id, invoke_id)
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_MSG req;         /* structured form of request message */
  int i,j;              /* loop counters */
  u8 da_len;           /* length of formatted u-data */
  u8 num_da_chars;     /* number of formatted*/
  u8 num_semi_oct;     /* number of encoded useful semi-octets */

  /*
   * The following parameters are set in the MAP-MT-FORWARD-SHORT-MESSAGE-Req:
   *    sm_rp_da - contains the international mobile subscriber id entered on
   *               the command line
   *    sm_rp_oa - contains the service centre address (defaulted)
   *    sm_rp_ui - contains the short message entered on the command line
   *    optional - 'More Messages To Send' (MAPPN_more_msgs)
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_MT_FWD_SM_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /*
   * Copy the IMSI, converting from ASCII to hex and packing into BCD format.
   */
  bit_set(req.pi, MAPPN_sm_rp_da);
  req.sm_rp_da.data[0] = 0;     /* indicates IMSI */
  i = 2;
  j = 0;

  /*
   * Take the destination address in ascii form and pack it into
   * the data buffer in BCD form, packing the last octet if needed.
   */
  while ((mtu_args.imsi[j] != '\0') && (i < MAX_BCDSTR_LEN))
  {
    req.sm_rp_da.data[i] = hextobin(mtu_args.imsi[j]);

    if (mtu_args.imsi[++j] != '\0')
    {
      req.sm_rp_da.data[i++] |= (hextobin(mtu_args.imsi[j])) << 4;
      j++;
    }
    else
    {
      /*
       * pack the spare 4 bits with 1111
       */
      req.sm_rp_da.data[i++] |= 0xf0;
      break;
    }
  }

  /*
   * number of bytes of imsi
   */
  req.sm_rp_da.data[1] = i - 2;

  req.sm_rp_da.num_bytes = i;


  /*
   * SM-RP-OA 2-12oct
   */
  bit_set(req.pi, MAPPN_sm_rp_oa);

  if (strlen(mtu_args.service_centre) != 0)
  {
    /*
     * toa, type of address = service centre address
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.sm_rp_oa.toa = 4;
    req.sm_rp_oa.noa = 2;
    req.sm_rp_oa.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the originating address in ascii form and pack it into
     * the data buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.service_centre[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.sm_rp_oa.digits[i] = hextobin(mtu_args.service_centre[j]);
      if (mtu_args.service_centre[++j] != '\0')
      {
        req.sm_rp_oa.digits[i++] |= (hextobin(mtu_args.service_centre[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.sm_rp_oa.digits[i++] |= 0xf0;
        break;
      }
    }

    req.sm_rp_oa.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default service centre
     * address into the message structure.
     */
    req.sm_rp_oa = DEFAULT_SC_ADDR;
  }

  /*
   * SM-RP-UI Signal info
   */

  bit_set(req.pi, MAPPN_sm_rp_ui);

  /*
   * TP-MTI (SMS-DELIVER)
   * TP-MMS (no more msgs to send= 0x1)
   * TP-RP (reply path not set)
   * TP-UDHI (optional=no)
   * TP-SRI (optional=yes)
   * 2 reserved bits
   */

  bit_to_byte(req.sm_rp_ui.data, 0x0, 0);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 1);
  bit_to_byte(req.sm_rp_ui.data, 0x1, 2);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 3);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 4);
  bit_to_byte(req.sm_rp_ui.data, 0x1, 5);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 6);
  bit_to_byte(req.sm_rp_ui.data, 0x0, 7);
   
  req.sm_rp_ui.num_bytes = 1;

  /*
   * TP-OA (get values from the SM-RP-OA, format is slightly different)
   *
   * Sub-fields:
   *   Address length in number of useful semi-octets (1 octet)
   *     (twice the number of octets minus one if a filler is used)
   *
   *   Type of address (1 octet)
   *     (same format as in SM-RP-OA)
   *
   *   Address Value (req.sm_rp_oa.num_dig_bytes octets)
   *     (same format as in SM-RP-OA)
   *
   */
  if (req.sm_rp_oa.digits[req.sm_rp_ui.num_bytes - 1] & 0xf0)
    num_semi_oct = (req.sm_rp_oa.num_dig_bytes * 2) - 1;
  else
    num_semi_oct = (req.sm_rp_oa.num_dig_bytes * 2);

  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = (u8)num_semi_oct;
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = req.sm_rp_oa.toa;

  for (i=0; i<req.sm_rp_oa.num_dig_bytes; i++)
    req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = req.sm_rp_oa.digits[i];

  /*
   * TP-PID (=voice telephone)
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = 0x04;

  /*
   * TP-DCS (= default alphabet)
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes++] = 0x00;

  /*
   * TP-SCTS always 7octs
   */
  MTU_get_scts(&req.sm_rp_ui.data[req.sm_rp_ui.num_bytes]);

  req.sm_rp_ui.num_bytes +=8; /* 7 octets for the TP-SCTS and 1 for the TP-UDL*/

  /*
   *TP-UDL, TP-UD
   */
  num_da_chars = MTU_str_to_def_alph(mtu_args.message,
                                     &req.sm_rp_ui.data[req.sm_rp_ui.num_bytes],
                                     &da_len,
                                     MAX_DATA_LEN - req.sm_rp_ui.num_bytes);
  /*
   * fill in the TP-UDL, the number of formated default alphabet characters
   */
  req.sm_rp_ui.data[req.sm_rp_ui.num_bytes - 1] = (u8)num_da_chars;

  req.sm_rp_ui.num_bytes += da_len;

  /* 
   * send 'More Messages To Send' optional parm
   */
  bit_set(req.pi, MAPPN_more_msgs);
  req.more_msgs = 1; 

  /* 
   * timeout 
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 60;

  MTU_send_srv_req(&req);

  return(0);
} /* end of MTU_MT_forward_sm() */

/*
 * MTU_sri_sm sends the Send Routing Info for Short Message service request.
 *
 * Always returns zero.
 */
static int MTU_sri_sm(dlg_id, invoke_id)
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_DLG *dlg;         /* dialogue data structure */
  MTU_MSG req;          /* structured form of request message */
  int i,j;              /* loop counters */

  dlg = MTU_get_dlg_data(dlg_id);

  /*
   * The following parameters are set in the
   * MAP-SEND-ROUTING-INFO-FOR-SM-Req:
   *    MSISDN - Mobile Subscriber ISDN
   *    SM-RP-PRI - whether or not delivery of the short message 
   *                shall be attempted when a service centre address is 
   *                already contained in the Message Waiting Data file
   *    Service Centre Address - address of a Short Message Service Centre
   */
   
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_SND_RTISM_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /*
   * MSISDN
   */
  bit_set(req.pi, MAPPN_msisdn);

  if (strlen(mtu_args.msisdn) != 0)
  {
    /*
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.msisdn.noa = 2;
    req.msisdn.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the MSISDN in ascii form and pack it into the data
     * buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.msisdn[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.msisdn.digits[i] = hextobin(mtu_args.msisdn[j]);
      if (mtu_args.msisdn[++j] != '\0')
      {
        req.msisdn.digits[i++] |= (hextobin(mtu_args.msisdn[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.msisdn.digits[i++] |= 0xf0;
        break;
      }
    }

    req.msisdn.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default MSISDN
     * into the message structure.
     */
    req.msisdn = DEFAULT_MSISDN;
  }

  /*
   * SM-RP-PRI
   */
  bit_set(req.pi, MAPPN_sm_rp_pri);
  req.sm_rp_pri = 1;

  /*
   * Service Centre Address 2-12oct
   */
  bit_set(req.pi, MAPPN_sc_addr);

  if (strlen(mtu_args.service_centre) != 0)
  {
    /*
     * noa, nature of address = national significant number
     * npi, numbering plan indicator = ISDN/telephony numbering plan
     */
    req.sc_addr.noa = 2;
    req.sc_addr.npi = 1;

    i = 0;
    j = 0;

    /*
     * Take the originating address in ascii form and pack it into
     * the data buffer in BCD form, packing the last octet if needed.
     */
    while ((mtu_args.service_centre[j] != '\0') && (i < MAX_ADDSTR_LEN))
    {
      req.sc_addr.digits[i] = hextobin(mtu_args.service_centre[j]);
      if (mtu_args.service_centre[++j] != '\0')
      {
        req.sc_addr.digits[i++] |= (hextobin(mtu_args.service_centre[j])) << 4;
        j++;
      }
      else
      {
        /*
         * pack the spare 4 bits with 1111
         */
        req.sc_addr.digits[i++] |= 0xf0;
        break;
      }
    }

    req.sc_addr.num_dig_bytes = i;
  }
  else
  {
    /*
     * No address given at command line so copy the default service centre
     * address into the message structure.
     */
    req.sc_addr = DEFAULT_MSISDN;
  }

  /*
   * Operation timeout - 15 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 15;

  MTU_send_srv_req(&req);

  return(0);
           
} /* end of MTU_sri_sm() */

/* MTU_Send_UnstructuredSSRequestRSP
 * Formats and sends an UnstructuredSS-RequestRSP message
 * in response to a received ProcessUnstructuredSS-Request.
 *
 *   MAP-OPEN-RSP
 *   service primitive 'UnstructuredSSRequestRSP'
 *   MAP-DELIMITER-REQ
 *
 */
 static int MTU_Send_UnstructuredSSRequestRSP(dlg_id, invoke_id)
  u16 dlg_id;          /* Dialogue id */
  u8  invoke_id;       /* Invoke_id */
{
  MTU_DLG *dlg;         /* dialogue data structure */
  MTU_MSG req;          /* structured form of request message */
  u8 da_len;           /* length of formatted u-data */
  u8 num_da_chars;     /* number of formatted*/
  /*
   *  Get the dialogue information associated with the dlg_id
   */
  dlg = MTU_get_dlg_data(dlg_id);
  
  /*
   * The following parameters are set in the
   * MTU_Send_UnstructuredSSRequestRSP:
   *    ussd-DataCodingScheme
   *    ussd-string - this will be entered by the user e.g. *88#
   */
   
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_UNSTR_SS_REQ_RSP;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /* 
   * USSD coding parameter 
   */ 
  bit_set(req.pi, MAPPN_USSD_coding);

  /*
  * USSD coding set to 'GSM default alphabet' 00001111
  * see GSM 03.38 'Cell Broadcast Data Coding Scheme'
  * for further detail
  */
  bit_to_byte(req.ussd_coding.data, 0x1, 0);
  bit_to_byte(req.ussd_coding.data, 0x1, 1);
  bit_to_byte(req.ussd_coding.data, 0x1, 2);
  bit_to_byte(req.ussd_coding.data, 0x1, 3);
  bit_to_byte(req.ussd_coding.data, 0x0, 4);
  bit_to_byte(req.ussd_coding.data, 0x0, 5);
  bit_to_byte(req.ussd_coding.data, 0x0, 6);
  bit_to_byte(req.ussd_coding.data, 0x0, 7);
 
  req.ussd_coding.num_bytes = 1;

  /* USSD string parameter */ 
  bit_set(req.pi, MAPPN_USSD_string);  

  /*
   * USSD string 
   */
  /* 
   * Use the following line to check USSD string formatting ..
   * mtu_args.message="XY Telecom\n 1. Balance\n 2. Texts Remaining";   
   */ 
  
  req.ussd_string.num_bytes = 1; /* USSD string, allow byte for data length */

  num_da_chars = MTU_USSD_str_to_def_alph(mtu_args.message,
                                     &req.ussd_string.data[req.ussd_string.num_bytes],
                                     &da_len, 
                                     MAX_DATA_LEN - req.ussd_string.num_bytes);
  /*
   * fill in the ussd_string, the number of formated default alphabet characters
   */
  req.ussd_string.data[req.ussd_string.num_bytes - 1] = num_da_chars;   
  
  req.ussd_string.num_bytes += da_len; 

  /*
   * Operation timeout - 15 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 15;

  MTU_send_srv_req(&req);

  req.type = MAPDT_DELIMITER_REQ;
  memset((void *)req.pi, 0, PI_BYTES);
  
  if(mtu_args.qos_present)
  {
    req.qos = mtu_args.qos;
    req.qos_size = mtu_args.qos_size;
    bit_set(req.pi, MAPPN_qos);
  }

  MTU_send_dlg_req(&req);
  return(0);
           
} /* end of MTU_process_uss_rsp() */

/*
 * MTU_process_uss_req sends the Process USS service request.
 *
 * Always returns zero.
 */
static int MTU_process_uss_req (dlg_id, invoke_id)   /* USSD */ 
  u16 dlg_id;           /* dialogue ID */
  u8 invoke_id;        /* invoke ID */
{
  MTU_DLG *dlg;         /* dialogue data structure */
  MTU_MSG req;          /* structured form of request message */
  u8 da_len;           /* length of formatted u-data */
  u8 num_da_chars;     /* number of formatted*/
  
  dlg = MTU_get_dlg_data(dlg_id);

  /*
   * The following parameters are set in the
   * MAP-ProcessUnstructuredSS-Request:
   *    ussd-DataCodingScheme
   *    ussd-string - this will be entered by the user e.g. *55#
   */
   
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = MAPST_PRO_UNSTR_SS_REQ_REQ;
  req.invoke_id = invoke_id;
  bit_set(req.pi, MAPPN_invoke_id);

  /* USSD coding parameter */ 
  bit_set(req.pi, MAPPN_USSD_coding);

  /*
  * USSD coding set to 'GSM default alphabet' 00001111
  * see GSM 03.38 'Cell Broadcast Data Coding Scheme'
  * for further detail
  */

  bit_to_byte(req.ussd_coding.data, 0x1, 0);
  bit_to_byte(req.ussd_coding.data, 0x1, 1);
  bit_to_byte(req.ussd_coding.data, 0x1, 2);
  bit_to_byte(req.ussd_coding.data, 0x1, 3);
  bit_to_byte(req.ussd_coding.data, 0x0, 4);
  bit_to_byte(req.ussd_coding.data, 0x0, 5);
  bit_to_byte(req.ussd_coding.data, 0x0, 6);
  bit_to_byte(req.ussd_coding.data, 0x0, 7);
 
  req.ussd_coding.num_bytes = 1;

  /* 
   * USSD string parameter 
   */ 
  bit_set(req.pi, MAPPN_USSD_string);  

  /*
   * USSD string 
   */
  req.ussd_string.num_bytes = 1; /* USSD string, allow byte for data length */

  num_da_chars = MTU_USSD_str_to_def_alph(mtu_args.ussd_string,
                                     &req.ussd_string.data[req.ussd_string.num_bytes],
                                     &da_len, 
                                     MAX_DATA_LEN - req.ussd_string.num_bytes);
  /*
   * fill in the ussd_string, the number of formated default alphabet characters
   */
  req.ussd_string.data[req.ussd_string.num_bytes - 1] = num_da_chars;   
  
  req.ussd_string.num_bytes += da_len;

  /*
   * Operation timeout - 15 seconds
   */
  bit_set(req.pi, MAPPN_timeout);
  req.timeout = 15;

  MTU_send_srv_req(&req);

  return(0);
           
} /* end of MTU_process_uss_req() */



/*
 * MTU_smac is Short Message Service state machine. It is entered after the
 * dialogue with the servicing MSC has been opened and the short message has
 * been forwarded.
 *
 * Always returns zero.
 */
static int MTU_smac(m)
  MSG *m;       /* received message */
{
  MTU_MSG ind;          /* structured form of received message */
  MTU_DLG *dlg;         /* dialogue data structure */

  /*
   * Recover the parameters from the MSG into a 'C' structure
   */
  if (MTU_msg_to_ind(&ind, m) != 0)
  {
    MTU_disp_err("Primitive indication recovery failure");
  }
  else
  {
    if ((ind.dlg_id < mtu_args.base_dlg_id) || 
        (ind.dlg_id >= (mtu_args.base_dlg_id + mtu_args.num_dlg_ids)))
    {
      MTU_disp_err_val("Unexpected dialogue ID=0x", ind.dlg_id);
    }
    else
    {
      dlg = MTU_get_dlg_data(ind.dlg_id);

      /*
       * Handle the event according to the current state.
       */
      switch (dlg->state)
      {
        case MTU_WAIT_OPEN_CNF:
          MTU_wait_open_cnf(&ind, dlg);
          break;

        case MTU_WAIT_SERV_CNF:
          MTU_wait_serv_cnf(&ind, dlg);
          break;

        case MTU_WAIT_CLOSE_IND:
          MTU_wait_close_ind(&ind, dlg);
          break;

        case MTU_IDLE:
        default:
          MTU_disp_err("Message received for inactive dialogue");
          break;
      }
    }
  }
  return(0);
} /* end of MTU_smac() */

/*
 * MTU_wait_open_cnf handles messages received in the waiting for open
 * confirmation state.
 *
 * Always returns zero.
 */
static int MTU_wait_open_cnf(msg, dlg)
  MTU_MSG *msg;         /* received message */
  MTU_DLG *dlg;         /* dialogue data structure */
{
  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case MAPDT_U_ABORT_IND:
      case MAPDT_P_ABORT_IND:
        /*
         * Dialogue aborted. Release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (msg->type == MAPDT_U_ABORT_IND)
        {
          if (bit_test(msg->pi, MAPPN_user_rsn))
            MTU_disp_err_val("MAP-U-ABORT-Ind received with user reason = ",
                              msg->user_reason);
          else
            MTU_disp_err("MAP-U-ABORT-Ind received");
        }
        else
        {
          if (bit_test(msg->pi, MAPPN_prov_rsn))
            MTU_disp_err_val("MAP-P-ABORT-Ind received with provider reason = ",
                             msg->prov_reason);
          else
            MTU_disp_err("MAP-P-ABORT-Ind received");
        }
        MTU_release_invoke_id(dlg->invoke_id, dlg);
        MTU_release_dlg_id(msg->dlg_id);
        finished = 1;
        break;

      case MAPDT_OPEN_CNF:
        if (msg->result == MAPRS_DLG_ACC)
        {
          /*
           * Dialogue has been accepted. Change state to wait for the
           * MAP-FORWARD-SHORT-MESSAGE-Cnf which indicates whether or
           * not the short message was delivered successfully.
           */
          dlg->state = MTU_WAIT_SERV_CNF;
        }
        else
        {
          /*
           * Report the error, release the invoke ID, release the dialogue ID,
           * and idle the state machine.
           */
          if (bit_test(msg->pi, MAPPN_refuse_rsn))
            MTU_disp_err_val("dialogue refused with reason: %x ",
                             msg->refuse_reason);
          else
            MTU_disp_err("dialogue refused");
          MTU_release_invoke_id(dlg->invoke_id, dlg);
          MTU_release_dlg_id(msg->dlg_id);
          finished = 1;
        }
        break;

      default:
        MTU_disp_err_val("Unexpected dialogue primitive received: ",msg->type);
        break;
    }
  }
  else
  {
      MTU_disp_err_val("Unexpected service primitive received: ", msg->type);
  }

  return(0);
} /* end of MTU_wait_open_cnf() */

/*
 * MTU_wait_serv_cnf handles messages received in the wait for mobile
 * terminated MTU confirmation state.
 *
 * Always returns zero.
 */
static int MTU_wait_serv_cnf(msg, dlg)
  MTU_MSG *msg;         /* received message */
  MTU_DLG *dlg;         /* dialogue data structure */
{
  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case MAPDT_U_ABORT_IND:
      case MAPDT_P_ABORT_IND:
        /*
         * Dialogue aborted. Release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (msg->type == MAPDT_U_ABORT_IND)
        {
          if (bit_test(msg->pi, MAPPN_user_rsn))
            MTU_disp_err_val("MAP-U-ABORT-Ind received with user reason = ",
                             msg->user_reason);
          else
            MTU_disp_err("MAP-U-ABORT-Ind received");
        }
        else
        {
          if (bit_test(msg->pi, MAPPN_prov_rsn))
            MTU_disp_err_val("MAP-P-ABORT-Ind received with provider reason = ",
                             msg->prov_reason);
          else
            MTU_disp_err("MAP-P-ABORT-Ind received");
        }
        MTU_release_invoke_id(dlg->invoke_id, dlg);
        MTU_release_dlg_id(msg->dlg_id);
        finished = 1;
        break;

      case MAPDT_NOTICE_IND:
        /*
         * MAP-NOTICE-IND indicates some kind of error. Close the dialogue
         * using MAP-U-ABORT-REQ, release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (bit_test(msg->pi, MAPPN_prob_diag))
          MTU_disp_err_val("MAP-NOTICE-Ind received with problem diagnostic = ",
                           msg->prob_diag);
        else
          MTU_disp_err("MAP-NOTICE-Ind received");


        /*
         * Send MAP-U_ABORT-Req containing the following parameters:
         *      release method
         */
        msg->type = MAPDT_U_ABORT_REQ;
        memset((void *)msg->pi, 0, PI_BYTES);

        bit_set(msg->pi, MAPPN_user_rsn);
        msg->user_reason = MAPUR_unspecified_reason;
        MTU_send_dlg_req(msg);

        MTU_release_invoke_id(dlg->invoke_id, dlg);
        MTU_release_dlg_id(msg->dlg_id);
        finished = 1;
        break;
      case MAPDT_DELIMITER_IND:
        /* 
         * USSD response - once the delimiter is received we can send the UnstructuredSSRequestRSP message 
         */ 
        MTU_Send_UnstructuredSSRequestRSP (msg->dlg_id, dlg->invoke_id);
        break;
    default:
        MTU_disp_err_val("Unexpected dialogue primitive received: ", msg->type);
        break;
    }
  }
  else
  {
    /*
     * Check that this message is related to the current invocation.
     */
    if (msg->invoke_id == dlg->invoke_id)
    {
      switch (msg->type)
      {
        case MAPST_FWD_SM_CNF:
        case MAPST_SEND_IMSI_CNF:
        case MAPST_SND_RTIGPRS_CNF:
        case MAPST_MT_FWD_SM_CNF:
        case MAPST_SND_RTISM_CNF:
        case MAPST_PRO_UNSTR_SS_REQ_CNF:
          /*
           * Confirmation to service request received. Release the invoke ID.
           */
          MTU_release_invoke_id(dlg->invoke_id, dlg);

          if (bit_test(msg->pi, MAPPN_prov_err))
          {
            /*
             * A provider error parameter is included indicating an error.
             * Send a MAP-U_ABORT-Req and release the dialogue ID.
             */
            MTU_disp_err("Service primitive cnf received with");
            MTU_disp_err_val("provider error = ", msg->prov_err);

            msg->type = MAPDT_U_ABORT_REQ;
            memset((void *)msg->pi, 0, PI_BYTES);

            bit_set(msg->pi, MAPPN_user_rsn);
            msg->user_reason = MAPUR_unspecified_reason;
            MTU_send_dlg_req(msg);

            MTU_release_dlg_id(msg->dlg_id);
            finished = 1;
          }
          else
          {
            if (bit_test(msg->pi, MAPPN_user_err))
            {
              MTU_disp_err("Service primitive cnf received with");
              MTU_disp_err_val("user error = ", msg->user_err);
            }

            /*
             * If the IMSI is present, save it in case it is needed for a
             * subsequent dialogue.
             */
            if (bit_test(msg->pi, MAPPN_imsi))
              dlg->imsi = msg->imsi;

            dlg->state = MTU_WAIT_CLOSE_IND;
          }
          break;
        case MAPST_UNSTR_SS_REQ_IND:
          {
             dlg->state = MTU_WAIT_SERV_CNF;
          }
          break;
        default:
            MTU_disp_err_val("Unexpected service primitive received: ", msg->type);
          break;
      }
    }
    else
    {
      MTU_disp_err_val("Received service primitive with unexpected invoke ID: ",
                       msg->invoke_id);
    }
  }

  return(0);
} /* end of MTU_wait_serv_cnf() */

/*
 * MTU_wait_close_ind handles messages received in the wait for close indication
 * state.
 *
 * Always returns zero.
 */
static int MTU_wait_close_ind(msg, dlg)
  MTU_MSG *msg;         /* received message */
  MTU_DLG *dlg;         /* dialogue data structure */
{
  MTU_BCDSTR imsi;      /* IMSI */

  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case MAPDT_CLOSE_IND:
        /*
         * MAP-CLOSE-IND received.
         */

        /*
         * Save the IMSI if necessary for later use and then release the
         * dialogue ID and idle the state machine.
         */
        if (mtu_args.mode == MTU_SI_SRIGPRS)
          imsi = dlg->imsi;
        MTU_release_dlg_id(msg->dlg_id);

        /*
         * For the mode where Send IMSI and Send routing info
         * for GPRS are used alternately, and this dialogue used Send IMSI,
         * open a new dialogue using Send routing info for GPRS. Only do this
         * if the IMSI was received.
         */
        if ((mtu_args.mode == MTU_SI_SRIGPRS) &&
            (dlg->service == MTU_SEND_IMSI) &&
            (imsi.num_bytes > 0))
        {
          if (MTU_open_dlg(MTU_SRI_GPRS, &imsi) != 0)
            MTU_disp_err("Failed to open dialogue");
        }
        else
          finished = 1;
        break;

      case MAPDT_U_ABORT_IND:
      case MAPDT_P_ABORT_IND:
        /*
         * Dialogue aborted. Release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (msg->type == MAPDT_U_ABORT_IND)
        {
          if (bit_test(msg->pi, MAPPN_user_rsn))
            MTU_disp_err_val("MAP-U-ABORT-Ind received with user reason = ",
                             msg->user_reason);
          else
            MTU_disp_err("MAP-U-ABORT-Ind received");
        }
        else
        {
          if (bit_test(msg->pi, MAPPN_prov_rsn))
            MTU_disp_err_val("MAP-P-ABORT-Ind received with provider reason = ",
                             msg->prov_reason);
          else
            MTU_disp_err("MAP-P-ABORT-Ind received");
        }
        MTU_release_invoke_id(dlg->invoke_id, dlg);
        MTU_release_dlg_id(msg->dlg_id);
        finished = 1;
        break;

      default:
        MTU_disp_err_val("Unexpected dialogue primitive received: ", msg->type);
        break;
    }
  }
  else
  {
      MTU_disp_err_val("Unexpected service primitive received: ", msg->type);
  }

  return(0);
} /* end of MTU_wait_close_ind() */

/*
 * MTU_send_dlg_req allocates a message (using the
 * getm() function) then converts the primitive parameters
 * from the 'C' structured representation into the correct
 * format for passing to the MAP module.
 * The formatted message is then sent.
 *
 * Always returns zero.
 */
static int MTU_send_dlg_req(req)
  MTU_MSG  *req;        /* structured primitive request to send */
{
  MSG *m;               /* message sent to MAP */

  req->dlg_prim = 1;

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)MAP_MSG_DLG_REQ, req->dlg_id, NO_RESPONSE,
                                      MTU_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = mtu_args.mtu_mod_id;
    m->hdr.dst = mtu_args.mtu_map_id;

    /*
     * Format the parameter area of the message and
     * (if successful) send it
     */
    if (MTU_dlg_req_to_msg(m, req) != 0)
    {
      MTU_disp_err("failed to format dialogue primitive request");
      relm(&m->hdr);
    }
    else
    {
      if (mtu_args.options & MTU_TRACE_TX)
        MTU_display_sent_msg(m);

      /*
       * and send to the call processing module:
       */
      MTU_send_msg(m);
    }
  }
  return(0);
} /* end of MTU_send_dlg_req() */

/*
 * MTU_send_srv_req allocates a message (using the
 * getm() function) then converts the primitive parameters
 * from the 'C' structured representation into the correct
 * format for passing to the MAP module.
 * The formatted message is then sent.
 *
 * Always returns zero.
 */
static int MTU_send_srv_req(req)
  MTU_MSG  *req;        /* structured primitive request to send */
{
  MSG *m;               /* message sent to MAP */

  req->dlg_prim = 0;

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)MAP_MSG_SRV_REQ, req->dlg_id, NO_RESPONSE,
                                      MTU_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = mtu_args.mtu_mod_id;
    m->hdr.dst = mtu_args.mtu_map_id;

    /*
     * Format the parameter area of the message and
     * (if successful) send it
     */
    if (MTU_srv_req_to_msg(m, req) != 0)
    {
      MTU_disp_err("failed to format service primitive request");
      relm(&m->hdr);
    }
    else
    {
      if (mtu_args.options & MTU_TRACE_TX)
        MTU_display_sent_msg(m);
      /*
       * and send to the call processing module:
       */
      MTU_send_msg(m);
    }
  }
  return(0);
}

/*
 * MTU_alloc_dlg_id allocates a dialogue ID to be used when opening a dialogue.
 *
 * Returns zero if a dialogue ID was allocated.
 *         -1   if no dialogue ID could be allocated.
 */
static u16 MTU_alloc_dlg_id(dlg_id_ptr)
u16 *dlg_id_ptr;        /* updated to point to a free dialogue id */
{
  u16 i;                /* dialogue ID loop counter */
  int found;            /* has an idle dialogue been found? */

  found = 0;

  /*
   * Look for an idle dialogue id starting at mtu_dlg_id
   */
  for (i = mtu_dlg_id; i < (mtu_args.base_dlg_id + mtu_args.num_dlg_ids); i++)
  {
    if (dlg_data[i - mtu_args.base_dlg_id].state == MTU_IDLE)
    {
      found = 1;
      break;
    }
  }

  /*
   * If we haven't found one yet, start looking again, this time from the
   * base id.
   */
  if (found == 0)
  {
    for (i = mtu_args.base_dlg_id; i < mtu_dlg_id; i++)
    {
      if (dlg_data[i - mtu_args.base_dlg_id].state == MTU_IDLE)
      {
        found = 1;
        break;
      }
    }
  }

  if (found)
  {
    /*
     * Update the dialogue id to return and increment the active dialogue count
     */
    *dlg_id_ptr = i;
    mtu_active++;

    /*
     * Select the next dialogue id to start looking for an idle one.
     * If we've reached the end of the range then start from the base id.
     */
    if (mtu_dlg_id == (mtu_args.base_dlg_id + mtu_args.num_dlg_ids - 1))
      mtu_dlg_id = mtu_args.base_dlg_id;
    else
      mtu_dlg_id++;

    return (0);
  }
  else
  {
    /*
     * No idle dialogue id found
     */
    return (-1);
  }
} /* end of MTU_alloc_dlg_id() */

/*
 * MTU_get_dlg_data returns the dlg data structure.
 */
MTU_DLG *MTU_get_dlg_data(dlg_id)
   u16 dlg_id;
{
   return(&(dlg_data[dlg_id - mtu_args.base_dlg_id]));
}

/*
 * MTU_alloc_invoke_id allocates an invoke ID to be used for a MAP request.
 */
static u8 MTU_alloc_invoke_id()
{
  /*
   * This function always uses the same invoke ID (because only one invocation
   * can be in progress at one time in this example program). In a real
   * application this function would have to search for a free invoke ID and
   * allocate that.
   */
  return(DEFAULT_INVOKE_ID);
};

/*
 * MTU_release_dlg_id is used to release the dialogue ID at the end of the
 * dialogue so that it may be used for another dialogue.
 */
static void MTU_release_dlg_id(dlg_id)
  u16 dlg_id;           /* Dialogue id of dialogue being released */
{
  MTU_DLG *dlg;
  /*
   * Decrement the active count.
   */
  mtu_active--;

  dlg = MTU_get_dlg_data(dlg_id);

  /*
   * Set dialogue state to idle.
   */
  dlg->state = MTU_IDLE;

  /*
   * Clear any stored IMSI by setting the number of bytes to zero.
   */
  dlg->imsi.num_bytes = 0;

  return;
}

static void MTU_release_invoke_id(invoke_id, dlg)
  u8 invoke_id;         /* invoke ID */
  MTU_DLG *dlg;         /* dialogue data structure */
{
  /*
   * Since only one invoke ID is ever used, it is not necessary to release
   * it. In a real application, the invoke ID would have to be marked as
   * free in this function.
   */

  dlg->invoke_id = 0;

  return;
}

/*
 * MTU_send_msg sends a MSG. On failure the
 * message is released and the user notified.
 *
 * Always returns zero.
 */
static int MTU_send_msg(m)
  MSG   *m;             /* MSG to send */
{

  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    MTU_disp_err("*** failed to send message");
    relm((HDR *)m);
  }
  return(0);
} /* end of MTU_send_msg()*/

/*
 * MTU_disp_err
 *
 * Traces internal progress to the console.
 *
 * Always returns zero.
 */
int MTU_disp_err(text)
  char *text;   /* Text for tracing progress of program */
{
  if (mtu_args.options & MTU_TRACE_ERROR)
    fprintf(stderr, "MTU: *** %s ***\n", text);

  return(0);
}

/*
 * MTU_disp_err_val
 *
 * Traces internal progress to the console.
 *
 * Always returns zero.
 */
int MTU_disp_err_val(text, value)
  char *text;   /* Text for tracing progress of program */
  u16 value;    /* Value to be displayed */
{
  if (mtu_args.options & MTU_TRACE_ERROR)
    fprintf(stderr, "MTU: *** %s%04x ***\n", text, value);

  return(0);
}


