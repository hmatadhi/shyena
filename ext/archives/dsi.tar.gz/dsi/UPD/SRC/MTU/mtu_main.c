/*
                Copyright (C) Dialogic Corporation 1997-2015. All Rights Reserved.

 Name:          mtu_main.c

 Description:   Console command line interface to mtu.

 Functions:     main()

 -----  ---------   ---------------------------------------------
 Issue    Date                       Changes
 -----  ---------   ---------------------------------------------
   A    23-Sep-97  - Initial code.
   B    20-Mar-98  - Added version 1 functionality.
   C    13-Jan-99  - Added '-g' option for gateway MSC address
                           '-c' option for service centre address
   D    07-Jul-99  - Corrected problem where digits a-f could not be
                     included in the address parameters.
   1    16-Feb-00  - Removed build warnings.
   2    31-Jul-01  - Changed default module ID to be 0x2d.
   3    10-Aug-01  - Added support for Send-IMSI and Send routing info
                     for GPRS. Also ability to generate multiple
                     dialogues.
   4    20-Jan-06  - Include reference to Intel Corporation in file header
                     and fix default module ID issue
   5    13-Dec-06  - Change to use of Dialogic Corporation copyright.
   6    30-Sep-09  - Support for additional MAP services, e.g. USSD.
   7    25-Sep-14  - Network Context support   
   8    09-Dec-14  - Add control of adding extra dest digits.
        06-Feb-15  - Enable QOS (-q option) to be set to 0.
        30-Jun-15  - QOS can now have up to 2 additional octets
 */

#include "mtu.h"


static int read_command_line_params(int argc, char *argv[], int *arg_index);
static int read_option(char *arg);
static void show_syntax(void);

#define COMMAND_LINE_EXIT_REQ          (-1) /* Option requires immediate exit */
#define COMMAND_LINE_UNRECON_OPTION    (-2) /* Unrecognised option */
#define COMMAND_LINE_RANGE_ERR         (-3) /* Option value is out of range */

/*
 * Default values for MTU's command line options:
 */
#define DEFAULT_MODULE_ID       (0x2d)
#define DEFAULT_MAP_ID          (MAP_TASK_ID)
#define DEFAULT_OPTIONS         (0x000f)
#define DEFAULT_MAX_ACTIVE      (0)

/*
 * Structure that stores the data entered on the command line
 */
static CL_ARGS cl_args;

/*
 * Program name
 */
static char *program;


/*
 * Main function for MAP Test Utility (MTU):
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

  program = argv[0];

  cl_args.mtu_mod_id = DEFAULT_MODULE_ID;
  cl_args.mtu_map_id = DEFAULT_MAP_ID;
  cl_args.map_version = MTU_MAPV2; 
  cl_args.mode = MTU_FORWARD_SM;
  cl_args.nc = DEFAULT_NC;
  cl_args.qos = DEFAULT_QOS;
  cl_args.qos_present = DEFAULT_QOS_FLAG;
  cl_args.qos_size = 0;
  cl_args.options = DEFAULT_OPTIONS;
  cl_args.base_dlg_id = BASE_DLG_ID;
  cl_args.num_dlg_ids = NUM_OF_DLG_IDS;
  cl_args.max_active = DEFAULT_MAX_ACTIVE;
  cl_args.imsi = "";
  cl_args.orig_address = "";
  cl_args.service_centre = "";
  cl_args.dest_address = "";
  cl_args.dest_add_digits = 0;
  cl_args.message = "";
  cl_args.msisdn = "";
  cl_args.ggsn_number = "";
  cl_args.ussd_string = "";

  if ((cli_error = read_command_line_params(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case COMMAND_LINE_UNRECON_OPTION :
        fprintf(stderr, "%s: Unrecognised option : %s\n", program, argv[failed_arg]);
        show_syntax();
        break;

      case COMMAND_LINE_RANGE_ERR :
        fprintf(stderr, "%s: Parameter range error : %s\n", program, argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }

    exit(0);
  }

  /*
   * Check the command line arguments
   */
  if (strlen(cl_args.orig_address) == 0)
  {
    fprintf(stderr, "%s: -g option missing \n", program);
    show_syntax();
    exit(0);
  }

  if (strlen(cl_args.dest_address) == 0)
  {
    fprintf(stderr, "%s: -a option missing \n", program);
    show_syntax();
    exit(0);
  }
  
  if (cl_args.num_dlg_ids > NUM_OF_DLG_IDS)
  {
    fprintf(stderr, "%s: -n option, too many dialogue ids requested \n", program);
    show_syntax();
    exit(0);
  }

  if (cl_args.max_active > cl_args.num_dlg_ids)
  {
    fprintf(stderr, "%s: -x option, too many active dialogues requested \n", program);
    show_syntax();
    exit(0);
  }

  switch (cl_args.mode)
  {
    case MTU_SI_SRIGPRS:
    case MTU_SEND_IMSI:
          break;

    case MTU_SRI_GPRS:
      if (strlen(cl_args.imsi) == 0)
      {
        fprintf(stderr, "%s: -i option missing \n", program);
        show_syntax();
        exit(0);
      }
      break;

    case MTU_PROCESS_USS_REQ:
      if (strlen(cl_args.ussd_string) == 0)
      {
        fprintf(stderr, "%s: -U option missing \n", program);
        show_syntax();
        exit(0);
      }
          if (strlen(cl_args.message) == 0)
      {
        fprintf(stderr, "%s: -s option missing \n", program);
        show_syntax();
        exit(0);
      }
      break;

    
    case MTU_SRI_SM:
      if (strlen(cl_args.service_centre) == 0)
      {
        fprintf(stderr, "%s: -c option missing \n", program);
        show_syntax();
        exit(0);
      }
          if (strlen(cl_args.msisdn) == 0)
      {
        fprintf(stderr, "%s: -e option missing \n", program);
        show_syntax();
        exit(0);
      }
      break;

    case MTU_MT_FORWARD_SM:
    case MTU_FORWARD_SM:
    default:
      if (strlen(cl_args.imsi) == 0)
      {
        fprintf(stderr, "%s: -i option missing \n", program);
        show_syntax();
        exit(0);
      }

      if (strlen(cl_args.message) == 0)
      {
        fprintf(stderr, "%s: -s option missing \n", program);
        show_syntax();
        exit(0);
      }
      break;
  } /* end switch on cl_args.mode */

  mtu_ent(&cl_args);
  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr,
        "Syntax: %s -d<mode> [-m<mod> -u<map> -o<options> ", program);
  fprintf(stderr,
        "-b<base_did> -x<active> -n<num_dlg_ids> -c<sc> -p<phase> -s<message>");
  fprintf(stderr,
        "-i<imsi> -e<msisdn> -f<ggsn_num> -U<ussd> -A -q<qos> -w<nc>] -g<orig> -a<dest>\n");
  fprintf(stderr,
        "  -a  : destination address\n");
  fprintf(stderr,
        "  -A  : append and rotate destination address digits (000000 to 999999)\n");
  fprintf(stderr,
        "  -b  : base MAP dialogue id\n");
  fprintf(stderr,
        "  -c  : service centre address  (only valid for mode=0)\n");
  fprintf(stderr,
        "  -d  : mode of operation: 0 - Forward short message\n");
  fprintf(stderr,
        "                           1 - Send IMSI\n");
  fprintf(stderr,
        "                           2 - Send routing info for GPRS\n");
  fprintf(stderr,
        "                           3 - Send IMSI & Send routing info for GPRS\n");
  fprintf(stderr,
        "                           4 - Forward MT short message\n");
  fprintf(stderr,
        "                           5 - Send routing info for SM\n");
  fprintf(stderr,
        "                           6 - Send ProcessUnstructuredSS-Request\n");
  fprintf(stderr,
        "  -e  : MSISDN (only valid for mode=1 or 3)\n");
  fprintf(stderr,
        "  -f  : GGSN number (only valid for mode=2 or 3)\n");
  fprintf(stderr,
        "  -g  : originating address\n");
  fprintf(stderr,
        "  -i  : international mobile subscriber ID (mandatory for modes 0 and 2)\n");
  fprintf(stderr,
        "  -m  : mtu's module ID (default=0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,
        "  -n  : number of outgoing MAP dialogue ids\n");
  fprintf(stderr,
        "  -o  : Output display options (default=0x%04x)\n", DEFAULT_OPTIONS);
  fprintf(stderr,
        "  -p  : MAP phase (i.e. phase 1 or phase 2 - default=2; only valid for mode=0)\n");
  fprintf(stderr,
        "  -q  : MAP QoS: flags(bit0=return option, bit1=class) + 2 optional octets\n"); 
  fprintf(stderr,
        "  -s  : short message (only valid for mode=0)\n");
  fprintf(stderr,
        "  -U  : USSD String (e.g. *123*456789#)\n");
  fprintf(stderr,
        "  -u  : MAP module ID (default=0x%02x)\n", DEFAULT_MAP_ID);
  fprintf(stderr,
        "  -w  : MAP Network Context (default=0)\n");                      
  fprintf(stderr,
        "  -x  : number of active dialogues to maintain (default=%i, max=%i)\n",
        DEFAULT_MAX_ACTIVE, NUM_OF_DLG_IDS);
  fprintf(stderr,
        "Example: %s -d0 -m0xdf -u0x66 -p1 -g43010008 -a43020008", program);
  fprintf(stderr,
        " -i987654321 -s\"good morning\"\n");
}

/*
 * Read in command line options and set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_command_line_params(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32  temp_u32;

  if (arg[0] != '-')
    return(COMMAND_LINE_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
      show_syntax();
      return(COMMAND_LINE_EXIT_REQ);

    case 'd' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      switch (temp_u32)
      {
        case MTU_FORWARD_SM :
        case MTU_SEND_IMSI :
        case MTU_SRI_GPRS :
        case MTU_SI_SRIGPRS :
        case MTU_MT_FORWARD_SM :
        case MTU_SRI_SM :
        case MTU_PROCESS_USS_REQ :
          cl_args.mode = (u8)temp_u32;
          break;
        default:
          return(COMMAND_LINE_RANGE_ERR);
      }
      break;

    case 'm' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.mtu_mod_id = (u8)temp_u32;
      break;

    case 'u' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.mtu_map_id = (u8)temp_u32;
      break;

    case 'p' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      switch(temp_u32)
      {
        case MTU_MAPV1:
        case MTU_MAPV2:
          cl_args.map_version = (u8)temp_u32;
          break;
        default:
          return(COMMAND_LINE_RANGE_ERR);
      }
      break;

    case 'e' :
      cl_args.msisdn = &arg[2];
      break;

    case 'f' :
      cl_args.ggsn_number = &arg[2];
      break;

    case 'g' :
      cl_args.orig_address = &arg[2];
      break;

    case 'c' :
      cl_args.service_centre = &arg[2];
      break;

    case 'x' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.max_active = (u16)temp_u32;
      break;

    case 'b' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.base_dlg_id = (u16)temp_u32;
      break;

    case 'n' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.num_dlg_ids = (u16)temp_u32;
      break;

    case 'w' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.nc = (u8)(temp_u32 & 0xff);
      break;
           
    case 'q' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.qos = (u32)(temp_u32 & 0x00ffffff);
      cl_args.qos_present = TRUE;
      cl_args.qos_size = 1;
      if(cl_args.qos > 0xff)
        cl_args.qos_size = 2;
      if(cl_args.qos > 0xffff)
        cl_args.qos_size = 3;        
      break;        

    case 'o' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      cl_args.options = (u16)temp_u32;
      break;

    case 'a' :
      cl_args.dest_address = &arg[2];
      break;

    case 'A' :
      cl_args.dest_add_digits = 1;
      break;

    case 'i' :
      cl_args.imsi = &arg[2];
      break;

    case 's' :
      cl_args.message = &arg[2];
      break;

    case 'U' :
      cl_args.ussd_string = &arg[2];
      break;
  }
  return(0);
}
