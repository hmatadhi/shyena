/*
                Copyright (C) Dialogic Corporation 1999-2009. All Rights Reserved.

 Name:          istu.h

 Description:   Contains macro and structure definitions used in ISTU.

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    14-Apr-99   RBP   - Initial code.
   B    09-Sep-99   JET   - Added ability to send multiple short messages
                            using different dialogue ids.
   C    15-Feb-00   JET   - Support for setting number of active dialogues
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
                          - Remove interMSCcctid from ISTU_MSG struct.
   2    01-Dec-09   JLP   - Remove unused macro
        18-Mar-15   MH    - CN1598SSS- 'New parameters for MTU/ISTU cause failur'
                            Modify PI_BYTES structure to scale with new
                            IS41 parameters.

 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "system.h"     /* system type definitions (u8, u16 etc) */
#include "msg.h"        /* basic message type definitions (MSG etc) */
#include "sysgct.h"     /* prototypes for GCT_xxx functions */
#include "bit2byte.h"
#include "asciibin.h"
#include "strtonum.h"
#include "is41_inc.h"
#include "ss7_inc.h"

#define MAX_ADDR_LEN            (36)    /* Max length of SCCP address */
#define MAX_DATA_LEN            (100)   /* Max length of bearer data */
#define MAX_RSN_LEN             (101)   /* Max length of user reason str */
#define MAX_BCDSTR_LEN          (8)     /* Max size of BCD octet string */
#define MAX_ADDSTR_LEN          (8)     /* Max size used to store addr digits */
#define BASE_DLG_ID             (0x0)   /* Base IS-41 dialogue id */
#define NUM_OF_DLG_IDS          (0x400) /* Number of OG dialogue ids */
#define DEFAULT_DLG_RUN         (0x800) /* Total number of dialogues in test */
#define DEFAULT_INVOKE_ID       (1)     /* Invoke id to use in all invokes */
#define SRV_ID_LEN              (2)     /* SMS Teleservice Id Length */
#define CCT_ID_LEN              (2)     /* Circuit Id Length */
#define MOB_ID_LEN              (5)     /* Mobile Id Number Length in octets */
#define PI_BYTES                ((IS41PN_end/8)+1) /* Size of bit field param indicator */
#define MAX_PARAM_LEN           (320)   /* Max length of MSG param area */

#define SUCCESS                 (0)
#define FAIL                    (1)

/*
 * Display options
 */
#define ISTU_TRACE_TX           (0x0001)  /* Trace messages sent */
#define ISTU_TRACE_RX           (0x0002)  /* Trace messages received */
#define ISTU_TRACE_ERROR        (0x0004)  /* Trace errors */
#define ISTU_TRACE_BEARER_DATA  (0x0008)  /* Display received bearer data */
#define ISTU_TRACE_DISPLAY      (0x0010)  /* Trace progress of program */

/*
 * Maximum parameter length in an MSG:
 */
#define ISTU_MAX_PARAM_LEN      (320)

#define NO_RESPONSE             (0)

/*
 * Structure used for origination and destination addresses
 */
typedef struct
{
  u8 num_bytes;                 /* number of digits */
  u8 data[MAX_ADDR_LEN];        /* contains the digits */
} ISTU_ADDR;

/*
 * Structure used for parameters of format TBCD_STRING
 */
typedef struct
{
  u8 num_bytes;                 /* number of bytes of data */
  u8 data[MAX_BCDSTR_LEN];      /* contains the data */
} ISTU_BCDSTR;

/*
 * Structure used for parameters of format AddressString
 */
typedef struct
{
  u8 toa;                       /* type of address */
  u8 num_dig_bytes;             /* number of bytes of digits */
  u8 noa;                       /* nature of address */
  u8 npi;                       /* numbering plan indicator */
  u8 digits[MAX_ADDSTR_LEN];    /* contains the digits */
} ISTU_ADDSTR;

/*
 * Structure used for parameters of format SignalInfo
 */
typedef struct
{
  u8 num_bytes;                 /* number of digits in the string */
  u8 data[MAX_DATA_LEN];        /* contains the digits */
} ISTU_SIGINFO;


/*
 * Structure containing all command-line parameters
 */
typedef struct
{
  u8 istu_is41_id;              /* the module ID of the IS41 module */
  u8 istu_mod_id;               /* the module ID of this module */
  u16 base_dlg_id;              /* the base dlg id to use */
  u16 num_dlg_ids;              /* the number of dlg ids */
  u16 options;                  /* program display options */
  u16 max_active;               /* number of active dialogues to maintain */
  u32 sms_run;                  /* the number of sms messages to send */
  char *SMSteleserviceid;       /* SMS teleservice identity */
  char *interMSCcctid;          /* inter MSC circuit identity */
  char *mid;                   /* international mobile subscriber ID */
  char *hmsc_address;           /* home MSC - originating address */
  char *smsc_address;           /* servicing MSC - destination address */
  char *message;                /* short message */
} SH_MSG;

/*
 * Structure containing a dialogue message to be sent or received.
 */
typedef struct
{
  u8 pi[PI_BYTES];              /* Bit field indicating parameters present */
  u16 dlg_id;                   /* dialogue ID */
  u8 invoke_id;                 /* invoke ID */
  u8 type;                      /* primitive type */
  u8 dlg_prim;                  /* indicates this is a dialogue primitive */
  u8 release_method;            /* release method */
  u8 result;                    /* result */
  u8 refuse_reason;             /* refuse reason */
  u8 user_rsn_str[MAX_RSN_LEN]; /* user reason */
  u8 prov_reason;               /* provider reason */
  u8 prob_diag;                 /* problem diagnostic */
  u8 prov_err;                  /* provider error */
  u8 user_err;                  /* user error */
  ISTU_ADDR dest_address;       /* destination address */
  ISTU_ADDR orig_address;       /* origination address */
  u8 interMSCcctid[CCT_ID_LEN]; /* inter MSC circuit identity */
  u8 mobileidnum[MOB_ID_LEN];   /* mobile id number */
  u8 SMStelesrvid[SRV_ID_LEN];  /* SMS Teleservice Identity */
  ISTU_SIGINFO SMSbearerdata;   /* user information - contains the short message */
} ISTU_MSG;

/*
 * Dialogue data structure
 */
typedef struct
{
  u8 invoke_id;                 /* Invoke ID for single operation request */
  u8 state;                     /* state machine state */
} ISTU_DLG;


/*
 * Macro for message display procedures
 */
#define BIN2CH(b)               ((char)(((b)<10)?'0'+(b):'a'-10+(b)))


/*
 * Function prototypes
 */
#ifdef LINT_ARGS
int istu_ent(SH_MSG *sh_msg);
int ISTU_dlg_req_to_msg(MSG *m, ISTU_MSG *dlg_req);
int ISTU_msg_to_ind(ISTU_MSG *ind, MSG *m);
int ISTU_srv_req_to_msg(MSG *m, ISTU_MSG *srv_req);
#else
int istu_ent();
int ISTU_dlg_req_to_msg();
int ISTU_msg_to_ind();
int ISTU_srv_req_to_msg();
#endif


