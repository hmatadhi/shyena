/*
                Copyright (C) Dialogic Corporation 1999-2009. All Rights Reserved.

 Name:          istu.c

 Description:   Example application program for the
                Dialogic IS41 user interface.

                The application receives requests to send
                short messages and handles them in a manner
                designed to exercise the SMS functionality
                and illustrate the programming techniques
                involved.

 Functions:     main

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    14-Apr-99   RBP   - Initial code.
   B    09-Sep-99   JET   - Added ability to send multiple short messages
                            using different dialogue ids.
   C    15-Feb-00   JET   - Support for setting number of active dialogues
   1    13-Jul-01   JER   - Removed call to GCT_grab().
   2    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.
   3    01-Dec-09   JLP   - Fixed CN1308SSS - dialog id's issue.
 */

#include "istu.h"

/*
 * ISTU state definitions
 */
#define SMS_IDLE                (0)     /* Idle */
#define SMS_WAIT_OPEN_CNF       (1)     /* Wait for Open confirmation */
#define SMS_WAIT_SMS_CNF        (2)     /* Wait for DPTP confirm */
#define SMS_WAIT_CLOSE_IND      (3)     /* Wait for Close ind */

/*
 * Prototypes for local functions:
 */
#ifdef LINT_ARGS
static int ISTU_alloc_dlg_id(u16 *dlg_id_ptr);
static u8 ISTU_alloc_invoke_id(void);
static int ISTU_disp_msg(char *prefix, MSG *m);
static int ISTU_disp_err(char *text);
static int ISTU_disp_err_val(char *text, u16 value);
static int ISTU_disp_err_str(char *text, char *str);
static int ISTU_disp_status(void);
static void ISTU_release_dlg_id(u16 dlg_id, u8 status);
static void ISTU_release_invoke_id(u8 invoke_id, ISTU_DLG *dlg);
static int ISTU_send_msg(MSG *m);
static int ISTU_send_dlg_req(ISTU_MSG *dlg_req);
static int ISTU_send_srv_req(ISTU_MSG *srv_req);
static int SMS_send_short_msg(SH_MSG *sh_msg);
static int SMS_smac(MSG *m);
static int SMS_wait_open_cnf(ISTU_MSG *ind, ISTU_DLG *dlg);
static int SMS_wait_mt_sms_cnf(ISTU_MSG *ind, ISTU_DLG *dlg);
static int SMS_wait_close_ind(ISTU_MSG *ind, ISTU_DLG *dlg);
static ISTU_DLG *ISTU_get_dlg_data(u16 dlg_id);
#else
static int ISTU_alloc_dlg_id();
static u8 ISTU_alloc_invoke_id();
static int ISTU_disp_msg();
static int ISTU_disp_err();
static int ISTU_disp_err_val();
static int ISTU_disp_err_str();
static int ISTU_disp_status();
static void ISTU_release_dlg_id();
static void ISTU_release_invoke_id();
static int ISTU_send_msg();
static int ISTU_send_dlg_req();
static int ISTU_send_srv_req();
static int SMS_send_short_msg();
static int SMS_smac();
static int SMS_wait_open_cnf();
static int SMS_wait_mt_sms_cnf();
static int SMS_wait_close_ind();
static ISTU_DLG *ISTU_get_dlg_data();
#endif


/*
 * Default Service Centre address. Note that if there are an odd number of
 * digits, then a digit 0xf should be added to the end of the digits as a
 * filler.
 * The default address below is 123456789, with a 0xf as a filler.
 */
ISTU_ADDSTR DEFAULT_SC_ADDR =
{
  4,              /* type of address = service centre address */
  5,              /* number of bytes of digits in the string */
  2,              /* nature of address = national significant number */
  1,              /* numbering plan indicator = ISDN/telephony numbering plan */
  {
    0x21, 0x43, 0x65, 0x87, 0xf9
  }               /* digits, packed in BCD format */
};

/*
 * Static data
 */
static ISTU_DLG dlg_data[NUM_OF_DLG_IDS];  /* Dialogue Data */
static u8 istu_mod_id;                     /* ISTU module id */
static u8 istu_is41_id;                    /* IS41 module id */
static u16 istu_base_dlg_id;               /* IS41 outgoing base dialogue id */
static u16 istu_num_dlg_ids;               /* Number of outgoing dialogue ids*/
static u16 istu_dlg_id;                    /* Current dialogue id */
static u32 istu_sms_run;                   /* Number of dialogues in run */
static u16 istu_options;                   /* Display options selected */
static u16 istu_active;                    /* Number of dialogues active */
static u16 istu_failed;                    /* Number of failed dialogues */
static u16 istu_completed;                 /* Number of successful dialogues */
static u8  istu_last_status;               /* Number of dialogues active*/

/*
 * istu_ent opens a dialogue with the servicing MSC and forwards the short
 * message. It then waits for messages and processes them appropriately
 * until a IS41-CLOSE-IND is received or an error occurs.
 *
 * Always returns zero.
 */
int istu_ent(sh_msg)
  SH_MSG *sh_msg;       /* structure containing all command-line parameters */
{
  HDR *h;               /* received message */
  MSG *m;               /* received message */
  int i;                /* dialogue loop counter */

  istu_mod_id = sh_msg->istu_mod_id;
  istu_is41_id = sh_msg->istu_is41_id;
  istu_base_dlg_id = sh_msg->base_dlg_id;
  istu_num_dlg_ids = sh_msg->num_dlg_ids;
  istu_dlg_id = sh_msg->base_dlg_id;
  istu_sms_run = sh_msg->sms_run;
  istu_options = sh_msg->options;
  istu_last_status = SUCCESS;
  istu_active = 0;
  istu_failed = 0;
  istu_completed = 0;

  /*
   * Make sure all the dialogues are idle
   */
  for (i=0; i<NUM_OF_DLG_IDS; i++)
  {
    dlg_data[i].state = SMS_IDLE;
  }

  /*
   * Print banner so we know what's running.
   */
  printf(
  "Example application and IS41 user interface  (C) Dialogic Corporation 1999-2009. All Rights Reserved.\n");
  printf(
  "=====================================================================================================\n\n");
  printf("ISTU mod Id - 0x%02x; IS41 module Id 0x%x; %i short messages \n",
        istu_mod_id, istu_is41_id, istu_sms_run);
  printf("IS41 base og_dlg_id - 0x%04x; IS41 number of og_dlg_id - 0x%04x\n",
        istu_base_dlg_id, istu_num_dlg_ids);
  printf("maintain %i dialogues, display options - 0x%04x\n",
        sh_msg->max_active, sh_msg->options);

  /*
   * Keep running while there are short messages to send or still active
   * dialogues waiting for responses.
   */
  while((istu_sms_run > 0) || (istu_active > 0))
  {
    /*
     * Open a dialogue with the servicing MSC and send the short message.
     */
    if ((istu_active <= sh_msg->max_active) && (istu_sms_run > 0))
    {
      if ((istu_last_status == SUCCESS) || (istu_active == 0))
      {
        if (SMS_send_short_msg(sh_msg) == 0)
          istu_sms_run--;
        else
          ISTU_disp_err("Failed to send short message");
      }
    }

    /*
     * Receive messages as they become available and
     * processing accordingly.
     *
     * GCT_receive will attempt to receive messages
     * from the task's message queue and block until
     * a message is ready.
     */
    if ((h = GCT_receive(istu_mod_id)) != 0)
    {
      m = (MSG *)h;
      switch (m->hdr.type)
      {
        case IS41_MSG_DLG_IND:
        case IS41_MSG_SRV_IND:
          if (istu_options & ISTU_TRACE_RX)
            ISTU_disp_msg("ISTU Rx:",m);
          SMS_smac(m);
          break;
        default:
          /*
           * Under normal operation we don't expect to receive anything else
           * but if we do report the messages.
           */
          if (istu_options & ISTU_TRACE_RX)
            ISTU_disp_msg("ISTU Rx:",m);
          ISTU_disp_err("Unexpected message type");
          break;
      }
      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }

  printf("ISTU: Finished Run\n");

  return(0);
} /* end of istu_ent() */

/*
 * ISTU_display message traces (prints) any message as hexadecimal
 * to the console.
 *
 * Always returns zero.
 */
static int ISTU_disp_msg(prefix, m)
  char *prefix;          /* String prefix to command line display*/
  MSG  *m;               /* received message */
{
  HDR   *h;              /* Header of message to trace */
  int   instance;        /* Instance of module message is sent from */
  u16   mlen;            /* Length of traced message */
  u8    *pptr;           /* Parameter area of traced message */

  h = (HDR*)m;
  instance = GCT_get_instance(h);
  printf("%s I%04x M t%04x i%04x f%02x d%02x s%02x", prefix, instance, h->type,
          h->id, h->src, h->dst, h->status);

  if ((mlen = m->len) > 0)
  {
    if (mlen > MAX_PARAM_LEN)
      mlen = MAX_PARAM_LEN;
    printf(" p");
    pptr = get_param(m);
    while (mlen--)
    {
      printf("%c%c", BIN2CH(*pptr/16), BIN2CH(*pptr%16));
      pptr++;
    }
  }
  printf("\n");
  return(0);
} /* end of ISTU_disp_msg() */

/*
 * SMS_send_short_msg opens a dialogue with the servicing MSC, and sends the
 * short message to the servicing MSC.
 *
 * Returns zero if the message was sent.
 *         -1   if the message could not be sent.
 */
static int SMS_send_short_msg(sh_msg)
  SH_MSG *sh_msg;      /* structure containing command-line parameters */
{
  ISTU_MSG req;         /* structured form of request message */
  ISTU_DLG *dlg;        /* dialogue data structure */
  u16 i,j;              /* loop counters */
  u16 dlg_id;           /* dialogue ID */

  /*
   * First allocate a dialogue ID for the dialogue with the serving MSC.
   * This dialogue ID is used in all messages sent to and from IS41 associated
   * with this dialogue.
   */
  if (ISTU_alloc_dlg_id(&dlg_id) !=0)
    return(-1);

  dlg = ISTU_get_dlg_data(dlg_id);

  /*
   * Open the dialogue with the serving MSC by sending IS41-OPEN-REQ. The
   * destination address used is the SCCP address of the serving MSC that
   * was entered on the command line.
   *
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;
  req.type = IS41DT_OPEN_REQ;


  /*
   * Copy the serving MSC address, converting from ASCII to hex, and packing
   * into BCD format.
   */
  bit_set(req.pi, IS41PN_dest_address);

  i = 0;
  j = 0;
  while ((sh_msg->smsc_address[j] != '\0') && (i < MAX_ADDR_LEN))
  {

    req.dest_address.data[i] = (hextobin(sh_msg->smsc_address[j])) << 4;

    if (sh_msg->smsc_address[j+1] != '\0')
    {
      req.dest_address.data[i++] |= hextobin(sh_msg->smsc_address[j+1]);
      j += 2;
    }
    else
    {
      i++;
      break;
    }
  }
  req.dest_address.num_bytes = (u8) i;

  /*
   * Copy the home MSC address, converting from ASCII to hex, and packing
   * into BCD format.
   */
  bit_set(req.pi, IS41PN_orig_address);

  i = 0;
  j = 0;
  while ((sh_msg->hmsc_address[j] != '\0') && (i < MAX_ADDR_LEN))
  {

    req.orig_address.data[i] = (hextobin(sh_msg->hmsc_address[j])) << 4;

    if (sh_msg->hmsc_address[j+1] != '\0')
    {
      req.orig_address.data[i++] |= hextobin(sh_msg->hmsc_address[j+1]);
      j += 2;
    }
    else
    {
      i++;
      break;
    }
  }
  req.orig_address.num_bytes = (u8) i;


  ISTU_send_dlg_req(&req);

  /*
   * Allocate an invoke ID for the IS41-SMS-DELIVERY-POINT-TO-POINT request.
   * This invoke ID is used in all messages to and from IS41 associated with
   * this request.
   */
  dlg->invoke_id = ISTU_alloc_invoke_id();

  /*
   * Next send the IS41-SMS-DELIVERY-POINT-TO-POINT-Req. The following
   * parameters are set:
   *  InterMSCCircuitID - Contains the inter MSC circuit id, entered on the
   *          command line.
   *  MobileIdentificationNumber - contains the international mobile
   *          subscriber id entered on the command line
   *  SMS_TeleserviceIdentifier - indicates the teleservice to which the SMS
   *          message applies, entered on the command line.
   *  SMS_BearerData - contains the short message entered on the command line
   */
  memset((void *)req.pi, 0, PI_BYTES);
  req.dlg_id = dlg_id;

  req.type = IS41ST_SMS_DPTP_REQ;

  req.invoke_id = dlg->invoke_id;
  bit_set(req.pi, IS41PN_invoke_id);

  /*
   * Copy the Inter-MSC Circuit Id, converting from ASCII to hex and packing
   * into BCD format.
   */
  bit_set(req.pi, IS41PN_interMSCcctId);
  for (i=0; i < 2; i++)
  {
    req.interMSCcctid[i] = hextobin(sh_msg->interMSCcctid[2*i]);
    req.interMSCcctid[i] |= (hextobin(sh_msg->interMSCcctid[(2*i)+1])) << 4;
  }

  /*
   * Copy the Mobile Id, converting from ASCII to hex and packing into BCD
   * format.
   */
  bit_set(req.pi, IS41PN_mobileIdNum);
  for (i=0; i < 5; i++)
  {
    req.mobileidnum[i] = hextobin(sh_msg->mid[2*i]);
    req.mobileidnum[i] |= (hextobin(sh_msg->mid[(2*i)+1])) << 4;
  }

  /*
   * SMS Teleservice Id 2 oct
   */
  bit_set(req.pi, IS41PN_SMStelesrvId);
  for (i=0; i < 2; i++)
  {
    req.SMStelesrvid[i] = hextobin(sh_msg->SMSteleserviceid[2*i]);
    req.SMStelesrvid[i] |= (hextobin(sh_msg->SMSteleserviceid[(2*i)+1])) << 4;
  }

  /*
   * SMS Bearer data.
   */
  bit_set(req.pi, IS41PN_SMSbearerdata);

  i = 0;
  j = 0;
  while ((sh_msg->message[j] != '\0') && (i < MAX_DATA_LEN))
  {

    req.SMSbearerdata.data[i] = (hextobin(sh_msg->message[j])) << 4;

    if (sh_msg->message[j+1] != '\0')
    {
      req.SMSbearerdata.data[i++] |= hextobin(sh_msg->message[j+1]);
      j += 2;
    }
    else
    {
      i++;
      break;
    }
  }
  req.SMSbearerdata.num_bytes = (u8) i;

  ISTU_send_srv_req(&req);

  /*
   * Now send IS41-DELIMITER-REQ to indicate that no more requests will be sent
   * (for now).
   */
  req.type = IS41DT_DELIMITER_REQ;
  memset((void *)req.pi, 0, PI_BYTES);

  ISTU_send_dlg_req(&req);

  /*
   * Change state to wait for the IS41-OPEN-CNF which indicates whether or not
   * the dialogue has been accepted.
   */
  dlg->state = SMS_WAIT_OPEN_CNF;

  return(0);
} /* end of SMS_send_short_message() */

/*
 * SMS_smac is Short Message Service state machine. It is entered after the
 * dialogue with the servicing MSC has been opened and the short message has
 * been forwarded.
 *
 * Always returns zero.
 */
static int SMS_smac(m)
  MSG *m;       /* received message */
{
  ISTU_MSG ind;         /* structured form of received message */
  ISTU_DLG *dlg;        /* dialogue data structure */

  /*
   * Recover the parameters from the MSG into a 'C' structure
   */
  if (ISTU_msg_to_ind(&ind, m) != 0)
  {
    ISTU_disp_err("Primitive indication recovery failure");
  }
  else
  {
    if ((ind.dlg_id < istu_base_dlg_id) || 
        (ind.dlg_id >= (istu_base_dlg_id + istu_num_dlg_ids)))
    {
      ISTU_disp_err_val("Unexpected dialogue ID= 0x",ind.dlg_id);
    }
    else
    {
      dlg = ISTU_get_dlg_data(ind.dlg_id);      

      /*
       * Handle the event according to the current state.
       */
      switch (dlg->state)
      {
        case SMS_WAIT_OPEN_CNF:
          SMS_wait_open_cnf(&ind, dlg);
          break;

        case SMS_WAIT_SMS_CNF:
          SMS_wait_mt_sms_cnf(&ind, dlg);
          break;

        case SMS_WAIT_CLOSE_IND:
          SMS_wait_close_ind(&ind, dlg);
          break;

        case SMS_IDLE:
        default:
          ISTU_disp_err("Message received for inactive dialogue");
          break;
      }
    }
  }
  return(0);
} /* end of SMS_smac() */

/*
 * SMS_wait_open_cnf handles messages received in the waiting for open
 * confirmation state.
 *
 * Always returns zero.
 */
static int SMS_wait_open_cnf(msg, dlg)
  ISTU_MSG *msg;
  ISTU_DLG *dlg;
{
  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case IS41DT_U_ABORT_IND:
      case IS41DT_P_ABORT_IND:
        /*
         * Dialogue aborted. Release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (msg->type == IS41DT_U_ABORT_IND)
        {
          if (bit_test(msg->pi, IS41PN_user_rsn))
          {
            if (istu_options & ISTU_TRACE_ERROR)
              fprintf(stderr, "*** IS41-U-ABORT-Ind received with user reason = %s ***\n",
                   msg->user_rsn_str);
          }
          else
          {
            ISTU_disp_err("IS41-U-ABORT-Ind received");
          }

        }
        else
        {
          if (bit_test(msg->pi, IS41PN_prov_rsn))
            ISTU_disp_err_val("IS41-P-ABORT-Ind received with provider reason = ",
                msg->prov_reason);
          else
            ISTU_disp_err("IS41-P-ABORT-Ind received");
        }
        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;

      case IS41DT_OPEN_CNF:
        if (msg->result == IS41RS_DLG_ACC)
        {
          /*
           * Dialogue has been accepted. Change state to wait for the
           * IS41-SMS-DELIVER-POINT-TO-POINT-Cnf which indicates whether or
           * not the short message was delivered successfully.
           */
          dlg->state = SMS_WAIT_SMS_CNF;
        }
        else
        {
          /*
           * Report the error, release the invoke ID, release the dialogue ID,
           * and idle the state machine.
           */
          ISTU_disp_err("dialogue refused");
          ISTU_release_invoke_id(dlg->invoke_id, dlg);
          ISTU_release_dlg_id(msg->dlg_id, FAIL);
        }
        break;

      default:
        ISTU_disp_err_val("Unexpected dialogue primitive received: ",msg->type);
        break;
    }
  }
  else
  {
    ISTU_disp_err_val("Unexpected service primitive received: ", msg->type);
  }

  return(0);
} /* end of SMS_wait_open_cnf() */

/*
 * SMS_wait_mt_sms_cnf handles messages received in the wait for mobile
 * terminated SMS confirmation state.
 *
 * Always returns zero.
 */
static int SMS_wait_mt_sms_cnf(msg, dlg)
  ISTU_MSG *msg;
  ISTU_DLG *dlg;
{
  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case IS41DT_U_ABORT_IND:
        /*
         * Dialogue aborted by remote user. Release the invoke ID, release the
         * dialogue ID, and idle the state machine.
         */
        if (bit_test(msg->pi, IS41PN_user_rsn))
        {
          ISTU_disp_err_str("IS41-U-ABORT-Ind received with user reason = ",
                msg->user_rsn_str);
        }
        else
        {
          ISTU_disp_err("IS41-U-ABORT-Ind received");
        }
        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;

      case IS41DT_P_ABORT_IND:
        /*
         * Dialogue aborted by network. Release the invoke ID, release the
         * dialogue ID, and idle the state machine.
         */
        if (bit_test(msg->pi, IS41PN_prov_rsn))
          ISTU_disp_err_val("IS41-P-ABORT-Ind received with provider reason = ",
                msg->prov_reason);
        else
          ISTU_disp_err("IS41-P-ABORT-Ind received");
        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;

      case IS41DT_NOTICE_IND:
        /*
         * IS41-NOTICE-IND indicates some kind of error. Close the dialogue
         * using IS41-U-ABORT-REQ, release the invoke ID, release the dialogue
         * ID, and idle the state machine.
         */
        if (bit_test(msg->pi, IS41PN_prob_diag))
          ISTU_disp_err_val("IS41-NOTICE-Ind received with problem diagnostic = ",
                  msg->prob_diag);
        else
          ISTU_disp_err("IS41-NOTICE-Ind received");


        /*
         * Send IS41-U_ABORT-Req containing the following parameters:
         *      release method
         */
        msg->type = IS41DT_U_ABORT_REQ;
        memset((void *)msg->pi, 0, PI_BYTES);

        bit_set(msg->pi, IS41PN_user_rsn);
        msg->user_rsn_str[0] = IS41UR_unspecified_reason;
        msg->user_rsn_str[1] = '\0';
        ISTU_send_dlg_req(msg);

        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;
    default:
      ISTU_disp_err_val("Unexpected dialogue primitive received: ", msg->type);
      break;
    }
  }
  else
  {
    /*
     * Check that this message is related to the current invocation.
     */
    if (msg->invoke_id == dlg->invoke_id)
    {
      switch (msg->type)
      {
        case IS41ST_SMS_DPTP_CNF:
          /*
           * IS41-SMS-DELIVERY-POINT-TO-POINT-Cnf received. Release the
           * invoke ID.
           */
          ISTU_release_invoke_id(dlg->invoke_id, dlg);

          if (bit_test(msg->pi, IS41PN_prov_err))
          {
            /*
             * A provider error parameter is included indicating an error.
             * Close the dialogue by sending IS41-CLOSE-Req and release the
             * dialogue ID.
             */
            ISTU_disp_err("IS41-SMS-DELIVERY-POINT-TO-POINT-Cnf received ");
            ISTU_disp_err_val("with provider error = ", msg->prov_err);

            /*
             * Send IS41-U_ABORT-Req containing the following parameters:
             *      release method
             */
            msg->type = IS41DT_U_ABORT_REQ;
            memset((void *)msg->pi, 0, PI_BYTES);

            bit_set(msg->pi, IS41PN_user_rsn);
            msg->user_rsn_str[0] = IS41UR_unspecified_reason;
            msg->user_rsn_str[1] = '\0';
            ISTU_send_dlg_req(msg);

            ISTU_release_dlg_id(msg->dlg_id, FAIL);
          }
          else
          {
            if (bit_test(msg->pi, IS41PN_user_err))
            {
              ISTU_disp_err("IS41-SMS-DELIVERY-POINT-TO-POINT-Cnf received");
              ISTU_disp_err_val("with user error = ", msg->user_err);
            }
            dlg->state = SMS_WAIT_CLOSE_IND;
          }
          break;

        default:
          ISTU_disp_err_val("Unexpected service primitive received: ", msg->type);
          break;
      }
    }
    else
    {
      ISTU_disp_err_val("Received service primitive with unexpected invoke ID:",
             msg->invoke_id);
    }
  }

  return(0);
} /* end of SMS_wait_mt_sms_cnf() */

/*
 * SMS_wait_close_ind handles messages received in the wait for close indication
 * state.
 *
 * Always returns zero.
 */
static int SMS_wait_close_ind(msg, dlg)
  ISTU_MSG *msg;
  ISTU_DLG *dlg;
{
  if (msg->dlg_prim)
  {
    switch (msg->type)
    {
      case IS41DT_CLOSE_IND:
        /*
         * IS41-CLOSE-IND received. Release the dialogue ID and idle the
         * state machine.
         */
        ISTU_release_dlg_id(msg->dlg_id, SUCCESS);
        break;

      case IS41DT_U_ABORT_IND:
        /*
         * Dialogue aborted by remote user. Release the invoke ID, release the
         * dialogue ID, and idle the state machine.
         */
        if (bit_test(msg->pi, IS41PN_user_rsn))
        {
          ISTU_disp_err_str("IS41-U-ABORT-Ind received with user reason = ",
                msg->user_rsn_str);
        }
        else
        {
          ISTU_disp_err("IS41-U-ABORT-Ind received");
        }
        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;

      case IS41DT_P_ABORT_IND:
        /*
         * Dialogue aborted by the network. Release the invoke ID, release the
         * dialogue ID, and idle the state machine.
         */
        if (bit_test(msg->pi, IS41PN_prov_rsn))
        {
          ISTU_disp_err_val("IS41-P-ABORT-Ind received with provider reason = 0x",
                msg->prov_reason);
        }
        else
        {
          ISTU_disp_err("IS41-P-ABORT-Ind received");
        }
        ISTU_release_invoke_id(dlg->invoke_id, dlg);
        ISTU_release_dlg_id(msg->dlg_id, FAIL);
        break;

      default:
        ISTU_disp_err_val("Unexpected dialogue primitive received: 0x",
                msg->type);
        break;
    }
  }
  else
  {
    ISTU_disp_err_val("Unexpected service primitive received: 0x", msg->type);
  }

  return(0);
} /* end of SMS_wait_close_ind() */

/*
 * ISTU_send_dlg_req allocates a message (using the
 * getm() function) then converts the primitive parameters
 * from the 'C' structured representation into the correct
 * format for passing to the IS41 module.
 * The formatted message is then sent.
 *
 * Always returns zero.
 */
static int ISTU_send_dlg_req(req)
  ISTU_MSG  *req;       /* structured primitive request to send */
{
  MSG *m;               /* message sent to IS41 */

  req->dlg_prim = 1;

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_DLG_REQ, req->dlg_id, NO_RESPONSE,
                                      ISTU_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = istu_mod_id;
    m->hdr.dst = istu_is41_id;

    /*
     * Format the parameter area of the message and
     * (if successful) send it
     */
    if (ISTU_dlg_req_to_msg(m, req) != 0)
    {
      ISTU_disp_err("failed to format dialogue primitive request");
      relm(&m->hdr);
    }
    else
    {
      /*
       * Display the message if requested
       */
      if (istu_options & ISTU_TRACE_TX)
        ISTU_disp_msg("ISTU Tx:",m);
      /*
       * and send to the call processing module:
       */
      ISTU_send_msg(m);
    }
  }
  return(0);
} /* end of ISTU_send_dlg_req() */

/*
 * ISTU_send_srv_req allocates a message (using the
 * getm() function) then converts the primitive parameters
 * from the 'C' structured representation into the correct
 * format for passing to the IS41 module.
 * The formatted message is then sent.
 *
 * Always returns zero.
 */
static int ISTU_send_srv_req(req)
  ISTU_MSG  *req;       /* structured primitive request to send */
{
  MSG *m;               /* message sent to IS41 */

  req->dlg_prim = 0;

  /*
   * Allocate a message (MSG) to send:
   */
  if ((m = getm((u16)IS41_MSG_SRV_REQ, req->dlg_id, NO_RESPONSE,
                                      ISTU_MAX_PARAM_LEN)) != 0)
  {
    m->hdr.src = istu_mod_id;
    m->hdr.dst = istu_is41_id;

    /*
     * Format the parameter area of the message and
     * (if successful) send it
     */
    if (ISTU_srv_req_to_msg(m, req) != 0)
    {
      ISTU_disp_err("failed to format service primitive request");
      relm(&m->hdr);
    }
    else
    {
      /*
       * Display the message if requested
       */
      if (istu_options & ISTU_TRACE_TX)
        ISTU_disp_msg("ISTU Tx:",m);
      /*
       * and send to the call processing module:
       */
      ISTU_send_msg(m);
    }
  }
  return(0);
} /* end of ISTU_send_srv_req() */

/*
 * ISTU_alloc_dlg_id allocates a dialogue ID to be used when opening a dialogue.
 */
static int ISTU_alloc_dlg_id(dlg_id_ptr)
u16 *dlg_id_ptr;    /* updated to point to a free dialogue id */
{
  u16 i;            /* dialogue id loop counter */
  int found;        /* has an idle dialogue been found  */

  found = 0;

  /*
   * Look for an idle dialogue id starting at istu_dlg_id
   */
  for (i = istu_dlg_id; i < (istu_base_dlg_id + istu_num_dlg_ids); i++)
  {
    if (ISTU_get_dlg_data(i)->state == SMS_IDLE)
    {
      found = 1;
      break;
    }
  }

  /*
   * If we haven't found one yet so start looking again, this time from the
   * base id.
   */
  if (found == 0)
  {
    for (i = istu_base_dlg_id; i < istu_dlg_id; i++)
    {
      if (ISTU_get_dlg_data(i)->state == SMS_IDLE)
      {
        found = 1;
        break;
      }
    }
  }

  if (found)
  {
    /*
     * Update the dialogue id to return and increment the active dialogue count
     */
    *dlg_id_ptr = i;
    istu_active++;

    /*
     * Select the next dialogue id to start looking for an idle one.
     * If we've reached the end of the range then start from the base id.
     */
    if (istu_dlg_id == (istu_base_dlg_id + istu_num_dlg_ids - 1))
      istu_dlg_id = istu_base_dlg_id;
    else
     istu_dlg_id++;

    return(0);
  }
  else
  {
  /*
   * No idle dialogue id found
   */
  return(-1);
  }
} /* end of ISTU_alloc_dlg_id() */

/*
 * ISTU_alloc_invoke_id allocates an invoke ID to be used for a IS41 request.
 */
static u8 ISTU_alloc_invoke_id()
{
  /*
   * This function always uses the same invoke ID (because only one invocation
   * can be in progress at one time in this example program). In a real
   * application, this function would have to search for a free invoke ID and
   * allocate that.
   */
  return(DEFAULT_INVOKE_ID);
} /* end of ISTU_alloc_invoke_id() */

static void ISTU_release_dlg_id(dlg_id, status)
  u16 dlg_id;   /* Dialogue id of dialogue being released */
  u8  status;   /* Was the dialogue a SUCCESS(0) or a FAILure(1)*/
{
  /*
   * Simply mark the dialogue id as idle and decrement the active count.
   */
  ISTU_get_dlg_data(dlg_id)->state = SMS_IDLE;
  istu_active--;

  /*
   * Record the number of successfully completed dialogues and the number of
   * failures.
   */
  if (status == SUCCESS)
    istu_completed++;
  else
    istu_failed++;

  /*
   * Remember if the last dialogue to close was a success or a failure.
   */
  istu_last_status = status;

  ISTU_disp_status();

  return;

} /* end of ISTU_release_dlg_id() */

static void ISTU_release_invoke_id(invoke_id, dlg)
  u8 invoke_id;         /* invoke ID */
  ISTU_DLG *dlg;        /* dialogue data structure */
{
  /*
   * Since only one invoke ID is ever used, it is not necessary to release
   * it. In a real application, the invoke ID would have to be marked as
   * free in this function.
   */

  dlg->invoke_id = 0;

  return;
} /* end of ISTU_release_invoke_id() */

/*
 * ISTU_send_msg sends a MSG. On failure the
 * message is released and the user notified.
 *
 * Always returns zero.
 */
static int ISTU_send_msg(m)
  MSG   *m;             /* MSG to send */
{
  if (GCT_send(m->hdr.dst, (HDR *)m) != 0)
  {
    fprintf(stderr, "ISTU: *** failed to send message ***\n");
    relm((HDR *)m);
  }
  return(0);
} /* end of ISTU_send_msg()*/

/*
 * ISTU_disp_err
 *
 * Traces internal progress to the console.
 *
 * Always returns zero.
 */
static int ISTU_disp_err(text)
  char *text; /* Text for tracing progress of program */
{
  if (istu_options & ISTU_TRACE_ERROR)
    fprintf(stderr, "ISTU: *** %s ***\n",text);

  return(0);
} /* end of ISTU_disp_err()*/


/*
 * ISTU_disp_err_val
 *
 * Like ISTU_disp_err it traces internal progress to the console but also
 * allows a value to be displayed.
 *
 * Always returns zero.
 */
static int ISTU_disp_err_val(text, value)
  char *text; /* Text for tracing progress of program */
  u16  value; /* Value to be displayed */
{
  if (istu_options & ISTU_TRACE_ERROR)
    fprintf(stderr, "ISTU: *** %s%04x ***\n", text, value);

  return(0);
} /* end of ISTU_disp_err_val() */

/*
 * ISTU_disp_err_str
 *
 * Like ISTU_disp_err it traces internal progress to the console but also
 * allows a string to be displayed.
 *
 * Always returns zero.
 */
static int ISTU_disp_err_str(text, str)
  char *text;      /* Text for tracing progress of program */
  char *str;       /* Text string value to be displayed */
{
  if (istu_options & ISTU_TRACE_ERROR)
    fprintf(stderr, "ISTU: *** %s%s ***\n", text, str);

  return(0);
} /* end of ISTU_disp_err_str() */

/*
 * ISTU_disp_status
 *
 * Shows number of active dialogues and number remaining in run
 *
 * Always returns zero.
 */
static int ISTU_disp_status()
{
  if (istu_options & ISTU_TRACE_DISPLAY)
  {
    printf("ISTU: Dlgs active [%i], failed [%i], successful [%i], remaining [%i]\n ",
        istu_active, istu_failed, istu_completed, istu_sms_run);
  }

  return(0);
} /* end of ISTU_disp_status() */


/*
 * ISTU_get_dlg_data returns the dlg data structure.
 */
static ISTU_DLG *ISTU_get_dlg_data(
  u16 dlg_id
  )
{
   return(&(dlg_data[dlg_id - istu_base_dlg_id]));
}



