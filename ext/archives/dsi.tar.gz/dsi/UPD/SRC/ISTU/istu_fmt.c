/*
                Copyright (C) Dialogic Corporation 1999-2006. All Rights Reserved.

 Name:          istu_fmt.c

 Description:   Contains functions used in formatting and recovery of
                messages.

 Functions:     ISTU_dlg_req_to_msg      ISTU_srv_req_to_msg
                ISTU_msg_to_ind

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------

   A    15-Apr-99   RBP   - Initial code.
   B    15-Feb-00   JET   - Minor comment corrections
   C    07-Mar-01   MH    - Correct printf().
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.                          
 */

#include "istu.h"


/*
 * Prototypes for local functions
 */
#ifdef LINT_ARGS
static int ISTU_recover_param(u8 pname, u8 *pptr, u8 plen, ISTU_MSG *ind);
#else
static int ISTU_recover_param();
#endif


/*
 * ISTU_dlg_req_to_msg formats a Dialogue Request message to send to IS41.
 *
 * Always returns zero.
 */
int ISTU_dlg_req_to_msg(m, dlg_req)
  MSG *m;               /* ptr to interprocess message resource */
  ISTU_MSG *dlg_req;    /* ptr to stuctured ISTU message resource */
{
  int mlen;             /* total param length */
  int i;                /* loop counter */
  u8  *pptr;            /* pointer to parameter area of message */

  pptr = get_param(m);

  /*
   * for type and terminator octet
   */
  mlen = 2;
  *pptr++ = (u8)dlg_req->type;

  switch (dlg_req->type)
  {
    case IS41DT_OPEN_REQ:
      /*
       * IS41-OPEN-REQ contains the following parameters:
       *        destination address
       *        origination address
       */

      if (bit_test(dlg_req->pi, IS41PN_dest_address))
      {
        /*
         * destination address
         */
        *pptr++ = IS41PN_dest_address;
        *pptr++ = dlg_req->dest_address.num_bytes;
        for (i=0; i<dlg_req->dest_address.num_bytes; i++)
        {
          *pptr++ = dlg_req->dest_address.data[i];
        }
        mlen += dlg_req->dest_address.num_bytes + 2;
      }

      if (bit_test(dlg_req->pi, IS41PN_orig_address))
      {
        /*
         * origination address
         */
        *pptr++ = IS41PN_orig_address;
        *pptr++ = dlg_req->orig_address.num_bytes;
        for (i=0; i<dlg_req->orig_address.num_bytes; i++)
        {
          *pptr++ = dlg_req->orig_address.data[i];
        }
        mlen += dlg_req->orig_address.num_bytes + 2;
      }
      break;

    case IS41DT_DELIMITER_REQ:
      /*
       * IS41-DELIMITER-REQ contains no parameters.
       */
      break;

    case IS41DT_CLOSE_REQ:
      /*
       * IS41-CLOSE-REQ contains the following parameters:
       *        release method
       */
      /*
       * release method
       */
      if (bit_test(dlg_req->pi, IS41PN_release_method))
      {
        *pptr++ = IS41PN_release_method;
        *pptr++ = 1;
        *pptr++ = dlg_req->release_method;
        mlen += 3;
      }
      break;

    case IS41DT_U_ABORT_REQ:
      /*
       * IS41-U-ABORT-REQ contains the following parameters:
       *        user reason
       */
      /*
       * User reason
       */
      if (bit_test(dlg_req->pi, IS41PN_user_rsn))
      {
        *pptr++ = IS41PN_user_rsn;
        *pptr++ = (u8)strlen(dlg_req->user_rsn_str);
        strcpy(pptr, dlg_req->user_rsn_str);
        mlen += 3;
      }
      break;

    default:
      printf("*** Unknown dialogue request message type: %x ***\n", 
        dlg_req->type);
      break;
  } /* end switch on dialogue message type */

  /*
   * Set last byte to zero, indicating no more parameters.
   */
  *pptr = 0;

  m->len = (unsigned short)mlen;

  return(0);
} /* end of ISTU_dlg_req_to_msg() */

/*
 * ISTU_srv_req_to_msg formats a Service Request message to send to IS41.
 *
 * Always returns zero.
 */
int ISTU_srv_req_to_msg(m, srv_req)
  MSG *m;                       /* ptr to interprocess message resource */
  ISTU_MSG *srv_req;            /* ptr to structured ISTU message resource */
{
  int   mlen;                   /* total param length */
  int   i;                      /* loop counter */
  u8    *pptr;                  /* pointer to parameter area of message */

  pptr = get_param(m);

  /*
   * for type and terminator octet
   */
  mlen = 2;
  *pptr++ = (u8)srv_req->type;

  switch (srv_req->type)
  {
    case IS41ST_SMS_DPTP_REQ:
      /*
       * IS41ST_SMS_DPTP_REQ contains the following parameters:
       *        invoke ID
       *        inter MSC circuit id
       *        mobile id number
       *        bearer data
       *        teleservice id
       */

      /*
       * Invoke ID
       */
      if (bit_test(srv_req->pi, IS41PN_invoke_id))
      {
        *pptr++ = IS41PN_invoke_id;
        *pptr++ = 1;
        *pptr++ = srv_req->invoke_id;
        mlen += 3;
      }

      /*
       * inter MSC circuit id
       */
      if (bit_test(srv_req->pi, IS41PN_interMSCcctId))
      {
        *pptr++ = IS41PN_interMSCcctId;
        *pptr++ = 2;
        *pptr++ = srv_req->interMSCcctid[0];
        *pptr++ = srv_req->interMSCcctid[1];
        mlen += 4;
      }

      /*
       * mobile id number
       */
      if (bit_test(srv_req->pi, IS41PN_mobileIdNum))
      {
        *pptr++ = IS41PN_mobileIdNum;
        *pptr++ = 5;
        *pptr++ = srv_req->mobileidnum[0];
        *pptr++ = srv_req->mobileidnum[1];
        *pptr++ = srv_req->mobileidnum[2];
        *pptr++ = srv_req->mobileidnum[3];
        *pptr++ = srv_req->mobileidnum[4];
        mlen += 7;
      }

      /*
       * teleservice id
       */
      if (bit_test(srv_req->pi, IS41PN_SMStelesrvId))
      {
        *pptr++ = IS41PN_SMStelesrvId;
        *pptr++ = 2;
        *pptr++ = srv_req->SMStelesrvid[0];
        *pptr++ = srv_req->SMStelesrvid[1];
        mlen += 4;
      }

      /*
       * bearer data
       */
      if (bit_test(srv_req->pi, IS41PN_SMSbearerdata))
      {
        *pptr++ = IS41PN_SMSbearerdata;
        *pptr++ = srv_req->SMSbearerdata.num_bytes;
        for (i=0; i<srv_req->SMSbearerdata.num_bytes; i++)
        {
          *pptr++ = srv_req->SMSbearerdata.data[i];
        }
        mlen += srv_req->SMSbearerdata.num_bytes + 2;
      }
      break;

    default:
      printf("*** Unknown service request message type: %x ***\n", 
        srv_req->type);
      break;
  } /* end switch on service message type */

  /*
   * Set last byte to zero, indicating no more parameters.
   */
  *pptr = 0;

  m->len = (unsigned short)mlen;

  return(0);
}

/*
 * ISTU_msg_to_ind converts primitive indications
 * from the IS41 module into the 'C' structured
 * representation of a primitive indication.
 *
 * Returns zero on success or an error code otherwise.
 */
int ISTU_msg_to_ind(ind, m)
  ISTU_MSG  *ind;       /* structure to recover data to */
  MSG        *m;        /* message to recover data from */
{
  u16   mlen;           /* total param length */
  int   ret;            /* return code */
  u8    plen;           /* current parameter length */
  u8    *pptr;          /* ptr to interprocess message parameter area */
  u8    *eop;           /* ptr to end of parameters */
  u8    pname;          /* parameter name */

  ret = -1;
  ind->dlg_id = m->hdr.id;
  if (m->hdr.type == IS41_MSG_DLG_IND)
    ind->dlg_prim = 1;
  else
    ind->dlg_prim = 0;
  mlen = m->len;

  /*
   * Clear the parameter indicator field
   */
  memset((void *)ind->pi, 0, PI_BYTES);

  /*
   * recover the parameters
   */
  if (mlen)
  {
    pptr = get_param(m);
    eop = pptr + mlen;
    ind->type = *pptr++;

    while (pptr < eop)
    {
      if (*pptr == 0)
      {
        if (++pptr == eop)
          ret = 0;
        break;
      }
      else
      {
        pname = *pptr++;
        bit_set(ind->pi, pname);
        plen = *pptr++;
        ret = ISTU_recover_param(pname, pptr, plen, ind);
        pptr += plen;
      }
    } /* end while */
  } /* end if */
  return(ret);
} /* end of ISTU_msg_to_ind() */

/*
 * ISTU_recover_param() recovers a parameter from a received message into
 * the C structure for that message.
 *
 * Always returns zero (success).
 */
static int ISTU_recover_param(pname, pptr, plen, ind)
  u8 pname;             /* parameter name */
  u8 *pptr;             /* parameter data */
  u8 plen;              /* parameter length */
  ISTU_MSG *ind;        /* structure to is41 parameter into */
{
  u8 i;                 /* local index */

  switch(pname)
  {
    case IS41PN_invoke_id:
      ind->invoke_id = *pptr;
      break;

    case IS41PN_prob_diag:
      ind->prob_diag = *pptr;
      break;

    case IS41PN_prov_rsn:
      ind->prov_reason = *pptr;
      break;

    case IS41PN_prov_err:
      ind->prov_err = *pptr;
      break;

    case IS41PN_result:
      ind->result = *pptr;
      break;

    case IS41PN_user_err:
      ind->user_err = *pptr;
      break;

    case IS41PN_user_rsn:
      if (plen > (MAX_RSN_LEN -1 ))
      {
        plen = MAX_RSN_LEN - 1;
      }
      for (i=0; i<plen; i++)
      {
        bintoasc(&ind->user_rsn_str[i*2], *pptr++);
      }
      ind->user_rsn_str[i*2] = '\0';
      break;
  }
  return(0);
} /* end of ISTU_recover_param() */


