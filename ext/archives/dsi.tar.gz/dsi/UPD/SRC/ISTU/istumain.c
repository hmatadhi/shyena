/*
                Copyright (C) Dialogic Corporation 1999-2009. All Rights Reserved.

 Name:          istu_main.c

 Description:   Console command line interface to istu.

 Functions:     main()

 -----  ---------  -----  ---------------------------------------------
 Issue    Date      By                     Changes
 -----  ---------  -----  ---------------------------------------------
   A    14-Apr-99   RBP   - Initial code.
   B    09-Sep-99   JET   - Added ability to send multiple short messages
                            using different dialogue ids.
   C    15-Feb-00   JET   - Support for setting number of active dialogues
   1    13-Dec-06   ML    - Change to use of Dialogic Corporation copyright.   
   2    01-Dec-09   JLP   - Prevent build warnings with cast
 */

#include "istu.h"

#ifdef LINT_ARGS
  static int read_command_line_params(int argc, char *argv[], int *arg_index);
  static void show_syntax(void);
  static int read_option(char *arg);
#else
  static int read_command_line_params();
  static void show_syntax();
  static int read_option();
#endif

#define COMMAND_LINE_EXIT_REQ          (-1) /* Option requires immediate exit */
#define COMMAND_LINE_UNRECON_OPTION    (-2) /* Unrecognised option */
#define COMMAND_LINE_RANGE_ERR         (-3) /* Option value is out of range */

/*
 * Default values for ISTU's command line options:
 */
#define DEFAULT_MODULE_ID              (0x2d)
#define DEFAULT_IS41_ID                (IS41_TASK_ID)
#define DEFAULT_OPTIONS                (0x001f)
#define DEFAULT_MAX_ACTIVE             (0x1)

/*
 * Structure that stores the data entered on the command line
 */
static SH_MSG sh_msg;

/*
 * Program name
 */
static char *program;


/*
 * Main function for IS41 Test Utility (ISTU):
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;
  u8 str_len;

  program = argv[0];

  sh_msg.istu_mod_id = DEFAULT_MODULE_ID;
  sh_msg.istu_is41_id = DEFAULT_IS41_ID;
  sh_msg.base_dlg_id = BASE_DLG_ID;
  sh_msg.num_dlg_ids = NUM_OF_DLG_IDS;
  sh_msg.sms_run = DEFAULT_DLG_RUN;
  sh_msg.options = DEFAULT_OPTIONS;
  sh_msg.max_active = DEFAULT_MAX_ACTIVE;
  sh_msg.SMSteleserviceid = "";
  sh_msg.interMSCcctid = "";
  sh_msg.mid = "";
  sh_msg.smsc_address = "";
  sh_msg.hmsc_address = "";
  sh_msg.message = "";

  if ((cli_error = read_command_line_params(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case COMMAND_LINE_UNRECON_OPTION :
	fprintf(stderr, "%s: Unrecognised option : %s\n", program, argv[failed_arg]);
	show_syntax();
        break;

      case COMMAND_LINE_RANGE_ERR :
	fprintf(stderr, "%s: Parameter range error : %s\n", program, argv[failed_arg]);
	show_syntax();
	break;

      default :
	break;
    }

    exit(0);
  }

  str_len = (u8)strlen(sh_msg.mid);
  if (str_len == 0)
  {
    fprintf(stderr, "%s: -i option missing \n", program);
    show_syntax();
    exit(0);
  }
  if (str_len != (MOB_ID_LEN * 2))
  {
    fprintf(stderr, "%s: -i Parameter range error\n", program);
    show_syntax();
    exit(0);
  }

  str_len = (u8)strlen(sh_msg.interMSCcctid);
  if (str_len == 0)
  {
    fprintf(stderr, "%s: -d option missing \n", program);
    show_syntax();
    exit(0);
  }
  if (str_len != (CCT_ID_LEN*2))
  {
    fprintf(stderr, "%s: -d Parameter range error \n", program);
    show_syntax();
    exit(0);
  }

  str_len = (u8)strlen(sh_msg.SMSteleserviceid);
  if (str_len == 0)
  {
    fprintf(stderr, "%s: -t option missing \n", program);
    show_syntax();
    exit(0);
  }
  if (str_len != (SRV_ID_LEN*2))
  {
    fprintf(stderr, "%s: -t Parameter range error \n", program);
    show_syntax();
    exit(0);
  }

  if (strlen(sh_msg.smsc_address) == 0)
  {
    fprintf(stderr, "%s: -a option missing \n", program);
    show_syntax();
    exit(0);
  }

  if (strlen(sh_msg.hmsc_address) == 0)
  {
    fprintf(stderr, "%s: -g option missing \n", program);
    show_syntax();
    exit(0);
  }

  if (strlen(sh_msg.message) == 0)
  {
    fprintf(stderr, "%s: -s option missing \n", program);
    show_syntax();
    exit(0);
  }

  istu_ent(&sh_msg);
  return(0);
}


/*
 *        show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr,
        "Syntax: %s [-m<modid> -u<is41id> -b<base_did> -d<intermsc> -n<num_dlg_ids> -r<num_sms> -x<active dlgs>] -g<hmsc> -a<smsc> -i<mid> -t<teleserv> -o<display options> -s<message> \n", program);
  fprintf(stderr,
	"  -m  : istu's module ID (default=0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,
	"  -u  : IS41 module ID (default=0x%02x)\n", DEFAULT_IS41_ID);
  fprintf(stderr,
        "  -b  : base IS-41 dialogue id\n");
  fprintf(stderr,
        "  -n  : number of og IS-41 dialogue ids\n");
  fprintf(stderr,
	"  -r  : number of sms messages to send\n");
  fprintf(stderr,
        "  -x  : number of active dialogue to maintain (default=%i)\n", DEFAULT_MAX_ACTIVE);
  fprintf(stderr,
	"  -g  : home MSC address\n");
  fprintf(stderr,
	"  -a  : serving MSC address\n");
  fprintf(stderr,
        "  -i  : mobile identity number (10 digits)\n");
  fprintf(stderr,
	"  -d  : inter MSC circuit identity \n");
  fprintf(stderr,
	"  -t  : SMS teleservice identifier \n");
  fprintf(stderr,
	"  -s  : short message - coded appropriately for this SMS teleservice \n");
  fprintf(stderr,
        "  -o  : Output display options (default=0x%04x)\n", DEFAULT_OPTIONS);
  fprintf(stderr,
        "Example: %s -m0x77 -u0x25 -g430c010000 -a430a020000 -i0123456789 -d0102 -t0203 -o0xf -s0123456789\n", program);
}

/*
 * Read in command line options and set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_command_line_params(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32  temp_u32;

  if (arg[0] != '-')
    return(COMMAND_LINE_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
      show_syntax();
      return(COMMAND_LINE_EXIT_REQ);

    case 'm' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);
      sh_msg.istu_mod_id = (u8)temp_u32;
      break;

    case 'u' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);
      sh_msg.istu_is41_id = (u8)temp_u32;
      break;

    case 'g' :
      sh_msg.hmsc_address = &arg[2];
      break;

    case 'a' :
      sh_msg.smsc_address = &arg[2];
      break;

    case 'b' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.base_dlg_id = (u16)temp_u32;
      break;

    case 'n' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.num_dlg_ids = (u16)temp_u32;
      break;

    case 'r' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.sms_run = (u32)temp_u32;
      break;

    case 'x' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.max_active = (u16)temp_u32;
      break;

    case 'i' :
      sh_msg.mid = &arg[2];
      break;

    case 'd' :
      sh_msg.interMSCcctid = &arg[2];
      break;

    case 't' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.SMSteleserviceid = &arg[2];
      break;

    case 'o' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
	return(COMMAND_LINE_RANGE_ERR);

      sh_msg.options = (u16)temp_u32;
      break;

    case 's' :
      sh_msg.message = &arg[2];
      break;

  }
  return(0);
}
