#!/bin/sh

# Default to 32 bit build
make_cmd=${1-32bit}

if [ $make_cmd == 32bit ]
then
make_opts="ARCH=32"
printf "Building 32bit UPD binaries ...\n"
elif [ $make_cmd == 64bit ]
then
make_opts="ARCH=64"
printf "Building 64bit UPD binaries ...\n"
else
make_opts=$1
fi

cd MTPSL
make -f mtpsl.mak $make_opts

cd ../CTU
make -f ctu.mak $make_opts

cd ../INTU
make -f intu.mak $make_opts

cd ../ISTR
make -f istr.mak $make_opts

cd ../ISTU
make -f istu.mak $make_opts

cd ../MTR
make -f mtr.mak $make_opts

cd ../MTU
make -f mtu.mak $make_opts

cd ../TTU
make -f ttu.mak $make_opts

cd ../SSM
make -f ssm.mak $make_opts

cd ../UPE
make -f upe.mak $make_opts

cd ../DTU
make -f dtu.mak $make_opts

cd ../DTR
make -f dtr.mak $make_opts

cd ../DMRAPI
make -f dmrapitest.mak $make_opts
