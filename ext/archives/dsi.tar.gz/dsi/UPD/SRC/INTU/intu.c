/*
   Copyright (C) Dialogic Corporation 1998-2016. All Rights Reserved.

   Name:         intu.c

   Description:  INAP Test Utility example application program using the
                 Dialogic INAP binary module and API interface.
                 The utility provides a simple number translation from
                 one known called party number to a new destination
                 routing address. This acts as a basis to build more complex
                 services as well as provide an example of using the
                 Dialogic INAP binary and API.

   Functions:    in_ent

   -----   ---------  -----     ------------------------------------
   Issue    Date       By        Changes
   -----   ---------  -----     ------------------------------------
     A     22-Dec-98   JET      - Initial code.
     B     22-Feb-99   JET      - Minor changes to reflect changes to parameter
                                  names.
     C     03-Jun-99   JET      - Added call to IN_version so API version is
                                  displayed on start-up. Changed ServiceKey
                                  lookup to handle variable lengths.
                                - Added additional error messages for invalid
                                  ServiceKeys
     D     08-Oct-99   JET      - Dialogue closed when SRV-IND received in wrong
                                  state.
     1     13-Jul-01   JET      - Allow operation with ACs from ITU-T CS-1,
                                  CAMEL v1, CAMEL v2 and ETSI CS-2.
     2     26-Jun-03   YTA      - Allow operation with ACs from CAP v3
     -     20-Jul-06   JTD      - Remove use of extern Protocol Definitions
                                - Updates to support INAPAPI DLL
     4     13-Dec-06   ML       - Change to use of Dialogic Corporation copyright.
     5     01-Dec-09   JLP      - Allow operation with ACs from CAP v4
     6     29-Mar-10   JLP      - INTU_rec_called_num() change plen from u8 to PLEN
     7     15-Mar-16   CJM      - Add option for INTU to use API Extended Dialog ID functions
                                - Tests for IN_LMSGS defined removed (no longer used by API)
 */

#include "intu_def.h"

/*
 * INTU
 * ====
 *
 * INTU operates as a state machine, with each state representing a point during
 * an INAP dialogue. A separate Dialogue Control Block (DLG_CB) exists for each
 * dialogue identifier in the supported range.
 *
 * The following Message Sequence Chart shows the messages that occur and the
 * expected flow through the state machine for a single dialogue. The messages
 * between INTU and the local INAP task.
 *
 *                INTU                             INAP
 *                =====                           =====
 *     (Note 1)     |                               |
 *                IDLE                              |
 *                  |        DLG-IND (OPEN)         |
 *     (Note 2)     | <---------------------------- |
 *                  |                               |
 *                OPEN                              |
 *                  |   SRV-IND (INVOKE:InitialDP)  |
 *     (Note 3)     | <---------------------------- |
 *                  |                               |
 *               PENDING                            |
 *               DELIMIT                            |
 *                  |       DLG-IND (DELIMIT)       |
 *                  | <---------------------------- |
 *     (Note 4)     |                               |
 *                  |      DLG-REQ (OPEN-RSP)       |
 *                  | ----------------------------> |
 *                  |                               |
 *                  |    SRV-REQ (INVOKE:Connect)   |
 *                  | ----------------------------> |
 *                  |                               |
 *                  |        DLG-REQ (DELIMIT)      |
 *                  | ----------------------------> |
 *                  |                               |
 *                  |        DLG-REQ (CLOSE)        |
 *                  | ----------------------------> |
 *                  |      (pre-arranged end)       |
 *                  |                               |
 *               CLOSING                            |
 *                  |        DLG-IND (CLOSE)        |
 *     (Note 5)     | <---------------------------- |
 *                  |                               |
 *                IDLE                              |
 *                  |                               |
 *
 * Note 1: Dialogue is idle
 *
 * Note 2: Dialogue OPEN indication causes the dialogue to be opened
 *
 * Note 3: The service key is checked if it matches the information needed
 *         to process the service is stored and prepared in the dialogue control
 *         block (DLG_CB) waiting for the delimit.
 *
 * Note 4: The delimit triggers the processing of the prepared service logic,
 *         In this case a simple number translation from one known number to
 *         another. If the called party address isn't recognised a ReleaseCall
 *         would be sent. INTU replies with an OPEN-RSP, INVOKE-Connect,
 *         DELIMIT, CLOSE(pre-arranged end).
 *
 * Note 5: The dialogue is waiting for INAP to tell it to close the dialogue.
 *         When the CLOSE comes the dialogue control block is reset.
 */

/*
 * Example numbers to use in number translation
 * e.g. 0800123456 translated to -> 01425651300
 */
static u8 example_freephone_num[]    = {0,8,0,0,1,2,3,4,5,6};
static u8 example_dest_routing_num[] = {0,1,4,2,5,6,5,1,3,0,0};

/*
 * Cause normal_unspecified
 */
static u8 example_release_cause[]= {0,0x80+INTU_cause_value_normal_unspecified};

/*
 * Example service key. This is the only service key recognised by this example
 * program. If the InitialDP does not use this service key INTU will respond
 * with U_ERROR.
 */
static u8 example_srv_key[] = {0xa,0xb,0xc,0xd};

/*
 * Module variables, updated by command line options in intu_main
 */
u8  intu_mod_id;      /* The task id of this module */
u8  inap_mod_id;      /* The task id of the INAP binary module*/
u16 num_dialogues;    /* The number of dialogues to support*/
u32 base_dialogue_id; /* The base number of the supported dialogue IDs */
u16 intu_options;     /* Defines which tracing options are configured */

/*
 * Module variables
 */
u32 last_dlg_id;      /* Last Dialog ID of configured range */

/*
 * Array of dialogue control blocks for dialogue ids
 * from (base_dialogue_id) to (base_dialogue_id + NUM_DIALOGUES - 1).
 */
DLG_CB dlg_data[MAX_NUM_DIALOGUES];

/*
 * Variables to log dialogue statistics
 */
static u16 active_dialogues = 0;
static u32 completed_dialogues = 0;
static u32 successful_dialogues = 0;

/*
 * main loop finished
 */
static int finished;


/*
 *******************************************************************************
 *                                                                             *
 * Main program loop                                                           *
 *                                                                             *
 *******************************************************************************
 */
int intu_ent()
{
  HDR    *h;             /* Received message */
  DLG_CB *dlg;           /* The control block for the dlg id of the received msg */
  u16    i;              /* loop counter */
  u16    min_rev;        /* INAP API major revision number */
  u16    maj_rev;        /* INAP API major revision number */
  char   *ident_text;    /* INAP API name in text */

  /*
   * Calculate last valid dialog ID
   */
  last_dlg_id = base_dialogue_id + num_dialogues - 1;

  /*
   * Check for configured number of dialogs too large
   */
  if (num_dialogues > MAX_NUM_DIALOGUES)
  {
    fprintf(stderr, "intu() : Not enough dialogue resources available\n");
    fprintf(stderr, "         0x%04x available, 0x%04x requested\n",
            MAX_NUM_DIALOGUES,
            num_dialogues);
    return(0);
  }

  /*
   * If not using Extended Dialog IDs, check that all dialog DIDs required only 16 bits
   */
  if ((intu_options & INTU_OPT_EXT_DLG) == 0)
  {
    if ((last_dlg_id > MAX_NON_EXT_DID) && (num_dialogues > 0))
    {
      fprintf(stderr, "intu() : Dialogue range requires use of Extended Dialog IDs option (0x%04x)\n", INTU_OPT_EXT_DLG);
      fprintf(stderr, "         last dialog in configured range is 0x%08lx\n", last_dlg_id);
      return(0);
    }
  }


  /*
   * Print banner so we know what's running:
   */
  printf(
  "INTU: Example INAP application (C) Dialogic Corporation 1997-2016. All Rights Reserved.\n");
  printf(
  "=======================================================================================\n\n");

  if (IN_version(&maj_rev, &min_rev, &ident_text) == IN_SUCCESS);
    printf("%s Version %i.%i\n",ident_text, maj_rev, min_rev);

  printf("INTU module ID - 0x%02x \nINAP module ID - 0x%02x\n",
          intu_mod_id, inap_mod_id);
  printf("Number of dialogues - 0x%04x (%i) \nBase dialogue ID - 0x%08lx\n",
          num_dialogues, num_dialogues, base_dialogue_id);
  printf("Options set - 0x%04x \n\n", intu_options);

  /*
   * Initialise the per-dialogue resources:
   */
   for (i=0; i<MAX_NUM_DIALOGUES; i++)
   {
     dlg = &dlg_data[i];
     dlg->state = INTU_STATE_IDLE;
     dlg->reply_prepared = INTU_REPLY_NONE;
     /*
      * dlg->cpt intialised when we receive the open indication
      */
   }

  /*
   * Now enter main loop, receiving messages as
   * they become available and processing accordingly:
   */
  finished = 0;
  while (!finished)
  {
    /*
     * GCT_receive will attempt to receive message
     * from the tasks message queue and block until
     * a message is ready:
     */
    if ((h = GCT_receive(intu_mod_id)) != 0)
    {
      switch (h->type)
      {
	case INAP_MSG_SRV_IND :
          INTU_srv_ind(h);
	  break;

      	case INAP_MSG_DLG_IND :
          INTU_dlg_ind(h);
	  break;

	default :
	  INTU_disp_other_msg(h);
	  break;
      }

      /*
       * Once we have finished processing the message
       * it must be released to the pool of messages.
       */
      relm(h);
    }
  }
  return(0);
}

/*
 *******************************************************************************
 *                                                                             *
 * Message handling state machines                                             *
 *                                                                             *
 *******************************************************************************
 */

/*
 * INTU_dlg_ind handles dialogue indications
 *
 * Returns 0 on success
 *         INTUE_INVALID_DLG_ID if the dialogue id was invalid
 *         INTUE_MSG_DECODE_ERROR if the message could not be decoded
 */
int INTU_dlg_ind(h)
  HDR *h;                  /* Received message */
{
  DLG_CB *dlg_ptr;         /* Pointer to the per-dialogue id control block */
  u32    ic_dlg_id;        /* Dialogue id of the incoming dialogue indication */
  u8     dialogue_type;    /* Type of the incoming dialogue indication */
  int    decode_status;    /* Return status of the dialogue type recovery */

  /*
   * Find the dialogue ID from the received message
   */
  dlg_ptr = INTU_get_dlg_cb(&ic_dlg_id, h);
  if (dlg_ptr == 0)
    return(INTUE_INVALID_DLG_ID);

  /*
   * We know the message is a Dialogue Indication but what type is it...
   * OPEN, CLOSE, DELIMIT, P_ABORT, U_ABORT, NOTICE or OPEN_RSP
   */
  decode_status = IN_get_dialogue_type(h, &dialogue_type);

  if (decode_status != IN_SUCCESS)
  {
    INTU_disp_other_msg(h);
    return(INTUE_MSG_DECODE_ERROR);
  }

  /*
   * If dialogue indication tracing is enabled display the message
   */
  if (intu_options & INTU_OPT_TR_DLG_IND)
    INTU_disp_dlg_msg(ic_dlg_id, h);

  /*
   * Switch on the current state of the dialogue control block for the
   * incoming dialogue indication.
   */
  switch (dlg_ptr->state)
  {
     /*
      * INTU_STATE_IDLE:
      * In this state we expect to receive only OPEN indications
      */
     case INTU_STATE_IDLE:
       if (dialogue_type == INDT_OPEN)
       {
         INTU_open_dialogue(ic_dlg_id, dlg_ptr, h);
       }
       else
       {
         INTU_disp_unexpected_dlg_ind(ic_dlg_id, dlg_ptr, h);
         INTU_send_u_abort(ic_dlg_id);
       }
       break;

     /*
      * INTU_STATE_OPEN:
      * In this state we wouldn't expect to receive a dialogue indication if the
      * dialogue is progressing normally but some indications are still valid.
      * For example a failure in the network could result in a P_ABORT.
      */
     case INTU_STATE_OPEN:
       switch (dialogue_type)
       {
         case INDT_OPEN:
           INTU_disp_dlg_reopened(ic_dlg_id, dlg_ptr, h);
           INTU_open_dialogue(ic_dlg_id, dlg_ptr, h);
           break;
         case INDT_CLOSE:
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         case INDT_DELIMIT:
           INTU_disp_unexpected_dlg_ind(ic_dlg_id, dlg_ptr, h);
           break;
         case INDT_U_ABORT:
         case INDT_P_ABORT:
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         case INDT_NOTICE:
           INTU_prepare_u_abort(ic_dlg_id, dlg_ptr);
           break;
         case INDT_OPEN_RSP:
           INTU_disp_unexpected_dlg_ind(ic_dlg_id, dlg_ptr, h);
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         default:
           INTU_disp_invalid_dlg_ind(ic_dlg_id, dlg_ptr, h);
           break;
       }
       break;

     /*
      * INTU_STATE_PENDING_DELIMIT:
      * In this state we are waiting for the DELIMIT to trigger any service
      * logic waiting to be processed.
      */
     case INTU_STATE_PENDING_DELIMIT:
       switch (dialogue_type)
       {
         case INDT_OPEN:
           INTU_disp_dlg_reopened(ic_dlg_id, dlg_ptr, h);
           INTU_open_dialogue(ic_dlg_id, dlg_ptr, h);
           break;
         case INDT_CLOSE:
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         case INDT_DELIMIT:
           INTU_process_pending_req(ic_dlg_id, dlg_ptr, h);
           break;
         case INDT_U_ABORT:
         case INDT_P_ABORT:
         case INDT_NOTICE:
         case INDT_OPEN_RSP:
           INTU_disp_unexpected_dlg_ind(ic_dlg_id, dlg_ptr, h);
           INTU_send_u_abort(ic_dlg_id);
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         default:
           INTU_disp_invalid_dlg_ind(ic_dlg_id, dlg_ptr, h);
           break;
       }
       break;

     /*
      * INTU_STATE_CLOSING:
      * In this state we have already sent a CLOSE DLG-REQ with pre-arranged end
      * and are just waiting to receive the CLOSE DLG-IND from INAP.
      */
     case INTU_STATE_CLOSING:
       switch(dialogue_type)
       {
         case INDT_OPEN:
           INTU_disp_dlg_reopened(ic_dlg_id, dlg_ptr, h);
           INTU_open_dialogue(ic_dlg_id, dlg_ptr, h);
           break;
         case INDT_CLOSE:
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_SUCCESS);
           break;
         case INDT_DELIMIT:
         case INDT_U_ABORT:
         case INDT_P_ABORT:
         case INDT_NOTICE:
         case INDT_OPEN_RSP:
           INTU_disp_unexpected_dlg_ind(ic_dlg_id, dlg_ptr, h);
           INTU_send_u_abort(ic_dlg_id);
           INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
           break;
         default:
           INTU_disp_invalid_dlg_ind(ic_dlg_id, dlg_ptr, h);
           break;
       }
       break;

     default:
       break;
  }

  return(0);
}

/*
 * INTU_srv_ind handles service indications for on a dialogue
 *
 * Returns 0 on success,
 *         INTUE_INVALID_DLG_ID if the dialogue id was invalid
 *         INTUE_MSG_DECODE_ERROR if the component type could not be decoded
 */
int INTU_srv_ind(h)
  HDR *h;                  /* Received message */
{
  DLG_CB *dlg_ptr;         /* Pointer to the per-dialogue id control block */
  u32    ic_dlg_id;        /* Dialogue id of the incoming dialogue indication */
  u8     cpt_type;         /* Type of the incoming service indication */
  int    decode_status;    /* Return status of the component type recovery */

  /*
   * Find the dialogue ID from the received message
   */
  dlg_ptr = INTU_get_dlg_cb(&ic_dlg_id, h);
  if (dlg_ptr == 0)
    return(INTUE_INVALID_DLG_ID);

  decode_status = IN_get_component_type(h, &cpt_type);

  if (decode_status != IN_SUCCESS)
  {
    INTU_disp_other_msg(h);
    return(INTUE_MSG_DECODE_ERROR);
  }

  if (intu_options & INTU_OPT_TR_SRV_IND)
    INTU_disp_srv_ind(ic_dlg_id, dlg_ptr, h);

  switch (dlg_ptr->state)
  {
     /*
      * INTU_STATE_IDLE:
      * The dialogue is not yet open, print the unexpected message.
      */
     case INTU_STATE_IDLE:
       INTU_disp_unexpected_srv_ind(ic_dlg_id, dlg_ptr, h);
       INTU_send_u_abort(ic_dlg_id);
       break;

     /*
      * INTU_STATE_OPEN:
      * In this state we would expect to receive a service indication with the
      * INVOKE (InitialDP). Handle this INVOKE to prepare the service logic.
      */
     case INTU_STATE_OPEN:
       switch (cpt_type)
       {
         case INCPT_INVOKE:
           INTU_handle_invoke(ic_dlg_id, dlg_ptr, h);
           break;
         case INCPT_RESULT_L:
         case INCPT_U_ERROR:
         case INCPT_NULL:
           INTU_disp_unexpected_srv_ind(ic_dlg_id, dlg_ptr, h);
           INTU_prepare_u_abort(ic_dlg_id, dlg_ptr);
           break;
         default:
           INTU_disp_invalid_srv_ind(ic_dlg_id, dlg_ptr, h);
           break;
       }
       break;

     /*
      * INTU_STATE_PENDING_DELIMIT:
      * We're waiting for a DELIMIT, we shouldn't expect any more SRV-IND in
      * this state.
      *
      * INTU_STATE_CLOSING:
      * We're waiting for a CLOSE, we shouldn't expect any more SRV-IND in
      * this state.
      */
     case INTU_STATE_PENDING_DELIMIT:
     case INTU_STATE_CLOSING:
       INTU_disp_unexpected_srv_ind(ic_dlg_id, dlg_ptr, h);
       INTU_send_u_abort(ic_dlg_id);
       INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
       break;

     default:
       break;
  }

  return(0);
}

/*
 *******************************************************************************
 *                                                                             *
 * Processing procedures                                                       *
 *                                                                             *
 *******************************************************************************
 */

/*
 * INTU_change_state handles the changing of state for dialogue control blocks.
 *
 * Returns 0
 */
int INTU_change_state(ic_dlg_id, dlg_ptr, new_state)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  u8     new_state;      /* New state to change the dlg pointed to by dlg_ptr */
{
  if (dlg_ptr != 0)
  {
    INTU_disp_state_change(ic_dlg_id, dlg_ptr, new_state);
    dlg_ptr->state = new_state;
  }

  return(0);
}

/*
 * INTU_open_dialogue()
 *
 * Checks the application context in index form against the supported contexts
 * and opens the dialogue control block for the dialogue id of the incoming
 * message. Dialogue statistics are updated and the dialogue state is set
 * to OPEN.
 *
 * Returns: 0 on success
 *          INTUE_INVALID_APPLIC_CONTEXT - if the application context was
 *                                         invalid or unsupported.
 *          INTUE_INIT_CPT_FAILED - if the component structure in the DLG_CB
 *                                  could not be initialised.
 */
int INTU_open_dialogue(ic_dlg_id, dlg_ptr, h)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  HDR    *h;             /* Received message */
{
  void  *prot_ptr;
  int   status;
  u16   dlg_ac_idx;
  u8    ac_index_data[2];
  PLEN  ac_index_data_len;

  status = IN_get_dialogue_param(INDP_applic_context_index, &ac_index_data_len,
                        ac_index_data, sizeof(ac_index_data), h);

  if (status != IN_SUCCESS)
  {
    fprintf(stderr,"INTU: *** No application context index  ***\n");
    return(INTUE_INVALID_APPLIC_CONTEXT);
  }
  if ((ac_index_data_len > 2) || (ac_index_data_len == 0))
  {
    fprintf(stderr,"INTU: *** Invalid application context index  ***\n");
    return(INTUE_INVALID_APPLIC_CONTEXT);
  }
  else
  {
    if (ac_index_data_len == 2)
      dlg_ac_idx = (ac_index_data[1] << 8) & 0xff00 + ac_index_data[0] & 0xff;
    else
      dlg_ac_idx = ac_index_data[0];

    prot_ptr = INTU_get_protocol_definition(dlg_ac_idx);

    if (prot_ptr != 0)
    {
      status = IN_init_component(prot_ptr, &dlg_ptr->cpt, 0);
      if (status != IN_SUCCESS)
        return(INTUE_INIT_CPT_FAILED);
    }
    else
    {
      fprintf(stderr, "INTU: *** Unsupported application context index ***\n");
      return(INTUE_INVALID_APPLIC_CONTEXT);
    }

    dlg_ptr->reply_prepared = INTU_REPLY_NONE;

    /*
     * If the dialogue was not idle then it is being re-opened and the old
     * dialogue is complete
     */
    if (dlg_ptr->state != INTU_STATE_IDLE)
      completed_dialogues++;

    /*
     * New active dialogue opening
     */
    active_dialogues++;
    INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_OPEN);

    if (intu_options & INTU_OPT_TR_ACTV_DLG)
    {
      printf(
      "INTU: Dialogues: Active [%i], Completed [%i], Successful [%i], Failed [%i]\n",
      active_dialogues, completed_dialogues, successful_dialogues,
      completed_dialogues - successful_dialogues);
    }

    return(0);
  }
}

/*
 * INTU_close_dialogue()
 *
 * Check for a pending reply, if one exists print a warning. Return the
 * dialogue state to IDLE and update the dialogue statistics.
 *
 * Returns 0
 */
int INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, dlg_close_rsn)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  HDR    *h;             /* Received message */
  u8     dlg_close_rsn;  /* Set to INTU_DLG_SUCCESS if the dialogue completed */
                         /* as expected. */
{
  switch (dlg_ptr->reply_prepared)
  {
    case INTU_REPLY_NONE:
      break;

    case INTU_REPLY_INVOKE:
    case INTU_REPLY_ERROR:
    case INTU_REPLY_REJECT:
    case INTU_REPLY_U_ABORT:
      if (intu_options & INTU_OPT_TR_ACTV_DLG)
      {
        printf("INTU: *** Dialogue 0x%04x closing with pending reply [%i]***\n",
        ic_dlg_id,dlg_ptr->reply_prepared);
      }

      break;

    default:
      break;
  }

  /*
   * Active dialogue closing, Another dialogue completed
   */
  active_dialogues--;
  completed_dialogues++;

  if (dlg_close_rsn == INTU_DLG_SUCCESS)
    successful_dialogues++;

  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_IDLE);

  if (intu_options & INTU_OPT_TR_ACTV_DLG)
  {
    printf(
    "INTU: Dialogues: Active [%i], Completed [%i], Successful [%i], Failed [%i]\n",
    active_dialogues, completed_dialogues, successful_dialogues,
    completed_dialogues - successful_dialogues);
  }

  return(0);
}

/*
 * INTU_handle_invoke()
 *
 */
int INTU_handle_invoke(ic_dlg_id, dlg_ptr, h)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  HDR    *h;             /* Received message */
{
  SERVICE_KEY_TYPE srv_key;       /* Recovered service key of the InitialDP */
  IN_CPT           *dlg_cpt_ptr;  /* Recovered INAP Component */
  int              status;        /* Return status fron INAP API functions */
  u16              op_code;       /* Opcode of the recovered invoke */

  dlg_cpt_ptr = &(dlg_ptr->cpt);

  status = IN_decode_operation(dlg_cpt_ptr, h);

  if (status != IN_SUCCESS)
  {
    if (status == IN_REJECT_REQUIRED)
    {
      fprintf(stderr,"INTU: *** Operation Invoke rejected ***\n");
      INTU_prepare_reject(ic_dlg_id, dlg_ptr);
      return(INTUE_MSG_REJECTED);
    }
    else
    {
      fprintf(stderr,"INTU: *** Operation Invoke decoding failed [%i] ***\n", status);
      INTU_prepare_u_abort(ic_dlg_id, dlg_ptr);
      return(INTUE_MSG_DECODE_ERROR);
    }
  }

  IN_get_operation(dlg_cpt_ptr, &op_code);

  if (op_code == INOP_InitialDP)
  {
    status = IN_get_component_param (INPN_ServiceKey,
                                         &srv_key.len,
                                          srv_key.data,
                                   sizeof(srv_key.data),dlg_cpt_ptr);

    if (status != IN_SUCCESS)
    {
      INTU_prepare_u_abort(ic_dlg_id, dlg_ptr);

      fprintf(stderr,
      "INTU: *** Operation Invoke processing failed [%i] ***\n", status);
    }
    else
    {
      if (intu_options & INTU_OPT_TR_SRV_PARAM)
        INTU_disp_param("ServiceKey", INPN_ServiceKey,srv_key.len,srv_key.data);

      /*
       * If service Key does not match, send error MissingCustomerRecord
       */
      if ((srv_key.len == sizeof(example_srv_key)) &&
          (memcmp(example_srv_key, srv_key.data, srv_key.len) == 0))
      {
        INTU_prepare_service_logic(ic_dlg_id, dlg_ptr);
      }
      else
      {
        fprintf(stderr,
        "INTU: *** Unexpected ServiceKey, sending MissingCustomerRecord ***\n");
        INTU_prepare_error(ic_dlg_id, dlg_ptr, INER_MissingCustomerRecord);
      }
    }
  }
  else
  {
    fprintf(stderr,"INTU: *** Unexpected operation [%i]***\n", op_code);
    INTU_prepare_u_abort(ic_dlg_id, dlg_ptr);
  }

  return(0);
}

/*
 * INTU_prepare_service_logic()
 *
 * Mark the reply prepared as invoke
 *
 * Returns 0
 */
int INTU_prepare_service_logic(ic_dlg_id, dlg_ptr)
  u32  ic_dlg_id;        /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
{
  /*
   * All the info we need is already decoded into the dlg->cpt structure
   * so just change state and wait for the delimit.
   */
  dlg_ptr->reply_prepared = INTU_REPLY_INVOKE;
  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_PENDING_DELIMIT);

  return(0);
}

/*
 * INTU_prepare_error()
 *
 * Mark the reply prepared as error
 *
 * Returns 0
 */
int INTU_prepare_error(ic_dlg_id, dlg_ptr, err_code)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  u16    err_code;       /* Error code being prepared */
{
  IN_set_error(dlg_ptr->cpt.operation, err_code, &(dlg_ptr->cpt));

  dlg_ptr->reply_prepared = INTU_REPLY_ERROR;
  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_PENDING_DELIMIT);

  return(0);
}

/*
 * INTU_prepare_reject()
 *
 * Mark the reply prepared as reject
 *
 * Returns 0
 */
int INTU_prepare_reject(ic_dlg_id, dlg_ptr)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
{
  /*
   * The decode operation_invoke stored the problem code into the cpt
   * structure so we have all the info we need.
   */
  dlg_ptr->reply_prepared = INTU_REPLY_REJECT;

  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_PENDING_DELIMIT);

  return(0);
}

/*
 * INTU_prepare_u_abort()
 *
 * Mark the reply prepared as u_abort
 *
 * Returns 0
 */
int INTU_prepare_u_abort(ic_dlg_id, dlg_ptr)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
{
  dlg_ptr->reply_prepared = INTU_REPLY_U_ABORT;

  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_PENDING_DELIMIT);

  return(0);
}

/*
 * INTU_process_pending_req()
 *
 * We should have a reply waiting to be sent or service logic waiting to be
 * processed. So check for the reply stored in the DLG_CB and process it.
 *
 * Returns 0
 */
int INTU_process_pending_req(ic_dlg_id, dlg_ptr, h)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  HDR    *h;             /* Received message */
{
  u8 reply;              /* Reply prepared before processing */

  reply = dlg_ptr->reply_prepared;

  /*
   * Reset the reply_prepared so we know we've tried to process it once.
   */
  dlg_ptr->reply_prepared = INTU_REPLY_NONE;

  switch (reply)
  {
    case INTU_REPLY_INVOKE:
      /*
       * Process_invoke changes to correct state internally.
       */
      INTU_process_invoke(ic_dlg_id, dlg_ptr, h);
      /*
       * Invoke processing complete, so return.
       */
      return(0);

    case INTU_REPLY_ERROR:
      INTU_send_open_rsp(ic_dlg_id);
      INTU_send_error(ic_dlg_id, dlg_ptr);
      INTU_send_close(ic_dlg_id, INAPRM_normal_release);
      break;

    case INTU_REPLY_REJECT:
      INTU_send_open_rsp(ic_dlg_id);
      INTU_send_reject(ic_dlg_id, dlg_ptr);
      INTU_send_close(ic_dlg_id, INAPRM_normal_release);
      break;

    case INTU_REPLY_U_ABORT:
      INTU_send_u_abort(ic_dlg_id);
      break;

    case INTU_REPLY_NONE:
      break;

    default:
      break;
  }

  /*
   * For all replies except invoke processing close the dialogue.
   */
  INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
  return(0);
}

/*
 * INTU_process_invoke()
 *
 * If the invokeID in the previously decoded service indication is invalid
 * an UnexpectedDataValue error is sent back to the remote end. For valid
 * invokeIDs either a Connect or a ReleaseCall operation is sent back depending
 * on the status returned by the number translation (Connect on success).
 *
 * Returns 0 on success
 *         INTUE_INVALID_INVOKE_ID
 *         INTUE_MSG_ALLOC_FAILED
 *         INTUE_MSG_DECODE_ERROR
 *         INTUE_CODING_FAILURE
 */
int INTU_process_invoke(ic_dlg_id, dlg_ptr, h)
  u32    ic_dlg_id;      /* Dialogue id of the incoming dialogue indication */
  DLG_CB *dlg_ptr;       /* Pointer to the per-dialogue id control block */
  HDR    *h;             /* Received message */
{
  PTY_ADDR called_pty;           /* Stores the recovered calling party number */
  PTY_ADDR dest_routing_addr;    /* Holds the outgoing destination number */

  u8   called_pty_param[INTU_max_called_party_num_len]; /*Called party in octets*/
  PLEN called_pty_plen;                                 /* Size of param */
  u8   dest_addr_param[INTU_max_called_party_num_len];  /* Dest Addr in octets */
  PLEN dest_addr_plen;                                  /* Size of param */

  IN_CPT *dlg_cpt_ptr;       /* Holds recovered INAP component */
  IN_CPT og_cpt;             /* Holds INAP component whilst building into message */
  HDR    *og_h;              /* Message used to send immediate replies */
  int    status;             /* Return code from INAP API functions */
  PLEN   invokeID_len = 0;   /* Octet length of InvokeID */
  u8     invokeID = 0;       /* Invoke ID of the incoming IntialDP */

  /*
   * Respond to the Open Request
   */
  INTU_send_open_rsp(ic_dlg_id);

  dlg_cpt_ptr = &(dlg_ptr->cpt);

  /*
   * Initialise the component used to build invoke replies
   */
  IN_init_component(dlg_cpt_ptr->prot_spec, &og_cpt, 0);

  /*
   * Get the invokeID, add 128 (0x80) and reply with that.
   * InvokeID chosen to be (0   to 127) Incoming
   *                       (128 to 255) Outgoing
   */
  status = IN_get_component_param(INPN_InvokeID, &invokeID_len, &invokeID, 1, dlg_cpt_ptr);

  /*
   * Check the invokeID isn't outside the expected range
   */
  if ((status != IN_SUCCESS) || (invokeID > 127))
  {
    if (status != IN_SUCCESS)
      fprintf(stderr, "INTU: *** No Invoke ID for dialogue ID 0x%08lx ***\n", ic_dlg_id);
    else
      fprintf(stderr, "INTU: *** Invalid Invoke ID 0x%02x for dialogue ID 0x%08lx ***\n", invokeID, ic_dlg_id);

    IN_set_error(dlg_ptr->cpt.operation, INER_UnexpectedDataValue, &(dlg_ptr->cpt));
    INTU_send_error(ic_dlg_id, dlg_ptr);
    INTU_send_close(ic_dlg_id, INAPRM_normal_release);
    INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
    return(INTUE_INVALID_INVOKE_ID);
  }
  else
  {
    invokeID += 128;
    IN_set_component_param(INPN_InvokeID, 1, &invokeID, &og_cpt);
  }

  if ((og_h = IN_alloc_message(0)) == 0)
  {
    /*
     * We can't get a message to reply with so just return
     */
    fprintf(stderr,
    "INTU: *** Failed allocate MSG for dialogue ID 0x%08lx ***\n", ic_dlg_id);

    return(INTUE_MSG_ALLOC_FAILED);
  }

  /*
   * Get the called party number
   */
  status = IN_get_component_param(INPN_CalledPartyNumber,
                                      &called_pty_plen,
                                       called_pty_param,
                                sizeof(called_pty_param), dlg_cpt_ptr);

  if (status != IN_SUCCESS)
  {
    if (status == IN_PARAM_NOT_FOUND)
    {
      fprintf(stderr,
      "INTU: *** Missing called party number for dialogue ID 0x%08lx ***\n",
      ic_dlg_id);

      IN_set_error(dlg_ptr->cpt.operation, INER_MissingParameter, &og_cpt);

      if (intu_options & INTU_OPT_EXT_DLG)
        IN_EXT_code_error(ic_dlg_id, &og_cpt,og_h);
      else
        IN_code_error((u16)ic_dlg_id, &og_cpt,og_h);

      if (INTU_send_message(intu_mod_id, inap_mod_id, og_h) != IN_SUCCESS)
         IN_free_message(og_h);
      INTU_send_close(ic_dlg_id, INAPRM_normal_release);
      INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
    }
    else
    {
      fprintf(stderr,
      "INTU: *** Error decoding called party number for dialogue ID 0x%08lx ***\n",
      ic_dlg_id);

      INTU_send_u_abort(ic_dlg_id);
      INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
    }
    return(INTUE_MSG_DECODE_ERROR);
  }

  if (INTU_rec_called_num(&called_pty,called_pty_param,called_pty_plen) != 0)
  {
    fprintf(stderr,
    "INTU: *** Error recovering called party number for dialogue ID 0x%08lx ***\n",
    ic_dlg_id);

    INTU_send_u_abort(ic_dlg_id);
    INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
    return(INTUE_MSG_DECODE_ERROR);
  }

  if (INTU_translate_number(&called_pty,&dest_routing_addr) != 0)
  {
    /*
     * We couldn't translate, but the dialogue itself is still successful.
     * Now build and send a ReleaseCall...
     */

    IN_set_component_param (INPN_Cause, sizeof(example_release_cause),
                                        example_release_cause, &og_cpt);
    IN_set_operation(INOP_ReleaseCall, INTU_ReleaseCall_timeout, &og_cpt);

    if (intu_options & INTU_OPT_EXT_DLG)
      status = IN_EXT_code_operation_invoke(ic_dlg_id, &og_cpt, og_h);
    else
      status = IN_code_operation_invoke((u16)ic_dlg_id, &og_cpt, og_h);

    if (status == IN_SUCCESS)
    {
       if (INTU_send_message(intu_mod_id, inap_mod_id, og_h) != IN_SUCCESS)
         IN_free_message(og_h);

       INTU_send_close(ic_dlg_id, INAPRM_normal_release);
       INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_SUCCESS);
       return(0);
    }
    else
    {
      fprintf(stderr,
      "INTU: *** Failed to encode invoke for dialogue ID 0x%08lx [%i] ***\n",
      ic_dlg_id, status);

      INTU_send_close(ic_dlg_id, INAPRM_normal_release);
      INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
      return(INTUE_CODING_FAILURE);
    }
  }
  else
  {
    /*
     * Build and send Connect...
     */
    dest_addr_plen = INTU_fmt_called_num(dest_addr_param,
                                  sizeof(dest_addr_param),
                                        &dest_routing_addr);
    /*
     * Copy the called party number into the original called party number
     */
    IN_set_component_param(INPN_OriginalCalledPartyID,
                                called_pty_plen,
                                called_pty_param,
                                &og_cpt);
    /*
     * Copy the destination routing address into the cpt
     */
    IN_set_component_param(INPN_DestinationRoutingAddress(0),
                                dest_addr_plen,
                                dest_addr_param,
                                &og_cpt);
    IN_set_operation(INOP_Connect, INTU_Connect_timeout, &og_cpt);
  }

  if (intu_options & INTU_OPT_EXT_DLG)
    status = IN_EXT_code_operation_invoke(ic_dlg_id, &og_cpt, og_h);
  else
    status = IN_code_operation_invoke((u16)ic_dlg_id, &og_cpt, og_h);

  if (status == IN_SUCCESS)
  {
    if (INTU_send_message(intu_mod_id, inap_mod_id, og_h) != IN_SUCCESS)
      IN_free_message(og_h);
  }
  else
  {
    fprintf(stderr,
    "INTU: *** Failed to encode invoke for dialogue ID 0x%08lx [%i] ***\n",
    ic_dlg_id, status);

    INTU_send_close(ic_dlg_id, INAPRM_normal_release);
    INTU_close_dialogue(ic_dlg_id, dlg_ptr, h, INTU_DLG_FAILED);
    return(INTUE_CODING_FAILURE);
  }

  /*
   * Send delimit, then Close pre-arranged end, finally goto closing state
   */
  INTU_send_delimit(ic_dlg_id);
  INTU_send_close(ic_dlg_id, INAPRM_prearranged_end);
  INTU_change_state(ic_dlg_id, dlg_ptr, INTU_STATE_CLOSING);

  return(0);
}

/*
 *******************************************************************************
 *                                                                             *
 * Helper procedures                                                           *
 *                                                                             *
 *******************************************************************************
 */

/*
 * INTU_get_dlg_cb()
 *
 * Returns recovered dialog id and pointer to the dialogue control block,
 * if the dialogue id was in the valid range.
 * Returns 0 otherwise.
 */
DLG_CB *INTU_get_dlg_cb(dlg_id, h)
  u32  *dlg_id;         /* Pointer to recovered Dialogue id */
  HDR  *h;              /* Received message */
{
  int  decode_status;   /* Return status of the dialogue type recovery */
  u16  did = 0;         /* Dialog ID used when not using Extended DIDs */

  /*
   * Find the dialogue ID from the received message
   */
  if (intu_options & INTU_OPT_EXT_DLG)
    decode_status = IN_EXT_get_dialogue_id(dlg_id, h);
  else
  {
    decode_status = IN_get_dialogue_id(&did, h);
    *dlg_id = (u32)did;
  }

  if (decode_status != IN_SUCCESS)
  {
    fprintf(stderr,
    "INTU: *** Error recovering Dialogue ID from received message ***\n");

    INTU_disp_other_msg(h);
    return(NULL);
  }

  /*
   * Check that the dialogue ID is in a valid range
   */
  if ((*dlg_id < base_dialogue_id) || (*dlg_id > last_dlg_id))
  {
    fprintf(stderr,
    "INTU: *** Dialogue ID 0x%08lx out of valid range [0x%08lx to 0x%08lx] ***\n",
    *dlg_id, base_dialogue_id, last_dlg_id);

    return(NULL);
  }

  /*
   * Return the dialogue record for this dialogue ID
   */
  return(&dlg_data[*dlg_id - base_dialogue_id]);
}

/*
 * IN_get_protocol_definition()
 *
 * Returns a pointer to the protocol defintion to use for the given application
 * context. Returns 0 if the lookup failed.
 */
void *INTU_get_protocol_definition(applic_context_index)
  u16 applic_context_index; /* Applic Context Index of protocol to be used */
{
 											 
  switch (applic_context_index)
  {
    case INETS_AC_CS1_SSP_TO_SCP:
    case INETS_AC_CS1_ASSIST_HANDOFF_TO_SSP_TO_SCP:
    case INETS_AC_CS1_IP_TO_SCP:
    case INETS_AC_CS1_SCP_TO_SSP:
    case INETS_AC_CS1_SCP_TO_SSP_TRAFFIC_MANAGEMENT:
    case INETS_AC_CS1_SCP_TO_SSP_SERVICE_MANAGEMENT:
    case INETS_AC_CS1_SSP_TO_SCP_SERVICE_MANAGEMENT:
      return(IN_get_prot_spec(INETS_300_374_1_PROTOCOL));

    case INITU_CS1_SSF_TO_SCF_GENERIC_AC:
    case INITU_CS1_SSF_TO_SCF_DPSPECIFIC_AC:
    case INITU_CS1_ASSIST_HANDOFF_SSF_TO_SCF_AC:
    case INITU_CS1_SRF_TO_SCF_AC:
    case INITU_CS1_SCF_TO_SSF_AC:
    case INITU_CS1_DP_SPECIFIC_SCF_TO_SSF_AC:
    case INITU_CS1_SCF_TO_SSF_TRAFFIC_MANAGEMENT_AC:
    case INITU_CS1_SCF_TO_SSF_SERVICE_MANAGEMENT_AC:
    case INITU_CS1_SSF_TO_SCF_SERVICE_MANAGEMENT_AC:
    case INITU_CS1_SCF_TO_SSF_STATUS_REPORTING_AC:
      return(IN_get_prot_spec(INITU_Q1218_PROTOCOL));

    case INCAP_V1_GSMSSF_TO_GSMSCF:
      return(IN_get_prot_spec(INCAP_V1_PROTOCOL));

    case INCAP_V2_GSMSSF_TO_GSMSCF:
    case INCAP_V2_ASSIST_HANDOFF_GSMSSF_TO_GSMSCF:
    case INCAP_V2_GSMSRF_TO_GSMSCF:
      return(IN_get_prot_spec(INCAP_V2_PROTOCOL));

    case INETS_AC_CS2_SSF_SCF_GENERIC:
    case INETS_AC_CS2_SSF_SCF_ASSIST_HANDOFF:
    case INETS_AC_CS2_SSF_SCF_SERVICE_MANAGEMENT:
    case INETS_AC_CS2_SCF_SSF_GENERIC:
    case INETS_AC_CS2_SCF_SSF_TRAFFIC_MANAGEMENT:
    case INETS_AC_CS2_SCF_SSF_SERVICE_MANAGEMENT:
    case INETS_AC_CS2_SCF_SSF_TRIGGER_MANAGEMENT:
    case INETS_AC_CS2_SRF_SCF:
    case INETS_AC_CS2_SCF_SCF_OPERATIONS:
    case INETS_AC_CS2_DISTRIBUTED_SCF_SYSTEM:
    case INETS_AC_CS2_SCF_SCF_OPERATIONS_WITH_3SE:
    case INETS_AC_CS2_DISTRIBUTED_SCF_SYSTEM_WITH_3SE:
    case INETS_AC_CS2_SCF_CUSF:
    case INETS_AC_CS2_CUSF_SCF:
      return(IN_get_prot_spec(INEN_301_140_1_PROTOCOL));

    case INCAP_V3_GSMSSF_TO_GSMSCF_GENERIC:
    case INCAP_V3_ASSIST_HANDOFF_GSMSSF_TO_GSMSCF:
    case INCAP_V3_GSMSRF_TO_GSMSCF:
    case INCAP_V3_GPRSSSF_TO_GSMSCF:
    case INCAP_V3_GSMSCF_TO_GPRSSSF:
    case INCAP_V3_SMS:
      return(IN_get_prot_spec(INCAP_V3_PROTOCOL));

    case INCAP_V4_GSMSSF_TO_GSMSCF_GENERIC:
    case INCAP_V4_ASSIST_HANDOFF_GSMSSF_TO_GSMSCF:
    case INCAP_V4_SCF_TO_GSMSSF_GENERIC:
    case INCAP_V4_GSMSRF_TO_GSMSCF:
    case INCAP_V4_GPRSSSF_TO_GSMSCF:
    case INCAP_V4_GSMSCF_TO_GPRSSSF:
    case INCAP_V4_SMS:
    return(IN_get_prot_spec(INCAP_V4_PROTOCOL));

    case INCAP_V4_IM_SSF_TO_GSMSCF_GENERIC:
      return(IN_get_prot_spec(INCAP_IMS_PROTOCOL));

    default:
      return(0);
  }

  return(0);
}

/*
 * INTU_translate_number()
 *
 * Returns 0 on successful number translation
 *         INTUE_NUM_TRANSLATE_FAILED otherwise
 */
int INTU_translate_number(old_num, new_num)
  PTY_ADDR *old_num;       /* Old called party number */
  PTY_ADDR *new_num;       /* New destination routing number */
{
  u8  called_pty_dgt_str[INTU_NUMBER_OF_DIGITS];/* Called party digits */
  u8  num_digits;                               /* number of called pty digits*/
  int i;                                        /* loop counter */

  num_digits = old_num->naddr;

  /*
   * Copy the whole orignal called party address onto the destination routing
   * address before looking at the actual digits.
   */
  memcpy((void *) new_num, (void *) old_num, sizeof(PTY_ADDR));

  if (num_digits > 0)
  {
    unpack_digits(called_pty_dgt_str, old_num->addr, 0, num_digits);

    if (intu_options & INTU_OPT_TR_NUM_TRANS)
    {
      printf("INTU: Called Party [");
      for (i=0;i<num_digits;i++)
        printf("%1.1x",called_pty_dgt_str[i]);
    }

    /*
     * Does the recovered called party number match our example freephone number
     */
    if ((memcmp(called_pty_dgt_str,example_freephone_num,num_digits) == 0) &&
        (num_digits == sizeof(example_freephone_num)))
    {
      num_digits = sizeof(example_dest_routing_num);
      pack_digits(new_num->addr, 0, example_dest_routing_num, num_digits);
      new_num->naddr = num_digits;

      if (intu_options & INTU_OPT_TR_NUM_TRANS)
      {
        printf("], Dest Routing Addr [");
        for (i=0;i<num_digits;i++)
          printf("%1.1x",example_dest_routing_num[i]);

        printf("]\n");
      }

      return(0);
    }
    else
    {
      if (intu_options & INTU_OPT_TR_NUM_TRANS)
        printf("], Releasing Call\n");

      return(INTUE_NUM_TRANSLATE_FAILED);
    }
  }
  else
  {
    return(INTUE_NUM_TRANSLATE_FAILED);
  }
}

/*
 * INTU_fmt_called_num()
 *
 * Returns formated length, 0 on failure
 */
u8 INTU_fmt_called_num(buf, siz, called_num)
  u8     	*buf;         /* pointer into message buffer */
  u8		siz;          /* size of buffer */
  PTY_ADDR      *called_num;  /* called party number to format */
{
  u8		oddn, adlen, *addr, iCt;

  /*
   * Verify that there is sufficient buffer space
   * for fixed fields and 'naddr' addres digits.
   */
  adlen = (called_num->naddr + 1) >> 1;
  if (siz < (adlen + 2))
    return(0);
  else
  {
    /*
     * Pack fixed fields
     */
    oddn = bit_from_byte(called_num->naddr, 0);
    bit_to_byte(buf, oddn, 7);
    bits_to_byte(buf++, called_num->noai, 0, 7);
    bits_to_byte(buf, 0, 0, 4);
    bits_to_byte(buf, called_num->npi, 4, 3);
    bit_to_byte(buf, called_num->inni, 7);
    /*
     * Now pack (variable length) address digits
     */
    addr = called_num->addr;
    for(iCt = adlen; iCt > 0; iCt--)
      *++buf = *addr++;
    /*
     * Add filler if naddr odd
     */
    if (oddn)
      *buf &= 0x0f;
  }

  return(2 + adlen);
}

/*
 * INTU_rec_called_num()
 *
 * Returns 0 on success
 *         INTUE_NUM_RECOVERY_FAILED otherwise
 */
int INTU_rec_called_num(called_num, pptr, plen)
  PTY_ADDR  *called_num;  /* called party number recovered into here */
  u8        *pptr;        /* pointer into parameter buffer */
  PLEN       plen;         /* length of parameter being recovered */
{
  u8        oddn, *addr;

  if ((plen < INTU_min_called_party_num_len) ||
      (plen > INTU_max_called_party_num_len))
  {
    /*
     * Parameter length is outside supported range.
     */
    return(INTUE_NUM_RECOVERY_FAILED);
  }

  /*
   * recover fixed length fields
   */
  oddn = bit_from_byte(*pptr, 7);
  plen -= 2;
  called_num->naddr = (u8)(plen << 1) - oddn;
  called_num->noai = bits_from_byte(*pptr++, 0, 7);
  called_num->inni = bit_from_byte(*pptr, 7);
  called_num->npi = bits_from_byte(*pptr, 4, 3);
  called_num->ni = 0;
  called_num->pri = 0;
  called_num->si =  0;
  /*
   * Now recover (variable length) address digits
   */
  addr = called_num->addr;
  while(plen--)
    *addr++ = *++pptr;
  /*
   * Force filler to zero (if naddr odd)
   */
  if (oddn)
    *--addr &= 0x0f;

  return(0);
}
