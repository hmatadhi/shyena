/*
              Copyright (C) Dialogic Corporation 1998-2016. All Rights Reserved.

   Name:          intumain.c

   Description:   Command line interface to intu. See the main body of intu
                  in file intu.c.

                  Files in this module:

                  intu_def.h - INTU module specific definitions
                  intu.c     - Main control loop and handling procedures
                  intumain.c - Reading and checking of command line options
                  intu_trc.c - Procedures for tracing and displaying output
                  intu_sys.c - Messages sending and formatting procedures


   Functions:     main()

   -----  ---------  -----  ---------------------------------------------
   Issue    Date      By                     Changes
   -----  ---------  -----  ---------------------------------------------
     A    22-Dec-98  JET    - Initial code based on ctu.
     1    09-Sep-04  GNK    - Eliminate warnings - declare static functions.
                            - Update copyright owner & year.
     2    13-Dec-06  ML     - Change to use of Dialogic Corporation copyright.
     3    15-Mar-16  CJM    - Use API Extended Dialog ID functions
                            - Removed LINT_ARGS defined test (always defined now)
                            - Tests for IN_LMSGS defined removed (no longer used by API)
 */

#include "intu_def.h"


/*
 * Module variables, updated by command line options in intu_main
 */
extern u8  intu_mod_id;      /* The task id of this module */
extern u8  inap_mod_id;      /* The task id of the INAP binary module*/
extern u16 num_dialogues;    /* The number of dialogues to support*/
extern u32 base_dialogue_id; /* The base number of the supported dialogue IDs */
extern u16 intu_options;     /* Defines which tracing options are configured */

/*
 * Declare static functions
 */
static int read_command_line_params(int argc, char *argv[], int *arg_index);
static void show_syntax(void);
static int read_option(char *args);


/*
 * Main function for INAP Test Utility (INTU)
 *
 * Returns 0
 */
int main(argc, argv)
  int argc;
  char *argv[];
{
  int failed_arg;
  int cli_error;

  intu_mod_id = DEFAULT_MODULE_ID;
  inap_mod_id = DEFAULT_INAP_MODULE_ID;
  num_dialogues = MAX_NUM_DIALOGUES;
  base_dialogue_id = DEFAULT_BASE_DIALOGUE_ID;
  intu_options = DEFAULT_OPTIONS;

  if ((cli_error = read_command_line_params(argc, argv, &failed_arg)) != 0)
  {
    switch (cli_error)
    {
      case COMMAND_LINE_UNRECON_OPTION :
        fprintf(stderr, "intu() : Unrecognised option : %s\n", argv[failed_arg]);
        show_syntax();
        break;

      case COMMAND_LINE_RANGE_ERR :
	fprintf(stderr, "intu() : Parameter range error : %s\n", argv[failed_arg]);
        show_syntax();
        break;

      default :
        break;
    }
    exit(0);
  }

  /*
   * Run Main INTU Code
   */
  intu_ent();

  return(0);
}


/*
 * show_syntax()
 */
static void show_syntax()
{
  fprintf(stderr,
	"Syntax: intu [-m -i -n -b -o]\n");
  fprintf(stderr,
	"  -m  : intu module_id (default=0x%02x)\n", DEFAULT_MODULE_ID);
  fprintf(stderr,
	"  -i  : inap module_id (default=0x%02x)\n", DEFAULT_INAP_MODULE_ID);
  fprintf(stderr,
	"  -n  : number of dialogues (default=0x%04x)\n", MAX_NUM_DIALOGUES);
  fprintf(stderr,
	"  -b  : base dialogue ID (default=0x%08lx)\n", DEFAULT_BASE_DIALOGUE_ID);
  fprintf(stderr,
	"  -o  : run-time options (default 0x%04x)\n", DEFAULT_OPTIONS);
  fprintf(stderr,
	"Example: intu -m0x3d -i0x35 -n0x200 -b0x4000 -o0x013f\n");
}

/*
 * Read in command line options a set the system variables accordingly.
 *
 * Returns 0 on success; on error returns non-zero and
 * writes the parameter index which caused the failure
 * to the variable arg_index.
 */
static int read_command_line_params(argc, argv, arg_index)
  int argc;             /* Number of arguments */
  char *argv[];         /* Array of argument pointers */
  int *arg_index;       /* Used to return parameter index on error */
{
  int error;
  int i;

  for (i=1; i < argc; i++)
  {
    if ((error = read_option(argv[i])) != 0)
    {
      *arg_index = i;
      return(error);
    }
  }
  return(0);
}

/*
 * Read a command line parameter and check syntax.
 *
 * Returns 0 on success or error code on failure.
 */
static int read_option(arg)
  char *arg;            /* Pointer to the parameter */
{
  u32 temp_u32;

  if (arg[0] != '-')
    return(COMMAND_LINE_UNRECON_OPTION);

  switch (arg[1])
  {
    case 'h' :
    case 'H' :
    case '?' :
    case 'v' :
      show_syntax();
      return(COMMAND_LINE_EXIT_REQ);

    case 'm' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      intu_mod_id = (u8)temp_u32;
      break;

    case 'i' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      inap_mod_id = (u8)temp_u32;
      break;

    case 'n' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      num_dialogues = (u16)temp_u32;
      break;

    case 'b' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      base_dialogue_id = temp_u32;
      break;

    case 'o' :
      if (strtou32(&temp_u32, &arg[2]) != 0)
        return(COMMAND_LINE_RANGE_ERR);
      intu_options = (u16)temp_u32;
      break;

    default:
      break;

  }
  return(0);
}
