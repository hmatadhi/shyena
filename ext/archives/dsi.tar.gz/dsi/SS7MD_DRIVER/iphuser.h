/****************************************************************************
 * NAME : iphuser.h
 * VERSION : 1.03.1.1
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the iphuser module of the base driver
 * REVISIONS :
 *    - Version 1.0 07/06/06 : Creation
 *    - Version 1.1 06/26/06 : Change global prefix into iphwae
 *    - Version 1.02 04/03/07 : Add the GiveRxDataBuffer function declaration
 *    - Version 1.03 01/16/09 : Add the GetTime and SetHostTimeOffset function 
 *                              declaration
 *    - Version 1.03.1 05/15/09 : Add the GetTempInfo function 
 *    - Version 1.03.1.1 07/02/10 : Add the DumpSeepromByte and 
 *                                  WriteSeepromByte functions 
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHUSER_H
#define IPHUSER_H

#ifdef IPHUSER_C
static dword drv_gdwInitOnLoadEnd(kmutex_t *pLock, IphWanDevPtr pDev);
static dword drv_gdwCtlSendPrim(ApplCtxtPtr pAppli, int iFlags, 
                                PrimDesc_t *pMem);
static dword drv_gdwCtlGiveRxPrim(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem);
static dword drv_gdwCtlGiveRxBuffer(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlGiveRxDataBuffer(ApplCtxtPtr pAppli, int iFlags, 
                                        MemDesc_t *pMem);
static dword drv_gdwCtlRecvPrim(ApplCtxtPtr pAppli, int iFlags, 
                                PrimDesc_t **pMem);
static dword drv_gdwCtlMaxRxQueue(ApplCtxtPtr pAppli, int iFlags, 
                                  MemDesc_t *pMem);
static dword drv_gdwCtlMaxRxChain(ApplCtxtPtr pAppli, int iFlags, 
                                  MemDesc_t *pMem);
static dword drv_gdwCtlNoOfDev(byte bAppliType, int iFlags, MemDesc_t *pMem);
static dword drv_gdwCtlGetCardId(byte bAppliType, int iFlags, 
                                 IphWanDevPtr pWanDev, MemDesc_t *pMem);
static dword drv_gdwCtlFreeControl(ApplCtxtPtr pAppli);
static dword drv_gdwCtlDumpMem(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem, 
                               int iRegion);
static dword drv_gdwCtlWriteMem(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem, 
                                int iRegion);
static dword drv_gdwCtlDumpReg(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem, 
                               int iRegion);
static dword drv_gdwCtlWriteReg(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem,
                                int iRegion);
static dword drv_gdwCtlDumpPCIConf(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem);
static dword drv_gdwCtlWritePCIConf(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlGetDrvVer(byte ucAppliType, int iFlags, MemDesc_t *pMem);
static dword drv_gdwCtlDumpCPUUsage(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlDumpPool(ApplCtxtPtr pAppli, int iFlags, 
                                MemDesc_t *pMem);
static dword drv_gdwCtlDumpDrvPool(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem);
static dword drv_gdwCtlDumpSeepromByte(ApplCtxtPtr pAppli, int iFlags, 
                                       MemDesc_t *pMem);
static dword drv_gdwCtlWriteSeepromByte(ApplCtxtPtr pAppli, int iFlags, 
                                        MemDesc_t *pMem);
static dword drv_gdwCtlMaxTransferSize(ApplCtxtPtr pAppli, int iFlags, 
                                       MemDesc_t *pMem);
static dword drv_gdwCtlInitPrimPool(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlInitBufferPool(ApplCtxtPtr pAppli, int iFlags, 
                                      MemDesc_t *pMem);
static dword drv_gdwCtlInitMaxAppli(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlInitMaxSession(ApplCtxtPtr pAppli, int iFlags, 
                                      MemDesc_t *pMem);
static dword drv_gdwCtlInitDrvTrace(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlSetDrvTrace(byte ucAppliType, kmutex_t *pLock, 
                                   int iFlags, MemDesc_t *pMem, byte ucTraceOn);
static dword drv_gdwCtlDumpDrvTrace(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlDumpTrace(ApplCtxtPtr pAppli, int iFlags, 
                                 MemDesc_t *pMem);
static dword drv_gdwCtlGetStatus(ApplCtxtPtr pAppli, int iFlags, 
                                 MemDesc_t *pMem);
static dword drv_gdwCtlSetCardStatus(ApplCtxtPtr pAppli, int iFlags, 
                                     MemDesc_t *pMem);
static dword drv_gdwCtlDumpHostArea(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem);
static dword drv_gdwCtlResetHostStat(ApplCtxtPtr pAppli, int iFlags, 
                                     MemDesc_t *pMem);
static dword drv_gdwCtlGetTime(ApplCtxtPtr pAppli, int iFlags,
                               MemDesc_t *pMem);
static dword drv_gdwCtlSetHostTimeOffset(ApplCtxtPtr pAppli, int iFlags,
                                         MemDesc_t *pMem);
static dword drv_gdwCtlGetTempInfo(ApplCtxtPtr pAppli, int iFlags,
                                   MemDesc_t *pMem);



#define ExportGlobalUser(PRFX) \
dword iph##PRFX##_gdwInitOnLoadEnd(kmutex_t *pLock, IphWanDevPtr pDev)\
{\
   return(drv_gdwInitOnLoadEnd(pLock, pDev));\
}\
dword iph##PRFX##_gdwCtlSendPrim(ApplCtxtPtr pAppli, int iFlags, \
                                 PrimDesc_t *pMem)\
{\
   return(drv_gdwCtlSendPrim(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGiveRxPrim(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGiveRxPrim(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGiveRxBuffer(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGiveRxBuffer(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGiveRxDataBuffer(ApplCtxtPtr pAppli, int iFlags, \
                                         MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGiveRxDataBuffer(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlRecvPrim(ApplCtxtPtr pAppli, int iFlags, \
                                 PrimDesc_t **pMem)\
{\
   return(drv_gdwCtlRecvPrim(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlMaxRxQueue(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem)\
{\
   return(drv_gdwCtlMaxRxQueue(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlMaxRxChain(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem)\
{\
   return(drv_gdwCtlMaxRxChain(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlNoOfDev(byte bAppliType, int iFlags, MemDesc_t *pMem)\
{\
   return(drv_gdwCtlNoOfDev(bAppliType, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGetCardId(byte bAppliType, int iFlags, \
                                  IphWanDevPtr pWanDev, MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGetCardId(bAppliType, iFlags, pWanDev, pMem));\
}\
dword iph##PRFX##_gdwCtlFreeControl(ApplCtxtPtr pAppli)\
{\
   return(drv_gdwCtlFreeControl(pAppli));\
}\
dword iph##PRFX##_gdwCtlDumpMem(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem, int iRegion)\
{\
   return(drv_gdwCtlDumpMem(pAppli, iFlags, pMem, iRegion));\
}\
dword iph##PRFX##_gdwCtlWriteMem(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem, int iRegion)\
{\
   return(drv_gdwCtlWriteMem(pAppli, iFlags, pMem, iRegion));\
}\
dword iph##PRFX##_gdwCtlDumpReg(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem, int iRegion)\
{\
   return(drv_gdwCtlDumpReg(pAppli, iFlags, pMem, iRegion));\
}\
dword iph##PRFX##_gdwCtlWriteReg(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem, int iRegion)\
{\
   return(drv_gdwCtlWriteReg(pAppli, iFlags, pMem, iRegion));\
}\
dword iph##PRFX##_gdwCtlDumpPCIConf(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpPCIConf(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlWritePCIConf(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlWritePCIConf(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGetDrvVer(byte ucAppliType, int iFlags, \
                                  MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGetDrvVer(ucAppliType, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpCPUUsage(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpCPUUsage(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpPool(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpPool(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpDrvPool(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpDrvPool(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpSeepromByte(ApplCtxtPtr pAppli, int iFlags, \
                                        MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpSeepromByte(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlWriteSeepromByte(ApplCtxtPtr pAppli, int iFlags, \
                                        MemDesc_t *pMem)\
{\
   return(drv_gdwCtlWriteSeepromByte(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlMaxTransferSize(ApplCtxtPtr pAppli, int iFlags, \
                                        MemDesc_t *pMem)\
{\
   return(drv_gdwCtlMaxTransferSize(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlInitPrimPool(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlInitPrimPool(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlInitBufferPool(ApplCtxtPtr pAppli, int iFlags, \
                                       MemDesc_t *pMem)\
{\
   return(drv_gdwCtlInitBufferPool(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlInitMaxAppli(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlInitMaxAppli(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlInitMaxSession(ApplCtxtPtr pAppli, int iFlags, \
                                       MemDesc_t *pMem)\
{\
   return(drv_gdwCtlInitMaxSession(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlInitDrvTrace(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlInitDrvTrace(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlSetDrvTrace(byte ucAppliType, kmutex_t *pLock, \
                                    int iFlags, MemDesc_t *pMem, \
                                    byte ucTraceOn)\
{\
   return(drv_gdwCtlSetDrvTrace(ucAppliType, pLock, iFlags, pMem, ucTraceOn));\
}\
dword iph##PRFX##_gdwCtlDumpDrvTrace(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpDrvTrace(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpTrace(ApplCtxtPtr pAppli, int iFlags, \
                                  MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpTrace(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGetStatus(ApplCtxtPtr pAppli, int iFlags, \
                                  MemDesc_t *pMem)\
{\
   return(drv_gdwCtlGetStatus(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlSetCardStatus(ApplCtxtPtr pAppli, int iFlags, \
                                      MemDesc_t *pMem)\
{\
   return(drv_gdwCtlSetCardStatus(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlDumpHostArea(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem)\
{\
   return(drv_gdwCtlDumpHostArea(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlResetHostStat(ApplCtxtPtr pAppli, int iFlags, \
                                      MemDesc_t *pMem)\
{\
   return(drv_gdwCtlResetHostStat(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGetTime(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem) \
{\
   return(drv_gdwCtlGetTime(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlSetHostTimeOffset(ApplCtxtPtr pAppli, int iFlags, \
                                          MemDesc_t *pMem) \
{\
   return(drv_gdwCtlSetHostTimeOffset(pAppli, iFlags, pMem));\
}\
dword iph##PRFX##_gdwCtlGetTempInfo(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem) \
{\
   return(drv_gdwCtlGetTempInfo(pAppli, iFlags, pMem));\
}


ExportGlobalUser(wae)
#else


#define ExportExtUser(PRFX) \
dword iph##PRFX##_gdwInitOnLoadEnd(kmutex_t *pLock, IphWanDevPtr pDev);\
dword iph##PRFX##_gdwCtlSendPrim(ApplCtxtPtr pAppli, int iFlags, \
                                 PrimDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGiveRxPrim(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGiveRxBuffer(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGiveRxDataBuffer(ApplCtxtPtr pAppli, int iFlags, \
                                         MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlRecvPrim(ApplCtxtPtr pAppli, int iFlags, \
                                 PrimDesc_t **pMem);\
dword iph##PRFX##_gdwCtlMaxRxQueue(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlMaxRxChain(ApplCtxtPtr pAppli, int iFlags, \
                                   MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlNoOfDev(byte bAppliType, int iFlags, MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGetCardId(byte bAppliType, int iFlags, \
                                  IphWanDevPtr pWanDev, MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlFreeControl(ApplCtxtPtr pAppli);\
dword iph##PRFX##_gdwCtlDumpMem(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem, int iRegion);\
dword iph##PRFX##_gdwCtlWriteMem(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem, int iRegion);\
dword iph##PRFX##_gdwCtlDumpReg(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem, int iRegion);\
dword iph##PRFX##_gdwCtlWriteReg(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem, int iRegion);\
dword iph##PRFX##_gdwCtlDumpPCIConf(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlWritePCIConf(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGetDrvVer(byte ucAppliType, int iFlags, \
                                  MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpCPUUsage(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpPool(ApplCtxtPtr pAppli, int iFlags, \
                                 MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpDrvPool(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpSeepromByte(ApplCtxtPtr pAppli, int iFlags, \
                                        MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlWriteSeepromByte(ApplCtxtPtr pAppli, int iFlags, \
                                         MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlMaxTransferSize(ApplCtxtPtr pAppli, int iFlags, \
                                        MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlInitPrimPool(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlInitBufferPool(ApplCtxtPtr pAppli, int iFlags, \
                                       MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlInitMaxAppli(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlInitMaxSession(ApplCtxtPtr pAppli, int iFlags, \
                                       MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlInitDrvTrace(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlSetDrvTrace(byte ucAppliType, kmutex_t *pLock, \
                                    int iFlags, MemDesc_t *pMem, \
                                    byte ucTraceOn);\
dword iph##PRFX##_gdwCtlDumpDrvTrace(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpTrace(ApplCtxtPtr pAppli, int iFlags, \
                                  MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGetStatus(ApplCtxtPtr pAppli, int iFlags, \
                                  MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlSetCardStatus(ApplCtxtPtr pAppli, int iFlags, \
                                      MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlDumpHostArea(ApplCtxtPtr pAppli, int iFlags, \
                                     MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlResetHostStat(ApplCtxtPtr pAppli, int iFlags, \
                                      MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGetTime(ApplCtxtPtr pAppli, int iFlags, \
                                MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlSetHostTimeOffset(ApplCtxtPtr pAppli, int iFlags, \
                                          MemDesc_t *pMem);\
dword iph##PRFX##_gdwCtlGetTempInfo(ApplCtxtPtr pAppli, int iFlags, \
                                    MemDesc_t *pMem);
ExportExtUser(wae)

#endif

#define iph_gdwInitOnLoadEnd iphwae_gdwInitOnLoadEnd
#define iph_gdwCtlSendPrim iphwae_gdwCtlSendPrim
#define iph_gdwCtlGiveRxPrim iphwae_gdwCtlGiveRxPrim
#define iph_gdwCtlGiveRxBuffer iphwae_gdwCtlGiveRxBuffer
#define iph_gdwCtlGiveRxDataBuffer iphwae_gdwCtlGiveRxDataBuffer
#define iph_gdwCtlRecvPrim iphwae_gdwCtlRecvPrim
#define iph_gdwCtlMaxRxQueue iphwae_gdwCtlMaxRxQueue
#define iph_gdwCtlMaxRxChain iphwae_gdwCtlMaxRxChain
#define iph_gdwCtlNoOfDev iphwae_gdwCtlNoOfDev
#define iph_gdwCtlGetCardId iphwae_gdwCtlGetCardId
#define iph_gdwCtlFreeControl iphwae_gdwCtlFreeControl
#define iph_gdwCtlDumpMem iphwae_gdwCtlDumpMem
#define iph_gdwCtlWriteMem iphwae_gdwCtlWriteMem
#define iph_gdwCtlDumpReg iphwae_gdwCtlDumpReg
#define iph_gdwCtlWriteReg iphwae_gdwCtlWriteReg
#define iph_gdwCtlDumpPCIConf iphwae_gdwCtlDumpPCIConf
#define iph_gdwCtlWritePCIConf iphwae_gdwCtlWritePCIConf
#define iph_gdwCtlGetDrvVer iphwae_gdwCtlGetDrvVer
#define iph_gdwCtlDumpCPUUsage iphwae_gdwCtlDumpCPUUsage
#define iph_gdwCtlDumpPool iphwae_gdwCtlDumpPool
#define iph_gdwCtlDumpDrvPool iphwae_gdwCtlDumpDrvPool
#define iph_gdwCtlDumpSeepromByte iphwae_gdwCtlDumpSeepromByte
#define iph_gdwCtlWriteSeepromByte iphwae_gdwCtlWriteSeepromByte
#define iph_gdwCtlMaxTransferSize iphwae_gdwCtlMaxTransferSize
#define iph_gdwCtlInitPrimPool iphwae_gdwCtlInitPrimPool
#define iph_gdwCtlInitBufferPool iphwae_gdwCtlInitBufferPool
#define iph_gdwCtlInitMaxAppli iphwae_gdwCtlInitMaxAppli
#define iph_gdwCtlInitMaxSession iphwae_gdwCtlInitMaxSession
#define iph_gdwCtlInitDrvTrace iphwae_gdwCtlInitDrvTrace
#define iph_gdwCtlSetDrvTrace iphwae_gdwCtlSetDrvTrace
#define iph_gdwCtlDumpDrvTrace iphwae_gdwCtlDumpDrvTrace
#define iph_gdwCtlDumpTrace iphwae_gdwCtlDumpTrace
#define iph_gdwCtlGetStatus iphwae_gdwCtlGetStatus
#define iph_gdwCtlSetCardStatus iphwae_gdwCtlSetCardStatus
#define iph_gdwCtlDumpHostArea iphwae_gdwCtlDumpHostArea
#define iph_gdwCtlResetHostStat iphwae_gdwCtlResetHostStat
#define iph_gdwCtlGetTime iphwae_gdwCtlGetTime
#define iph_gdwCtlSetHostTimeOffset iphwae_gdwCtlSetHostTimeOffset
#define iph_gdwCtlGetTempInfo iphwae_gdwCtlGetTempInfo
#endif
