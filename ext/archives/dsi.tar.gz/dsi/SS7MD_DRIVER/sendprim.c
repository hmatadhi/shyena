/****************************************************************************
 * (C) Copyright Interphase Corp 2002-2009.
 *
 * NAME : sendprim.c
 * VERSION : 1.10.2
 * DESCRIPTION : 
 *    Functions to send a primitive to the card
 * REVISIONS :
 *    - Version 1.00 10/04/05 : Creation
 *    - Version 1.01 03/14/06 : - Add init of Outbound Window 0
 *                              - Fix a bug in window size calculation
 *    - Version 1.02 03/21/06 : - change the way to stop echo timer to prevent
 *                                handler from running (set EchoTimer to FALSE)
 *                              - Update for Solaris
 *                              - Change the way to detect whether a descriptor
 *                                is free
 *    - Version 1.03 05/15/06 : - Keep at least on transfer descriptor free
 *    - Version 1.04 05/23/06 :
 *       - Add mutex protection for access to MEM_REGION to avoid unexpected
 *         window translation
 *    - Version 1.05 07/12/06 : - Use MUTEX_xx and CV_xx macros
 *    - Version 1.06 12/27/2006:
 *       - Suppress many Linux compilation warnings
 *    - Version 1.07 07/12/2007:
 *       - Lock before tracing the sent primitive
 *    - Version 1.08 04/17/2008:
 *       - Fix bug2687: forbid concurrent access to dwInitDMATransfer_PQ3.
 *    - Version 1.09 09/11/2008:
 *      - dwStartTransfer_PQ3: before deleting a timer, release any lock
 *    - Version 1.10 10/30/2008:
 *      - since IPH_GET_TIME uses different structure type on Linux and 
 *        Solaris, fix SendWaiting device variable management
 *    - Version 1.10.1 03/04/2009:
 *      - Fix a lock problem in drv_gdwCardSendPrim_PQ3
 *    - Version 1.10.2 04/08/2009:
 *      - update AppliReady on session correlator allocation
 * FUNCTIONS LIST :
 *    Local functions :
 *       pAllocCorrForAppli
 *       vAbortCorrForAppli
 *       dwInitDMATransfer_PQ3
 *       dwStartTransfer_PQ3
 *       pFindCorrForAppli
 *    Public functions :
 *       drv_gdwCardSendPrim_PQ3
 *       drv_gvInitDialogWithCard
 *    
 ****************************************************************************/
#define SENDPRIM_C
#include "iphwan.h"
#include "poolqueu.h"
#include "ithandle.h"
#include "sendprim.h"
#include "iphwantr.h"
#include "iphtrace.h"
#include "iphmsys.h"


/* new macro to change a correlator status */
#define CHANGE_CORR_STATUS(pLock, pCorr, NewStatus)                     \
{                                                                       \
   IPH_LOCK(pLock);                                                     \
   (pCorr)->Status = (NewStatus);                                       \
   IPH_UNLOCK(pLock);                                                   \
}

/***************************************************************************/
/* Local functions                                                         */
/***************************************************************************/


/**************************************************************************
* NAME : pAllocCorrForAppli
* DESCRIPTION : allocate a correlator for an application and store it in 
*               the application context
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pDev = device context
*    Input   : pAppli = application context
*    Input   : wSession = logical session number as received from an appli,
*                         that is in network representation
* RETURN : the correlator pointer if successfully allocated, NULL else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static MGRSessionCorrPtr pAllocCorrForAppli(kmutex_t *pLock, IphWanDevPtr pDev,
                                            ApplCtxtPtr pAppli, word wSession)
{
   MGRSessionCorrPtr pCorr;

   pCorr = 
      (MGRSessionCorrPtr)iph_gpGetQueue(pLock,
                                        &pDev->FreeMGRSessionCorrQueue);
   if (pCorr != (MGRSessionCorrPtr)0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[pAllocCorrForAppli] add session equivalence");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_APPLI_SESSION,
                   pAppli->Minor, (wSession));
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_SESSION,
                   pDev->Index, (pCorr->CardMGRSession));
#endif

      /* store the MGR session and the application context numbers */
      pCorr->LogicalMGRSession = wSession;
      pCorr->AppliPtr = pAppli;
      pCorr->AppliType = pAppli->Type;
      pCorr->AppliReady = 1;

      pCorr->Status = SESS_OPENING;

      /* store the allocated correlator with the used correlators */
      iph_gvPutQueue(pLock,
                     &pDev->UsedMGRSessionCorrQueue,
                     (QueueItemPtr)pCorr);
      /* add the correlator to the application's hash table */
      iph_gvPutCorrHash(&pAppli->AppliMutex,
                        &pAppli->HashTable[(wSession) % MODULO],
                        pCorr);
   }
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[pAllocCorrForAppli] no correlator can be allocated");
#endif
   }
   return(pCorr);
}

/**************************************************************************
* NAME : vAbortCorrForAppli
* DESCRIPTION : release a correlator for an application due to an error before
*               sending the equivalent MGR_OPEN_USER to the card
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pDev = device context
*    Input   : pAppli = application context
*    Input   : pCorr = correlator context
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void vAbortCorrForAppli(kmutex_t *pLock, IphWanDevPtr pDev,
                               ApplCtxtPtr pAppli, MGRSessionCorrPtr pCorr)
{
   iph_gvExtractCorrHash(&pAppli->AppliMutex,
                         &pAppli->HashTable[(pCorr->LogicalMGRSession) % MODULO],
                         pCorr);
   iph_gvExtractQueue(pLock,
                      &pDev->UsedMGRSessionCorrQueue,
                      (QueueItemPtr)pCorr);
   iph_gvPutQueue(pLock,
                  &pDev->FreeMGRSessionCorrQueue,
                  (QueueItemPtr)pCorr);
}

/**************************************************************************
* NAME : dwInitDMATransfer_PQ3
* DESCRIPTION : prepare and send a primitive to the card (PQIII)
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : isLocked = flag set if mutex is already locked
*    Input   : pDev = device context
*    Input   : pPrim = primitive to send
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect or bind failed
*          EAGAIN if all the DMA descriptors are already used
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword dwInitDMATransfer_PQ3(kmutex_t *pLock, int isLocked,
                                   IphWanDevPtr pDev, PrimDesc_t *pPrim)
{
   dword ulSizeToCopy;
   V5_TransferCtrlPtr pTransf;
   dword ulTransfSize;
   dword dwError;
   DataDesc_t *pDataDesc;
   word wBuffCount;
   word uwIndex, uwCount, uwFirst;
   V5_TransferCtrl_t tTmp;
   dword *pdw;
   dword *pdwd;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwInitDMATransfer_PQ3] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
#endif

   dwError = 0;

   pTransf = &pDev->InbCtrl[pDev->InbCtrlIndex];

   /* if additionnal data are provided */
   wBuffCount = 0;
   pDataDesc = pPrim->DataDescPtr;
   uwFirst = pDev->InbSendIndex;
   while (pDataDesc != NULL && dwError == 0)
   {
      ulSizeToCopy = pDataDesc->Size;
      uwIndex = pDataDesc->Offset;
      while (ulSizeToCopy > 0 && dwError == 0)
      {
         ulTransfSize = ulSizeToCopy;
         if (ulTransfSize > pDev->MaxTransferSize)
         {
            ulTransfSize = pDev->MaxTransferSize;
         }

         /* copy data */
         if ((pDataDesc->Reserved & USER_BUFFER) != 0)
         {
            if (isLocked == TRUE)
               IPH_UNLOCK(pLock);
            GET_DATA_USER(&pDataDesc->DataPtr[uwIndex],
                          pDev->SendDmaDesc[pDev->InbSendIndex].VirtAddr,
                          ulTransfSize,
                          ((DrvDataDescPtr)pDataDesc)->iFlags,
                          &dwError);
            if (isLocked == TRUE)
               IPH_LOCK(pLock);
         }
         else
         {
            memcpy(pDev->SendDmaDesc[pDev->InbSendIndex].VirtAddr,
                   &pDataDesc->DataPtr[uwIndex], 
                   ulTransfSize);
         }
         if (dwError != 0)
         {
            if (isLocked == FALSE)
               IPH_LOCK(pLock);
            for (uwCount = uwFirst; uwCount != pDev->InbSendIndex; )
            {
               WRITE_MEM_WORD(pDev, 
                              &pDev->InbSend[uwCount].ByteCount,
                              0);
               uwCount++;
               if (uwCount == pDev->InbDataNb)
               {
                  uwCount = 0;
               }
            }
            if (isLocked == FALSE)
               IPH_UNLOCK(pLock);
            pDev->InbSendIndex = uwFirst;
         }
         else
         {
#ifdef SOLARIS
            /* synchronize data */
            ddi_dma_sync(pDev->DmaAreaDesc.Handle,
                         pDev->SendDmaDesc[pDev->InbSendIndex].PhysAddr -
                         pDev->DmaAreaDesc.PhysAddr, ulTransfSize,
                         DDI_DMA_SYNC_FORDEV);
#endif
            /* update the variables for next block */
            uwIndex += ulTransfSize;
            ulSizeToCopy -= ulTransfSize;
            wBuffCount++;

            /* add buffer in SendQueue */
            if (isLocked == FALSE)
               IPH_LOCK(pLock);
            WRITE_MEM_WORD(pDev, 
                           &pDev->InbSend[pDev->InbSendIndex].ByteCount,
                           ulTransfSize);
            if (isLocked == FALSE)
               IPH_UNLOCK(pLock);
            /* update index in InbSend */
            pDev->InbSendIndex++;
            if (pDev->InbSendIndex == pDev->InbDataNb)
            {
               pDev->InbSendIndex = 0;
            }
            pDev->InbTotalSendCount++;
         }
      }
      pDataDesc = pDataDesc->NextPtr;
   }

   if (dwError == 0)
   {
      /* memorize the primitive to release it after DMA transfer is done */
      pDev->SendingPrim[pDev->InbCtrlIndex] = pPrim;

      pDev->InbStatus[pDev->InbCtrlIndex].Status = TRANSFER_READY;
      /* initialize the transfer descriptor fields */
      tTmp.Status = TRANSFER_READY;
      tTmp.DataCount = wBuffCount;
      tTmp.RefIndx = HOST_CARD16(pDev->RefIndex);
      tTmp.PrimitiveId = HOST_CARD16(pPrim->PrimId);
      tTmp.PrimitiveRef = HOST_CARD16(pPrim->PrimRef);
      bcopy(pPrim->PrimInfo, tTmp.PrimitiveInfo, MAX_PRIM_INFO);
      pdw = (dword *)&tTmp;
      pdwd = (dword *)pTransf;
      if (isLocked == FALSE)
         IPH_LOCK(pLock);
      for (ulSizeToCopy = (sizeof(V5_TransferCtrl_t ) / sizeof(dword)); 
           ulSizeToCopy > 0; ulSizeToCopy--, pdw++, pdwd++)
      {
         pDev->Region[MEM_REGION].Ops.write32(&pDev->Region[MEM_REGION],
                                              (dword)(unsigned long)pdwd, *pdw);
      }
      if (isLocked == FALSE)
         IPH_UNLOCK(pLock);

      /* update index in InbCtrl */
      pDev->InbCtrlIndex++;
      if (pDev->InbCtrlIndex == pDev->InbCtrlNb)
      {
         pDev->InbCtrlIndex = 0;
      }
      /* Card notification is deferred in dwStartTransfer_PQ3 */

#ifdef DEBUG_PERF
      /* counters to monitor driver's activity */
      pDev->SendNb++;
      if (pDev->SendNb > pDev->MaxSendNb)
         pDev->MaxSendNb = pDev->SendNb;
      pDev->SendMsgNb++;
#endif
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwInitDMATransfer_PQ3] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : dwStartTransfer_PQ3
* DESCRIPTION : notify the card for at least one host-to-card transfer ready
*               (for PQ3 only)
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
* NOTE: pDev->DevMutex is locked
**************************************************************************/
static dword dwStartTransfer_PQ3(IphWanDevPtr pDev)
{
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwStartTransfer_PQ3] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
#endif

   dwError = 0;

   pDev->HostToCardSigCount++;
   pDev->HostArea->HostToCardEchoCount = -1;
   WRITE_EXCH_SIG_COUNT(pDev, pDev->ExchArea, pDev->HostToCardSigCount);

   /* signal the card */
   WRITE_CORE_DWORD(pDev, MPC856X_MSGR0, 0xFFFFFFFF);

   if (pDev->EchoTimer == TRUE)
   {
      pDev->EchoTimer = FALSE;
      /* release lock */
      MUTEX_EXIT(&pDev->DevMutex);
      IPH_DEL_TIMER(&pDev->EchoPoll);
      MUTEX_ENTER(&pDev->DevMutex);
   }

   /* start the Watchdog function */
   pDev->EchoTimeout = FALSE;
   pDev->EchoTimer = TRUE;
   IPH_START_TIMER(&pDev->EchoPoll, iph_gvITEchoPoll, pDev,
                   ECHO_TIMEOUT);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwStartTransfer_PQ3] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}


/**************************************************************************
* NAME : pFindCorrForAppli
* DESCRIPTION : find a correlator in an application context
* PARAMETERS :
*    Input   : pAppli = application context
*    Input   : wSession = logical session number as received from an appli,
*                         that is in network representation
* RETURN : the correlator pointer if found, NULL else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static MGRSessionCorrPtr pFindCorrForAppli(ApplCtxtPtr pAppli, word wSession)
{
   Queue_t *pCorrQueue;
   MGRSessionCorrPtr pCorr;

   MUTEX_ENTER(&pAppli->AppliMutex);
   pCorrQueue = &pAppli->HashTable[wSession % MODULO];
   pCorr = (MGRSessionCorrPtr)pCorrQueue->FirstPtr;
   while (pCorr != (MGRSessionCorrPtr)pCorrQueue)
   {
      /* compare the identificators */
      if (pCorr->LogicalMGRSession == wSession)
      {
         /* found it */
         break;
      }

      /* get the next correlator */
      pCorr = pCorr->HashNextPtr;
   }
   MUTEX_EXIT(&pAppli->AppliMutex);

   if (pCorr == (MGRSessionCorrPtr)pCorrQueue)
      pCorr = NULL;

   return(pCorr);
}

/***************************************************************************/
/* Public functions                                                        */
/***************************************************************************/

/**************************************************************************
* NAME : drv_gdwCardSendPrim_PQ3
* DESCRIPTION : send a primitive to the card equipped with PQ3
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pDev = device context
*    Input   : pAppli = context of the application that request the send
*                          (can be NULL)
*    Input   : pPrim = primitive to send (can be NULL to reactivate send)
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EAGAIN if no transfer descriptor and kernel application
*          ENODEV if the firmware is not running
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCardSendPrim_PQ3(kmutex_t *pLock, IphWanDevPtr pDev,
                                     ApplCtxtPtr pAppli,
                                     PrimDesc_t *pPrim)
{
   MGRSessionCorrPtr pMGRSessionCorr;
   byte ucSendThePrim;
   dword dwError;
   word wLogicalSession;
   word wCardSession;
   byte bCorrStatus = 0;
   byte bChangeCorrStatus = 0;
   word wNextIndex;
#ifdef LINUX
   struct timeval tNow;
#endif
#ifdef SOLARIS
   dword tNow;
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                (byte *)"[gdwCardSendPrim_PQ3] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
   if (pAppli != NULL)
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pAppli->Minor);
#endif

   if (pPrim == NULL)
   {
      return(EINVAL);
   }

   ucSendThePrim = TRUE;
   dwError = 0;
   pMGRSessionCorr = (MGRSessionCorrPtr)0;

   /* first check if card is ready */
   if (pDev->Status != CARD_LOADED && pDev->Status != CARD_RUNNING)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCardSendPrim_PQ3] device not ready");
#endif
      return(ENODEV);
   }
   else
   {
#if 0
      dword CardState;
      IPH_LOCK(pLock);
      READ_EXCH_CODE_READY(pDev, pDev->ExchArea, &CardState);
      IPH_UNLOCK(pLock);
      if (CardState != CODE_RDY)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwCardSendPrim_PQ3] code not ready");
#endif
         return(ENODEV);
      }
#endif
   }

   /* add protection on whole routine */
   IPH_LOCK(pLock);
   if (pDev->SendPending != 0)
   {
      /* only a USER application can wait for completion */
      if (pAppli != NULL && pAppli->Type == TYPE_USER)
      {
#ifdef DEBUG_PERF
         pDev->SendPendingWait++;
#endif
         wNextIndex = 10;
         while (wNextIndex != 0 &&
                (CV_WAIT_SIG(&pDev->SendPendingCv, &pDev->DevMutex) <= 0 ||
                 pDev->SendPending != 0))
         {
            wNextIndex --;
         }
         if (wNextIndex == 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCardSendPrim] failed to wait for end of transmission");
#endif
            dwError = EAGAIN;
         }
      }
      else
      {
         dwError = EAGAIN;
      }
   } 
   if (dwError == 0 && pDev->SendPending == 0)
      pDev->SendPending = 1;
   IPH_UNLOCK(pLock);
   if (dwError != 0)
      return(dwError);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                (byte *)"[gdwCardSendPrim_PQ3] got control");
   if (pAppli != NULL)
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pAppli->Minor);
#endif
   /* get application session number (before translation) */
   wLogicalSession = wCardSession = pPrim->PrimRef;

   /* if this is a MGR_OPEN_USER primitive, remember the equivalence */
   /* between the MGR session and the application context */
   /* Note: we assume that only an application can send such a primitive */
   if (pPrim->PrimId == ((MGR_PRIM | MGR_OPEN_USER)) ||
       ((pPrim->PrimId & 0xFF00) == 0x4000))
   {
      /* check if this MGR session is not already used */
      pMGRSessionCorr = pFindCorrForAppli(pAppli, pPrim->PrimRef);
      if (pMGRSessionCorr == NULL && 
          (pPrim->PrimRef) < pDev->MaxSession)
      {
         pMGRSessionCorr = pAllocCorrForAppli(pLock, pDev, pAppli, 
                                              pPrim->PrimRef);
         if (pMGRSessionCorr != (MGRSessionCorrPtr)0)
         {
            /* Use the Card Session number */
            wCardSession = pMGRSessionCorr->CardMGRSession;
            if ((pPrim->PrimId & 0xFF00) == 0x4000)
            {
               bChangeCorrStatus = 1;
               bCorrStatus = SESS_CLOSED;
            }
         }
         else
         {
            ucSendThePrim = FALSE;
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCardSendPrim_PQ3] send of MGR_OPEN_USER aborted");
#endif
            dwError = EINVAL;
         }
      } 
      else if ((pPrim->PrimId & 0xFF00) == 0x4000)
      {
         /* Put the correct session number */
         wCardSession = pMGRSessionCorr->CardMGRSession;
      }
      else
      {
         ucSendThePrim = FALSE;
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwCardSendPrim_PQ3] session already used or out of range");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_APPLI_SESSION,
                      pAppli->Minor,
                      (pPrim->PrimRef));
#endif
         dwError = EINVAL;
      }
   }
   else
   {
      /* if an application sent this primitive, the session number must be */
      /* translated */
      if (pAppli != NULL)
      {
         /* Find equivalence between LogicalMGR Session number and */
         /* Card MGR Session Number */
         pMGRSessionCorr = pFindCorrForAppli(pAppli, pPrim->PrimRef);
         if (pMGRSessionCorr == NULL)
         {
            /* can't find context */
            ucSendThePrim = FALSE;
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCardSendPrim_PQ3] no context found");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_APPLI_SESSION,
                         pAppli->Minor,
                         (pPrim->PrimRef));
#endif
            dwError = EINVAL;
         }
         else
         {
            /* closing session */
            if (pPrim->PrimId == ((MGR_PRIM | MGR_CLOSE_USER)))
            {
               bChangeCorrStatus = 1;
               bCorrStatus = SESS_CLOSING;
            }

            /* Put the correct session number */
            wCardSession = pMGRSessionCorr->CardMGRSession;
         }
      }
      else  /* the driver initialized this primitive */
      {
         /* closing session */
         if (pPrim->PrimId == ((MGR_PRIM | MGR_CLOSE_USER)))
         {
            CHANGE_CORR_STATUS(pLock, 
                               pDev->MGRSessionCorrTable[(pPrim->PrimRef)],
                               SESS_CLOSING);
         }
      }
   }
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwCardSendPrim] gonna send primitive:");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF,
                pPrim->PrimId, pPrim->PrimRef);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_LOGICAL_REF, wLogicalSession);
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwCardSendPrim] InbCtrlIndex - status");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                pDev->InbCtrlIndex,
                pDev->InbStatus[pDev->InbCtrlIndex].Status);
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwCardSendPrim] InbTotalSendCount - InbDatNb");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                pDev->InbTotalSendCount, pDev->InbDataNb);
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwCardSendPrim] Buffers nb");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                pPrim->BuffInPool);
#endif

   /* NOTE: at this point, no semaphore is hold except if the function is */
   /* called with a hold sempahore */

   /* if the primitive can still be sent */
   if (ucSendThePrim == TRUE)
   {
      /* free the descriptors and their owning application that completed */
      /* the transmission from host to local */
      pDev->Rsrc->ReleaseP2LTransfer(pLock, pDev);

      IPH_LOCK(pLock);

      wNextIndex = pDev->InbCtrlIndex + 1;
      if (wNextIndex == pDev->InbCtrlNb)
      {
         wNextIndex = 0;
      }
      /* check whether one transfer descriptor and as much data */
      /* descriptors as necessary are available */
      /*while (pDev->InbStatus[pDev->InbCtrlIndex].Status != TRANSFER_IDLE ||
             pDev->SendingPrim[pDev->InbCtrlIndex] != NULL ||
             pDev->InbTotalSendCount + pPrim->BuffInPool > pDev->InbDataNb)*/
      while (pDev->InbStatus[pDev->InbCtrlIndex].Status != TRANSFER_IDLE ||
             pDev->SendingPrim[pDev->InbCtrlIndex] != NULL ||
             pDev->SendingPrim[wNextIndex] != NULL ||
             pDev->InbTotalSendCount + pPrim->BuffInPool > pDev->InbDataNb)
      {
         /* no wait for a kernel application */
         if (pAppli != NULL && pAppli->Type == TYPE_KERNEL)
         {
            dwError = EAGAIN;
            break;
         }
         else if (pAppli != NULL && pAppli->Type == TYPE_USER)
         {
#ifdef DEBUG_PERF
            pDev->SendWait++;
#endif
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCardSendPrim] wait for a descriptor...");
#endif
            IPH_GET_TIME(&tNow);
#ifdef LINUX
            pDev->SendWaiting = tNow.tv_sec;
#endif
#ifdef SOLARIS
            pDev->SendWaiting = tNow;
#endif
            if (CV_WAIT_SIG(&pDev->CondVar, &pDev->DevMutex) <= 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCardSendPrim] failed to wait for a descriptor");
#endif
               pDev->SendWaiting = 0;
               dwError = EAGAIN;
               break;
            }
            pDev->SendWaiting = 0;
            if (pDev->Status != CARD_LOADED && pDev->Status != CARD_RUNNING)
               break;
         }
         else /* pAppli = NULL */
         {
            iph_TRACEK(TRCLVL_0, DRIVER_NAME" : failed to close session %d on adapter %d",
                       wCardSession, pDev->Index);
            break;
         }
      }
      /* if the card has been reset, then abort sending */
      if (pDev->Status != CARD_LOADED && pDev->Status != CARD_RUNNING)
      {
         dwError = ENODEV;
      }
      /*else if (pDev->InbStatus[pDev->InbCtrlIndex].Status != TRANSFER_IDLE ||
               pDev->SendingPrim[pDev->InbCtrlIndex] != NULL ||
               pDev->InbTotalSendCount + pPrim->BuffInPool > pDev->InbDataNb)*/
      else if (pDev->InbStatus[pDev->InbCtrlIndex].Status != TRANSFER_IDLE ||
               pDev->SendingPrim[pDev->InbCtrlIndex] != NULL ||
               pDev->SendingPrim[wNextIndex] != NULL ||
               pDev->InbTotalSendCount + pPrim->BuffInPool > pDev->InbDataNb)
      {
         dwError = EAGAIN;
      }
#if 0
      else if (dwError == 0 && pDev->SendPending != 0)
      {
         /* only a USER application can wait for completion */
         if (pAppli != NULL && pAppli->Type == TYPE_USER)
         {
#ifdef DEBUG_PERF
            pDev->SendPendingWait++;
#endif
            if (CV_WAIT_SIG(&pDev->SendPendingCv, &pDev->DevMutex) <= 0 ||
                pDev->SendPending != 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCardSendPrim] failed to wait for end of transmission");
#endif
               dwError = EAGAIN;
            }
         }
         else
         {
            dwError = EAGAIN;
         }
      }
#endif

      if (dwError != 0)
      {
         /* if a correlator was just allocated, release it */
         if (pPrim->PrimId == ((MGR_PRIM | MGR_OPEN_USER)))
         {
            vAbortCorrForAppli(NULL, pDev, pAppli, pMGRSessionCorr);
         }
      }
      else
      {
         /* this section is critical only for a USER application */
         /* sending buffers */
#if 0
         if (pAppli != NULL && pAppli->Type == TYPE_USER && 
             pPrim->BuffInPool > 0)
         {
            pDev->SendPending = 1;
         }
#endif

         if (bChangeCorrStatus != 0)
         {
            CHANGE_CORR_STATUS(NULL, pMGRSessionCorr, bCorrStatus);
         }
         pPrim->PrimRef = wCardSession;
         IPH_UNLOCK(pLock);
         iph_gvDumpPrim(pPrim, pDev, pAppli, TRUE);
         IPH_LOCK(pLock);

         /* if we get here, we can send the primitive */
         dwError = dwInitDMATransfer_PQ3(pLock, TRUE, pDev, pPrim);

         if (dwError != 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCardSendPrim_PQ3] failed to prepare descriptor");
#endif
         }
         else
         {
            dwStartTransfer_PQ3(pDev);
         }
#if 0
         pDev->SendPending = 0;
         CV_SIGNAL(&pDev->SendPendingCv);
#endif
      }
      IPH_UNLOCK(pLock);
   }
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCardSendPrim_PQ3] the primitive can't be sent");
#endif
   }
   IPH_LOCK(pLock);
   pDev->SendPending = 0;
   CV_SIGNAL(&pDev->SendPendingCv);
   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwCardSendPrim] end InbTotalSendCount - InbDatNb");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                pDev->InbTotalSendCount, pDev->InbDataNb);
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCardSendPrim_PQ3] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gvInitDialogWithCard
* DESCRIPTION : initialize the dialog with the card if it is not already done
* PARAMETERS :
*    Input   : pDev = device for which the dialog must be initialized
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvInitDialogWithCard(kmutex_t *pLock, IphWanDevPtr pDev)
{
   V5_TransferCtrlPtr pTransf;
   dword tmp32;
   byte ucStatus;
   word wCount;
   DrvPool_t *pPool;
   V5_DataAddrPtr pDataAddr;
   dword winSizeDma, winSizeHost;
   dword owsDma, owsHost, owsDummy;
   dword dmaAddrStart;
   dword hostAddrStart;
   dword dummyAddrStart;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvInitDialogWithCard] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
#endif

   IPH_LOCK(pLock);

   if (pDev->Rsrc->IntfVer != V5_MAJOR_VER)
   {
      IPH_UNLOCK(pLock);
      return;
   }
   /* if the dialog with the card is not initialized yet, do it */
   if (pDev->OpenPrimDone != TRUE)
   {
      /* Note: we assume that when the dialog is not initialized, */
      /* no transfer are in progress and one transfer descriptor is */
      /* always available so we don't wait for a descriptor */

      pDev->InbCtrlIndex = 0;
      pDev->InbSendIndex = 0;
      pDev->InbStatusIndex = 0;
      pDev->OutbCtrlIndex = 0;
      pDev->OutbSendIndex = 0;
      pDev->HostToCardSigCount = 0;
      pDev->InbTotalSendCount = 0;
      bzero(pDev->HostArea, pDev->HostAreaDesc.Size);

      /* Initialize Card Control Area */
      if (pDev->Rsrc->Type == CARD_3639)
      {
         /* estimate Host DMA Area window size */
         tmp32 = pDev->LastDmaDesc->PhysAddr +
                 pDev->LastDmaDesc->Size -
                 pDev->FirstDmaDesc->PhysAddr;
         for (winSizeDma = 0x1000, owsDma = 0x0B; owsDma <= 0x1F;)
         {
            if (tmp32 <= winSizeDma &&
                ADDR_WINSIZE_MASK(pDev->FirstDmaDesc->PhysAddr, 
                                  winSizeDma) ==
                ADDR_WINSIZE_MASK(pDev->LastDmaDesc->PhysAddr +
                                  pDev->LastDmaDesc->Size - 1, winSizeDma)) 
            {
               break;
            }
            winSizeDma = winSizeDma << 1;
            owsDma++;
         }
            
         dmaAddrStart = 
            ADDR_WINSIZE_MASK(pDev->FirstDmaDesc->PhysAddr, winSizeDma);

         /* estimate Host Control Area window size */
         tmp32 = pDev->HostAreaDesc.Size;
         for (winSizeHost = 0x1000, owsHost = 0x0B; owsHost <= 0x1F;)
         {
            if (tmp32 <= winSizeHost &&
                ADDR_WINSIZE_MASK(pDev->HostAreaDesc.PhysAddr, 
                                  winSizeHost) ==
                ADDR_WINSIZE_MASK(pDev->HostAreaDesc.PhysAddr +
                                  pDev->HostAreaDesc.Size - 1, winSizeHost)) 
            {
               break;
            }
            winSizeHost = winSizeHost << 1;
            owsHost++;
         }

         hostAddrStart = 
            ADDR_WINSIZE_MASK(pDev->HostAreaDesc.PhysAddr, winSizeHost);

         /* estimate Dummy Area window size */
         tmp32 = pDev->DummyAreaDesc.Size;
         for (winSizeHost = 0x1000, owsDummy = 0x0B; owsDummy <= 0x1F;)
         {
            if (tmp32 <= winSizeHost &&
                ADDR_WINSIZE_MASK(pDev->DummyAreaDesc.PhysAddr, 
                                  winSizeHost) ==
                ADDR_WINSIZE_MASK(pDev->DummyAreaDesc.PhysAddr +
                                  pDev->DummyAreaDesc.Size - 1, winSizeHost)) 
            {
               break;
            }
            winSizeHost = winSizeHost << 1;
            owsDummy++;
         }

         dummyAddrStart = 
            ADDR_WINSIZE_MASK(pDev->DummyAreaDesc.PhysAddr, winSizeHost);
      }
      else
      {
         dmaAddrStart = pDev->FirstDmaDesc->PhysAddr;
         hostAddrStart = pDev->HostAreaDesc.PhysAddr;
         dummyAddrStart = pDev->DummyAreaDesc.PhysAddr;
         owsDma = owsHost = owsDummy = 0;
      }

      /* number of Inbound transfer control descriptor */
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init InbCtrlNb");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->InbCtrlNb);
#endif
      WRITE_EXCH_INB_CTRL_NB(pDev, pDev->ExchArea, pDev->InbCtrlNb);
      /* number of Inbound transfer data descriptor */
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init InbDataNb");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->InbDataNb);
#endif
      WRITE_EXCH_INB_DATA_NB(pDev, pDev->ExchArea, pDev->InbDataNb);
      /* number of Outbound transfer control descriptor */
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init OutbCtrlNb");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->OutbCtrlNb);
#endif
      WRITE_EXCH_OUTB_CTRL_NB(pDev, pDev->ExchArea, pDev->OutbCtrlNb);
      /* number of Outbound transfer data descriptor */
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init OutbDataNb");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->OutbDataNb);
#endif
      WRITE_EXCH_OUTB_DATA_NB(pDev, pDev->ExchArea, pDev->OutbDataNb);
      /* offset of HostArea in Host */
      tmp32 = pDev->HostAreaDesc.PhysAddr - hostAddrStart;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init HostAreaOffset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, tmp32);
#endif
      WRITE_EXCH_HOST_AREA_OFFSET(pDev, pDev->ExchArea, tmp32);
      /* offset of InbStatus table in Host Control Area */
      tmp32 = (byte *)pDev->InbStatus - (byte *)pDev->HostArea;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init InbStatusOffset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, tmp32);
#endif
      WRITE_EXCH_INB_STATUS_OFFSET(pDev, pDev->ExchArea, tmp32);
      /* offset of OutbCtrl table in Host Control Area */
      tmp32 = (byte *)pDev->OutbCtrl - (byte *)pDev->HostArea;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init OutbCtrlOffset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, tmp32);
#endif
      WRITE_EXCH_OUTB_CTRL_OFFSET(pDev, pDev->ExchArea, tmp32);
      /* offset of OutbSend table in Host Control Area */
      tmp32 = (byte *)pDev->OutbSend - (byte *)pDev->HostArea;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init OutbSendOffset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, tmp32);
#endif
      WRITE_EXCH_OUTB_SEND_OFFSET(pDev, pDev->ExchArea, tmp32);

      /* Fill InbAddr table */
      READ_EXCH_INB_ADDR_OFFSET(pDev, pDev->ExchArea, &tmp32);
      tmp32 = OFFSET_CARD_TO_HOST(tmp32);
      pDataAddr = (V5_DataAddrPtr)(unsigned long)(tmp32 + pDev->ExchArea);
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init InbAddr at offset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)(unsigned long)pDataAddr);
#endif
      for (wCount = 0; wCount < pDev->InbDataNb; wCount++)
      {
         /* give offset of the buffer in the InbAddr table */
         tmp32 = pDev->SendDmaDesc[wCount].PhysAddr - dmaAddrStart;
         WRITE_MEM_DWORD(pDev, &(pDataAddr[wCount].BufferOffset), tmp32);
      }
      /* Initialize pool sizes */
      for (wCount = 0; wCount <= pDev->LastPool; wCount++)
      {
         pPool = &pDev->FreeDataPools[wCount];
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                          (byte *)"[gvInitDialogWithCard] init pool index/size");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                      wCount, pPool->PoolSize);
#endif
         WRITE_EXCH_OUTB_POOL_SIZE(pDev, pDev->ExchArea, pPool->PoolSize, wCount);
         pDev->OutbPoolIndex[wCount] = 0;
      }
      /* Fill OutbAddr table and OutbPool */
      READ_EXCH_OUTB_ADDR_OFFSET(pDev, pDev->ExchArea, &tmp32);
      tmp32 = OFFSET_CARD_TO_HOST(tmp32);
      pDataAddr = (V5_DataAddrPtr)(unsigned long)(tmp32 + pDev->ExchArea);
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gvInitDialogWithCard] init OutbAddr at offset");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)(unsigned long)pDataAddr);
#endif
      for (wCount = 0; wCount < pDev->OutbDataNb; wCount++)
      {
         /* give offset of the buffer in the OutbAddr table */
         tmp32 = pDev->RecvDmaDesc[wCount].PhysAddr - dmaAddrStart;
         WRITE_MEM_DWORD(pDev, &(pDataAddr[wCount].BufferOffset), tmp32);
         /* add buffer in the card pool */
         GIVE_BUFF_TO_CARD(pDev, &pDev->RecvDmaDesc[wCount]);
      }

      if (pDev->Rsrc->Type == CARD_3639)
      {
         /* initialize POTAR0 with address of the Dummy area */
         tmp32 = dummyAddrStart;
         tmp32 = tmp32 >> 12;
         WRITE_CORE_DWORD(pDev, MPC856X_POTAR0, tmp32);

         /* initialize POWAR0 with correct window size */
         tmp32 = 0x80044000 | owsDummy;
         WRITE_CORE_DWORD(pDev, MPC856X_POWAR0, tmp32);

         /* initialize POTAR1 with address of the Host DMA area */
         tmp32 = dmaAddrStart;
         tmp32 = tmp32 >> 12;
         WRITE_CORE_DWORD(pDev, MPC856X_POTAR1, tmp32);

         /* initialize POWAR1 with correct window size */
         tmp32 = 0x80044000 | owsDma;
         WRITE_CORE_DWORD(pDev, MPC856X_POWAR1, tmp32);

         /* initialize POTAR2 with address of the Host control area */
         tmp32 = hostAddrStart;
         tmp32 = tmp32 >> 12;
         WRITE_CORE_DWORD(pDev, MPC856X_POTAR2, tmp32);

         /* initialize POWAR2 with correct window size */
         tmp32 = 0x80044000 | owsHost;
         WRITE_CORE_DWORD(pDev, MPC856X_POWAR2, tmp32);

         /* enable interrupts from the card */
         /* - by setting E1 bit in MER register */
         READ_CORE_DWORD(pDev, MPC856X_MER, &tmp32);
         tmp32 |= 0x00000002;
         WRITE_CORE_DWORD(pDev, MPC856X_MER, tmp32);
         /* - by setting EP bit in MIDR1 register */
         WRITE_CORE_DWORD(pDev, MPC856X_MIDR1, 0x80000000);
      }

      /* get the first descriptor that can be used for the transmission */
      /* from host to local */
      pTransf = &pDev->InbCtrl[0];

      READ_TRANSFER_STATUS(pDev, pTransf, &ucStatus);
      if (ucStatus != TRANSFER_IDLE)
      {
         /* something may be wrong because all the descriptors are used... */
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                      (byte *)"[gvInitDialogWithCard] unable to get a transfer descriptor");
#endif
      }
      else
      {
         pDev->InbStatus[pDev->InbCtrlIndex].Status = TRANSFER_READY;
         /* update the index of the first descriptor to use next time */
         pDev->InbCtrlIndex++;

         /* wraps the index if necessary */
         if (pDev->InbCtrlIndex == pDev->InbCtrlNb)
         {
            pDev->InbCtrlIndex = 0;
         }
         pDev->InbStatusIndex = pDev->InbCtrlIndex;
         /* initialize the transfer descriptor fields */
         WRITE_TRANSFER_REF_INDX(pDev, pTransf, pDev->RefIndex);
         WRITE_TRANSFER_PRIM_ID(pDev, pTransf, OPEN_PRIM);
         WRITE_TRANSFER_PRIM_REF(pDev, pTransf, 0);
         WRITE_TRANSFER_DATA_COUNT(pDev, pTransf, 0);

         /* update the status for the transfer descriptor */
         WRITE_TRANSFER_STATUS(pDev, pTransf, TRANSFER_READY);

         dwStartTransfer_PQ3(pDev);

#ifdef DEBUG_PERF
         /* counters to monitor driver's activity */
         pDev->SendNb++;
         if (pDev->SendNb > pDev->MaxSendNb)
         {
            pDev->MaxSendNb = pDev->SendNb;
         }
#endif
         /* initialization is now done */
         pDev->OpenPrimDone = TRUE;
         pDev->OpenPrimToDo = FALSE;
      }
   }
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gvInitDialogWithCard] initialization already done");
#endif
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvInitDialogWithCard] return");
#endif
}

