/****************************************************************************
 * (C) Copyright Interphase Corp 2005.
 * NAME : PEX811X811x.h
 * DESCRIPTION : 
 *    Define for PEX811X device
 * 
 * REVISIONS : 1.0
 *    
 ****************************************************************************/
 
#ifndef _IPH_PEX811X_H
#define _IPH_PEX811X_H

#define PEX811X_BOARD_HRESET_EN        0x00000020
#define PEX811X_BOARD_HRESET_BIT       0x00000002
#define PEX811X_BOARD_SRESET_EN        0x00000080
#define PEX811X_BOARD_SRESET_BIT       0x00000008


#define READ_STATUS_PEX811X_EE_OPCODE  5
#define WREN_PEX811X_EE_OPCODE         6
#define WRITE_PEX811X_EE_OPCODE        2
#define READ_PEX811X_EE_OPCODE         3

/*--------- PLX PEX811X8111 Control Register Offsets */
#define PEX811X_DEVINIT             0x1000   
#define PEX811X_EECTL               0x1004       
#define PEX811X_EECLKFREQ           0x1008
#define PEX811X_PCICTL              0x100C   
#define PEX811X_PCIEIRQENB          0x1010
#define PEX811X_PCIIRQENB           0x1014
#define PEX811X_IRQSTAT             0x1018   
#define PEX811X_POWER               0x101C       
#define PEX811X_GPIOCTL             0x1020   
#define PEX811X_GPIOSTAT            0x1024   
#define PEX811X_MAILBOX0            0x1030  
#define PEX811X_MAILBOX1            0x1034   
#define PEX811X_MAILBOX2            0x1038   
#define PEX811X_MAILBOX3            0x103C   
#define PEX811X_CHIPREV             0x1040   
#define PEX811X_DIAG                0x1044       
#define PEX811X_TLPCFG0             0x1048   
#define PEX811X_TLPCFG1             0x104C   
#define PEX811X_TLPCFG2             0x1050   
#define PEX811X_TLPTAG              0x1054   
#define PEX811X_TLPTIMELIMIT0       0x1058        
#define PEX811X_TLPTIMELIMIT1       0x105C        
#define PEX811X_CRSTIMER            0x1060   
#define PEX811X_ECFGADDR            0x1064

/* PEX811X8111 EEPROM */
#define PEX811X_EEPROM_SIZE 0x80 // 128 bytes

/* PEX811X8111 Register Settings */
#define PEX811X_EEPROM_BUSY         19
#define PEX811X_EEPROM_CS_ENABLE    18
#define PEX811X_EEPROM_BYTE_READ_START 17
#define PEX811X_EEPROM_BYTE_WRITE_START 16
#define PEX811X_EEPROM_READ_DATA    8
#define PEX811X_EEPROM_WRITE_DATA   0

/* iSPAN 3639 PEX811X GPIO Values */
#define PEX811X_WP_OE               0x40
#define PEX811X_WP_N                0x04

/* Read write Macros */
#endif
