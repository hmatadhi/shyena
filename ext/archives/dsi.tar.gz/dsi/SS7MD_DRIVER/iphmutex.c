/****************************************************************************
 * (C) Copyright Interphase Corp 2005-2007.
 *
 * NAME : iphmutex.c
 * VERSION : 1.03
 * DESCRIPTION : 
 *    Linux implementation of mutex and conditional variable functions
 * REVISIONS :
 *    - Version 1.00 12/01/05 : Creation
 *    - Version 1.01 12/07/06 : Add drv_ prefix to any routine
 *    - Version 1.02 02/20/07 : Include <linux/autoconf.h> file instead of
 *                              <linux/config.h> file.
 *    - Version 1.03 09/27/07 : Fix gcc4 compilation problems
 *
 * FUNCTIONS LIST :
 *    Local functions :
 *    Public functions :
 *       drv_mutex_init
 *       drv_mutex_lock
 *       drv_mutex_trylock
 *       drv_mutex_unlock
 *       drv_cond_init
 *       drv_cond_wait
 *       drv_cond_timed_wait_rel
 *       drv_cond_timed_wait_abs
 *       drv_cond_signal
 *       drv_cond_broadcast
 *    
 ****************************************************************************/
#define MUTEX_C
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 33)
#include <linux/autoconf.h>
#else
#include <generated/autoconf.h>
#endif
#if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
#define MODVERSIONS
#endif

#ifdef MODVERSIONS
#ifdef LINUX_2_4
#include <linux/modversions.h>
#endif
#ifdef LINUX_2_6
#include <config/modversions.h>
#endif
#endif

#include <asm/delay.h>
#include <linux/sched.h>

#include "iphmutex.h"

static void drv_mutex_init(mutex_t *mx, int lockIT, char *desc)
{
   spin_lock_init(&mx->spin);
   mx->count_lock = 0;
   mx->count_unlock = 0;
   mx->lockIT = lockIT;
   mx->desc = desc;
}

static void drv_mutex_lock(mutex_t *mx)
{
   unsigned long flags;
   if (mx->lockIT == 1)
   {
      spin_lock_irqsave(&mx->spin, flags);
      mx->flags = flags;
   }
   else
      spin_lock(&mx->spin);
   mx->count_lock++; 
}

static int drv_mutex_trylock(mutex_t *mx)
{
   unsigned long flags;
#ifdef LINUX_2_4
   __save_flags(flags); __cli();
#else
   local_save_flags(flags);
   local_irq_disable();
#endif
   if (spin_trylock(&mx->spin))
   {
      mx->flags = flags;
      return 1;
   }
#ifdef LINUX_2_4
   __restore_flags(flags);
#else
   local_irq_restore(flags);
#endif
   return 0;
}

static void drv_mutex_unlock(mutex_t *mx)
{
   unsigned long flags = mx->flags;

   if (mx->lockIT == 1)
      spin_unlock_irqrestore(&mx->spin, flags);
   else
      spin_unlock(&mx->spin);
   mx->count_unlock++;
}

static void drv_cond_init(cond_t *cv)
{
   init_waitqueue_head(&cv->queue);
}

static int drv_cond_wait(cond_t *cv, mutex_t *mx)
{
   wait_queue_t wait;
   int ret;

   init_waitqueue_entry(&wait, current);   
   current->state = TASK_INTERRUPTIBLE;
   add_wait_queue(&cv->queue, &wait);

   drv_mutex_unlock(mx);

   schedule();
   ret = signal_pending(current) ? COND_WAIT_SIGNAL : COND_WAIT_SUCCESS;
   current->state = TASK_RUNNING;
   remove_wait_queue(&cv->queue, &wait);

   drv_mutex_lock(mx);
   return ret;
}

static int drv_cond_timed_wait_rel(cond_t *cv, mutex_t *mx, long jiff_delta)
{
   wait_queue_t wait;
   int ret;
   long remaining;

   init_waitqueue_entry(&wait, current);   
   current->state = TASK_INTERRUPTIBLE;
   add_wait_queue(&cv->queue, &wait);

   drv_mutex_unlock(mx);

   remaining = schedule_timeout(jiff_delta);
   ret = remaining ? (signal_pending(current) ? COND_WAIT_SIGNAL : COND_WAIT_SUCCESS) : COND_WAIT_TIMEOUT;
   current->state = TASK_RUNNING;
   remove_wait_queue(&cv->queue, &wait);
   drv_mutex_lock(mx);
   return ret;
}

static int drv_cond_timed_wait_abs(cond_t *cv, mutex_t *mx, unsigned long jiff_wakeup)
{
   long delta = jiff_wakeup - jiffies;

   /* Avoid accidental indefinite suspension; maybe the user really wanted
      a 497 day delay! :) */

   if (delta == MAX_SCHEDULE_TIMEOUT)
      --delta;

   return drv_cond_timed_wait_rel(cv, mx, delta);
}

static void drv_cond_signal(cond_t *cv)
{
   /* todo: need way to wake up single process */
   wake_up_interruptible(&cv->queue);
}

static void drv_cond_broadcast(cond_t *cv)
{
   wake_up_interruptible(&cv->queue);
}
