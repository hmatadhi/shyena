/****************************************************************************
 * NAME : iphtrace.h
 * VERSION : 1.02
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the iphtrace module of the base driver
 * REVISIONS :
 *    - Version 1.0 12/15/05 : Creation
 *    - Version 1.1 06/22/06 : Fix filter on IPHWAN_SVRDATA_ID traces
 *                             Change global prefix into iphwae
 *    - Version 1.02 06/25/08 : Add the IPHWAN_DATA_PRIM_ID module id
 *                              Rename IPHWAN_DATA_ID into IPHWAN_OTHER_PRIM_ID
 *                              Rename IPHWAN_SVRDATA_ID into IPHWAN_SVR_PRIM_ID
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHTRACE_H
#define IPHTRACE_H

#ifdef IPHTRACE_C
static dword drv_TRACE_NO_PARAM(byte module_id, byte trace_type, word trace_id);
static dword drv_TRACE_D1(byte module_id, byte trace_type, word trace_id, 
                          dword data);
static dword drv_TRACE_D2(byte module_id, byte trace_type, word trace_id,
                          dword data1, dword data2);
static dword drv_TRACE_STRING(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf);
static dword drv_TRACE_STRUCT(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf);
static dword drv_TRACE_PACKET(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf);
static void drv_gvDumpDrvPool(DrvPoolPtr pPool);
static void drv_gvDumpIoctlCmd(dword dwCmd);
static void drv_gvDumpPrim(PrimDescPtr pPrim, IphWanDevPtr pDev,
                           ApplCtxtPtr pAppli, byte bSent);

#define ExportGlobalTrace(PRFX) \
kmutex_t iph##PRFX##_gTraceMutex; \
byte iph##PRFX##_gpucTraceMask[256];\
byte *iph##PRFX##_gpucTrace;\
dword iph##PRFX##_TRACE_NO_PARAM(byte mod, byte type, word id)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_NO_PARAM(mod,type,id));\
}\
dword iph##PRFX##_TRACE_D1(byte mod, byte type, word id, dword data)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_D1(mod,type,id,data));\
}\
dword iph##PRFX##_TRACE_D2(byte mod, byte type, word id, dword d1, dword d2)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_D2(mod,type,id,d1,d2));\
}\
dword iph##PRFX##_TRACE_STRING(byte mod, byte type, word id, word l, byte *b)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_STRING(mod,type,id,l,b));\
}\
dword iph##PRFX##_TRACE_STRUCT(byte mod, byte type, word id, word l, byte *b)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_STRUCT(mod,type,id,l,b));\
}\
dword iph##PRFX##_TRACE_PACKET(byte mod, byte type, word id, word l, byte *b)\
{\
   if (iph##PRFX##_gpucTraceMask[mod] == FALSE)\
      return(1); \
   return(drv_TRACE_PACKET(mod,type,id,l,b));\
}\
void iph##PRFX##_gvDumpDrvPool(DrvPoolPtr pPool)\
{\
   if (iph##PRFX##_gpucTrace == (byte *)0 || \
       iph##PRFX##_gpucTraceMask[IPHWAN_ID] == FALSE)\
      return; \
   drv_gvDumpDrvPool(pPool);\
}\
void iph##PRFX##_gvDumpIoctlCmd(dword dwCmd)\
{\
   if (iph##PRFX##_gpucTrace == (byte *)0 || \
       iph##PRFX##_gpucTraceMask[IPHWAN_ID] == FALSE)\
      return; \
   drv_gvDumpIoctlCmd(dwCmd);\
}\
void iph##PRFX##_gvDumpPrim(PrimDescPtr pPrim, IphWanDevPtr pDev,\
                           ApplCtxtPtr pAppli, byte bSent)\
{\
   if (iph##PRFX##_gpucTrace == (byte *)0 || \
       (iph##PRFX##_gpucTraceMask[IPHWAN_ID] == FALSE &&\
        iph##PRFX##_gpucTraceMask[IPHWAN_OTHER_PRIM_ID] == FALSE &&\
        iph##PRFX##_gpucTraceMask[IPHWAN_DATA_PRIM_ID] == FALSE &&\
        iph##PRFX##_gpucTraceMask[IPHWAN_SVR_PRIM_ID] == FALSE))\
      return; \
   drv_gvDumpPrim(pPrim, pDev, pAppli, bSent);\
}

ExportGlobalTrace(wae)

#ifdef LINUX
#define CONSOLE_PRINT(buff)\
   strcat(buff, "\n");\
   printk(buff);
#endif
#ifdef SOLARIS
#define CONSOLE_PRINT(buff)\
   cmn_err(CE_NOTE, buff);
#endif

#ifndef DEBUG_LEVEL
#define DEBUG_LEVEL TRCLVL_1
#endif

#define ExportGlobalTraceK(PRFX) \
int iph##PRFX##_debug = DEBUG_LEVEL;\
void iph##PRFX##_TRACEK(int level, char *str, ...)\
{\
   va_list ap;\
   char bufk[256];\
   int len = 0;\
   if (level <= iph##PRFX##_debug)\
   {\
      if (level > TRCLVL_0)\
      {\
         sprintf(bufk, "<%d>->", level);\
         len = strlen(bufk);\
      }\
      va_start(ap, str);\
      vsnprintf(&bufk[len], sizeof(bufk)-len, str, ap);\
      va_end(ap);\
      CONSOLE_PRINT(bufk);\
   }\
}
ExportGlobalTraceK(wae)

#ifdef LINUX_2_6
EXPORT_SYMBOL(iphwae_TRACE_NO_PARAM);
EXPORT_SYMBOL(iphwae_TRACE_PACKET);
EXPORT_SYMBOL(iphwae_TRACE_D1);
EXPORT_SYMBOL(iphwae_TRACE_D2);
EXPORT_SYMBOL(iphwae_TRACE_STRING);
EXPORT_SYMBOL(iphwae_TRACE_STRUCT);
#endif

#else /* IPHTRACE_C */

#define ExportExtTrace(PRFX) \
extern kmutex_t iph##PRFX##_gTraceMutex; \
extern byte iph##PRFX##_gpucTraceMask[256];\
extern byte *iph##PRFX##_gpucTrace;\
dword iph##PRFX##_TRACE_NO_PARAM(byte mod, byte type, word id);\
dword iph##PRFX##_TRACE_D1(byte mod, byte type, word id, dword data);\
dword iph##PRFX##_TRACE_D2(byte mod, byte type, word id, dword d1, dword d2);\
dword iph##PRFX##_TRACE_STRING(byte mod, byte type, word id, word l, byte *b);\
dword iph##PRFX##_TRACE_STRUCT(byte mod, byte type, word id, word l, byte *b);\
dword iph##PRFX##_TRACE_PACKET(byte mod, byte type, word id, word l, byte *b);\
void iph##PRFX##_gvDumpDrvPool(DrvPoolPtr pPool);\
void iph##PRFX##_gvDumpIoctlCmd(dword dwCmd);\
void iph##PRFX##_gvDumpPrim(PrimDescPtr pPrim, IphWanDevPtr pDev,\
                            ApplCtxtPtr pAppli, byte bSent);

ExportExtTrace(wae)

#define ExportExtTraceK(PRFX) \
extern int iph##PRFX##_debug;\
void iph##PRFX##_TRACEK(int level, char *str, ...);

ExportExtTraceK(wae)
#endif

#define iph_gTraceMutex iphwae_gTraceMutex
#define iph_gpucTraceMask iphwae_gpucTraceMask
#define iph_gpucTrace iphwae_gpucTrace
#define iph_TRACE_NO_PARAM iphwae_TRACE_NO_PARAM
#define iph_TRACE_D1 iphwae_TRACE_D1
#define iph_TRACE_D2 iphwae_TRACE_D2
#define iph_TRACE_STRING iphwae_TRACE_STRING
#define iph_TRACE_STRUCT iphwae_TRACE_STRUCT
#define iph_TRACE_PACKET iphwae_TRACE_PACKET
#define iph_gvDumpDrvPool iphwae_gvDumpDrvPool
#define iph_gvDumpIoctlCmd iphwae_gvDumpIoctlCmd
#define iph_gvDumpPrim iphwae_gvDumpPrim
#define iph_TRACEK iphwae_TRACEK
#define iph_debug iphwae_debug

#endif
