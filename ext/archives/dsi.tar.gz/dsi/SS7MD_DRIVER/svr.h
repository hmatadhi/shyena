/****************************************************************************
 * NAME : svr.h
 * VERSION : 3.2
 * DESCRIPTION : 
 *    Constants, types, structures, macros for using the Supervision layer
 * REVISIONS :
 *    - Version 1.0 01/27/97 : Creation
 *    - Version 2.0 07/24/97 : (SET_VAR|x)    -> (SVR_SET_VAR|x)
 *                             (VAR_IS|x)     -> (SVR_VAR_IS|x)
 *                             (SIGNAL_ON|x)  -> (SVR_SIGNAL_ON|x)
 *                             (SIGNAL_OFF|x) -> (SVR_SIGNAL_OFF|x)
 *    - Version 3.0 04/22/98 : change on SVRCODE, SVRDECODE, SVRHIBYTE and
 *                             SVRLOBYTE macros
 *    - Version 3.1 12/16/02 : Add some SVR errors
 *    - Version 3.2 08/16/05 : Add the session parameter dynamic update constant
 ****************************************************************************/

#ifndef SVR_H
#define SVR_H

/***************************************************************************/
/* macros to encode/decode ISO8825 index                                   */
/***************************************************************************/
#define NEXT_BYTE_MSK      0x80

/* ISO8825 with bit 7 ( 0x80 ) as an indicator */

#define SVRCODE(x)                           \
   ((x & (0x7F)) | (((x & 0x3F80) != 0) << 15) | ((x & 0x3F80) << 1))

#define SVRHIBYTE(x)                         \
   ((byte)((SVRCODE(x) & 0xFF00) >> 8))

#define SVRLOBYTE(x)                         \
   ((byte)(SVRCODE(x) & 0xFF))

#define SVRDECODE(x)                         \
   (((x & 0x3F00) >> 1) & (-((x & 0x8000) != 0)) | (x & (0x7F)))

#define SVRCODE_EXCEPTION  0xFFFF

/***************************************************************************/
/* SVR primitives                                                          */
/***************************************************************************/

/* Type of SVR primitives */

#define SVR_PRIM             0x7E00

#define ERR_BIT              0x0080               /* error indication bit */
#define ANS_BIT              0x0001               /* answer indication bit */

/* Sub-types of SVR primitives */

#define SVR_CLOSE_USER       0x00                 /* close a session */
#define SVR_USER_CLOSED      0x00                 /* session closed */

#define SVR_OPEN_USER        0x01                 /* open a session */
#define SVR_USER_OPENED      0x01                 /* session opened */

#define SVR_GET_VAR          0x0010               /* get variable value */
#define SVR_VAR_IS           (SVR_GET_VAR|ANS_BIT)/* variable value got */

#define SVR_SET_VAR          0x0012               /* set variable value */
#define SVR_VAR_SET          (SVR_SET_VAR|ANS_BIT)/* variable value set */

#define SVR_SIGNAL_ON        0x0014               /* variable activation */
#define SVR_SIGNAL_STAT_ON   (SVR_SIGNAL_ON|ANS_BIT)  /* variable activated */

#define SVR_SIGNAL_OFF       0x0016               /* variable deactivation */
#define SVR_SIGNAL_STAT_OFF  (SVR_SIGNAL_OFF|ANS_BIT) /* variable deactivated */

#define SVR_SIGNAL           0x0018               /* trace */
#define SVR_DATA_LOST        0x0019               /* data lost */

#define SVR_DATA_ACK         0x0005               /* trace acknowledgment */
#define SVR_RNR_REQ          0x0006               /* trace flow blocking */
#define SVR_RR_REQ           0x0007               /* trace flow unblocking */

#define SVR_PARAMETERS       0x0020               /* configuration */


/***************************************************************************/
/* SVR errors                                                              */
/***************************************************************************/
#define SVRREF_ERR                  0xFFF0
#define UNKNOWN_OBJECT              0xFFF0
#define TYPES_NOT_COMPATIBLE        0xFFEF
#define VALUE_NOT_POSSIBLE          0xFFEE
#define ACTIVATE_ERR                0xFFED
#define DEACTIVATE_ERR              0xFFEC
#define OBJECT_NOT_ACCESSIBLE       0xFFEB
#define SIG_MODE_ERR                0xFFEA
#define BAD_OBJ_ERR                 0xFFE9
#define BAD_STATE_ERR               0xFFE8
#define ACCESS_ERR                  0xFFE7
#define SYNTAX_ERR                  0xFFE6
#define LENGTH_ERR                  0xFFE5
#define MEM_ERR                     0xFFE4
#define ALREADY_SVR_ERR             0xFFE3
#define SESSION_ERR                 0xFFE2
#define CMD_ERR                     0xFFE1
#define LAYER_ERR                   0xFFE0
#define SVR_UNAVAILABLE_ERR         0xFFDF
#define FORMAT_ID_ERR               0xFFDE
#define DATE_ERR                    0xFFDD
#define FLASH_ACCESS_ERR            0xFFDC
#define SSN_ERR                     0xFFDB
#define DURATION_ERR                0xFFDA
#define SVR_OK                      0

/***************************************************************************/
/* Maximum size of an object identificator                                 */
/***************************************************************************/
#define  SVR_MAX_INFO       8

/***************************************************************************/
/* Set or update dynamic configuration parameters                          */
/***************************************************************************/
#define  SET_SESSION_PARAM  0x32  /* set param req discriminant */

/***************************************************************************/
/* Objects type                                                            */
/***************************************************************************/
#define  SVRARRAY          0
#define  SVRBYTE           sizeof(byte)
#define  SVRWORD           sizeof(word)
#define  SVRDWORD          sizeof(dword)
#define  SVRBUFFER         3

/***************************************************************************/
/* Filter type                                                             */
/***************************************************************************/
#define ASSIGN_FILTER         0x00

#endif


