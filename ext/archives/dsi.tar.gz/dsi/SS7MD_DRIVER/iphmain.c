/****************************************************************************
 * (C) Copyright Interphase Corp 2005-2010.
 * NAME : iphmain.c
 * VERSION : 1.34.4.2+
 * DESCRIPTION : 
 *    Linux/Solaris driver file entry points
 * 
 * REVISIONS :
 *    - Version 1.0 10/04/2005 : Creation
 *    - Version 1.1 02/03/2006 : - Change /proc/iphwamc management (SEQ_PROC)
 *                               - Get Hardware Revision number in SEEPROM
 *    - Version 1.2 02/14/2006 : - On attach, poll ATN to detect end of POST
 *                               - in iph_gdwResetBoard, reset card context and
 *                                 state if not already done
 *    - Version 1.3 02/14/2006 : - On attach, add an extra delay after end 
 *                                 of POST
 *                               - Do not get DRAM size from BER
 *    - Version 1.4 03/21/2006 : - Fix a bug in timer management on detach
 *                               - Update for Solaris
 *                               - Use HOST_CORExx macros to convert values 
 *                                 for PQIII
 *                               - In iph_detach_device fix bug when stopping 
 *                                 timers
 *                               - Use IPHWAN_REGACC_ID module Id to isolate 
 *                                 trace for access to registers & DRAM
 *    - Version 1.5 05/15/2006 : - For Solaris, set IT priority to 1
 *    - Version 1.6 05/19/2006 : - In run_ioctl(CTL_CHECK_CARD_STATUS) 
 *                                 restart PollTimer only if it is not already
 *                                 started
 *    - Version 1.7 06/22/2006 : - Fix multicard support on LINUX: 
 *                                 all Pex PCI devices may be attached before 
 *                                 the 1st PQ3 device is attached.
 *                                 The link between the Pex and the PQ3 is
 *                                 established thanks to the PCI bus descriptor
 *                                 stored in the PCI device context
 *                               - Rename driver into iphwae
 *    - Version 1.8 07/12/2006 : - Use MUTEX_xx and CV_xx macros
 *                               - gdwResetBoard becomes public
 *    - Version 1.9 09/04/2006 : 
 *      - In iph_open/iph_kernel_open, complete device context init only if
 *        no application is controlling the device.
 *      - On Solaris, change the version displayed with modinfo (use _VERSION_)
 *    - Version 1.10 09/21/2006: 
 *      - Add support for 5639
 *    - Version 1.11 12/20/2006: LINUX only
 *      - Suppress many Linux compilation warnings
 *      - Check the device id specified in the PEX Mailbox 3
 *      - Manage the situation where the attachment is rejected by the PEX device
 *    - Version 1.12 01/24/2007: SOLARIS only
 *      - SOLARIS only: iph_detach returns DDI_FAILURE if some applications are 
 *        currently using the the device to detach (This situation may occur 
 *        during boot phase while iphPortStatd is active)
 *      - Add a 2s delay when detaching in case StatusPoll executes once more
 *    - Version 1.13 01/31/2007: LINUX only
 *      - Release every context in case of non Interphase card found
 *    - Version 1.14 04/03/2007: 
 *      - Add the DATA_IND dedicated buffer support
 *      - generic_writebuf performs 32 bit accesses instead of 8 bit 
 *        (Linux only) 
 *      - Reset the adapter in the detach procedure after the timer tasks are
 *        removed.
 *    - Version 1.15 05/10/2007: 
 *      - Add PCI location information in /proc/iphwae
 *    - Version 1.16 07/12/2007: 
 *      - Add the Linux hotplug support
 *      - Add the secondary rsrc id support
 *      - Shutdown the adapter before resetting the card even if the card
 *        is not RESET. (ShtudownAdapter is required to kill all the timer 
 *        routines)
 *      - Add a 2s sleep before resetting the card in case the last timer 
 *        routine execution is still pending.
 *      - Add the 3639 rev.C support (default PQIII configuration is different
 *        when resetting with boot holdoff set 
 *    - Version 1.17 07/19/2007: 
 *      - Change the serial number acquisition prototype in order to retrieve
 *        the customer information as well
 *      - Add the CTL_GET_CUSTOM_INFO ioctl support
 *    - Version 1.18 08/16/2007: 
 *      - Release the current mutex before copy_to_user in CHECK_CARD_STATUS
 *    - Version 1.19 09/27/2007: 
 *      - Free the card context when attach is called for an unupported card
 *        equipped with a PEX (Linux only)
 *      - Add support for 32-bit applis on 64-bit systems (Linux 2.6 only)
 *      - Add the 5639E support
 *    - Version 1.20 10/15/2007: 
 *      - On Linux, support of 32-bit applis on 64-bit systems is done 
 *        only if COMPAT_IOCTL is defined
 *    - Version 1.21 04/16/2008: 
 *      - Use pci_register_driver() instead of pci_module_init() after
 *        Linux 2.6.18 version.
 *      - Remove return code checking of the unregister_chrdev() since no
 *        return code is provided after Linux 2.6.18 version.
 *      - COMPAT_IOCTL is defined automatically if the linux version
 *        is greater than 2.6.10
 *    - Version 1.22 04/21/2008:
 *         - Use IRQF_SHARED instead of SA_SHIRQ after
 *           Linux 2.6.18 version.
 *    - Version 1.23 06/24/2008: 
 *      - Add support for 32-bit applis on 64-bit systems for Linux < 2.6.10
 *      - Support of 32-bit applis on 64-bit systems is restricted to 2.6 kernels
 *    - Version 1.24 07/29/2008: 
 *      - until now, reset of a card was entirely done under DevMutex lock. 
 *        This was leading to a system crash (because of MDELAY with semaphore 
 *        hold) when another application (like iphDumpCardList) was launched 
 *        during reset.
 *        Now protection is done only with device status set to CARD_RESETTING
 *        before real reset (no more done with DevMutex locked).
 *      - Add the 5639L support
 *    - Version 1.25 08/11/2008: 
 *      - Custom info offset and size depend on the card type
 *      - Allow an application to retrieve the bound card custom information 
 *        without specifying the serial number
 *      - resource and card is matched thanks to the card id and the front/rear 
 *        T1/E1 port presence
 *    - Version 1.26 09/01/2008: 
 *      - in dwBuildCardRsrc, do not swap value directly in buffer because of
 *        unaligned access causing crash on Solaris Sparc
 *      - in MovePQ3Window, when moving the window, change the way to wait for
 *        the move (replace UDELAY with a register read)
 *      - in CTL_CHECK_CARD_STATUS, release lock before deleting status timer
 *        to avoid dead lock if the timer has just began to run.
 *      - on SOLARIS, deal with 16/32 bit unaligned read/write to avoid 
 *        system crash
 *      - on SOLARIS, 5639L is reset through the FPGA reset command 
 *      - on SOLARIS, 5639/5639E are reset through the EPLD reset command
 *      - on SOLARIS, check the reset capability in FPGA or EPLD but reject
 *        attachment only if CHECK_RESET_CAPABILITY compilation option 
 *        is enabled, else display a warning
 *      - Add support for Solaris 9 (SOL_9 compilation option)
 *    - Version 1.27 10/22/2008: 
 *      - on SOLARIS, reset card on detach
 *      - on SOLARIS 10, call ddi_intr_enable/ddi_intr_disable only once on
 *        attach/detach to avoid spurious IT messages when resetting the card
 *    - Version 1.28 10/30/2008: 
 *      - reset without PEX is reserved to Solaris
 *    - Version 1.29 11/06/2008: 
 *      - include linux/ioctl32.h only if OLD_COMPAT (It is not supported on
 *        kernels higher than 2.6.21)
 *      - Add the support of PEX device 0x8112
 *    - Version 1.30 11/19/2008: 
 *      - on application end, wait for the end of all the pending sessions 
 *        before freeing the context to ensure that the IT handler will always
 *        have a valid application context
 *      - move the reset capability checking after the end of reset is detected
 *        to avoid erroneous warning (access to FPGA/EPLD fails if the card is
 *        resetting).
 *    - Version 1.31 12/15/2008: 
 *      - Retry sending MGR_CLOSE_USER on EAGAIN when processing automatic
 *        session close at application closure
 *    - Version 1.32 01/07/2009: 
 *      - fix a bug on application closure when a session cannot be closed
 *        because of a lack of resource and log the error
 *      - Add CTL_GET_TIME and CTL_SET_HOST_TIME_OFFSET command support
 *    - Version 1.33 01/22/2009: 
 *      - Board reset is done through PEX (instead of FPGA) on Solaris intel 
 *        platforms
 *    - Version 1.34 01/30/2009: 
 *      - Do not access a device context if it is not fully attached
 *    - Version 1.34.1 02/23/2009: 
 *      - Restore ddi_intr_enable/ddi_intr_disable in iph_add_intr/iph_rem_intr
 *        for Solaris 10 only. Not doing this (on Solaris Intel) was leading to 
 *        a pb with MDELAY called during ResetBoard (it was not ending)
 *      - Do not advertize the PEX device in case of Linux 2.4
 *        (RHEL 3 distribution brings a generic bridge driver that is
 *         automatically attached to the PEX device at boot time)
 *      - Fix a lock up problem on driver unload when PQIII failed to attach and
 *        PEX is already attached
 *      - Update the number of attached cards only when a card is fully attached
 *        (PEX + PQIII devices)
 *    - Version 1.34.2 04/03/2009: 
 *      - In vEndAppli, if a session could not be successfully closed 
 *        (because of memory shortage), reset reference to the application in
 *        the correlator
 *      - before removing IT handler, disables IT on card
 *    - Version 1.34.3 05/11/2009: 
 *      - Add support for 32-bit applis on 64-bit systems for Linux 2.4
 *      - Add the CARD_UNAVAILABLE status support
 *      - Add the CTL_GET_TEMP_INFO ioctl support
 *      - Add the 64MB flash support
 *      - Do not attach if too many cards (Solaris)
 *    - Version 1.34.4 06/15/2009: 
 *      - Consider the case where device minor number is required to be
 *        manually assigned instead of being assigned by Solaris
 *    - Version 1.34.4.1 07/01/2010: 
 *      - Add the I2C access semaphore support
 *    - Version 1.34.4.2 07/02/2010: 
 *      - Add the CTL_DUMP_SEEPROM_BYTE and CTL_WRITE_SEEPROM_BYTE 
 *        ioctl command support
 *      - Declare as volatile any data read from the device (Linux only)
 *        (see generic_read... functions)
 *    - Version 1.34.4.2+ 24/02/2010 - ****** NOTE ***** Temporary change 
 *      made by JCo to get around Solaris 10 x86 update 9 where the 
 *      ddi_intr_set_pri  call is broken. this is specifically for RW depolying
 *      on the HP DL380 G7 server. 
 *    - Version 1.34.4.2+ 12/05/2011
 *      - IDP - Add CTL_GET_TEMP_INFO to list of IOCTLs registered with ioctl32
 *    - Version 1.34.4.2+ 17/02/2015
 *      - IDP - Ensure both sides of PCIe-PCI bridge are enabled
 *    - Version 1.34.4.2+ 30/04/2015
 *      - IDP - Update to cope with RHEL7 kernel API changes
 *    - Version 1.34.4.2+ 04/08/2015
 *      - IDP - Ensure both sides of the bridge are enabled during reset on Sol
 *      - IDP - On Solaris restrict DMA region to 2G
 *
 * FUNCTIONS LIST :
 *    Local functions :
 *       MovePQ3Window
 *       generic_nopsr8
 *       generic_nopsr16
 *       generic_nopsr32
 *       generic_nopsrbuf
 *       generic_nopsw8
 *       generic_nopsw16
 *       generic_nopsw32
 *       generic_nopswbuf
 *       generic_read32
 *       generic_read16
 *       generic_read8
 *       generic_write32
 *       generic_write16
 *       generic_write8
 *       generic_writebuf
 *       generic_readbuf
 *       vResetPexRegionValue
 *       iRestorePciConfRegister
 *       vSetDefaultPexPQ3Config
 *       iPexPq3BoardReset
 *       iPexPq3BoardRun
 *       bIsPexPq3BoardInReset
 *       dwBuildCardRsrc
 *       vWaitEndOfExch
 *       vEndAppli
 *       dwClose
 *       allocDevCtxt
 *       iph_add_intr
 *       iph_rem_intr
 *       iph_attach_device
 *       iph_detach_device
 *       allocAppliCtxt
 *       run_ioctl
 *       iph_open
 *       iph_close
 *       iph_ioctl
 *       iph_chpoll
 *       iph_attach
 *       iph_detach
 *       
 *    Public functions :
 *       drv_gdwResetBoard
 *       drv_kernel_open
 *       drv_kernel_close
 *       drv_kernel_ioctl
 *
 ****************************************************************************/
#define IPHMAIN_C
#ifdef LINUX
#include <linux/version.h>
#endif
#include "iphwan.h"
#include "wanapi.h"
#include "iphuser.h"
#include "iphwantr.h"
#include "poolqueu.h"
#include "ithandle.h"
#include "sendprim.h"
#include "ppcperf.h"
#include "iphtrace.h"
#include "iphmsys.h"
#include "iphmain.h"

#include "Driver.Version"

#if defined(LINUX_2_6) && defined(CONFIG_COMPAT)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,10))
#define COMPAT_IOCTL
#else
#define OLD_COMPAT_IOCTL
#include <linux/ioctl32.h>
#endif

#include <linux/compat.h>
#endif

#if defined(LINUX_2_4) && defined(CONFIG_COMPAT)
#define OLD_COMPAT_IOCTL
#include <asm/ioctl32.h>
#endif

#ifdef LINUX
MODULE_AUTHOR ("Interphase Corp; linux driver .");
MODULE_DESCRIPTION ("Driver for the Interphase WAN PQ3 family Version "_VERSION_"\n. Copyright (c) 2005-2009 - Interphase Corp");
MODULE_SUPPORTED_DEVICE ("Interphase 3639/5639/5639E/5639L");

#ifdef LINUX_2_4
char WhatString[132] = "@(#)iphwae base driver SX01629-X04 For Linux 2.4.X Version "_VERSION_" (C) Interphase Corp.";
#else
char WhatString[132] = "@(#)iphwae base driver SX01629-X04 For Linux 2.6.X Version "_VERSION_" (C) Interphase Corp.";
#endif

#ifdef MODULE_LICENSE
MODULE_LICENSE("Dual BSD/GPL");
#endif

#endif

#include "sltddlnx_iss.h"
#include "prod_rel.h"


#if defined(DSIPRODUCT_DPK_SOLARIS_SPARC)
#define PRODUCT_BUILDSTR        "DSI Development Package for Solaris(SPARC)"

#elif defined(DSIPRODUCT_DPK_SOLARIS_X86)
#define PRODUCT_BUILDSTR        "DSI Development Package for Solaris(X86)"

#elif defined(DSIPRODUCT_DPK_LINUX)
#define PRODUCT_BUILDSTR        "DSI Development Package for Linux"
#endif

#ifdef SOLARIS
#ifdef SOL_9
#define SOLARIS_VERSION "9"
#else
#define SOLARIS_VERSION "10"
#endif

#ifdef _LP64
char WhatString[132] = "@(#)iphwae base driver "_SX_" For Solaris "SOLARIS_VERSION" 64-bit Version "_VERSION_" (C) Interphase Corp.";
#else
char WhatString[132] = "@(#)iphwae base driver "_SX_" For Solaris "SOLARIS_VERSION" 32-bit Version "_VERSION_" (C) Interphase Corp.";
#endif
#endif

static int iph_add_intr(IphWanDevPtr pDev);
static int iph_rem_intr(IphWanDevPtr pDev);
static int iph_attach_device(IphWanDevPtr pDev);
/* detaches an individual card from the system */
static int iph_detach_device(IphWanDevPtr pWanDev);

#ifdef LINUX
static int iph_attach(struct pci_dev *dev, const struct pci_device_id *id);
static void iph_detach(struct pci_dev *dev);

/* Open entry point for the kernel to the driver */
static int iph_open(struct inode *inode_, struct file *file_);

/* Close entry point for the kernel to the driver */
static int iph_close(struct inode *inode_, struct file *file_);

#ifdef HAVE_UNLOCKED_IOCTL
static long iph_unlocked_ioctl(struct file *file_,
                             unsigned int cmd, unsigned long userData);
#else
/* ioctl entry point for the kernel to the driver */
static int iph_ioctl(struct inode *inode_, struct file *file_,
                     unsigned int cmd, unsigned long userData);
#endif

#ifdef COMPAT_IOCTL
static long iph_compat_ioctl(struct file *file_,
                             unsigned int cmd, unsigned long userData);
#endif

/* poll entry point for the kernel to the driver */
static unsigned int iph_chpoll(struct file *file_, poll_table *wait_);

/* structure to export the character operations*/
static struct file_operations gfops = {
#ifdef HAVE_UNLOCKED_IOCTL
   unlocked_ioctl: iph_unlocked_ioctl, /* ioctl with no global lock */
#else
   ioctl: iph_ioctl,       /* ioctl */
#endif
#ifdef COMPAT_IOCTL
   compat_ioctl: iph_compat_ioctl,  /* ioctl 32 bits on 64-bit systems */
#endif
   open: iph_open,         /*open */
   poll: iph_chpoll,       /* poll */
   release: iph_close,     /* release */
   owner: THIS_MODULE      /* for usage count management */
};

/* Structure indicating which PCI devices we support */
static struct pci_device_id iph_pci_tbl[] = 
{
   { MPC85XX_VID, IPH_3639_PCI_ID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
#ifndef LINUX_2_4
   { PEX_VID    , IPH_PEX1_PCI_ID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
   { PEX_VID    , IPH_PEX2_PCI_ID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
#endif
   { 0, 0, 0, 0, 0, 0, 0}
};                     
MODULE_DEVICE_TABLE(pci, iph_pci_tbl);

/* structure for supplying PCI hotswap functions */
static struct pci_driver gIphwanDriver = {
   name: "Interphase iphwae",
   id_table: iph_pci_tbl,
   probe: iph_attach,
#ifdef LINUX_2_6
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0))
   remove: iph_detach,
#else
   remove: __devexit_p(iph_detach),
#endif
#endif
#ifdef LINUX_2_4
   remove: iph_detach,
#endif
};
#endif /* LINUX */

#ifdef SOLARIS
/* prototypes of the public functions to export */
static int iph_getinfo(dev_info_t *dip, ddi_info_cmd_t cmd, void *arg,
                       void **resultp);
static int iph_attach(dev_info_t *dip, ddi_attach_cmd_t cmd);
static int iph_detach(dev_info_t *dip, ddi_detach_cmd_t cmd);
static int iph_open(dev_t *devp, int flag, int otyp, cred_t *credp);
static int iph_close(dev_t devp, int flag, int otyp, cred_t *credp);
static int iph_ioctl(dev_t devp, int cmd, intptr_t arg, int mode,
                     cred_t *credp, int *rvalp);
static int iph_chpoll(dev_t devp, short events, int anyyet, short *reventsp,
                      struct pollhead **phpp);
#if DEVO_REV==4
static int iph_quiesce(dev_info_t *dip);
#endif

/* structure to export the character operations */
static struct cb_ops gCbOps = {
   iph_open,
   iph_close,
   nodev,            /* strategy */
   nodev,            /* print */
   nodev,            /* dump */
   nodev,            /* read */
   nodev,            /* write */
   iph_ioctl,
   nodev,            /* devmap */
   nodev,            /* mmap */
   nodev,            /* segmap */
   iph_chpoll,
   ddi_prop_op,
   NULL,             /* cb_str (STREAMS only) */
#ifdef _LP64
   D_MP | D_64BIT,   /* cb_flag */
#else
   D_MP,             /* cb_flag */
#endif
   CB_REV,           /* cb_rev */
   nodev,            /* aread */
   nodev             /* awrite */
};

/* structure to export the autoconfiguration entry points */
static struct dev_ops gDevOps = {
   DEVO_REV,
   0,
   iph_getinfo,
   nulldev,          /* identity (obsolete) */
   nulldev,          /* probe */
   iph_attach,
   iph_detach,
   nodev,            /* reset */
   &gCbOps,
   NULL,             /* bus operations */
   NULL,             /* power */
#if DEVO_REV==4
   iph_quiesce,      /* quiesce */
#endif
};

/* structure to describe the driver */
static struct modldrv gModldrv = {
   &mod_driverops,
   "Iphwae driver v"_VERSION_,
   &gDevOps
};

/* structure exported to the kernel on load */
static struct modlinkage gModlinkage = {
   MODREV_1,
   &gModldrv,
   NULL
};
#endif /* SOLARIS */

#ifdef LINUX
/* major number allocated to this driver */
static int giMajor; 
#endif /* LINUX */

#ifdef SOLARIS
/* for soft state routine */
static void *gpvState;

#endif

static kmutex_t gAccessMutex;

/* pointer to the attached devices structure */
static Queue_t gWanDevQueue;

/* current number of applications */
static word gwNbAppli;

/* list of the application contexts using the various minor numbers only used in kernel_API*/
static ApplCtxtPtr gpAppliMinor[TOTAL_APPLI];

#if defined(SOLARIS) && defined(CONTROL_MINOR)
static byte CurrentMinorNumber=0;
#endif

#ifdef SOLARIS
static int minor2instance[MAX_CARD];
#endif

/* default settings for a 3639 */
static DefCardParm_t DefCard3639 =
{
   DEF_MAX_TRANSFER_SIZE,
   V5_INB_CTRL_MAX,
   /*V5_INB_DATA_MAX,*/
   128,
   V5_OUTB_CTRL_MAX,
   /*V5_OUTB_DATA_MAX,*/
   1024,
   DEF_6535_MAX_MGR_REF,
   DEF_6535_MAX_APPLI,
   {(word)-1, sizeof(PrimDesc_t), 0, DEF_6535_POOL_PRIM}, /* primitive pool */
   {
      {0, DEF_3639_BUFFER_SIZE_0, DEF_3639_POOL_0_INIT, DEF_3639_POOL_0}, /* buffer pool 0 */
      {1, DEF_3639_BUFFER_SIZE_1, DEF_3639_POOL_1_INIT, DEF_3639_POOL_1}, /* buffer pool 1 */
      {2, DEF_3639_BUFFER_SIZE_2, DEF_3639_POOL_2_INIT, DEF_3639_POOL_2}, /* buffer pool 2 */
      {3, DEF_3639_BUFFER_SIZE_3, DEF_3639_POOL_3_INIT, DEF_3639_POOL_3}  /* buffer pool 3 */
   }
};

static int iPexPq3BoardReset(IphWanDevPtr pDev);
static int iPexPq3BoardRun(IphWanDevPtr pDev);
static int bIsPexPq3BoardInReset(IphWanDevPtr pDev);

#if defined(SOLARIS) && defined(_BIG_ENDIAN)
static int iPexPq3EpldBoardReset(IphWanDevPtr pDev);
static int iPexPq3FpgaBoardReset(IphWanDevPtr pDev);
static int iNoPexPq3BoardRun(IphWanDevPtr pDev);
static int bIsNoPexPq3BoardInReset(IphWanDevPtr pDev);
#endif

/* table of resources describing the cards according to their type */
static IphCardDesc_t IphCardList[] = 
{
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_3639_DID,                  /* PCI Device Id (0x90E0) */
      CARD_3639,                      /* card type */
      4,                              /* number of ports */
      "PPPP",                         /* port description */
      "3639 AMC quad T1/E1/J1",       /* commercial name */
      0x0F,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_3639_DID,                  /* PCI Device Id (0x90E0) */
      CARD_3639,                      /* card type */
      8,                              /* number of ports */
      "PPPPPPPP",                     /* port description */
      "3639 AMC octal T1/E1/J1",      /* commercial name */
      0xFF,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639_DID,                  /* PCI Device Id (0x90E1) */
      CARD_3639,                      /* card type */
      4,                              /* number of ports */
      "PPPP",                         /* port description */
      "5639 quad T1/E1/J1",           /* commercial name */
      0x0F,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3EpldBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639_DID,                  /* PCI Device Id (0x90E1) */
      CARD_3639,                      /* card type */
      8,                              /* number of ports */
      "PPPPPPPP",                     /* port description */
      "5639 octal T1/E1/J1",          /* commercial name */
      0xFF,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3EpldBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639E_DID,                  /* PCI Device Id (0x90E2) */
      CARD_3639,                      /* card type */
      4,                              /* number of ports */
      "PPPP",                         /* port description */
      "5639E quad T1/E1/J1",           /* commercial name */
      0x0F,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3EpldBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639E_DID,                  /* PCI Device Id (0x90E2) */
      CARD_3639,                      /* card type */
      8,                              /* number of ports */
      "PPPPPPPP",                     /* port description */
      "5639E octal T1/E1/J1",          /* commercial name */
      0xFF,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO_OFFSET,    /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO16_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3EpldBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639L_DID,                 /* PCI Device Id (0x90E5) */
      CARD_3639,                      /* card type */
      4,                              /* number of ports */
      "PPPP",                         /* port description */
      "5639L quad T1/E1/J1",          /* commercial name */
      0x0F,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO32_OFFSET,  /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO32_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3FpgaBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },
   {
      MPC85XX_VID,                    /* PCI Vendor Id (0x1057) */
      CARD_5639L_DID,                 /* PCI Device Id (0x90E5) */
      CARD_3639,                      /* card type */
      8,                              /* number of ports */
      "PPPPPPPP",                     /* port description */
      "5639L octal T1/E1/J1",         /* commercial name */
      0xFF,                           /* more info for options */
      V5_MAJOR_VER,                   /* major number of interface */
      PQ3,                            /* type of PCI chip */
      CARD_PQ3_CUSTOM_INFO32_OFFSET,  /* Custom info offset */
      CARD_PQ3_CUSTOM_INFO32_SIZE,    /* Custom info size */
      &DefCard3639,                   /* default settings */
      iph_guiITHandler_PQ3,           /* IT handler */
      iph_guiITHandlerDpc_PQ3,        /* IT DPC */
      iph_gdwCardSendPrim_PQ3,        /* routine to send a primitive */
      iph_gvReleaseP2LTransfer_PQ3,   /* routine to release send descriptors*/
      iph_gdwAdapterSerialNum_PQ3,    /* routine to get serial number */
      iph_gbCheckCardStatus_PQ3,      /* routine to check card status */
#if defined(SOLARIS) && defined(_BIG_ENDIAN)
      iPexPq3FpgaBoardReset,              /* routine to put the card in reset*/
      iNoPexPq3BoardRun,              /* routine to run the card in reset*/
      bIsNoPexPq3BoardInReset         /* routine to check reset status */
#else
      iPexPq3BoardReset,              /* routine to put the card in reset*/
      iPexPq3BoardRun,                /* routine to run the card in reset*/
      bIsPexPq3BoardInReset           /* routine to check reset status */
#endif
   },

   {0, 0, 0, 0, NULL, NULL}
};


/* board specific define*/
#define PEX_PQ3_HARD_RESET_EN   PEX811X_BOARD_HRESET_EN
#define PEX_PQ3_HARD_RESET      PEX811X_BOARD_HRESET_BIT
#define PEX_PQ3_SOFT_RESET_EN   PEX811X_BOARD_SRESET_EN
#define PEX_PQ3_SOFT_RESET      PEX811X_BOARD_SRESET_BIT

#define CARD_MPC856X_REG_ID     MPC856X_POTAR4

/*************************************************************************************/
/* Generic region Operation                                                         */
/************************************************************************************/

#define BAD_REGION_OFFSET(RegPtr, offset, size)                         \
   ((((offset) & ~(RegPtr->CardBaseAddr)) + (size)) > (RegPtr->MaxSize)) 

#define TRACE_ACCESS

/**************************************************************************
* NAME : MovePQ3Window
* DESCRIPTION : move a window for a PQIII based card
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = destination address to reach with window
* RETURN : 
*    none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void MovePQ3Window(DevRegionPtr pRegion, dword addr)
{
   IphWanDevPtr pDev = (IphWanDevPtr)pRegion->Priv;
   DevRegionPtr pCore = &pDev->Region[CORE_REGION];
   dword newWin;

   newWin = (addr & pRegion->WinMask);
   if (newWin != pRegion->CurWin)
   {
      pRegion->CurWin = newWin;
      newWin += pRegion->CardBaseAddr;
      iph_TRACEK(TRCLVL_2, "Move the Region %s Windows to %08x ",
                 pRegion->Name, newWin);
      pCore->Ops.write32(pCore, pRegion->Cfg, 
                         HOST_CORE32((newWin >> pRegion->WinShift)));
      pCore->Ops.read32(pCore, pRegion->Cfg, &newWin);
      /*UDELAY(10);*/
   }
}

/**************************************************************************
* NAME : generic_nopsr8
* DESCRIPTION : empty read for a byte
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsr8(DevRegionPtr pRegion, dword addr, byte *data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopsr16
* DESCRIPTION : empty read for a word
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsr16(DevRegionPtr pRegion, dword addr, word *data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopsr32
* DESCRIPTION : empty read for a dword
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsr32(DevRegionPtr pRegion, dword addr, dword *data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopsrbuf
* DESCRIPTION : empty read for a buffer
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : size = size to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsrbuf(DevRegionPtr pRegion, dword addr, int size, byte *data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopsw8
* DESCRIPTION : empty write for a byte
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsw8(DevRegionPtr pRegion, dword addr, byte data)
{
   return(EINVAL);
}


/**************************************************************************
* NAME : generic_nopsw16
* DESCRIPTION : empty write for a word
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsw16(DevRegionPtr pRegion, dword addr, word data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopsw32
* DESCRIPTION : empty write for a dword
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopsw32(DevRegionPtr pRegion, dword addr, dword data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_nopswbuf
* DESCRIPTION : empty write for a buffer
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_nopswbuf(DevRegionPtr pRegion, dword addr, int size, byte *data)
{
   return(EINVAL);
}

/**************************************************************************
* NAME : generic_read32
* DESCRIPTION : read for a dword
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_read32(DevRegionPtr pRegion, dword addr, dword *data)
{
#ifdef SOLARIS
   byte *ptrb;
   byte *datab;
   int count;
   dword *ptr;
#else
   volatile dword *ptr;
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Read32 - Region %s addr %x \n", pRegion->Name, addr);
#endif
   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(dword)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[read32] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
#ifdef TRACE_ACCESS
      iph_TRACEK(TRCLVL_2, "Read32 - Region %s addr %x - BAD_REGION_OFFSET\n", pRegion->Name, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (dword *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *data = *ptr;
#endif
#ifdef SOLARIS
   if ((addr & 0x03) == 0)
      *data = ddi_get32(pRegion->AccHandle, ptr);
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[read32] !! unaligned access");
#endif
      datab = (byte *)data;
      ptrb = (byte *)ptr;
      for (count = sizeof(dword); count > 0; count--)
      {
         *datab = ddi_get8(pRegion->AccHandle, ptrb);
         datab++;
         ptrb++;
      }
   }
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[read32] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, *data);
#endif
#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Read32 - Region %s addr %x => %x\n", pRegion->Name, addr, *data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_read16
* DESCRIPTION : read for a word
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_read16(DevRegionPtr pRegion, dword addr, word *data)
{
#ifdef SOLARIS
   byte *ptrb;
   byte *datab;
   int count;
   word *ptr;
#else
   volatile word *ptr;
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Read16 - Region %s addr %x\n", pRegion->Name, addr);
#endif
   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(word)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[read16] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (word *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *data = *ptr;
#endif
#ifdef SOLARIS
   if ((addr & 0x01) == 0)
      *data = ddi_get16(pRegion->AccHandle, ptr);
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[read16] !! unaligned access");
#endif
      datab = (byte *)data;
      ptrb = (byte *)ptr;
      for (count = sizeof(word); count > 0; count--)
      {
         *datab = ddi_get8(pRegion->AccHandle, ptrb);
         datab++;
         ptrb++;
      }
   }
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Region %s at %p val %04x", pRegion->Name, ptr, *data);
#endif
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[read16] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, *data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_read8
* DESCRIPTION : read for a byte
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_read8(DevRegionPtr pRegion, dword addr, byte *data)
{
#ifdef SOLARIS
   byte *ptr;
#else
   volatile byte *ptr;
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Read8  - Region %s addr %x \n", pRegion->Name, addr);
#endif
   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(byte)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[read8] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (byte *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *data = *ptr;
#endif
#ifdef SOLARIS
   *data = ddi_get8(pRegion->AccHandle, ptr);
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Region %s at %x val %02x", pRegion->Name, addr, *data);
#endif
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[read8] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, *data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_write32
* DESCRIPTION : write for a dword
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_write32(DevRegionPtr pRegion, dword addr, dword data)
{
   dword *ptr;
#ifdef SOLARIS
   dword datadw = data;
   byte *ptrb;
   byte *datab;
   int count;
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Write32 - Region %s addr %x\n", pRegion->Name, addr);
#endif
   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(dword)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[write32] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (dword *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *ptr = data;
#endif
#ifdef SOLARIS
   if ((addr & 0x03) == 0)
      ddi_put32(pRegion->AccHandle, ptr, data);
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[write32] !! unaligned access");
#endif
      datab = (byte *)&datadw;
      ptrb = (byte *)ptr;
      for (count = sizeof(dword); count > 0; count--)
      {
         ddi_put8(pRegion->AccHandle, ptrb, *datab);
         datab++;
         ptrb++;
      }
   }
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Region %s at %p val %x", pRegion->Name, ptr, data);
#endif
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[write32] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_write16
* DESCRIPTION : write for a word
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_write16(DevRegionPtr pRegion, dword addr, word data)
{
   word *ptr;
#ifdef SOLARIS
   word dataw = data;
   byte *ptrb;
   byte *datab;
   int count;
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Write16 - Region %s addr %x\n", pRegion->Name, addr);
#endif
   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(word)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[write16] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (word *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *ptr = data;
#endif
#ifdef SOLARIS
   if ((addr & 0x01) == 0)
      ddi_put16(pRegion->AccHandle, ptr, data);
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[write16] !! unaligned access");
#endif
      datab = (byte *)&dataw;
      ptrb = (byte *)ptr;
      for (count = sizeof(word); count > 0; count--)
      {
         ddi_put8(pRegion->AccHandle, ptrb, *datab);
         datab++;
         ptrb++;
      }
   }
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Region %s at %x data %x", pRegion->Name, addr, data);
#endif
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[write16] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_write8
* DESCRIPTION : write for a byte
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_write8(DevRegionPtr pRegion, dword addr, byte data)
{
   byte *ptr;

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Write8  - Region %s addr %x \n", pRegion->Name, addr);
#endif

   if (BAD_REGION_OFFSET(pRegion, addr, sizeof(byte)))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[write8] BAD region/addr");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }
   if (pRegion->Ops.moveWindow)
      pRegion->Ops.moveWindow(pRegion, addr);

   ptr =  (byte *)(pRegion->Mapped + (addr & pRegion->WinLimit));

   /* !!! depends on OS */
#ifdef LINUX
   *ptr = data;
#endif
#ifdef SOLARIS
   ddi_put8(pRegion->AccHandle, ptr, data);
#endif

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "Region %s at %x val %x", pRegion->Name, addr, data);
#endif
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[write8] region/addr - ptr/data");
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, addr);
   iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, data);
#endif
   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : generic_writebuf
* DESCRIPTION : write for a buffer
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to write
*    Input   : size = size to write
*    Input   : data = data to write
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_writebuf(DevRegionPtr pRegion, dword start, int size, 
                            byte *data)
{
   volatile byte *ptr;
   volatile dword *dwordptr;
   int count;

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "WriteBf - Region %s start %x size %d\n", 
              pRegion->Name, start, size);
#endif

   if (BAD_REGION_OFFSET(pRegion, start, size))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[writebuf] BAD region/addr - size");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, start);
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, size);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }

   count = 0;

#ifdef SOLARIS
   while (count < size)
   {
      if (pRegion->Ops.moveWindow)
         pRegion->Ops.moveWindow(pRegion, start);

#ifdef TRACE_ACCESS
      if (count < 4)
         iph_TRACEK(TRCLVL_2, "Region %s at start %08x count %d val %02x", 
                    pRegion->Name, start, count, data[0]);
      else
         iph_TRACEK(TRCLVL_3, "Region %s at start %08x count %d val %02x", 
                    pRegion->Name, start, count, data[0]);
#endif

      ptr =  (byte *)(pRegion->Mapped + (start & pRegion->WinLimit));

      ddi_put8(pRegion->AccHandle, (byte *)ptr, *data);
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[writebf] region/addr - ptr/data");
      iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index,start);
      iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, *data);
#endif

      ptr++;
      data++;
      start++;
      count++;
   }
#endif

#ifdef LINUX
   /* byte access if start address is not 4-byte aligned */
   while ( start % sizeof(dword) )
   {
      if (pRegion->Ops.moveWindow)
         pRegion->Ops.moveWindow(pRegion, start);

      ptr =  (byte *)(pRegion->Mapped + (start & pRegion->WinLimit));

      *ptr = *data;

      ptr++;
      data++;
      start++;
      count++;
   }

   /* dword access */
   while ((size-count) >= sizeof(dword))
   {
      if (pRegion->Ops.moveWindow)
         pRegion->Ops.moveWindow(pRegion, start);

      dwordptr =  (dword *)(pRegion->Mapped + (start & pRegion->WinLimit));

      *dwordptr = *(dword *)data;

      dwordptr++;
      data += sizeof(dword);
      start += sizeof(dword);
      count += sizeof(dword);
   }

   /* byte access for the rest of the data if required */
   while ( (size-count) != 0 )
   {
      if (pRegion->Ops.moveWindow)
         pRegion->Ops.moveWindow(pRegion, start);

      ptr =  (byte *)(pRegion->Mapped + (start & pRegion->WinLimit));

      *ptr = *data;

      ptr++;
      data++;
      start++;
      count++;
   }
#endif

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);
}

/**************************************************************************
* NAME : generic_readbuf
* DESCRIPTION : read for a word
* PARAMETERS :
*    Input   : pRegion = region context
*    Input   : addr = address where to read
*    Input   : size = size to read
*    Input   : data = where to return data
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int generic_readbuf(DevRegionPtr pRegion, dword start, int size, 
                           byte *data)
{
#ifdef SOLARIS
   byte *ptr;
#else
   volatile byte *ptr;
#endif
   int count;

#ifdef TRACE_ACCESS
   iph_TRACEK(TRCLVL_2, "ReadBf - Region %s start %x size %d\n", pRegion->Name, start, size);
#endif

   if (BAD_REGION_OFFSET(pRegion, start, size))
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[readbuf] BAD region/addr - size");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index, start);
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, size);
#endif
      return(EINVAL);
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_LOCK(&pRegion->Access);
   }

   count = 0;
   while (count < size)
   {
      if (pRegion->Ops.moveWindow)
         pRegion->Ops.moveWindow(pRegion, start);

      ptr =  (byte *)(pRegion->Mapped + (start & pRegion->WinLimit));

      /* !!! depends on OS */
#ifdef LINUX
      *data = *ptr;
#endif
#ifdef SOLARIS
      *data = ddi_get8(pRegion->AccHandle, ptr);
#endif

#ifdef TRACE_ACCESS
      if (count < 4)
         iph_TRACEK(TRCLVL_2, 
                    "Region %s at start %08x count %d val %02x ptr %p\n",
                    pRegion->Name, start, count, data[0], ptr);
      else
         iph_TRACEK(TRCLVL_3, 
                    "Region %s at start %08x count %d val %02x ptr %p\n",
                    pRegion->Name, start, count, data[0], ptr);
#endif

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_REGACC_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[readbf] region/addr - ptr/data");
      iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, pRegion->Index,start);
      iph_TRACE_D2(IPHWAN_REGACC_ID, TRC, IPHWAN_ARGVAL2, (dword)(unsigned long)ptr, *data);
#endif
      start++;
      ptr++;
      data++;
      count++;
   }

   if (pRegion->ProtAccess == TRUE)
   {
      IPH_UNLOCK(&pRegion->Access);
   }
   return(0);

}

/**************************************************************************
* NAME : vResetPexRegionValue
* DESCRIPTION : reset some region characteristics
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void vResetPexRegionValue(IphWanDevPtr pDev)
{
   /* Reset CurWin region value*/
   pDev->Region[CORE_REGION].CurWin  = 0xFFFFFFFF;
   pDev->Region[FLASH_REGION].CurWin = 0xFFFFFFFF;
   pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;

}

/**************************************************************************
* NAME : iRestorePciConfRegister
* DESCRIPTION : restore PCI configuration register (after a card reset)
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iRestorePciConfRegister(IphWanDevPtr pDev)
{
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, VID_INDX, 
                       *(word *)&pDev->PCIConf[VID_INDX]);
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, DID_INDX, 
                       *(word *)&pDev->PCIConf[DID_INDX]);
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, SUBVID_INDX, 
                       *(word *)&pDev->PCIConf[SUBVID_INDX]);
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, SUBSYS_INDX, 
                       *(word *)&pDev->PCIConf[SUBSYS_INDX]);
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, PCICMD_INDX, 
                       *(word *)&pDev->PCIConf[PCICMD_INDX]);
   WRITE_PCI_CONF_WORD(pDev->sDev.Dev, PCISTS_INDX, 
                       *(word *)&pDev->PCIConf[PCISTS_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, RID_INDX, pDev->PCIConf[RID_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, HDR_INDX, pDev->PCIConf[HDR_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, BIST_INDX, pDev->PCIConf[BIST_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, LAT_INDX, pDev->PCIConf[LAT_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, CALN_INDX, pDev->PCIConf[CALN_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, CLDEV_INDX, pDev->PCIConf[CLDEV_INDX]);
   WRITE_PCI_CONF_DWORD(pDev->sDev.Dev, BADDR0_INDX, 
                        *(dword *)&pDev->PCIConf[BADDR0_INDX]);
   WRITE_PCI_CONF_DWORD(pDev->sDev.Dev, BADDR1_INDX, 
                        *(dword *)&pDev->PCIConf[BADDR1_INDX]);
   WRITE_PCI_CONF_DWORD(pDev->sDev.Dev, BADDR2_INDX, 
                        *(dword *)&pDev->PCIConf[BADDR2_INDX]);
   WRITE_PCI_CONF_DWORD(pDev->sDev.Dev, BADDR3_INDX, 
                        *(dword *)&pDev->PCIConf[BADDR3_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, INTLN_INDX, 
                       pDev->PCIConf[INTLN_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, INTPIN_INDX, 
                       pDev->PCIConf[INTPIN_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, MINGNT_INDX, 
                       pDev->PCIConf[MINGNT_INDX]);
   WRITE_PCI_CONF_BYTE(pDev->sDev.Dev, MAXLAT_INDX, 
                       pDev->PCIConf[MAXLAT_INDX]);
#ifdef LINUX
   if (pci_enable_device(pDev->sDev.Dev))
   {
      iph_TRACEK(TRCLVL_0, 
                 "[iRestorePciConfRegister] error enabling pci device %p\n", 
                 pDev->sDev.Dev);
      return(EIO);
   }
#endif

   return(0);
}

/**************************************************************************
* NAME : vSetDefaultPexPQ3Config
* DESCRIPTION : set default configuration for PQIII (after a card reset)
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void vSetDefaultPexPQ3Config(IphWanDevPtr pDev)
{
   DevRegionPtr RegPtr = &pDev->Region[CORE_REGION];
   dword regval;
   byte  val;

   iph_TRACEK(TRCLVL_1, "   MPC8560 in 'Boot Holdoff' - Setting a default configuration");

   if ( pDev->Rsrc->DevId == CARD_3639_DID && pDev->Rsrc->BoardRevisionId == 0x2 )
   {
      RegPtr->Ops.write32(RegPtr,MPC856X_BRGC3,  HOST_CORE32(0x12010));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARA,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRA,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORA,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRA,  HOST_CORE32(0x8C3B7FFE));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATA,  HOST_CORE32(0x8C02CE0E));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARB,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRB,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORB,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRB,  HOST_CORE32(0x0FF95000));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATB,  HOST_CORE32(0x0AA00000));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARC,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRC,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORC,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRC,  HOST_CORE32(0xFF800000));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATC,  HOST_CORE32(0xAA000000));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARD,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRD,  HOST_CORE32(0x0));
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORD,  HOST_CORE32(0x00400000));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRD,  HOST_CORE32(0x07C10004));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATD,  HOST_CORE32(0x07800004));

      RegPtr->Ops.read8(RegPtr, MPC856X_I2CFDR, &val);
      RegPtr->Ops.write8(RegPtr, MPC856X_I2CFDR, val|0x32);
      RegPtr->Ops.write8(RegPtr, MPC856X_I2CCR, 0x80);

      RegPtr->Ops.write32(RegPtr,MPC856X_OR0,    HOST_CORE32(0xFC001936));
      RegPtr->Ops.write32(RegPtr,MPC856X_BR0,    HOST_CORE32(0xFC000801));

      RegPtr->Ops.write32(RegPtr,MPC856X_LAWBAR0,HOST_CORE32(0x000FC000));
      RegPtr->Ops.write32(RegPtr,MPC856X_LAWAR0, HOST_CORE32(0x80400019));
      RegPtr->Ops.write32(RegPtr,MPC856X_PITAR1, HOST_CORE32(0x000FFF00));
      RegPtr->Ops.write32(RegPtr,MPC856X_PIWAR1, HOST_CORE32(0x80F44013));
   }
   else
   {
      /* Set BRGs (For QuadFalc Clock) */
      /* BRG EN, CLK source = CLK9, Divide by 8 */
      RegPtr->Ops.write32(RegPtr, MPC856X_BRGC3, HOST_CORE32(0x12010));

      /* Set GPIOs in this order: PPAR, PSOR, PDAT, PDIR.*/
      /* To simplify here, every serial or unused pin = input*/
      RegPtr->Ops.write32(RegPtr,MPC856X_PPARA, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRA, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORA, 0x0);
      /* pins set for PLD programming */
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRA, HOST_CORE32(0x38F0FE));
      /* Resets asserted */
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATA, HOST_CORE32(0xC00E));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARB, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRB, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORB, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRB, HOST_CORE32(0x0FF00000));
      /* Green LEDs ON */
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATB, HOST_CORE32(0x0AA00000));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARC, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRC, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORC, HOST_CORE32(0x00000000));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRC, HOST_CORE32(0xFF800000));
      /* Green LEDs ON */
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATC, HOST_CORE32(0xAA000000));

      RegPtr->Ops.write32(RegPtr,MPC856X_PPARD, 0x0);
      RegPtr->Ops.write32(RegPtr,MPC856X_PODRD, 0x0);
      /* BRG3 */
      RegPtr->Ops.write32(RegPtr,MPC856X_PSORD, HOST_CORE32(0x00400000));
      RegPtr->Ops.write32(RegPtr,MPC856X_PDIRD, HOST_CORE32(0x00400000)); 
      RegPtr->Ops.write32(RegPtr,MPC856X_PDATD, HOST_CORE32(0x00000000));

      /* Get the Flash Configuration by reading the MPC8560 GPIOs */
      /* A PCI inbound window is set by the Boot Sequencer */
      RegPtr->Ops.read32(RegPtr, MPC856X_PDATA, &regval);

      regval = (HOST_CORE32(regval) & 0x00000E00) >>9;
      switch (regval)
      {
         case 0x2: /* 1x8MB */
            break;
   
         case(0x6): /* 2x8MB */
            iph_TRACEK(TRCLVL_2, "Interphase Board with Flash 2*8MBytes");                 
            RegPtr->Ops.write32(RegPtr,MPC856X_OR0,    HOST_CORE32(0xFF800EF2)); 
            RegPtr->Ops.write32(RegPtr,MPC856X_OR1,    HOST_CORE32(0xFF800EF2));
            RegPtr->Ops.write32(RegPtr,MPC856X_BR1,    HOST_CORE32(0xFF000801));  
            RegPtr->Ops.write32(RegPtr,MPC856X_BR0,    HOST_CORE32(0xFF800801)); 
            RegPtr->Ops.write32(RegPtr,MPC856X_LAWBAR0,HOST_CORE32(0x000FF000));
            RegPtr->Ops.write32(RegPtr,MPC856X_LAWAR0, HOST_CORE32(0x80400017));
            RegPtr->Ops.write32(RegPtr,MPC856X_LAWBAR1,HOST_CORE32(0x000FF800));
            RegPtr->Ops.write32(RegPtr,MPC856X_LAWAR1, HOST_CORE32(0x80400017));
            RegPtr->Ops.write32(RegPtr,MPC856X_PITAR1, HOST_CORE32(0x000FF000));
            RegPtr->Ops.write32(RegPtr,MPC856X_PIWAR1, HOST_CORE32(0x80F44017));
            break;

         case(0x1): /* 1x32MB */
            break;

         default:
            break;
      }
   }
}

/**************************************************************************
* NAME : iPexPq3BoardReset
* DESCRIPTION : reset a card
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iPexPq3BoardReset(IphWanDevPtr pDev)
{
   dword regval;

   /*
    * Ensure both sides of the bridge are enabled
    */
   READ_PCI_DWORD(pDev, PEX811X_DEVINIT, &regval);
   if((regval & 0x30) != 0x30)
   {
     iph_TRACEK(TRCLVL_1, DRIVER_NAME"[iPexPq3BoardReset] 0x%x", regval);
     regval |= 0x30;
     WRITE_PCI_DWORD(pDev, PEX811X_DEVINIT, regval);
   }

   READ_PCI_DWORD(pDev, PEX811X_GPIOCTL, &regval);
   regval |= (PEX_PQ3_HARD_RESET_EN | PEX_PQ3_SOFT_RESET_EN);
   WRITE_PCI_DWORD(pDev, PEX811X_GPIOCTL, regval);
   regval &= ~(PEX_PQ3_HARD_RESET | PEX_PQ3_SOFT_RESET);
   WRITE_PCI_DWORD(pDev, PEX811X_GPIOCTL, regval);

   return(0);
}

/**************************************************************************
* NAME : iPexPq3BoardRun
* DESCRIPTION : run a card in reset
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iPexPq3BoardRun(IphWanDevPtr pDev)
{
   dword regval;

   READ_PCI_DWORD(pDev, PEX811X_GPIOCTL, &regval);
   regval |= (PEX_PQ3_HARD_RESET |  PEX_PQ3_SOFT_RESET);
   WRITE_PCI_DWORD(pDev, PEX811X_GPIOCTL, regval);
   MDELAY(100);
   WRITE_PCI_DWORD(pDev, PEX811X_GPIOCTL, 
                   ((regval) & ~PEX_PQ3_HARD_RESET_EN & ~PEX_PQ3_SOFT_RESET_EN));
   MDELAY(1000);
   if (regval & PEX_PQ3_HARD_RESET_EN)
   {
      iph_TRACEK(TRCLVL_1,
                "Restoring the PCI configuration register for dev %d  ...", 
                pDev->Index);
      iRestorePciConfRegister(pDev);
   }

   READ_CORE_DWORD(pDev, MPC856X_P0RBMSR, &regval);

   /* if board boot with the Hold off jumper set */
   /* Default configuration should be set       */
   if (!(regval & 0x80000000))
   {
      vSetDefaultPexPQ3Config(pDev);
   }

   vResetPexRegionValue(pDev);

   return(0);
}

/**************************************************************************
* NAME : bIsPexPq3BoardInReset
* DESCRIPTION : check whether a card is in reset
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int bIsPexPq3BoardInReset(IphWanDevPtr pDev)
{
   dword regval;

   READ_PCI_DWORD(pDev, PEX811X_GPIOCTL, &regval);
   if (regval & (PEX_PQ3_HARD_RESET_EN|PEX_PQ3_SOFT_RESET_EN))
   {
      return(TRUE);
   }
   if (pDev->Status == CARD_RESETTING)
   {
      READ_CORE_DWORD(pDev, MPC856X_MSGR0, &regval);
      if (regval == 0xFFFFFFFF || (regval & 1UL) == 0)
      {
         return(TRUE);
      }
      else
      {
         pDev->Status = CARD_RESET;
         READ_CORE_DWORD(pDev, MPC856X_MSGR2, &regval);
         iph_TRACEK(TRCLVL_1,
                    "End of POST detected for dev %d - POST result 0x%08X", 
                    pDev->Index, regval);
      }
   }
   return(FALSE);
}

#if defined(SOLARIS) && defined(_BIG_ENDIAN)
/**************************************************************************
* NAME : iPexPq3EpldBoardReset
* DESCRIPTION : reset a card
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iPexPq3EpldBoardReset(IphWanDevPtr pDev)
{
   dword regval = 0;
   dword addrEpld = 0;

   pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
   pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
   if (pDev->Type == CARD_5639E_DID)
      addrEpld = 0x80000;
   else if (pDev->Type == CARD_5639_DID)
      addrEpld = 0x20000;
   else
   {
      iph_TRACEK(TRCLVL_0,
                 "Unsupported EPLD reset for dev %d", 
                 pDev->Index);
   }
   READ_MEM_DWORD(pDev, addrEpld + 0x0C, &regval);
   iph_TRACEK(TRCLVL_1,
              "EPLD(D00%05x) for dev %d = %08X", 
              addrEpld + 0x0C, pDev->Index, regval);
   READ_MEM_DWORD(pDev, addrEpld + 0x18, &regval);
   iph_TRACEK(TRCLVL_1,
              "EPLD(D00%05x) for dev %d = %08X", 
              addrEpld + 0x18, pDev->Index, regval);
   regval = 0x02020202;
   WRITE_MEM_DWORD(pDev, addrEpld + 0x18, regval);
   pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
   pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
   pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
   return(0);
}

/**************************************************************************
* NAME : iNoPexPq3BoardRun
* DESCRIPTION : run a card in reset
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iNoPexPq3BoardRun(IphWanDevPtr pDev)
{
   dword regval;

   MDELAY(1000);
   iph_TRACEK(TRCLVL_1,
              "Restoring the PCI configuration register for dev %d  ...", 
              pDev->Index);
   iRestorePciConfRegister(pDev);

   READ_CORE_DWORD(pDev, MPC856X_P0RBMSR, &regval);

   vResetPexRegionValue(pDev);

   return(0);
}

/**************************************************************************
* NAME : bIsNoPexPq3BoardInReset
* DESCRIPTION : check whether a card is in reset
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int bIsNoPexPq3BoardInReset(IphWanDevPtr pDev)
{
   dword regval;

   if (pDev->Status == CARD_RESETTING)
   {
      READ_CORE_DWORD(pDev, MPC856X_MSGR0, &regval);
      if (regval == 0xFFFFFFFF || (regval & 1UL) == 0)
      {
         return(TRUE);
      }
      else
      {
         pDev->Status = CARD_RESET;
         READ_CORE_DWORD(pDev, MPC856X_MSGR2, &regval);
         iph_TRACEK(TRCLVL_1,
                    "End of POST detected for dev %d - POST result 0x%08X", 
                    pDev->Index, regval);
      }
   }
   return(FALSE);
}

/**************************************************************************
* NAME : iPexPq3FpgaBoardReset
* DESCRIPTION : reset a card
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iPexPq3FpgaBoardReset(IphWanDevPtr pDev)
{
   dword regval = 0;

   pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
   pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
   READ_MEM_DWORD(pDev, 0x45000, &regval);
   iph_TRACEK(TRCLVL_1,
              "TDM Switch Status Register for dev %d = 0x%x  ...", 
              pDev->Index, regval);
   READ_MEM_DWORD(pDev, 0x44000, &regval);
   iph_TRACEK(TRCLVL_1,
              "TDM Switch Control Register for dev %d = 0x%x  ...", 
              pDev->Index, regval);
   regval |= 0x08;
   WRITE_MEM_DWORD(pDev, 0x44000, regval);
   pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
   pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
   pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
   return(0);
}
#endif

/**************************************************************************
* NAME : dwBuildCardRsrc
* DESCRIPTION : build the card resource buffer
* PARAMETERS :
*    Input   : pWanDev = adapter context
*    Input   : wDevId = PCI device ID
*    I/O     : pBuff = destination buffer
*    I/O     : pSize = input => maximum buffer size, output => data size
* RETURN : 
*    0 if all is OK
*    EINVAL if the PCI device ID is unreferenced
*    ENOMEM if the buffer is not large enough
* REVISION :
*    - Version 1.0 : 06/03/02 Creation
**************************************************************************/
static dword dwBuildCardRsrc(IphWanDevPtr pWanDev, word wDevId, 
                             byte *pBuff, dword *pSize)
{
   word wCount;
   word wIndex;
   IphCardDesc_t *pCardDesc = NULL;
   word val16;
   dword val32;

   if (wDevId == 0 || pWanDev->Type == wDevId)
   {
      pCardDesc = pWanDev->Rsrc;
   }
   else
   {
      /* search for the device ID in the resource list */
      for (wCount = 0; IphCardList[wCount].DevId != 0; wCount++)
      {
         if (IphCardList[wCount].DevId == wDevId)
            break;
      }
   }
   if (pCardDesc != NULL)
   {
      if (*pSize < (4 + 4 + 2 + pCardDesc->PortNb + 
                    2 + strlen(pCardDesc->CardName)+6+6+3))
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[dwBuildCardRsrc] buffer not large enough");
#endif
         return(ENOMEM);
      }

      wIndex = 0;

      /* the buffer is large enough, so build it */
      pBuff[wIndex++] = RSRC_DEVID;
      pBuff[wIndex++] = 2;
      /* return value must be Big Endian */
      val16 = HOST_CARD16(pCardDesc->DevId);
      bcopy(&val16, &pBuff[wIndex], sizeof(word));
      wIndex+=sizeof(word);

      pBuff[wIndex++] = RSRC_DEVTYPE;
      pBuff[wIndex++] = 2;
      /* return value must be Big Endian */
      val16 = HOST_CARD16(pCardDesc->Type);
      bcopy(&val16, &pBuff[wIndex], sizeof(word));
      wIndex+=sizeof(word);

      pBuff[wIndex++] = RSRC_PORTYPE;
      pBuff[wIndex++] = pCardDesc->PortNb;
      bcopy(pCardDesc->PortDesc, &pBuff[wIndex], 
            pCardDesc->PortNb);
      wIndex+=pCardDesc->PortNb;

      pBuff[wIndex++] = RSRC_DEVNAME;
      pBuff[wIndex++] = strlen(pCardDesc->CardName);
      bcopy(pCardDesc->CardName, &pBuff[wIndex], 
            strlen(pCardDesc->CardName));
      wIndex+=strlen(pCardDesc->CardName);

      pBuff[wIndex++] = RSRC_DRAMSIZE;
      pBuff[wIndex++] = 4;
      /* return value must be Big Endian */
      val32 = HOST_CARD32(pWanDev->Region[MEM_REGION].MaxSize);
      bcopy(&val32, &pBuff[wIndex], sizeof(dword));
      wIndex+=sizeof(dword);

      /* Primary Subid type */
      pBuff[wIndex++] = RSRC_PRIMARY_SUBID;
      pBuff[wIndex++] = 4;
      /* return value must be Big Endian */
      val32 = HOST_CARD32(pCardDesc->PrimarySubid);
      bcopy(&val32, &pBuff[wIndex], sizeof(dword));
      wIndex+=sizeof(dword);

      /* Secondary Subid type */
      pBuff[wIndex++] = RSRC_SECONDARY_SUBID;
      pBuff[wIndex++] = 4;
      /* return value must be Big Endian */
      val32 = HOST_CARD32(pCardDesc->SecondarySubid);
      bcopy(&val32, &pBuff[wIndex], sizeof(dword));
      wIndex+=sizeof(dword);

      /* Revision Id */
      pBuff[wIndex++] = RSRC_DEVREV;
      pBuff[wIndex++] = 1;
      bcopy(&pCardDesc->BoardRevisionId, &pBuff[wIndex], sizeof(byte));
      wIndex+=sizeof(byte);

      *pSize = (dword)wIndex;

      return(0);
   }
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[dwBuildCardRsrc] didn't find the card resource");
#endif
      return(EINVAL);
   }
}

/**************************************************************************
* NAME : vWaitEndOfExch
* DESCRIPTION : wait for end of all pending transmissions on an adapter
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pWanDev = adapter context
*    Input   : pAppli = application for which we must wait for end of
*                       transmission
*                       if NULL, wait for end of ALL transmissions
* RETURN : none
* REVISION :
*    - Version 1.0 : 04/30/02 Creation
**************************************************************************/
static void vWaitEndOfExch(kmutex_t *pLock, IphWanDevPtr pWanDev, 
                           ApplCtxtPtr pAppli)
{
   MGRSessionCorrPtr pCorr;
   word wCount;
   word wCardSess;
   long EndWait;
   PrimDescPtr pPrim;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[vWaitEndOfExch] entry (Index - Status)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pWanDev->Index);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pWanDev->Status);
#endif

   if (pWanDev->Status != CARD_RUNNING &&
       pWanDev->Status != CARD_LOADED)
      return;

   IPH_LOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[vWaitEndOfExch] check pending transmission");
#endif

   wCount = 0;
   /* check if there are a pending transmission */
   while (wCount < pWanDev->InbCtrlNb)
   {
      if (pWanDev->SendingPrim[wCount] != NULL)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[vWaitEndOfExch] found one pending transmission");
#endif
         pPrim = pWanDev->SendingPrim[wCount];
         wCardSess = pWanDev->SendingPrim[wCount]->PrimRef;
         pCorr = pWanDev->MGRSessionCorrTable[wCardSess];
         if (pAppli != (ApplCtxtPtr)0 && 
             pCorr != NULL && pCorr->AppliPtr == pAppli)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[vWaitEndOfExch] wait end of send for this application");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                         pWanDev->Index, wCount);
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF,
                         pWanDev->SendingPrim[wCount]->PrimId,
                         pWanDev->SendingPrim[wCount]->PrimRef);
#endif
            /* NOTE: at this point we are sure that we are holding protection */
            /* mutex for this device so we release the mutex to allow the */
            /* arrival of ITs and by this way the end of the DMA transfer */
            MUTEX_EXIT(&pWanDev->DevMutex);

            MUTEX_ENTER(&pAppli->AppliMutex);
            pAppli->Status = WAIT_SEND_END;
            /* wait for transmission completion */
#ifdef LINUX
            EndWait = jiffies;
            EndWait += HZ; /* 1 second */
#endif
#ifdef SOLARIS
            GET_LBOLT(&EndWait);
            EndWait += drv_usectohz(1000000);
#endif
            if (CV_TIMEDWAIT(&pAppli->CondVar, 
                             &pAppli->AppliMutex, EndWait) == -1 &&
                pWanDev->SendingPrim[wCount] == pPrim)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[vWaitEndOfExch] timeout on wait for end of send");
#endif
               MUTEX_EXIT(&pAppli->AppliMutex);

               MUTEX_ENTER(&pWanDev->DevMutex);
               pWanDev->SendingPrim[wCount] = NULL;
               if (pAppli->Type == TYPE_KERNEL)
                  pPrim->PrimInPool|=SENT_PRIM;
               iph_gvReleaseDrvPrim(NULL, pAppli, pWanDev, pPrim);

               MUTEX_EXIT(&pWanDev->DevMutex);
            }
            else
            {
               MUTEX_EXIT(&pAppli->AppliMutex);
            }
            pAppli->Status = 0;
            MUTEX_ENTER(&pWanDev->DevMutex);
         }
      }
      wCount++;
   }

   /* NOTE: at this point we are protected against interrupts */

   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[vWaitEndOfExch] return");
#endif
}

/**************************************************************************
* NAME : vEndAppli
* DESCRIPTION : release an application context
* PARAMETERS :
*    Input   : pAppli = application context
*    Input   : bFull = flag set to release the entire context
* RETURN : none
* REVISION :
*    - Version 1.0 : 05/21/02 Creation
*    - Version 1.01: 10/03/02 
*         -Do not free memory allocated for application context
**************************************************************************/
static void vEndAppli(ApplCtxtPtr pAppli, int bFull)
{
   IphWanDevPtr pWanDev;
   PrimDescPtr pPrim;
   DataDescPtr pData;
   DataDescPtr pNextData;
   MGRSessionCorrPtr pCorr;
   MGRSessionCorrPtr pCorrNext;
   word wCount, wLoop;
   long EndWait;
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[vEndAppli] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* end dialog with device, only if not already ended */
   if (pAppli->Status != RESET)
   {
      pWanDev = pAppli->WanDevPtr;

      /* check whether this application owns the control */
      MUTEX_ENTER(&pWanDev->DevMutex);
      if (pAppli != NULL && pWanDev->ControlAppli == pAppli)
         pWanDev->ControlAppli = NULL;
      MUTEX_EXIT(&pWanDev->DevMutex);

      /* wait for end of exchanges on this adapter */
      vWaitEndOfExch(&pWanDev->DevMutex, pWanDev, pAppli);

      MUTEX_ENTER(&pAppli->AppliMutex);
      pAppli->Status = RESET;

      /* Now we must close all the sessions opened by this application */
      for (wCount = 0; wCount < MODULO; wCount++)
      {
         pCorr = (MGRSessionCorrPtr)pAppli->HashTable[wCount].FirstPtr;
         while (pCorr != (MGRSessionCorrPtr)&pAppli->HashTable[wCount])
         {
            pCorrNext = pCorr->HashNextPtr;

            /* release AppliMutex to prevent deadlock with DevMutex */
            MUTEX_EXIT(&pAppli->AppliMutex);

            if (pCorr->Status != SESS_CLOSED &&
                pCorr->Status != SESS_CLOSING)
            {
               MUTEX_ENTER(&pWanDev->DevMutex);
               pPrim = iph_gpGetPrimPool(NULL,
                                         &pWanDev->FreePrimHeadPool);
               if (pPrim == (PrimDescPtr)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[vEndAppli] not enough memory to close session");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV_SESSION,
                               (pCorr->CardMGRSession));
#endif
                  iph_TRACEK(TRCLVL_0,
                             DRIVER_NAME" not enough memory to close session %d (session locked)",
                             pCorr->CardMGRSession);
                  /* release the MGR_OPEN_USER primitive if not already done */
                  if (pCorr->OpenPrim != NULL)
                  {
                     if (pCorr->AppliPtr != NULL)
                     {
                        if (pCorr->AppliPtr->Type == TYPE_USER)
                        {
                           /* release the primitive structure and attached buffers */
                           iph_gvReleaseDrvPrim(NULL, pCorr->AppliPtr, pWanDev, 
                                                pCorr->OpenPrim);
                        }
                        else
                        {
                           IPH_UNLOCK(&pWanDev->DevMutex);
                           /* give back the primitive to the kernel application */
                           pCorr->AppliPtr->kd_free(pCorr->AppliPtr->Backref, 
                                                    pCorr->AppliPtr->Minor, 
                                                    SENT_PRIM,
                                                    (void *)pCorr->OpenPrim);
                           IPH_LOCK(&pWanDev->DevMutex);
                        }
                     }
                  }
                  pCorr->OpenPrim = NULL;
                  pCorr->AppliPtr = NULL;
                  MUTEX_EXIT(&pWanDev->DevMutex);
               }
               else
               {
                  MUTEX_EXIT(&pWanDev->DevMutex);
                  pPrim->PrimId = (MGR_PRIM + MGR_CLOSE_USER);
                  pPrim->PrimRef = pCorr->CardMGRSession;
                  memset(pPrim->PrimInfo, 0, MAX_PRIM_INFO);
                  pPrim->DataDescPtr = (DataDesc_t *)0;
                  pPrim->BuffInPool = 0;
                  /* Note: do not send for an application because the session */
                  /* correlator is no more valid */
                  while ((dwError=pWanDev->Rsrc->CardSendPrim(&pWanDev->DevMutex, pWanDev, NULL, pPrim)) == EAGAIN)
                  {
                     /* Invoke the scheduler and retry */
                     MDELAY(1);
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, (byte *)"[vEndAppli] EAGAIN on CardSendPrim");
#endif
                  }

                  if ( dwError != 0 )
                  {
                     /* release the primitive structure and its attached buffers */
                     iph_gvReleaseDrvPrim(&pWanDev->DevMutex, pAppli, pWanDev, pPrim);
                  }

               }
            }
            MUTEX_ENTER(&pAppli->AppliMutex);

            pCorr = pCorrNext;
         }
      }
      pCorr = NULL;
      for (wCount = 0; wCount < MODULO; wCount++)
      {
         pCorrNext = (MGRSessionCorrPtr)pAppli->HashTable[wCount].FirstPtr;
         while (pCorrNext != (MGRSessionCorrPtr)&pAppli->HashTable[wCount])
         {
            if (pCorrNext->Status != SESS_CLOSED)
            {
               pCorr = pCorrNext;
               break;
            }
            pCorrNext = pCorrNext->HashNextPtr;
         }
         if (pCorr != NULL)
             break;
      }
      wLoop = 0;
      while (pCorr != NULL && wLoop < 3)
      {
         /* wait for session completion */
#ifdef LINUX
         EndWait = jiffies;
         EndWait += HZ; /* 1 second */
#endif
#ifdef SOLARIS
         GET_LBOLT(&EndWait);
         EndWait += drv_usectohz(1000000);
#endif
         if (CV_TIMEDWAIT(&pAppli->CondVar, 
                          &pAppli->AppliMutex, EndWait) == -1)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[vEndAppli] timeout on wait for end of session");
#endif
            wLoop++;
            /*pCorr = NULL;
            break;*/
         }
         pCorr = NULL;
         for (wCount = 0; wCount < MODULO; wCount++)
         {
            pCorrNext = (MGRSessionCorrPtr)pAppli->HashTable[wCount].FirstPtr;
            while (pCorrNext != (MGRSessionCorrPtr)&pAppli->HashTable[wCount])
            {
               if (pCorrNext->Status != SESS_CLOSED)
               {
                  pCorr = pCorrNext;
                  break;
               }
               pCorrNext = pCorrNext->HashNextPtr;
            }
            if (pCorr != NULL)
                break;
         }
      }
      /* Now we must close all the sessions opened by this application */
      for (wCount = 0; wCount < MODULO; wCount++)
      {
         pCorr = (MGRSessionCorrPtr)pAppli->HashTable[wCount].FirstPtr;
         while (pCorr != (MGRSessionCorrPtr)&pAppli->HashTable[wCount])
         {
            iph_gvExtractCorrHash(NULL, &pAppli->HashTable[wCount], pCorr);
            pCorr->AppliPtr = NULL;

            pCorr = (MGRSessionCorrPtr)pAppli->HashTable[wCount].FirstPtr;
         }
      }
      /* reset the application context */
      /* NOTE: here AppliMutex is hold */

      /* For a KERNEL application, release all the unused buffers */
      if (pAppli->Type == TYPE_KERNEL)
      {
         pPrim = (PrimDescPtr)iph_gpGetPool(NULL, &pAppli->FreePrimHeadPool);
         while (pPrim != (PrimDescPtr)0)
         {
            MUTEX_EXIT(&pAppli->AppliMutex);

            pAppli->kd_free(pAppli->Backref, pAppli->Minor, 
                            RECV_PRIM, (void *)pPrim);

            MUTEX_ENTER(&pAppli->AppliMutex);

            pPrim = (PrimDescPtr)iph_gpGetPool(NULL, &pAppli->FreePrimHeadPool);
         }

         /* NOTE: here AppliMutex is hold */

         for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
         {
            pData = (DataDescPtr)iph_gpGetPool(NULL,
                                               &pAppli->FreeDataPools[wCount]);
            while (pData != (DataDescPtr)0)
            {
               MUTEX_EXIT(&pAppli->AppliMutex);

               pAppli->kd_free(pAppli->Backref, pAppli->Minor, RECV_BUFFER,
                               (void *)pData);

               MUTEX_ENTER(&pAppli->AppliMutex);

               pData = (DataDescPtr)iph_gpGetPool(NULL,
                                                  &pAppli->FreeDataPools[wCount]);
            }
         }

         /* NOTE: here AppliMutex is hold */

         /* release also the pending received primitives */
         pPrim = (PrimDescPtr)iph_gpGetQueue(NULL, &pAppli->RecvQueue);
         while (pPrim != (PrimDescPtr)0)
         {
            pAppli->RecvNb--;

            MUTEX_EXIT(&pAppli->AppliMutex);

            pData = (DataDescPtr)pPrim->DataDescPtr;
            while (pData != (DataDescPtr)0)
            {
               pNextData = pData->NextPtr;
               pAppli->kd_free(pAppli->Backref, pAppli->Minor, RECV_BUFFER,
                               (void *)pData);
               pData = pNextData;
            }
            pPrim->DataDescPtr = (DataDescPtr)0;
            pAppli->kd_free(pAppli->Backref, pAppli->Minor, RECV_PRIM,
                            (void *)pPrim);

            MUTEX_ENTER(&pAppli->AppliMutex);

            pPrim = (PrimDescPtr)iph_gpGetQueue(NULL, &pAppli->RecvQueue);
         }
      }
      else  /* USER application */
      {
         /* release the pending received primitives (all internal structures) */
         pPrim = (PrimDescPtr)iph_gpGetQueue(NULL, &pAppli->RecvQueue);
         while (pPrim != (PrimDescPtr)0)
         {
            pAppli->RecvNb--;

            MUTEX_EXIT(&pAppli->AppliMutex);

            iph_gvReleaseDrvPrim(&pWanDev->DevMutex, pAppli, pWanDev, pPrim);

            MUTEX_ENTER(&pAppli->AppliMutex);

            pPrim = (PrimDescPtr)iph_gpGetQueue(NULL, &pAppli->RecvQueue);
         }
      }

      /* NOTE: here AppliMutex is hold */
      MUTEX_EXIT(&pAppli->AppliMutex);

#ifdef SOLARIS
      CV_DESTROY(&pAppli->CondVar);
      MUTEX_DESTROY(&pAppli->AppliMutex);
#endif
   }

   /* if application context must be released */
   if (bFull != 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                       (byte *)"[vEndAppli] free application context");
#endif
      gpAppliMinor[pAppli->Minor] = (ApplCtxtPtr)0;
      gwNbAppli--;

      /* free the complete structure */
      iph_gvMemFree((void *)pAppli);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, (byte *)"[vEndAppli] return");
#endif
}

/**************************************************************************
* NAME : dwClose
* DESCRIPTION : close for an instance of application
* PARAMETERS :
*    Input  : pAppli = application context
*    Input  : pDev = device context
*    Input   : bFull = flag set to release the entire context
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 06/10/02 Creation
* NOTE : if the device context is not null, all the applications currently
*        linked to the device will be destroyed.
**************************************************************************/
static dword dwClose(ApplCtxtPtr pAppli, IphWanDevPtr pWanDev, int bFull)
{
   dword dwError;
   ApplCtxtPtr pTempAppli;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwClose] entry");
   if (pWanDev != NULL)
       iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pWanDev->Index);
   else if (pAppli != NULL)
       iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                    pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pWanDev != NULL)
   {
      /* close all the pending applications using this device */
      pTempAppli = (ApplCtxtPtr)iph_gpGetQueue(&pWanDev->DevMutex,
                                               &pWanDev->UsingAppliQueue);
#ifdef TRACE
      if (pTempAppli != (ApplCtxtPtr)0)
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[dwClose] application list not empty");
#endif
      while (pTempAppli != (ApplCtxtPtr)0)
      {
         /* free the application context */
         vEndAppli(pTempAppli, bFull);
         pWanDev->NbAppli--;
         pTempAppli = (ApplCtxtPtr)iph_gpGetQueue(&pWanDev->DevMutex,
                                                  &pWanDev->UsingAppliQueue);
      }
   }
   else
   {
      if (pAppli != (ApplCtxtPtr)0)
      {
         if (pAppli->Status != RESET && pAppli->WanDevPtr!= (IphWanDevPtr)0)
         {
            MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
            /* find whether the application is queued in the device context */
            pTempAppli = (ApplCtxtPtr)pAppli->WanDevPtr->UsingAppliQueue.FirstPtr;
            while (pTempAppli != (ApplCtxtPtr)&pAppli->WanDevPtr->UsingAppliQueue)
            {
               if (pTempAppli == pAppli)
                  break;
               pTempAppli = pTempAppli->NextPtr;
            }
            if (pTempAppli != (ApplCtxtPtr)&pAppli->WanDevPtr->UsingAppliQueue)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[dwClose] extract appli from device");
#endif
               iph_gvExtractQueue(NULL, &pAppli->WanDevPtr->UsingAppliQueue,
                                  (QueueItemPtr)pAppli);
               pAppli->WanDevPtr->NbAppli--;
            }
            MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
         }
         vEndAppli(pAppli, bFull);
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[dwClose] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwResetBoard
* DESCRIPTION : reset a card
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
*    EINVAL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static dword drv_gdwResetBoard(IphWanDevPtr pDev)
{
   int dwError;

   dwError = 0;

   iph_TRACEK(TRCLVL_0, "ResetBoard for dev %d", pDev->Index);
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_gdwResetBoard] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
#endif
   if (pDev->Rsrc->IsCardInReset(pDev) == FALSE)
   {
      IPH_LOCK(&pDev->DevMutex);
      /* first get the exchange area address*/
      WRITE_MEM_DWORD(pDev, EXCH_AREA_ADDR_INDX, 0xFFFFFFFF);
      if (pDev->ExchArea != 0)
      {
         /* Reset CodeReady before resetting the card */
         WRITE_EXCH_CODE_READY(pDev, pDev->ExchArea, 0x52535421);
         /* reset also ConfigStatus */
         WRITE_EXCH_CONFIG_STATUS(pDev, pDev->ExchArea, 0);
      }
      IPH_UNLOCK(&pDev->DevMutex);
   }

   iph_gvShutdownAdapter(&pDev->DevMutex, pDev, CARD_RESET);

   /* Wait for a delay of 2s in case StatusPoll executes once more */
   /* StatusPoll should have been killed previously */
   IPH_DELAY ( POLL_STATUS_DEL_DELAY );

   /* v1.24 protection now done with Status = CARD_RESETTING */
   IPH_LOCK(&pDev->DevMutex);
   pDev->Status = CARD_RESETTING;
   IPH_UNLOCK(&pDev->DevMutex);

   /* reset the board */
   iph_rem_intr(pDev);
   /* v1.24 no more lock because of MDELAY */
   /*IPH_LOCK(&pDev->DevMutex);*/
   pDev->Rsrc->ResetCard(pDev);
   MDELAY(500);
   pDev->Rsrc->RunCard(pDev);
   pDev->Status = CARD_RESETTING;
   /* v1.24 no more lock because of MDELAY */
   /*IPH_UNLOCK(&pDev->DevMutex);*/
   iph_add_intr(pDev);

   return(dwError);
}

/**************************************************************************
* NAME : allocDevCtxt
* DESCRIPTION : allocate a context for a device
* PARAMETERS :
*    Input   : sysDev = protection against interrupts from this device
*    Output  : pDev = where to return the device context
* RETURN : 0 if OK, != 0 else
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
#ifdef LINUX
static int allocDevCtxt(void *sysDev, IphWanDevPtr *pDev)
{
   u16 wCount;

   /* locate a spare minor number for this device
    * The minor number is assigned by the script which
    * load the iphWan driver modules
    * The first card detected has the minor 0, the second card 1 .....     
    */
   for (wCount = 0; wCount < MAX_CARD; wCount++)
   {
      if (iph_gMinorMap[wCount] == (IphWanDevPtr)NULL)
      {
         break;
      }
   }
   if (wCount >= MAX_CARD)
   {
      return(EINVAL);
   }

   /* 
    * allocate a memory to store the data of the device found 
    */
   pDev[0] = kmalloc (sizeof (IphWanDev_t), GFP_KERNEL);
   if (!*pDev)
   {
      iph_TRACEK(TRCLVL_0, "[allocDevCtxt]: lack of memory while attaching card, aborting\n");
      return(-ENOMEM);
   }
   memset(pDev[0], 0, sizeof(IphWanDev_t)); 
   pDev[0]->Index = wCount;
   iph_gMinorMap[wCount] = pDev[0];
#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_1, "[allocDevCtxt]: found index %d @ 0x%08x",
               wCount, iph_gMinorMap[wCount]);
#endif

   return(0);
}
#endif

#ifdef SOLARIS
static int allocDevCtxt(void *sysDev, IphWanDevPtr *pDev)
{
   int iInstance;
   int MinorNum;

   /* get the device instance */
   iInstance = ddi_get_instance(sysDev);

#ifdef CONTROL_MINOR
   MinorNum = CurrentMinorNumber;
   CurrentMinorNumber++;
#else
   MinorNum = iInstance;
#endif

   /* Verify if we reach the maximum number of board */
   if (MinorNum >= MAX_CARD)
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" [allocDevCtxt] device %d failed : Maximum number of board reached (%d)",
                 MinorNum, MAX_CARD);

      return(EINVAL);
   }
   minor2instance[MinorNum] = iInstance;

  cmn_err(CE_CONT, "ss7md: Mapping instance# %d to minor# %d\n", iInstance, MinorNum);

   /* allocate the device structure */
/*
 * to_be_resolved.
 * MH 04mar11.
 * The 'item' parameter is set to MinorNum.
 * Should it be iInstance? The DDK doesn ot mandate using the instance:

'    item     The item number for the  state  structure;  usually
              the instance number of the associated devinfo node.'
 */

   if (ddi_soft_state_zalloc(gpvState, MinorNum) != 0)
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" [allocDevCtxt] device %d: ddi_soft_state_zalloc failed",
                 MinorNum);

      return(ENOMEM);
   }

   /* get the device structure */
   pDev[0] = ddi_get_soft_state(gpvState, MinorNum);
   if (!*pDev)
   {
      iph_TRACEK(TRCLVL_0, "[allocDevCtxt]: lack of memory while attaching card, aborting\n");
      return(-ENOMEM);
   }


   memset(pDev[0], 0, sizeof(IphWanDev_t)); 
   pDev[0]->Index = MinorNum;
   iph_gMinorMap[MinorNum] = pDev[0];
#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_1, "[allocDevCtxt]: found index %d @ 0x%08x",
               MinorNum, pDev[0]);
#endif

   return(0);
}
#endif

/**************************************************************************
* NAME : iph_add_intr
* DESCRIPTION : install interrupt handler
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if all is OK else an error code
* REVISION :
*    - Version 1.0 : 10/17/05 Creation
**************************************************************************/
static int iph_add_intr(IphWanDevPtr pDev)
{
   int iError;
#ifdef LINUX
   /* setup the interrupt */
   if ((iError = request_irq(pDev->sDev.iDev->irq,
                             (void *)pDev->Rsrc->ITHandler,
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,18)
                             SA_SHIRQ,
#else
                             IRQF_SHARED,
#endif
                             DRIVER_NAME,
                             (void *)pDev)) != 0)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_add_intr] device %d: request_irq(%d) failed(%d)",
                 pDev->Index, pDev->sDev.iDev->irq, iError);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_add_intr] request_irq failed");
#endif
      return(-1);
   }
#endif

#ifdef SOLARIS
#ifndef SOL_9
   if ((iError = ddi_intr_enable(pDev->sDev.intHandle)) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_add_intr] device %d: ddi_intr_enable failed (%d)",
                 pDev->Index, iError);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_add_intr] ddi_intr_enable failed");
#endif
      return(-1);
   }
#endif
#endif

   return(0);
}

/**************************************************************************
* NAME : iph_rem_intr
* DESCRIPTION : remove interrupt handler
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if all is OK else an error code
* REVISION :
*    - Version 1.0 : 10/17/05 Creation
**************************************************************************/
static int iph_rem_intr(IphWanDevPtr pDev)
{
   dword dwBS;
#ifdef SOLARIS
   int iError;
#endif

   /* disable interrupt before removing the handler */
   /* disable only our ITs */
   if (pDev->Rsrc != NULL && pDev->Rsrc->PCIDevType == PQ3)
   {
      /* - by resetting E1 bit in MER register */
      READ_CORE_DWORD(pDev, MPC856X_MER, &dwBS);
      dwBS &= ~(0x00000002);
      WRITE_CORE_DWORD(pDev, MPC856X_MER, dwBS);
      /* - by resetting EP bit in MIDR1 register */
      READ_CORE_DWORD(pDev, MPC856X_MIDR1, &dwBS);
      dwBS &= ~(0x80000000);
      WRITE_CORE_DWORD(pDev, MPC856X_MIDR1, dwBS);
      /* ack any pending IT */
      READ_CORE_DWORD(pDev, MPC856X_MSR, &dwBS);
      if ((dwBS & 0x00000002) != 0)
      {
         /* Acknowledge IT by setting S1 bit in MSR register */
         WRITE_CORE_DWORD(pDev, MPC856X_MSR, 0x00000002);
         /* to prevent Interrupt not serviced ??? */
         READ_CORE_DWORD(pDev, MPC856X_MSR, &dwBS);
      }
   }

#ifdef LINUX
   free_irq(pDev->sDev.iDev->irq, pDev);
#endif

#ifdef SOLARIS
#ifndef SOL_9
   if ((iError = ddi_intr_disable(pDev->sDev.intHandle)) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_rem_intr] device %d: ddi_intr_disable failed (%d)",
                 pDev->Index, iError);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_rem_intr] ddi_intr_disable failed");
#endif
   }
#endif
#endif

   return(0);
}

/**************************************************************************
* NAME : iph_attach_device
* DESCRIPTION : complete attach of a device
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if all is OK else an error code
* REVISION :
*    - Version 1.0 : 10/17/05 Creation
**************************************************************************/
static int iph_attach_device(IphWanDevPtr pDev)
{
   word wCount;
   IphCardDesc_t *RsrcDescPtr;
   dword dwBS;
#ifdef SOLARIS
   char DeviceName[20];
   int res;
   int iTNb;
#endif

   /* search for the device ID in the resource list */
   for (wCount = 0; IphCardList[wCount].DevId != 0; wCount++)
   {
      if (IphCardList[wCount].VendorId == *(word *)&pDev->PCIConf[VID_INDX] &&
          IphCardList[wCount].DevId == pDev->Type)
         break;
   }

   if (IphCardList[wCount].DevId != 0)
   {
      pDev->Rsrc = &IphCardList[wCount];
   }
   else
   {
      iph_TRACEK(TRCLVL_0, "[iph_attach_device] device %d: Unknown PCI device 0x%x",
                 pDev->Index, pDev->Type);
      RETURN_TO_USER(EIO);
   }

   /* Initialize the  mapped the exchange zone */
   pDev->ExchArea = 0;

   if (pDev->Rsrc != NULL && pDev->Rsrc->Type == CARD_3639)
   {
      READ_CORE_DWORD(pDev, MPC856X_MSGR0, &dwBS);
      if ((dwBS & 1) == 0)
      {
         iph_TRACEK(TRCLVL_1, 
                    "[iph_attach] device %d is resetting (MSGR0=0x%08x)", 
                    pDev->Index, dwBS);
      }
      for (wCount = 0; wCount < 100 && (dwBS & 1) == 0; wCount++)
      {
         MDELAY(500);
         READ_CORE_DWORD(pDev, MPC856X_MSGR0, &dwBS);
      }
      if (wCount == 100 && (dwBS & 1) == 0)
      {
         iph_TRACEK(TRCLVL_0, "[iph_attach] device %d: failed to detect end of POST", pDev->Index);
      }
      else
      {
         iph_TRACEK(TRCLVL_1, 
                    "[iph_attach] device %d ended reset (%d)", 
                    pDev->Index, wCount);
      }
      MDELAY(1000);

      /* check the reset command is supported without PEX */
      if (pDev->Region[BRIDGE_REGION].WinSize == 0)
      {
         if (pDev->Type == CARD_5639_DID || pDev->Type == CARD_5639E_DID)
         {
            pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
            pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
            if (pDev->Type == CARD_5639E_DID)
            {
               READ_MEM_DWORD(pDev, 0x80018, &dwBS);
            }
            else
            {
               READ_MEM_DWORD(pDev, 0x20018, &dwBS);
            }
            if ((dwBS & 0x04000000) == 0)
            {
#ifdef CHECK_RESET_CAPABILITY
               iph_TRACEK(TRCLVL_0,  " found an Interphase card but it cannot be reset through EPLD => Skip it");
               iph_detach_device(pDev);
               RETURN_TO_USER(ENODEV);
#else
               iph_TRACEK(TRCLVL_0,  " found an Interphase card that may not support reset through EPLD");
#endif
            }
            pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
            pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
            pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
         }
         else if (pDev->Type == CARD_5639L_DID)
         {
            pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
            pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
            READ_MEM_DWORD(pDev, 0x44000, &dwBS);
            if ((dwBS & 0x00000010) == 0)
            {
#ifdef CHECK_RESET_CAPABILITY
               iph_TRACEK(TRCLVL_0,  " found an Interphase card but it cannot be reset through FPGA => Skip it");
               iph_detach_device(pDev);
               RETURN_TO_USER(ENODEV);
#else
               iph_TRACEK(TRCLVL_0,  " found an Interphase card that may not support reset through FPGA");
#endif
            }
            pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
            pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
            pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
         }
      }

      /* Allocate a resource structure */
      RsrcDescPtr = (IphCardDesc_t *)iph_gpMemAlloc(sizeof(IphCardDesc_t),1,
                                                    ALLOC_KERNEL, 1);
      if (RsrcDescPtr == NULL)
      {
         iph_TRACEK(TRCLVL_0, "[iph_attach] device %d: resource allocation failed", pDev->Index);
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_attach] resource allocation failed");
#endif
      }
      else
      {
         /* Initialize the I2C bus access semaphore */
#ifdef SOLARIS
         MUTEX_INIT(&pDev->I2CMutex, "IphPq3 I2C mutex", MUTEX_DRIVER, NULL);
#endif
#ifdef LINUX
         MUTEX_INIT(&pDev->I2CMutex, 1, "I2C");
#endif
         /* search for the device ID & Options in the resource list */
         /* read BER register to get secondary equipment options */
         dwBS = iph_gdwAdapterBoardEquipReg_PQ3(pDev, CARD_PQ3_BOARD_EQUIP_REG+sizeof(dword));
         for (wCount = 0; IphCardList[wCount].DevId != 0; wCount++)
         {
            if ( (IphCardList[wCount].DevId == pDev->Type) &&
                 ( (IphCardList[wCount].DevOption == (dwBS & 0xFF) ||
                   (IphCardList[wCount].DevOption == ((dwBS >> 8) & 0xFF)) ) ) )
               break;
         }
         if (IphCardList[wCount].DevId != 0)
         {
            /* copy the generic resource content to the specific resource */
            bcopy(&IphCardList[wCount], RsrcDescPtr, sizeof(IphCardDesc_t));

            /* save the secondary equipment options */
            RsrcDescPtr->SecondarySubid = dwBS;

            /* read BER register to get primary equipment options */
            dwBS = iph_gdwAdapterBoardEquipReg_PQ3(pDev, CARD_PQ3_BOARD_EQUIP_REG);

            iph_TRACEK(TRCLVL_1, "[iph_attach] device %d: BER=0x%08x", pDev->Index, dwBS);
            /* Set the right Flash size */
            wCount = (dwBS & 0x0000000F);
            pDev->Region[FLASH_REGION].MaxSize = 0x800000 << (wCount - 2);
            if ( pDev->Region[FLASH_REGION].MaxSize == 0x4000000 )
               pDev->Region[FLASH_REGION].CardBaseAddr = 0xFC000000; /* 64MB */
            else
               pDev->Region[FLASH_REGION].CardBaseAddr = 0xFF000000; /* 16MB */

            /* Update the specific resource description */
            RsrcDescPtr->PrimarySubid = dwBS;
            RsrcDescPtr->BoardRevisionId = iph_gbAdapterRev_PQ3(pDev);

            /* Check if the card is equipped with a temperature sensor */
            if ( pDev->Type == CARD_5639L_DID )
            {
               pDev->TempSensorPresent = RsrcDescPtr->PrimarySubid >> 31;

               if ( pDev->TempSensorPresent )
               {
                  /* get the TOS and compute the temperature shutdown threshold */
                  pDev->StopThreshold = iph_gbTOS(pDev) - STOP_MARGIN;
                  pDev->CurTemp = iph_gbCurTemp(pDev);
                  if ( pDev->CurTemp >= pDev->StopThreshold )
                  {
                     iph_TRACEK(TRCLVL_0, 
                                DRIVER_NAME" [iph_attach_device] device %d too hot (%d degrees)",
                                pDev->Index, pDev->CurTemp);
                     iph_detach_device(pDev);
                     RETURN_TO_USER(ENODEV);
                  }
               }
            }

            /* Replace the generic resource description by the specific one */
            pDev->Rsrc = RsrcDescPtr;
         }
         else
         {
            /* Current card is not found in the resource list */
            pDev->Rsrc = NULL;
         }
      }

   }

   /* initialization of some characteristics of the adapter */
   if (pDev->Rsrc == NULL)
   {
      iph_TRACEK(TRCLVL_0, "[iph_attach] found an incompatible card");
      iph_detach_device(pDev);
      RETURN_TO_USER(ENOMEM);
   }

   pDev->DetachPoint = DP_RSRC_ALLOCATED;

   /* get the adapter serial number */
   pDev->Rsrc->AdapterSerialNum(pDev);

   /* if the first read of the serail number fails */
   /* it will be retried in CheckStatus */
   if (pDev->Serial == 0)
   {
      pDev->SerialNumberRead = FALSE;
   }
   else
   {
      pDev->SerialNumberRead = TRUE;
   }

   /* disable interrupt before installing the handler */
   /* disable only our ITs */
   if (pDev->Rsrc != NULL && pDev->Rsrc->PCIDevType == PQ3)
   {
      /* - by resetting E1 bit in MER register */
      READ_CORE_DWORD(pDev, MPC856X_MER, &dwBS);
      dwBS &= ~(0x00000002);
      WRITE_CORE_DWORD(pDev, MPC856X_MER, dwBS);
      /* - by resetting EP bit in MIDR1 register */
      READ_CORE_DWORD(pDev, MPC856X_MIDR1, &dwBS);
      dwBS &= ~(0x80000000);
      WRITE_CORE_DWORD(pDev, MPC856X_MIDR1, dwBS);
   }

#ifdef SOLARIS
#ifdef SOL_9
   /* retrieve interrupt block cookie */
   if ((res = ddi_get_iblock_cookie(pDev->sDev.iDev, 0, 
                                    &pDev->sDev.Cookie)) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: ddi_get_iblock_cookie failed %d",
                 pDev->Index, res);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
   MUTEX_INIT(&pDev->DevMutex, "IphPq3 device mutex", MUTEX_DRIVER, (void *)pDev->sDev.Cookie);
   /* set up interrupt handler for the device */
   if ((res = ddi_add_intr(pDev->sDev.iDev, 0, NULL, NULL, 
                           pDev->Rsrc->ITHandler, (caddr_t)pDev)) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: ddi_add_intr failed %d",
                 pDev->Index, res);
      MUTEX_DESTROY(&pDev->DevMutex);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
#else
   res = ddi_intr_alloc(pDev->sDev.iDev, &pDev->sDev.intHandle, 
                        DDI_INTR_TYPE_FIXED, 0, 1, &iTNb, 0);
   if (res != DDI_SUCCESS || iTNb != 1)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: intr_alloc failed %d",
                 pDev->Index, res);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
   if (ddi_intr_get_pri(pDev->sDev.intHandle, &pDev->sDev.intPri))
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: intr_get_pri failed",
                 pDev->Index);
      ddi_intr_free(pDev->sDev.intHandle);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
   pDev->sDev.intPri = 1;
   if ((res = ddi_intr_set_pri(pDev->sDev.intHandle, pDev->sDev.intPri)) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: intr_set_pri failed %d",
                 pDev->Index, res);
#if 0
/*
 * JCo - removed error handling, but left message to log
 */
      ddi_intr_free(pDev->sDev.intHandle);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
#endif
   }
   MUTEX_INIT(&pDev->DevMutex, "IphPq3 device mutex", MUTEX_DRIVER, (void *)(uintptr_t)pDev->sDev.intPri);
   if (ddi_intr_add_handler(pDev->sDev.intHandle, pDev->Rsrc->ITHandler,
                            (caddr_t)pDev, NULL) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: ddi_add_intr failed",
                 pDev->Index);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_attach_device] ddi_add_intr failed");
#endif
      MUTEX_DESTROY(&pDev->DevMutex);
      ddi_intr_free(pDev->sDev.intHandle);
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
#endif
#endif

#ifdef LINUX
   /* mutex to protect access to the structure */
   MUTEX_INIT(&pDev->DevMutex, 1, "Device");
#endif

   /* setup the interrupt */
   if (iph_add_intr(pDev) != 0)
   {
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME" [iph_attach_device] device %d: iph_add_intr failed",
                 pDev->Index);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_attach_device] iph_add_intr failed");
#endif
#ifdef SOLARIS
#ifndef SOL_9
      ddi_intr_remove_handler(pDev->sDev.intHandle);
#endif
      MUTEX_DESTROY(&pDev->DevMutex);
      MUTEX_DESTROY(&pDev->I2CMutex);
#ifdef SOL_9
      ddi_remove_intr(pDev->sDev.iDev, 0, pDev->sDev.Cookie);
#else
      ddi_intr_free(pDev->sDev.intHandle);
#endif
#endif
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }

#ifdef SOLARIS
#ifdef SOL_9
   if (ddi_add_softintr(pDev->sDev.Dev, DDI_SOFTINT_HIGH, 
                        &pDev->SoftId, NULL,
                        NULL, pDev->Rsrc->ITHandlerDpc,
                        (caddr_t)pDev) != DDI_SUCCESS)
#else
   if (ddi_intr_add_softint(pDev->sDev.Dev, &pDev->SoftId, DDI_INTR_SOFTPRI_MAX,
                            pDev->Rsrc->ITHandlerDpc,
                            (caddr_t)pDev) != DDI_SUCCESS)
#endif
   {
      iph_rem_intr(pDev);
#ifndef SOL_9
      ddi_intr_remove_handler(pDev->sDev.intHandle);
#endif
      MUTEX_DESTROY(&pDev->DevMutex);
      MUTEX_DESTROY(&pDev->I2CMutex);
#ifdef SOL_9
      ddi_remove_intr(pDev->sDev.iDev, 0, pDev->sDev.Cookie);
#else
      ddi_intr_free(pDev->sDev.intHandle);
#endif
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
#endif

   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_attach_device] IT handler installed");

   pDev->DetachPoint = DP_INTERRUPT_ALLOCATED;

#ifdef SOLARIS
   sprintf(DeviceName, "%s%d", DEVICE_NAME, pDev->Index);
   if (ddi_create_minor_node(pDev->sDev.Dev, DeviceName, S_IFCHR, 
                             pDev->Index, 
                             DDI_NT_NET, 0) != DDI_SUCCESS)
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" [iph_attach_device] device %d: ddi_create_minor_node failed",
                 pDev->Index);

#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_attach_device] ddi_create_minor_node failed");
#endif
      iph_detach_device(pDev);
      RETURN_TO_USER(EAGAIN);
   }
   pDev->DetachPoint = DP_MINOR_CREATED;
#endif

   /* condition variable to wait for an event on this adapter */
#ifdef SOLARIS
   CV_INIT(&pDev->CondVar, "", CV_DRIVER, NULL);
#endif
#ifdef LINUX
   CV_INIT(&pDev->CondVar, 2,3,4);
#endif

   /* miscellaneous initializations */
   pDev->SoftITNeeded = FALSE;
   pDev->SoftITRunning = FALSE;
   pDev->Status = CARD_RESET;
   pDev->OpenPrimToDo = FALSE;
   pDev->OpenPrimDone = FALSE;
   pDev->IRQStatus = 0;

   /* Init every timer */
   INIT_TIMER(&pDev->Watchdog);
   INIT_TIMER(&pDev->StatusPoll);
   INIT_TIMER(&pDev->EchoPoll);

#ifdef DEBUG_PERF
   pDev->ITCount = 0;
   pDev->ITDpcCount = 0;
   pDev->SendNb = 0;
   pDev->MaxSendNb = 0;
   pDev->MaxSendLoop = 0;
   pDev->SendWait = 0;
   pDev->RecvChainNb = 0;
   pDev->MaxRecvChainNb = 0;
   pDev->ITPerDpc = 0; 
   pDev->MaxITPerDpc = 0;
   pDev->SendMsgNb = 0;
   pDev->RecvMsgNb = 0;
   pDev->RecvChainCount = 0;
   pDev->NbrLackRecvPrim = 0;
   pDev->NbrLackRecvBuffer = 0;
   pDev->SendPendingWait = 0;
#endif

   pDev->DummyAreaDesc.VirtAddr = NULL;
   pDev->DummyAreaDesc.Size = 0;
   pDev->HostArea = NULL;
   pDev->HostAreaDesc.Size = 0;
   pDev->InbStatus = NULL;
   pDev->OutbCtrl = NULL;
   pDev->OutbSend = NULL;
   pDev->InbCtrl = NULL;
   pDev->InbSend = NULL;
   pDev->OutbStatus = NULL;
   pDev->OutbAddr = NULL;
   for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
   {
      pDev->OutbPool[wCount] = NULL;
   }
   pDev->SendingPrim = NULL;
   pDev->SendDmaDesc = NULL;
   pDev->RecvDmaDesc = NULL;
   pDev->FirstDmaDesc = NULL;

   pDev->MaxTransferSize = DEF_MAX_TRANSFER_SIZE;
   pDev->MaxSession = 0;
   pDev->MGRSessionCorrTable = NULL;
   iph_gvInitQueue(&pDev->FreeMGRSessionCorrQueue);
   iph_gvInitQueue(&pDev->UsedMGRSessionCorrQueue);
   pDev->MaxAppli = DEF_MAX_APPLI;
   pDev->NbAppli = 0;
   iph_gvInitQueue(&pDev->UsingAppliQueue);
   pDev->ControlAppli = 0;

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_attach_detach]: initializing pools...");
#endif

   /* we initialize all the pools that are going to store dynamically */
   /* allocated structures, to handle proper deallocation when there */
   /* is a failure */
   iph_gvInitDrvPool(&pDev->FreePrimHeadPool);
   iph_gvInitDrvPool(&pDev->FreeDataDescPool);
   for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
   {
      iph_gvInitDrvPool(&pDev->FreeDataPools[wCount]);
      pDev->FreeDataPools[wCount].PoolIndex = wCount;
   }
   pDev->LastPool = 0;

   pDev->SendPending = 0;
   /* condition variable to wait for exclusive send access */
#ifdef LINUX
   CV_INIT(&pDev->SendPendingCv, 2,3,4);
#endif
#ifdef SOLARIS
   CV_INIT(&pDev->SendPendingCv, "device send cv", CV_DRIVER, NULL);
#endif

   /* add a new card in the list */
   MUTEX_ENTER(&gAccessMutex);
   iph_gvPutQueue(NULL, &gWanDevQueue, (QueueItemPtr)pDev);
   MUTEX_EXIT(&gAccessMutex);

   /* Initialize WatchDog the timer */
   pDev->WatchdogTimeout = FALSE;
   pDev->WatchdogTimer = FALSE;

   /* Initialize Echo the timer */
   pDev->EchoTimeout = FALSE;
   pDev->EchoTimer = FALSE;

   /* check the card status */
   if (pDev->Rsrc->CheckCardStatus != NULL)
   {
      pDev->Status = pDev->Rsrc->CheckCardStatus(NULL, pDev);

      /* start timer to poll the status */
      IPH_START_TIMER(&pDev->StatusPoll, iph_gvITPollStatus, pDev, 
                      POLL_STATUS_TIMEOUT);
      pDev->PollTimeout = FALSE;
      pDev->PollTimer = TRUE;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_attach_device] return");
#endif

   /* switch off the BLUE LED */
   /* TO COMPLETE */

   return(0);
}

/**************************************************************************
* NAME : iph_detach_device
* DESCRIPTION : detach an individual card entry point
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if all is OK else an error code
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int iph_detach_device(IphWanDevPtr pWanDev)
{
   IphWanDevPtr pWanDevTmp;
   word wCount;
   DrvPrimDescPtr pDrvPrim;
   DrvPrimDescPtr pNextDrvPrim;
   DrvDataDescPtr pDrvData;
   DrvDataDescPtr pNextDrvData;
#ifdef SOLARIS
   char DeviceName[20];
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[iph_detach] entry");
#endif

   iph_TRACEK(TRCLVL_1, "[iph_detach_device] detaching device %s%d - detach %d",
              DEVICE_NAME, pWanDev->Index, pWanDev->DetachPoint);

#ifdef LINUX
   if (iph_gMinorMap[pWanDev->Index] != 0)
   {
      iph_TRACEK(TRCLVL_1, "[iph_detach_device] detach delayed");
      return(0);
   }
#endif

   if (pWanDev->DetachPoint == DP_ALL)
   {
      /* No more access to the card */
      pWanDev->EchoTimer = FALSE;
      pWanDev->Rsrc->CheckCardStatus = NULL;

      if (pWanDev->Rsrc->IsCardInReset(pWanDev) == FALSE)
      {
         IPH_LOCK(&pWanDev->DevMutex);
         /* first get the exchange area address*/
         WRITE_MEM_DWORD(pWanDev, EXCH_AREA_ADDR_INDX, 0xFFFFFFFF);
         if (pWanDev->ExchArea != 0)
         {
            /* Reset CodeReady */
            WRITE_EXCH_CODE_READY(pWanDev, pWanDev->ExchArea, 0x52535421);
            /* reset also ConfigStatus */
            WRITE_EXCH_CONFIG_STATUS(pWanDev, pWanDev->ExchArea, 0);
         }
         IPH_UNLOCK(&pWanDev->DevMutex);
      }

      if (pWanDev->Status != CARD_RESET)
      {
         iph_gvShutdownAdapter(&pWanDev->DevMutex, pWanDev, CARD_RESET);
      }
#ifdef SOLARIS
      if (pWanDev->Status != CARD_UNAVAILABLE)
      {
         iph_gdwResetBoard(pWanDev);
      }
#endif

      /* disable interrupt */
      iph_TRACEK(TRCLVL_1, DRIVER_NAME" [iph_detach_device]: disable interrupt\n");
      if (pWanDev->Rsrc != NULL && pWanDev->Rsrc->PCIDevType == PQ3)
      {
         dword tmp32;

         /* - by resetting E1 bit in MER register */
         READ_CORE_DWORD(pWanDev, MPC856X_MER, &tmp32);
         tmp32 &= ~(0x00000002);
         WRITE_CORE_DWORD(pWanDev, MPC856X_MER, tmp32);
         /* - by resetting EP bit in MIDR1 register */
         READ_CORE_DWORD(pWanDev, MPC856X_MIDR1, &tmp32);
         tmp32 &= ~(0x80000000);
         WRITE_CORE_DWORD(pWanDev, MPC856X_MIDR1, tmp32);
      }

      /* extract the device from the attached devices queue */
      pWanDevTmp = (IphWanDevPtr)gWanDevQueue.FirstPtr;
      while (pWanDevTmp != (IphWanDevPtr)&gWanDevQueue)
      {
         if (pWanDevTmp == pWanDev)
            break;
         pWanDevTmp = pWanDevTmp->NextPtr;
      }
      if (pWanDevTmp != (IphWanDevPtr)&gWanDevQueue)
      {
         MUTEX_ENTER(&gAccessMutex);
         iph_gvExtractQueue(NULL, &gWanDevQueue, (QueueItemPtr)pWanDev);
         MUTEX_EXIT(&gAccessMutex);
      }
      else
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] device not in queue!!!");
#endif
      }

#ifdef SOLARIS
      CV_DESTROY(&pWanDev->SendPendingCv);
#endif

      /* del timer watchdog timer */
      if (pWanDev->WatchdogTimer == TRUE)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] stop watchdog timer");
#endif
         pWanDev->WatchdogTimer = FALSE;
         IPH_DEL_TIMER(&pWanDev->Watchdog);
         /* to prevent restart of timer */
         pWanDev->WatchdogTimeout = TRUE;
      }

      /* remove the poll status timer */
      if (pWanDev->PollTimer == TRUE)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] stop poll timer");
#endif
         pWanDev->PollTimer = FALSE;
         IPH_DEL_TIMER(&pWanDev->StatusPoll);
         /* to prevent restart of timer */
         pWanDev->PollTimeout = TRUE;
      }

      /* Wait for a delay of 2s in case StatusPoll executes once more */
      IPH_DELAY ( POLL_STATUS_DEL_DELAY );

      /* remove the poll status timer */
      if (pWanDev->EchoTimer == TRUE)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] stop echo timer");
#endif
         pWanDev->EchoTimer = FALSE;
         IPH_DEL_TIMER(&pWanDev->EchoPoll);
         /* to prevent restart of timer */
         pWanDev->EchoTimeout = TRUE;
      }

      /* we must free the Dummy area */
      if (pWanDev->DummyAreaDesc.VirtAddr != NULL)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free DummyArea!!");
#endif
         DMA_UNBIND_HANDLE(pWanDev, &pWanDev->DummyAreaDesc);
         DMA_FREE_MEM(pWanDev, &pWanDev->DummyAreaDesc);
         DMA_FREE_HANDLE(pWanDev, &pWanDev->DummyAreaDesc);
         pWanDev->DummyAreaDesc.VirtAddr = NULL;
      }

      /* we must free the Host control area */
      if (pWanDev->HostArea != NULL)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free HostArea!!");
#endif
         DMA_UNBIND_HANDLE(pWanDev, &pWanDev->HostAreaDesc);
         DMA_FREE_MEM(pWanDev, &pWanDev->HostAreaDesc);
         DMA_FREE_HANDLE(pWanDev, &pWanDev->HostAreaDesc);
         pWanDev->HostArea = NULL;
      }

      /* we must free the session correlators */
      if (pWanDev->MGRSessionCorrTable != NULL)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free CorrTable!!");
#endif
         for (wCount = 0; wCount < pWanDev->MaxSession; wCount++)
            iph_gvMemFree(pWanDev->MGRSessionCorrTable[wCount]);
         iph_gvMemFree(pWanDev->MGRSessionCorrTable);
         pWanDev->MGRSessionCorrTable = NULL;
      }

      if (pWanDev->SendingPrim != NULL)
      {
         iph_gvMemFree(pWanDev->SendingPrim);
      }

      /* free memory allocated for DMA */
      iph_gdwFreeDmaMem(pWanDev);

      /* we must free the DrvPrimDesc_t structures in FreePrimHeadPool */
      pDrvPrim = (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.UsedQueue[0];
#ifdef TRACE
      if (pDrvPrim != (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.UsedQueue)
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free FreePrimHeadPool.Used!!");
#endif
      while (pDrvPrim != (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.UsedQueue)
      {
         pNextDrvPrim = pDrvPrim->NextItemPtr;
         iph_gvMemFree((void *)pDrvPrim);
         pDrvPrim = pNextDrvPrim;
      }
      pDrvPrim = (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.FreeQueue[0];
#ifdef TRACE
      if (pDrvPrim != (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.FreeQueue)
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free FreePrimHeadPool.Free!!");
#endif
      while (pDrvPrim != (DrvPrimDescPtr)pWanDev->FreePrimHeadPool.FreeQueue)
      {
         pNextDrvPrim = pDrvPrim->NextItemPtr;
         iph_gvMemFree((void *)pDrvPrim);
         pDrvPrim = pNextDrvPrim;
      }
      /* we must free the DrvDataDesc_t structures in FreeDataDescPool */
      pDrvData = (DrvDataDescPtr)pWanDev->FreeDataDescPool.UsedQueue[0];
#ifdef TRACE
      if (pDrvData != (DrvDataDescPtr)pWanDev->FreeDataDescPool.UsedQueue)
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free FreeDataDescPool.Used!!");
#endif
      while (pDrvData != (DrvDataDescPtr)pWanDev->FreeDataDescPool.UsedQueue)
      {
         pNextDrvData = pDrvData->NextItemPtr;
         iph_gvMemFree((void *)pDrvData);
         pDrvData = pNextDrvData;
      }
      pDrvData = (DrvDataDescPtr)pWanDev->FreeDataDescPool.FreeQueue[0];
#ifdef TRACE
      if (pDrvData != (DrvDataDescPtr)pWanDev->FreeDataDescPool.FreeQueue)
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_detach_device] gonna free FreeDataDescPool.Free!!");
#endif
      while (pDrvData != (DrvDataDescPtr)pWanDev->FreeDataDescPool.FreeQueue)
      {
         pNextDrvData = pDrvData->NextItemPtr;
         iph_gvMemFree((void *)pDrvData);
         pDrvData = pNextDrvData;
      }

   }

   switch (pWanDev->DetachPoint)
   {
      case DP_ALL:
#ifdef SOLARIS
         CV_DESTROY(&pWanDev->CondVar);
#endif
         iph_gbAttachedCard--;
      case DP_MINOR_CREATED:
#ifdef SOLARIS
         ddi_remove_minor_node(pWanDev->sDev.Dev, NULL);
#endif
      case DP_INTERRUPT_ALLOCATED:
#ifdef LINUX
         iph_guiCleanTasklet(pWanDev);
#endif
#ifdef SOLARIS
#ifdef SOL_9
         ddi_remove_softintr(pWanDev->SoftId);
#else
         ddi_intr_remove_softint(pWanDev->SoftId);
#endif
#endif
         iph_rem_intr(pWanDev);
#ifdef SOLARIS
#ifndef SOL_9
         ddi_intr_remove_handler(pWanDev->sDev.intHandle);
#endif
         MUTEX_DESTROY(&pWanDev->DevMutex);
#ifdef SOL_9
         ddi_remove_intr(pWanDev->sDev.iDev, 0, pWanDev->sDev.Cookie);
#else
         ddi_intr_free(pWanDev->sDev.intHandle);
#endif
#endif
      case DP_RSRC_ALLOCATED:
         if (pWanDev->Rsrc != NULL)
         {
            iph_gvMemFree((void *)pWanDev->Rsrc);
         }
      case DP_PCI_REGISTERS_MAPPED:
         for (wCount = BRIDGE_REGION; wCount < MAX_REGION; wCount++)
         {
            if (pWanDev->Region[wCount].Mapped)
            {
#ifdef LINUX
               iounmap((void *)pWanDev->Region[wCount].Mapped);
#endif
#ifdef SOLARIS
               ddi_regs_map_free(&pWanDev->Region[wCount].AccHandle);
#endif
            }
         }
#ifdef SOLARIS
         MUTEX_DESTROY(&pWanDev->I2CMutex);
#endif
      case DP_CTX_ALLOCATED:
#ifdef LINUX
         kfree(pWanDev);
#endif
#ifdef SOLARIS
         ddi_soft_state_free(gpvState, pWanDev->Index);
#ifdef CONTROL_MINOR
         CurrentMinorNumber--;
#endif
#endif
      case DP_NONE: 
         break;
   }


   return(0);
}

/**************************************************************************
* NAME : allocAppliCtxt
* DESCRIPTION : allocate an application context
* PARAMETERS :
*    Input   : pWanDev = device context
* RETURN : pointer on application context if all is OK
*          NULL else
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
* Note: the routine must be called with any needed protection already done
**************************************************************************/
static ApplCtxtPtr allocAppliCtxt(IphWanDevPtr pWanDev)
{
   word wCount;
   ApplCtxtPtr pAppli;

   /* Allocate a memory to store application context */
   pAppli = (ApplCtxtPtr)iph_gpMemAlloc(sizeof(ApplCtxt_t), 1, 
                                        ALLOC_KERNEL, 1);
   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[allocAppliCtxt] alloc failed => ENOMEM");
#endif
      return(NULL);
   }

   pAppli->NextPtr = NULL;
   pAppli->PrevPtr = NULL;

   /* create a mutex for the application */
#ifdef LINUX
   MUTEX_INIT(&pAppli->AppliMutex, 1, "Appli");
#endif
#ifdef SOLARIS
   MUTEX_INIT(&pAppli->AppliMutex, "IphWan appli mutex", MUTEX_DRIVER, 
              (void *)(uintptr_t)pWanDev->sDev.intPri);
#endif

   /* condition variable to wait for an event on this adapter */
#ifdef LINUX
   CV_INIT(&pAppli->CondVar, 2,3,4);
#endif
#ifdef SOLARIS
   CV_INIT(&pAppli->CondVar, "IphWan appli cv", CV_DRIVER, NULL);
#endif

   pAppli->Status = RUNNING;
   pAppli->kd_wakeup = NULL;
   pAppli->kd_free = NULL;
   pAppli->WanDevPtr = pWanDev;
   for (wCount = 0; wCount < MODULO; wCount++)
   {
      iph_gvInitQueue(&pAppli->HashTable[wCount]);
   }

   /* Allocation of buffer pool   */
   pAppli->PoolInUse = FALSE;
   pAppli->FreePrimHeadPool.NextPtr = NULL;
   pAppli->FreePrimHeadPool.PoolSize = sizeof(PrimDesc_t);
   pAppli->FreePrimHeadPool.PoolCount = 0;

   for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
   {
      pAppli->FreeDataPools[wCount].NextPtr = NULL;
      pAppli->FreeDataPools[wCount].PoolSize =
          (word)pWanDev->FreeDataPools[wCount].PoolSize;
      pAppli->FreeDataPools[wCount].PoolCount = 0;
   }
   pAppli->MaxRecvNb = DEF_MAX_RX_QUEUE;
   pAppli->MaxChainRecvNb = 1;
   pAppli->ChainGiveRx = 0;
   pAppli->RecvNb = 0;
   iph_gvInitQueue(&pAppli->RecvQueue);

   /* dedicated DATA_IND buffer pool initialization*/
   pAppli->DataIndPool.CurIndx = 0;
   pAppli->DataIndPool.MaxBuff = 0;
   for (wCount = 0; wCount < MAX_CIRC_POOL_SIZE; wCount++)
   {
      pAppli->DataIndPool.BuffPtr[wCount] = NULL;
   }

   return(pAppli);
}

/**************************************************************************
* NAME : run_ioctl
* DESCRIPTION : ioctl entry point
* PARAMETERS :
*    Input   : pAppli = application context
*    Input   : cmd = command type
*    Input   : arg = command argument
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          EBUSY if adapter not available
*          ENODEV if the adapter is not accessible
* REVISION :
*    - Version 1.0: 12/01/2005 creation
**************************************************************************/
static int run_ioctl(ApplCtxtPtr pAppli, unsigned int cmd, void *arg,
                     int mode)
{
   IphWanDevPtr pWanDev = NULL;
   IphWanDevPtr pTmpDev = NULL;
   int iError = 0;
   CardId_t MyCardId;
   MemDesc_t MyMem;
   MemDesc_t *pMem;
   CardId_t *pCardId;
   word wCount;
   CardStatus_t MyCardStatus;
   CardStatus_t *pCardStatus = NULL;
   byte *pucMyBuff;
   word wDevId;
   word wAppliNb;
   ApplCtxtPtr pAppliTmp;
   byte AppliType = TYPE_KERNEL;
   byte level;
   CustomInfo_t MyCustomInfo;
   byte MyStatus;

   if (pAppli != NULL)
   {
      pWanDev = pAppli->WanDevPtr;
      AppliType = pAppli->Type;
   }

   switch (cmd)
   {
      case CTL_CLOSE_DEVICE:
         if (AppliType == TYPE_USER)
         {
            iError = (int)dwClose(pAppli, NULL, 0);
         }
         else
         {
            iError = (int)dwClose(pAppli, NULL, 1);
         }
         break;

      case CTL_SEND_PRIM:
         iError = (int)iph_gdwCtlSendPrim(pAppli, mode, (PrimDesc_t *)arg);
         break;

      case CTL_GIVE_RX_PRIM:
         iError = (int)iph_gdwCtlGiveRxPrim(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_GIVE_RX_BUFFER:
         iError = (int)iph_gdwCtlGiveRxBuffer(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_GIVE_RX_DATA_BUFFER:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlGiveRxDataBuffer(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_GIVE_MAX_RX_DATA_BUFFER not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_RECV_PRIM:
         iError = (int)iph_gdwCtlRecvPrim(pAppli, mode, (PrimDesc_t **)arg);
         break;

      case CTL_MAX_RX_QUEUE:
         iError = (int)iph_gdwCtlMaxRxQueue(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_MAX_RX_CHAIN:
         iError = (int)iph_gdwCtlMaxRxChain(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_NO_OF_DEVICES:
         iError = (int)iph_gdwCtlNoOfDev(AppliType, mode, (MemDesc_t *)arg);
         break;

      case CTL_GET_CARD_ID:
         if (AppliType == TYPE_USER)
         {
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size == sizeof(CardId_t) && MyMem.DataPtr != NULL)
            {
               GET_DATA_USER(MyMem.DataPtr, &MyCardId, sizeof(CardId_t), 
                             mode, &iError);
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_ID failed to copy argument");
#endif
               }
            }
            else
            {
               if (iError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_ID bad argument");
#endif
                  iError = EINVAL;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_ID failed to copy argument");
#endif
               }
            }
         }
         else
         {
            pMem = (MemDesc_t *)arg;
            pCardId = (CardId_t *)pMem->DataPtr;
            MyCardId.Index = pCardId->Index;
         }
         if (iError == 0)
         {
            if (MyCardId.Index != NO_INDEX)
            {
               pTmpDev = (IphWanDevPtr)gWanDevQueue.FirstPtr;
               for (wCount = 0;
                    wCount < MyCardId.Index &&
                    pTmpDev != (IphWanDevPtr)&gWanDevQueue;
                    wCount++)
               {
                  pTmpDev = pTmpDev->NextPtr;
               }
               if (pTmpDev == (IphWanDevPtr)&gWanDevQueue)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_ID no device");
#endif
                  pTmpDev = NULL;
               }
            }
            else
               pTmpDev = pWanDev;
         }
         else
            pTmpDev = NULL;
         if (pTmpDev != NULL)
         {
            iError = iph_gdwCtlGetCardId(AppliType, mode, pTmpDev, 
                                         (MemDesc_t *)arg);
         }
         else
         {
            iError = EINVAL;
         }
         break;

      case CTL_GET_CONTROL:
         if (AppliType == TYPE_USER)
         {
            MUTEX_ENTER(&pWanDev->DevMutex);
            if (pWanDev->Status == CARD_UNAVAILABLE)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CONTROL not allowed with this card status");
#endif
               iError = ENODEV;
            }
            else if (pWanDev->Status == CARD_POST_FAILED)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CONTROL not allowed with this card status");
#endif
               iError = ENXIO;
            }
            else if (pWanDev->ControlAppli != (ApplCtxtPtr)0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CONTROL already owned");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                            pWanDev->ControlAppli->WanDevPtr->Index,
                            pWanDev->ControlAppli->Minor);
#endif
               iError = EBUSY;
            }
            else
            {
               pWanDev->ControlAppli = pAppli;
            }
            MUTEX_EXIT(&pWanDev->DevMutex);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_GET_CONTROL not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_FREE_CONTROL:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlFreeControl(pAppli);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_FREE_CONTROL not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_DUMP_MEM:
         iError = (int)iph_gdwCtlDumpMem(pAppli, mode, (MemDesc_t *)arg, MEM_REGION);
         break;

      case CTL_WRITE_MEM:
         iError = (int)iph_gdwCtlWriteMem(pAppli, mode, (MemDesc_t *)arg, MEM_REGION);
         break;

      case CTL_READ_FLASH:
         iError = (int)iph_gdwCtlDumpMem(pAppli, mode, (MemDesc_t *)arg, FLASH_REGION);
         break;

      case CTL_WRITE_FLASH:
         iError = (int)iph_gdwCtlWriteMem(pAppli, mode, (MemDesc_t *)arg, FLASH_REGION);
         break;

      case CTL_DUMP_PLX_REG:
         if (pAppli->WanDevPtr->Region[BRIDGE_REGION].WinSize > 0)
            iError = (int)iph_gdwCtlDumpReg(pAppli, mode, (MemDesc_t *)arg, BRIDGE_REGION);
         else
            iError = EACCES;
         break;

      case CTL_WRITE_PLX_REG:
         if (pAppli->WanDevPtr->Region[BRIDGE_REGION].WinSize > 0)
            iError = (int)iph_gdwCtlWriteReg(pAppli, mode, (MemDesc_t *)arg, BRIDGE_REGION);
         else
            iError = EACCES;
         break;

      case CTL_DUMP_CORE_REG:
         iError = (int)iph_gdwCtlDumpReg(pAppli, mode, (MemDesc_t *)arg, CORE_REGION);
         break;

      case CTL_WRITE_CORE_REG:
         iError = (int)iph_gdwCtlWriteReg(pAppli, mode, (MemDesc_t *)arg, CORE_REGION);
         break;

      case CTL_DUMP_PCI_CONF:
         iError = (int)iph_gdwCtlDumpPCIConf(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_WRITE_PCI_CONF:
         iError = (int)iph_gdwCtlWritePCIConf(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_GET_DRV_VER:
         iError = (int)iph_gdwCtlGetDrvVer(AppliType, mode, (MemDesc_t *)arg);
         break;

      case CTL_DUMP_CPU_USAGE:
         iError = (int)iph_gdwCtlDumpCPUUsage(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_DUMP_POOL:
         iError = (int)iph_gdwCtlDumpPool(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_DUMP_DRV_POOL:
         iError = (int)iph_gdwCtlDumpDrvPool(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_DUMP_SEEPROM_BYTE:
         iError = (int)iph_gdwCtlDumpSeepromByte(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_WRITE_SEEPROM_BYTE:
         iError = (int)iph_gdwCtlWriteSeepromByte(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_MAX_TRANSFER_SIZE:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlMaxTransferSize(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_MAX_TRANSFER_SIZE not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_INIT_PRIM_POOL:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlInitPrimPool(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_INIT_PRIM_POOL not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_INIT_BUFFER_POOL:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlInitBufferPool(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_INIT_BUFFER_POOL not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_INIT_MAX_APPLI:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlInitMaxAppli(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_MAX_APPLI not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_INIT_MAX_SESSION:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlInitMaxSession(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_MAX_SESSION not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_INIT_DRV_TRACE:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlInitDrvTrace(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_INIT_DRV_TRACE not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_START_DRV_TRACE:
         iError = (int)iph_gdwCtlSetDrvTrace(AppliType, &gAccessMutex, 
                                             mode, (MemDesc_t *)arg,
                                             TRUE);
         break;

      case CTL_STOP_DRV_TRACE:
         iError = (int)iph_gdwCtlSetDrvTrace(AppliType, &gAccessMutex, 
                                             mode, (MemDesc_t *)arg,
                                             FALSE);
         break;

      case CTL_DUMP_TRACE:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlDumpTrace(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_DUMP_TRACE not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_GET_STATUS:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlGetStatus(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_GET_STATUS not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_GET_CARD_STATUS:
         if (AppliType == TYPE_USER)
         {
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size == sizeof(CardStatus_t) && MyMem.DataPtr != NULL)
            {
               GET_DATA_USER(MyMem.DataPtr, &MyCardStatus, sizeof(CardStatus_t),
                             mode, &iError);
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_STATUS failed to copy argument");
#endif
               }
            }
            else
            {
               if (iError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_STATUS bad argument");
#endif
                  iError = EINVAL;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_STATUS failed to copy argument");
#endif
               }
            }

            if (iError == 0)
            {
               pTmpDev = NULL;
               if (MyCardStatus.SerialNum != 0)
               {
                  /* thanks to the serial number, find the corresponding adapter */
                  MUTEX_ENTER(&gAccessMutex);
                  pTmpDev = (IphWanDevPtr)gWanDevQueue.FirstPtr;
                  while (pTmpDev != (IphWanDevPtr)&gWanDevQueue)
                  {
                     if (pTmpDev->Serial == MyCardStatus.SerialNum)
                        break;
                     pTmpDev = pTmpDev->NextPtr;
                  }
                  MUTEX_EXIT(&gAccessMutex);

                  if (pTmpDev == (IphWanDevPtr)&gWanDevQueue)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[run_ioctl] device not found => EINVAL");
#endif
                     pTmpDev = NULL;
                     iError = EINVAL;
                  }
               }
               else
               {
                  pTmpDev = pWanDev;
               }
            }
            else
               pTmpDev = NULL;
            if (iError == 0 && pTmpDev != NULL)
            {
               MyCardStatus.SerialNum = pTmpDev->Serial;
               MyCardStatus.Status = pTmpDev->Status;
               if (MyCardStatus.Status == CARD_RESETTING)
               {
                  MyCardStatus.Status = CARD_RESET;
               }

               PUT_DATA_USER(MyMem.DataPtr, &MyCardStatus, sizeof(CardStatus_t),
                             mode, &iError);
               if (iError != 0)
               {
                  iError = EFAULT;
               }
            }
         }
         else
         {
            pMem = (MemDesc_t *)arg;
            if (pMem == NULL || pMem->Size != sizeof(CardStatus_t) ||
                ((pCardStatus = (CardStatus_t *)pMem->DataPtr) == NULL) ||
                (pAppli == NULL && pCardStatus->SerialNum == 0))
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CTL_GET_CARD_STATUS bad argument => EINVAL");
#endif
               iError = EINVAL;
            }
            else
            {
               pTmpDev = NULL;
               if (pCardStatus->SerialNum != 0)
               {
                  /* thanks to the serial number, find the corresponding adapter */
                  MUTEX_ENTER(&gAccessMutex);
                  pTmpDev = (IphWanDevPtr)gWanDevQueue.FirstPtr;
                  while (pTmpDev != (IphWanDevPtr)&gWanDevQueue)
                  {
                     if (pTmpDev->Serial == pCardStatus->SerialNum)
                        break;
                     pTmpDev = pTmpDev->NextPtr;
                  }
                  MUTEX_EXIT(&gAccessMutex);

                  if (pTmpDev == (IphWanDevPtr)&gWanDevQueue)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[run_ioctl] GET_CARD_STATUS device not found => EINVAL");
#endif
                     pTmpDev = NULL;
                     iError = EINVAL;
                  }
               }
               else
                  pTmpDev = pWanDev;
            }
            if (iError == 0 && pTmpDev != NULL)
            {
               pCardStatus->SerialNum = pTmpDev->Serial;
               pCardStatus->Status = pTmpDev->Status;
               if (pCardStatus->Status == CARD_RESETTING)
               {
                  pCardStatus->Status = CARD_RESET;
               }
            }
         }
         break;

      case CTL_SET_CARD_STATUS: 
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlSetCardStatus(pAppli, mode, (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_SET_CARD_STATUS not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_GET_CARD_RSRC:
         if (AppliType == TYPE_USER)
         {
            pucMyBuff = NULL;
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size > 0 && MyMem.DataPtr != NULL)
            {
               /* allocate a temporary buffer to dump the DRAM content */
               pucMyBuff = (byte *)iph_gpMemAlloc(MyMem.Size, 1, ALLOC_KERNEL, 1);
               if (pucMyBuff == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] CTL_GET_CARD_RSRC memory allocation failed");
#endif
                  iError = ENOMEM;
               }
               else if (MyMem.Offset > 0)
               {
                  GET_DATA_USER(MyMem.DataPtr, pucMyBuff, MyMem.Offset, 
                                mode, &iError);
               }
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_RSRC failed to copy argument");
#endif
               }
            }
            else
            {
               if (iError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_RSRC bad argument");
#endif
                  iError = EINVAL;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_RSRC failed to copy argument");
#endif
               }
            }

            if (iError == 0)
            {
               if (MyMem.Offset >= 4)
               {
                  bcopy(&pucMyBuff[2], &wDevId, sizeof(word));
                  if (wDevId == 0)
                  {
                     wDevId = pWanDev->Type;
                  }
               }
               else
               {
                  wDevId = pWanDev->Type;
               }

               iError = dwBuildCardRsrc(pWanDev, wDevId, pucMyBuff, &MyMem.Size);
               if (iError == 0)
               {
                  PUT_DATA_USER(MyMem.DataPtr, pucMyBuff, MyMem.Size,
                                mode, &iError);
               }
            }
            if (iError != 0)
            {
               MyMem.Size = 0;
            }
            /* copy the memory descriptor */
            PUT_MEM_DESC(&MyMem, arg, mode, &iError);
            if (pucMyBuff != NULL)
            {
               iph_gvMemFree((void *)pucMyBuff);
            }
         }
         else
         {
            pMem = (MemDesc_t *)arg;
            if (pMem == NULL || pMem->Size == 0 ||
                pMem->DataPtr == NULL ||
                (pAppli == NULL && pMem->Offset < 4))
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CTL_GET_CARD_RSRC bad argument => EINVAL");
#endif
               iError = EINVAL;
            }
            else
            {
               if (pMem->Offset >= 4)
                  bcopy(&pMem->DataPtr[2], &wDevId, sizeof(word));
               else
                  wDevId = pWanDev->Type;
               iError = dwBuildCardRsrc(pWanDev, wDevId, pMem->DataPtr, 
                                        &pMem->Size);
            }
            if (iError != 0)
            {
               pMem->Size = 0;
            }
         }
         break;

      case CTL_GET_USING_APPLI:
         if (AppliType == TYPE_USER)
         {
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size >= sizeof(pid_t) && MyMem.DataPtr != NULL)
            {
               wAppliNb = MyMem.Size / sizeof(pid_t);
               pAppliTmp = (ApplCtxtPtr)pWanDev->UsingAppliQueue.FirstPtr;
               for (wCount = 0; 
                    wCount < wAppliNb && 
                    pAppliTmp != (ApplCtxtPtr)&pWanDev->UsingAppliQueue; 
                    wCount++)
               {
                  if (pAppliTmp->Type == TYPE_USER)
                  {
                     PUT_DATA_USER((MyMem.DataPtr + wCount * sizeof(pid_t)),
                                   &pAppliTmp->ProcID, sizeof(pid_t),
                                   mode, &iError);
                  }
                  pAppliTmp = pAppliTmp->NextPtr;
               }
               MyMem.Size = wCount * sizeof(pid_t);
               PUT_MEM_DESC(&MyMem, arg, mode, &iError);
            }
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_GET_USING_APPLI not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

        case CTL_GET_CONTROL_DBG:
           if (pWanDev->Status == CARD_UNAVAILABLE)
           {
#ifdef TRACE
              iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                               (byte *)"[run_ioctl] CONTROL_DBG: Card is not accessible");
#endif
                 iError = ENODEV;
           }
           else if (AppliType == TYPE_USER)
           {
              /* ioctl to handle devices with POST failed */
              MUTEX_ENTER(&pWanDev->DevMutex);
              if (pWanDev->ControlAppli != (ApplCtxtPtr)0)
              {
#ifdef TRACE
                 iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                  (byte *)"[run_ioctl] CONTROL_DBG already owned");
                 iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                              pWanDev->ControlAppli->WanDevPtr->Index,
                              pWanDev->ControlAppli->Minor);
#endif
                 iError = EBUSY;
              }
              else
              {
                 pWanDev->ControlAppli = pAppli;
              }
              MUTEX_EXIT(&pWanDev->DevMutex);
           }
           else
           {
#ifdef TRACE
              iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                               (byte *)"[run_ioctl] CTL_GET_CONTROL_DBG not allowed => EPERM");
#endif
              iError = EPERM;
           }
           break;

      case CTL_CHECK_CARD_STATUS:
         if (pWanDev->Status == CARD_UNAVAILABLE)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CHECK_CARD_STATUS: Card is not accessible");
#endif
            iError = ENODEV;
         }
         else if (AppliType == TYPE_USER)
         {
            /* ioctl to rebuild card status */
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError != 0 ||
                MyMem.Size != sizeof(byte) || MyMem.DataPtr == NULL)
            {
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_STATUS failed to copy argument");
#endif
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] GET_CARD_STATUS bad argument");
#endif
                  iError = EINVAL;
               }
            }
            if (iError == 0)
            {
               MUTEX_ENTER(&pWanDev->DevMutex);
               if (pWanDev->ControlAppli != pAppli)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] CHECK_CARD_STATUS : application has not the control");
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                               pWanDev->ControlAppli->WanDevPtr->Index,
                               pWanDev->ControlAppli->Minor);
#endif
                  MUTEX_EXIT(&pWanDev->DevMutex);
                  iError = EBUSY;
               }
               else
               {
                  /* if we know how to build the card status */
                  if (pWanDev->Rsrc->CheckCardStatus != NULL)
                  {
                     /* remove the poll status timer if active */
                     if (pWanDev->PollTimeout == FALSE && 
                         pWanDev->PollTimer == TRUE)
                     {
                        pWanDev->PollTimer = FALSE;
                        /* release lock before deleting timer */
                        MUTEX_EXIT(&pWanDev->DevMutex);
                        IPH_DEL_TIMER(&pWanDev->StatusPoll);
                        MUTEX_ENTER(&pWanDev->DevMutex);
                     }
                     /* check the card status to find out whether it's */
                     /* running */
                     pWanDev->Status = 
                        pWanDev->Rsrc->CheckCardStatus(NULL, pWanDev);
                     /* if no firmware is running */
                     if (pWanDev->Status == CARD_RESET)
                     {
                        /* reset the status to POST_FAILED to check the */
                        /* POST result again */
                        pWanDev->Status = CARD_POST_FAILED;
                        pWanDev->Status = 
                           pWanDev->Rsrc->CheckCardStatus(NULL, pWanDev);
                     }
                     /* restart polling timer */
                     if (pWanDev->PollTimer == FALSE)
                     {
                        IPH_START_TIMER(&pWanDev->StatusPoll, 
                                        iph_gvITPollStatus, pWanDev,
                                        POLL_STATUS_TIMEOUT);
                        pWanDev->PollTimeout = FALSE;
                        pWanDev->PollTimer = TRUE;
                     }
                  }
                  MyStatus = pWanDev->Status;
                  MUTEX_EXIT(&pWanDev->DevMutex);
                  /* return the current status */
                  PUT_DATA_USER(MyMem.DataPtr, &MyStatus, sizeof(byte),
                                mode, &iError);
                  if (iError != 0)
                  {
                     iError = EFAULT;
                  }
               }
            }
            }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_CHECK_CARD_STATUS not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_GET_CUSTOM_INFO:
         if (AppliType == TYPE_USER)
         {
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size >= CARD_PQ3_CUSTOM_INFO_SIZE && MyMem.DataPtr != NULL)
            {
               GET_DATA_USER(MyMem.DataPtr, &MyCustomInfo, CARD_PQ3_CUSTOM_INFO_SIZE, 
                             mode, &iError);
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] CTL_GET_CUSTOM_INFO failed to copy argument");
#endif
               }
               else
               {

                  if (MyCustomInfo.SerialNum != 0)
                  {
                     /* thanks to the serial number, find the corresponding adapter */
                     MUTEX_ENTER(&gAccessMutex);
                     pTmpDev = (IphWanDevPtr)gWanDevQueue.FirstPtr;
                     while (pTmpDev != (IphWanDevPtr)&gWanDevQueue)
                     {
                        if (pTmpDev->Serial == MyCustomInfo.SerialNum)
                           break;
                        pTmpDev = pTmpDev->NextPtr;
                     }
                     MUTEX_EXIT(&gAccessMutex);

                     if (pTmpDev == (IphWanDevPtr)&gWanDevQueue)
                     {
#ifdef TRACE
                        iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                         (byte *)"[run_ioctl] CTL_GET_CUSTOM_INFO device not found => EINVAL");
#endif
                        pTmpDev = NULL;
                        iError = EINVAL;
                     }
                  }
                  else
                     pTmpDev = pWanDev;

                  if (pTmpDev != NULL)
                  {
                     bcopy(&pTmpDev->CustInfo, &MyCustomInfo.Info, CARD_PQ3_CUSTOM_INFO_SIZE);
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&MyCustomInfo,
                                   sizeof(CustomInfo_t), mode, &iError);
                     if (iError != 0)
                     {
                        iError = EFAULT;
                     }
                  }
                  else
                  {
                     iError = EINVAL;
                  }
               }
            }
            else
            {
               if (iError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] CTL_GET_CUSTOM_INFO bad argument");
#endif
                  iError = EINVAL;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] CTL_GET_CUSTOM_INFO failed to copy argument");
#endif
               }
            }
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_GET_CUSTOM_INFO not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_GET_TIME:
         iError = (int)iph_gdwCtlGetTime(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_SET_HOST_TIME_OFFSET:
         iError = (int)iph_gdwCtlSetHostTimeOffset(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_GET_TEMP_INFO:
         iError = (int)iph_gdwCtlGetTempInfo(pAppli, mode, (MemDesc_t *)arg);
         break;

      case CTL_RESET_BOARD:
         if (pWanDev->Status == CARD_UNAVAILABLE)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] RESET_BOARD: Card is not accessible");
#endif
            iError = ENODEV;
         }
         else if (AppliType == TYPE_USER)
         {
            if (pAppli != pWanDev->ControlAppli)
               iError = EBUSY;
            else
               iError = iph_gdwResetBoard(pWanDev);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_RESET_BOARD not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_DUMP_HOST:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlDumpHostArea(pAppli, mode, 
                                                 (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_DUMP_HOST not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_RESET_HOST_STAT:
         if (AppliType == TYPE_USER)
         {
            iError = (int)iph_gdwCtlResetHostStat(pAppli, mode, 
                                                  (MemDesc_t *)arg);
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[run_ioctl] CTL_RESET_HOST_STAT not allowed => EPERM");
#endif
            iError = EPERM;
         }
         break;

      case CTL_TRACE_CONSOLE_LEVEL:
         if (AppliType == TYPE_USER)
         {
            GET_MEM_DESC(arg, &MyMem, mode, &iError);
            if (iError == 0 &&
                MyMem.Size == sizeof(byte) && MyMem.DataPtr != NULL)
            {
               GET_DATA_USER(MyMem.DataPtr, &level, sizeof(byte),
                             mode, &iError);
               if (iError != 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] TRACE_CONSOLE_LEVEL failed to copy argument");
#endif
               }
            }
            else
            {
               if (iError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] TRACE_CONSOLE_LEVEL bad argument");
#endif
                  iError = EINVAL;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[run_ioctl] TRACE_CONSOLE_LEVEL failed to copy argument");
#endif
               }
            }

            if (iError == 0)
            {
               iph_debug = level;
            }
         }
         else
         {
            pMem = (MemDesc_t *)arg;
            if (pMem == NULL || pMem->Size != sizeof(byte) ||
                pMem->DataPtr == NULL)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[run_ioctl] CTL_TRACE_CONSOLE_LEVEL bad argument => EINVAL");
#endif
               iError = EINVAL;
            }
            else
            {
               level = *(byte *)pMem->DataPtr;
               iph_debug = level;
            }
         }
         break;

      default:
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[run_ioctl] invalid command => EINVAL");
#endif
         iError = EINVAL;
         break;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[run_ioctl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif
   return(iError);
}

/**************************************************************************
* NAME : iph_open
* DESCRIPTION : open entry point
* PARAMETERS :
*    Input   : pointer to inode structure for the device. It contain major and minor 
               information 
*    Input   : ponter to a structure file associated by the system to the device
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          ENOMEM if memory allocation failed
*          EPERM if too many applications are already opened
* REVISION :
*    - Version 1.0 : 05/02/02 Creation
**************************************************************************/
#ifdef LINUX
static int iph_open(struct inode *inodep, struct file *filep)
#endif
#ifdef SOLARIS
static int iph_open(dev_t *devp, int flag, int otyp, cred_t *credp)
#endif
{
   IphWanDevPtr pWanDev;
   ApplCtxtPtr pAppli;
   int minor;
   word uwMinor;
#ifdef SOLARIS
   minor_t iInstance;
#endif

#ifdef LINUX
   /* at this point the minor  defines the device instance */
   minor = MINOR(inodep->i_rdev);

   if (minor >= MAX_CARD)
   {
      iph_TRACEK(TRCLVL_0, "[iph_open] Minor number out of number");
      RETURN_TO_USER(EINVAL);
   }
#endif

#ifdef SOLARIS
   /* at this point the minor  defines the device instance */
   iInstance = getminor(*devp);
   minor = (int)iInstance;
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_open] entry (instance)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, minor);
#endif

#ifdef LINUX
   /* take the pointer to the device context 
    * corresponding to the minor 
    */
   pWanDev = iph_gMinorMap[minor];
#endif
#ifdef SOLARIS
   pWanDev = (IphWanDevPtr)ddi_get_soft_state(gpvState, iInstance);
#endif

   if ( pWanDev == NULL || 
        (pWanDev != NULL && pWanDev->DetachPoint != DP_ALL) )
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_open] no device => ENODEV");
#endif
      RETURN_TO_USER(ENODEV);
   }

#ifdef SOLARIS
   /* checks the otyp value */
   if (otyp != OTYP_CHR)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_open] otyp != OTYP_CHR => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }
#endif

   /* gain protection for global context and single device context*/
   MUTEX_ENTER(&pWanDev->DevMutex);

   /* check whether there are not too many applications */
   if (pWanDev->NbAppli >= pWanDev->MaxAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_open] too many applications => EBUSY");
#endif

      /* release protection */
      MUTEX_EXIT(&pWanDev->DevMutex);

      RETURN_TO_USER(EBUSY);
   }
   MUTEX_EXIT(&pWanDev->DevMutex);

   /* finds a free minor */
   MUTEX_ENTER(&gAccessMutex);
   for (uwMinor = 0; uwMinor < TOTAL_APPLI; uwMinor++)
   {
      if (gpAppliMinor[uwMinor] == (ApplCtxtPtr)0)
         break;
   }
   if (uwMinor == TOTAL_APPLI)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_open] no free minor => EPERM");
#endif

      /* release protection */
      MUTEX_EXIT(&gAccessMutex);

      RETURN_TO_USER(EPERM);
   }

   /* Allocate an application context */
   pAppli = allocAppliCtxt(pWanDev);
   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_open] alloc failed => ENOMEM");
#endif
      /* release protection */
      MUTEX_EXIT(&gAccessMutex);
      RETURN_TO_USER(ENOMEM);
   }

   pAppli->Type = TYPE_USER;
   pAppli->Minor = uwMinor;       /* uwMinor is an index in gpAppliMinor */

   /* get pid of the process calling the open */
#ifdef LINUX
   pAppli->ProcID = current->pid;
#endif
#if defined(SOLARIS) && defined(SOL_7)
   pAppli->ProcID = ddi_get_pid();
#endif
#if defined(SOLARIS) && defined(SOL_6)
   drv_getparm(PPID, (void *)&pAppli->ProcID);
#endif

#ifdef LINUX
   init_waitqueue_head(&pAppli->Pollhead);
#endif

#ifdef LINUX
   /* store in filep->private_data the pointer to the application context */
   filep->private_data = pAppli;
#endif
   /* stores this newly allocated structure in gpAppliMinor */
   gpAppliMinor[uwMinor] = pAppli;
   gwNbAppli++;
   MUTEX_EXIT(&gAccessMutex);

   /* stores this newly allocated structure in the device's UsingAppliQueue */
   MUTEX_ENTER(&pWanDev->DevMutex);
   iph_gvPutQueue(NULL, &pWanDev->UsingAppliQueue, (QueueItemPtr)pAppli);
   pWanDev->NbAppli++;

   if (pWanDev->OpenPrimToDo == TRUE && pWanDev->ControlAppli == (ApplCtxtPtr)0)
   {
      pWanDev->OpenPrimToDo = FALSE;
      MUTEX_EXIT(&pWanDev->DevMutex);
      /* initialize context */
      iph_gdwInitOnLoadEnd(&pWanDev->DevMutex, pWanDev);
   }
   else
   {
      MUTEX_EXIT(&pWanDev->DevMutex);
   }

#ifdef SOLARIS
   *devp = makedevice(getmajor(*devp), uwMinor);
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_open] return OK");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   RETURN_TO_USER(0);
}

/**************************************************************************
* NAME : iph_close
* DESCRIPTION : close entry point
* PARAMETERS :
*    Input   : pointer to inode structure for the device. It contain major and minor 
               information 
*    Input   : ponter to a structure file associated by the system to the device
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          ENOMEM if memory allocation failed
*          EPERM if too many applications are already opened
* REVISION :
*    - Version 1.0 : 05/02/02 Creation
*    - Version 1.01: 10/03/02 
*       -Free, the application context at the end of iph_close
**************************************************************************/
#ifdef LINUX
static int iph_close(struct inode* inodep, struct file *filep)
#endif
#ifdef SOLARIS
static int iph_close(dev_t devp, int flag, int otyp, cred_t *credp)
#endif
{
   int iError = 0;
   ApplCtxtPtr pAppli = NULL;
#ifdef SOLARIS
   minor_t iInstance;
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_close] entry");
#endif

#ifdef LINUX
   if (filep == 0)
   {
      iph_TRACEK(TRCLVL_2, "[iph_close] application has already closed");
      RETURN_TO_USER(EBADF);
   }

   if (filep->private_data == 0)
   {
      iph_TRACEK(TRCLVL_2, "[iph_close] application has already closed"); 
      RETURN_TO_USER(ENODEV);
   }

   pAppli = filep->private_data;
#endif

#ifdef SOLARIS
   /* checks the otyp value */
   if (otyp != OTYP_CHR)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_close] otyp != OTYP_CHR => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }
   iInstance = getminor(devp);
   if (iInstance < TOTAL_APPLI &&
       gpAppliMinor[iInstance] != NULL)
   {
      pAppli = gpAppliMinor[iInstance];
   }
#endif

   if (pAppli != NULL)
   {
#ifdef TRACE
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                   pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

      /* close all session and free memory
       * used by the application
       */
      iError = (int)dwClose(pAppli, NULL, 1);

#ifdef LINUX
      filep->private_data = 0;
#endif
   }
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_close] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif

   RETURN_TO_USER(iError);
}

#ifdef HAVE_UNLOCKED_IOCTL
/* This is just a copy of compat ioctl */
static long iph_unlocked_ioctl(struct file *filep, unsigned int cmd, 
                             unsigned long arg)
{
   ApplCtxtPtr pAppli = NULL;
   int iError = 0;
   int mode = MODE_32;

   /* get application context */
   pAppli = filep->private_data;

   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_compat_ioctl] no application context => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }
   if (pAppli->Status == RESET)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_compat_ioctl] application is RESET => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }

   if (cmd == CTL_DUMP_DRV_TRACE)
   {
      iError = (int)iph_gdwCtlDumpDrvTrace(pAppli, mode, (MemDesc_t *)arg);
      RETURN_TO_USER(iError);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_compat_ioctl] entry Proc ID =");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pAppli->ProcID);
   iph_gvDumpIoctlCmd(cmd);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   iError = run_ioctl(pAppli, cmd, (void *)arg, mode);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_compat_ioctl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif
   RETURN_TO_USER(iError);
}

#else

/**************************************************************************
* NAME : iph_ioctl
* DESCRIPTION : ioctl entry point
* PARAMETERS :
*    Input   : pointer to inode structure for the device. It contain major and minor 
               information 
*    Input   : ponter to a structure file associated by the system to the device
*    Input   : cmd = command type
*    Input   : arg = command argument
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          EBUSY if adapter not available
* REVISION :
*    - Version 1.0: 05/02/2002 creation
**************************************************************************/
#ifdef LINUX
static int iph_ioctl(struct inode *inodep, struct file *filep, 
                     unsigned int cmd, unsigned long arg)
#endif
#ifdef SOLARIS
static int iph_ioctl(dev_t devp, int cmd, intptr_t arg, int mode,
                     cred_t *credp, int *rvalp)
#endif
{
   ApplCtxtPtr pAppli = NULL;
   int iError = 0;
#ifdef LINUX
   int mode = MODE_NONE;
#endif
#ifdef SOLARIS
   minor_t iInstance;
#endif

   /* get application context */
#ifdef LINUX
   pAppli = filep->private_data;
#endif

#ifdef SOLARIS
   iInstance = getminor(devp);
   if (iInstance < TOTAL_APPLI)
   {
      pAppli = gpAppliMinor[iInstance];
   }
#endif

   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_ioctl] no application context => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }
   if (pAppli->Status == RESET)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_ioctl] application is RESET => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }

   if (cmd == CTL_DUMP_DRV_TRACE)
   {
      iError = (int)iph_gdwCtlDumpDrvTrace(pAppli, mode, (MemDesc_t *)arg);
      RETURN_TO_USER(iError);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_ioctl] entry Proc ID =");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pAppli->ProcID);
   iph_gvDumpIoctlCmd(cmd);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   iError = run_ioctl(pAppli, cmd, (void *)arg, mode);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_ioctl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif
   RETURN_TO_USER(iError);
}
#endif


#ifdef CONFIG_COMPAT
/**************************************************************************
* NAME : iph_compat_ioctl
* DESCRIPTION : 32-bit ioctl entry point on 64-bit system
* PARAMETERS :
*    Input   : filep = pointer to a structure file associated by the system 
*                      to the device
*    Input   : cmd = command type
*    Input   : arg = command argument
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          EBUSY if adapter not available
* REVISION :
*    - Version 1.0: 10/05/2007 creation
**************************************************************************/
#ifdef COMPAT_IOCTL
static long iph_compat_ioctl(struct file *filep, unsigned int cmd, 
                             unsigned long arg)
#else
static int iph_compat_ioctl(unsigned int fd, unsigned int cmd, 
                            unsigned long arg, struct file *filep)
#endif
{
   ApplCtxtPtr pAppli = NULL;
   int iError = 0;
   int mode = MODE_32;

   /* get application context */
   pAppli = filep->private_data;

   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_compat_ioctl] no application context => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }
   if (pAppli->Status == RESET)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_compat_ioctl] application is RESET => EINVAL");
#endif
      RETURN_TO_USER(EINVAL);
   }

   if (cmd == CTL_DUMP_DRV_TRACE)
   {
      iError = (int)iph_gdwCtlDumpDrvTrace(pAppli, mode, (MemDesc_t *)arg);
      RETURN_TO_USER(iError);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_compat_ioctl] entry Proc ID =");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pAppli->ProcID);
   iph_gvDumpIoctlCmd(cmd);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   iError = run_ioctl(pAppli, cmd, (void *)arg, mode);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_compat_ioctl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif
   RETURN_TO_USER(iError);
}
#endif

/**************************************************************************
* NAME : iph_chpoll
* DESCRIPTION : chpoll entry point
* PARAMETERS :
*    Input   : pointer to a structure file associated by the system to the device
*    Input   : A poll table corresponding to the all application waiting a event form the
*              driver 
* RETURN : 0 if all is OK
*          ENXIO if the device does not exist
*          EINVAL if one parameter is incorrect
*          EBUSY if adapter not available
* REVISION :
*    - Version 1.0 : 10/21/99 Creation
**************************************************************************/
#ifdef LINUX
static unsigned  int iph_chpoll(struct file *filep, poll_table *waitp)
{
   ApplCtxtPtr pAppli;
   unsigned int retcode = 0;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_chpoll] entry");
#endif

   if (filep == 0)
   {
      printk(KERN_ERR"iph_chpoll file already closed");
      RETURN_TO_USER(0);
   }

   if (filep->private_data == 0)
   {
      printk(KERN_ERR"[iph_chpoll] cannot access application Object");
      RETURN_TO_USER(0);
   }

   pAppli = filep->private_data;

#ifdef TRACE
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif


   /*Add the process to the waiting queue poll_table which is managed
    *by the kernel
    */
   poll_wait(filep, &pAppli->Pollhead, waitp);

   /* If there are a data ready to read, return the appropriate value */
#if 0
   if (pAppli->RecvQueue.FirstPtr != (QueueItemPtr)&pAppli->RecvQueue)
#endif
   if (pAppli->RecvNb > 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                       (byte *)"[iph_chpoll] pending event for this application");
#endif
      retcode = POLLIN | POLLRDNORM;
   }
   else
   {
      if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_chpoll] Card is not available");
#endif
         retcode = POLLERR;
      }
      if (pAppli->WanDevPtr->Status == CARD_WATCHDOG)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_chpoll] WATCHDOG expired => ENXIO");
#endif
         retcode = POLLERR;
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_chpoll] return OK");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, retcode);
#endif
   RETURN_TO_USER(retcode);
}
#endif

#ifdef SOLARIS
static int iph_chpoll(dev_t devp, short events, int anyyet, short *reventsp,
                      struct pollhead **phpp)
{
   minor_t iInstance;
   ApplCtxtPtr pAppli;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_chpoll] entry");
#endif

   iInstance = getminor(devp);

   /* check whether the application is not closing */
   if (iInstance >= TOTAL_APPLI ||
       gpAppliMinor[iInstance] == (ApplCtxtPtr)0 ||
       gpAppliMinor[iInstance]->Status == RESET)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iph_chpoll] no application context => ENXIO");
#endif
      RETURN_TO_USER(ENXIO);
   }

   pAppli = gpAppliMinor[iInstance];

#ifdef TRACE
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   *reventsp = 0;
   if (pAppli->RecvQueue.FirstPtr != (QueueItemPtr)&pAppli->RecvQueue)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                       (byte *)"[iph_chpoll] pending event for this application");
#endif
      *reventsp |= POLLRDBAND;
   }
   else
   {
      if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_chpoll] Card is not available => ENODEV");
#endif
         RETURN_TO_USER(ENODEV);
      }
      if (pAppli->WanDevPtr->Status == CARD_WATCHDOG)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_chpoll] WATCHDOG expired => ENXIO");
#endif
         RETURN_TO_USER(ENXIO);
      }

      if (anyyet == 0)
         *phpp = &pAppli->Pollhead;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_chpoll] return OK");
#endif
   RETURN_TO_USER(0);
}
#endif

#ifdef IPH_API_KERNEL
/**************************************************************************
* NAME : drv_kernel_open
* DESCRIPTION : kernel open entry point
* PARAMETERS :
*    Input   : serial = serial number
*    Input   : wakeup_ptr = kd_wakeup callback pointer
*    Input   : free_ptr = kd_free callback pointer
*    Input   : backref_ptr = backward reference
*    Output  : app_id_ptr = pointer where to return the application id
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect (the serial for instance)
*          ENOMEM if memory allocation failed
*          EPERM if too many applications are already opened
*          EBUSY if adapter not available (reset, firmware not loaded)
* REVISION :
*    - Version 1.0 : 06/17/02 Creation
*    - Version 1.21 : returns positive error code instead of negative
**************************************************************************/
static dword drv_kernel_open(dword serial, void (*wakeup_ptr)(void *, word), 
                             void (*free_ptr)(void *, word, byte, void *),
                             void *backref_ptr, word *app_id_ptr)
{
   IphWanDevPtr pWanDev;
   word uwMinor;
   ApplCtxtPtr pAppli;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_open] entry (serial)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, serial);
#endif

   /* thanks to the serial number, find the corresponding adapter */
   MUTEX_ENTER(&gAccessMutex);
   pWanDev = (IphWanDevPtr)gWanDevQueue.FirstPtr;
   while (pWanDev != (IphWanDevPtr)&gWanDevQueue)
   {
      if (pWanDev->Serial == serial)
         break;
      pWanDev = pWanDev->NextPtr;
   }
   MUTEX_EXIT(&gAccessMutex);

   if (pWanDev == (IphWanDevPtr)&gWanDevQueue)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_open] device not found => EINVAL");
#endif
      return(EINVAL);
   }

   /* check whether the device is ready */
   if (pWanDev->Status != CARD_RUNNING &&
       pWanDev->Status != CARD_LOADED)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_open] device not ready => EBUSY");
#endif
      return(EBUSY);
   }

   /* gain protection */
   MUTEX_ENTER(&gAccessMutex);
   MUTEX_ENTER(&pWanDev->DevMutex);

   /* check whether there are not too many applications */
   if (pWanDev->NbAppli >= pWanDev->MaxAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_open] too many applications => EPERM");
#endif

      /* release protection */
      MUTEX_EXIT(&pWanDev->DevMutex);
      MUTEX_EXIT(&gAccessMutex);

      return(EPERM);
   }

   /* find a free minor */
   for (uwMinor = 0; uwMinor < TOTAL_APPLI; uwMinor++)
   {
      if (gpAppliMinor[uwMinor] == (ApplCtxtPtr)0)
      {
         break;
      }
   }

   if (uwMinor == TOTAL_APPLI)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_open] no free minor => EPERM");
#endif
      /* release protection */
      MUTEX_EXIT(&pWanDev->DevMutex);
      MUTEX_EXIT(&gAccessMutex);

      return(EPERM);
   }

   /* Allocate an application context */
   pAppli = allocAppliCtxt(pWanDev);
   if (pAppli == NULL)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_open] alloc failed => ENOMEM");
#endif
      /* release protection */
      MUTEX_EXIT(&pWanDev->DevMutex);
      MUTEX_EXIT(&gAccessMutex);
      return(ENOMEM);
   }
   pAppli->Minor = uwMinor;       /* uwMinor is an index in gpAppliMinor */
   pAppli->Type = TYPE_KERNEL;
   pAppli->kd_wakeup = wakeup_ptr;
   pAppli->kd_free = free_ptr;
   pAppli->Backref = backref_ptr;

   /* stores this newly allocated structure in gpAppliMinor and the device's*/
   /* UsingAppliQueue */
   gpAppliMinor[uwMinor] = pAppli;
   gwNbAppli++;
   iph_gvPutQueue(NULL, &pWanDev->UsingAppliQueue, (QueueItemPtr)pAppli);
   pWanDev->NbAppli++;

   if (pWanDev->OpenPrimToDo == TRUE && pWanDev->ControlAppli == (ApplCtxtPtr)0)
   {
      /* initialize context */
      iph_gdwInitOnLoadEnd(NULL, pWanDev);
      pWanDev->OpenPrimToDo = FALSE;
   }

   MUTEX_EXIT(&pWanDev->DevMutex);
   MUTEX_EXIT(&gAccessMutex);

   *app_id_ptr = uwMinor;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_open] return OK");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   return(0);
}

/**************************************************************************
* NAME : drv_kernel_close
* DESCRIPTION : kernel close entry point
* PARAMETERS :
*    Input   : app_id = application identifier
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*     - Version 1.0 : 06/17/02 Creation
*     - Version 1.21 : returns positive error code instead of negative
**************************************************************************/
static dword drv_kernel_close(word app_id)
{
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_close] entry");
#endif

   dwError = EINVAL;

   if (app_id != NO_APP_ID && app_id < TOTAL_APPLI &&
       gpAppliMinor[app_id] != (ApplCtxtPtr)0)
   {
#ifdef TRACE
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                   gpAppliMinor[app_id]->WanDevPtr->Index, 
                   gpAppliMinor[app_id]->Minor);
#endif
      dwError = dwClose(gpAppliMinor[app_id], NULL, 1);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_close] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

   return(dwError);
}

/**************************************************************************
* NAME : drv_kernel_ioctl
* DESCRIPTION : kernel ioctl entry point
* PARAMETERS :
*    Input   : app_id = application identifier
*    Input   : cmd_type = command type
*    Input   : arg = command argument
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if adapter not available
*          EAGAIN if primitive not sent because of missing DMA descriptors
*          EPERM if request not available for a kernel application
* REVISION :
*   - Version 1.0 : 06/17/02 Creation
*   - Version 1.21 : returns positive error code instead of negative
**************************************************************************/
static dword drv_kernel_ioctl(word app_id, dword cmd_type, void *arg)
{
   ApplCtxtPtr pAppli = NULL;
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_ioctl] entry (app_id)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, app_id);
   iph_gvDumpIoctlCmd(cmd_type);
#endif

   if (app_id != NO_APP_ID)
   {
      if (app_id >= TOTAL_APPLI ||
          gpAppliMinor[app_id] == (ApplCtxtPtr)0 ||
          gpAppliMinor[app_id]->Status == RESET)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[kernel_ioctl] no application context => EINVAL");
#endif
         return(EINVAL);
      }

      pAppli = gpAppliMinor[app_id];
      if (pAppli->WanDevPtr == (IphWanDevPtr)0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[kernel_ioctl] no device context => EINVAL");
#endif
         return(EINVAL);
      }
#ifdef TRACE
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                   pAppli->WanDevPtr->Index, pAppli->Minor);
#endif
   }
   else
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[kernel_ioctl] for NO_APP_ID");
#endif
   }

   dwError = run_ioctl(pAppli, cmd_type, arg, 0);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[kernel_ioctl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

#endif


#ifdef LINUX
/**************************************************************************
* NAME : iph_attach_pex
* DESCRIPTION : attach the PEX device
* PARAMETERS :
*    Input   : pDev= point to the adapter driver context
*    Input   : dev = point to a strucur pci_dev allocated by the kernel
* RETURN : 0 if all is OK else an error code 
* REVISION :
*    - Version 1.0 : 02/23/09 Creation
**************************************************************************/
static int iph_attach_pex(IphWanDevPtr pDev, struct pci_dev *dev)
{
   dword regVal;

   strcpy(pDev->Region[BRIDGE_REGION].Name,"Bridge Registers");
   pDev->Region[BRIDGE_REGION].HostBaseAddr = pci_resource_start(dev,0);
   pDev->Region[BRIDGE_REGION].WinSize      = pci_resource_len(dev,0);
   pDev->Region[BRIDGE_REGION].WinLimit     = 
      pDev->Region[BRIDGE_REGION].WinSize - 1;
   pDev->Region[BRIDGE_REGION].WinMask      = 
      ~(pDev->Region[BRIDGE_REGION].WinSize - 1);
   pDev->Region[BRIDGE_REGION].CurWin       = 0xFFFFFFFF;
   pDev->Region[BRIDGE_REGION].MaxSize      = pci_resource_len(dev,0);
   pDev->Region[BRIDGE_REGION].WinShift     = 0;
   pDev->Region[BRIDGE_REGION].CardBaseAddr = 0;
   pDev->Region[BRIDGE_REGION].Ops.read32   = generic_read32;
   pDev->Region[BRIDGE_REGION].Ops.write32  = generic_write32;
   pDev->Region[BRIDGE_REGION].Ops.read16   = generic_nopsr16;
   pDev->Region[BRIDGE_REGION].Ops.write16  = generic_nopsw16;
   pDev->Region[BRIDGE_REGION].Ops.read8    = generic_nopsr8;
   pDev->Region[BRIDGE_REGION].Ops.write8   = generic_nopsw8;
   pDev->Region[BRIDGE_REGION].Ops.readbuf  = generic_nopsrbuf;
   pDev->Region[BRIDGE_REGION].Ops.writebuf = generic_nopswbuf;

   pDev->Region[BRIDGE_REGION].Mapped       = ioremap(pDev->Region[BRIDGE_REGION].HostBaseAddr, 
                                                      pDev->Region[BRIDGE_REGION].WinSize);
   if (pDev->Region[BRIDGE_REGION].Mapped == 0)
   {
      iph_gMinorMap[pDev->Index] = 0;
      iph_detach_device(pDev);
      return(-ENOMEM);
   }

   pDev->sDev.iDev = dev;

   /* Check whether it is an Interphase Card */
   pDev->Region[BRIDGE_REGION].Ops.read32(&pDev->Region[BRIDGE_REGION],
                                          PEX811X_MAILBOX3,
                                          &regVal);
   regVal = PCI_SWAP32(regVal);
   if ((regVal & 0x0000FFFF) != CARD_3639_DID &&
       (regVal & 0x0000FFFF) != CARD_5639_DID &&
       (regVal & 0x0000FFFF) != CARD_5639E_DID &&
       (regVal & 0x0000FFFF) != CARD_5639L_DID)
   {
      iph_TRACEK(TRCLVL_0,  " found a PEX but not a supported device (0x%x)", regVal);
      iph_gMinorMap[pDev->Index] = 0;
      iph_detach_device(pDev);
      return(-ENODEV);
   }

   pDev->Region[BRIDGE_REGION].Index = BRIDGE_REGION;
   pDev->Region[BRIDGE_REGION].BigEnd = FALSE;
   pDev->Region[BRIDGE_REGION].ProtAccess = FALSE;
   /*MUTEX_INIT(pDev->Region[BRIDGE_REGION].Access, 1, "Bridge");*/
   pDev->Region[BRIDGE_REGION].Priv = pDev;
   /* associate device context to the pci_dev structure */
   pci_set_drvdata(dev, pDev);
   pDev->DetachPoint = DP_PCI_REGISTERS_MAPPED; 

   return(0);
}

/**************************************************************************
* NAME : iph_attach
* DESCRIPTION : attach entry point
* PARAMETERS :
*    Input   : dev = point to a strucur pci_dev allocated by the kernel
*    Input   : id  = Id of the Wan  pci adapter 
* RETURN : 0 if all is OK else an error code 
* REVISION :
*    - Version 1.0 : 04/30/02 Creation
**************************************************************************/
static int iph_attach(struct pci_dev *dev, const struct pci_device_id *id)
{
   IphWanDevPtr pDev;
   int iError = 0;
   byte PCIConf[MAX_PCI_CONF];
   dword regVal;
   word wCount;
   int cr;

   /*
    * Dialogic copyright banner.
    */
   printk("DSI SS7MD Release %d.%d.%d (Build %d)\n", 
    PRODUCT_MAJREV, PRODUCT_MINREV, PRODUCT_SPKREV, PRODUCT_BLDREV);

   printk("Part of the Dialogic(R) %s\n", PRODUCT_BUILDSTR);

   if (COPYRIGHT_BEGIN == PRODUCT_COPYRIGHT)
   {
     printk("Copyright (C) Dialogic Corporation %d. All Rights Reserved.\n", COPYRIGHT_BEGIN);
   }
   else
   {
     printk("Copyright (C) Dialogic Corporation %d-%d. All Rights Reserved.\n", COPYRIGHT_BEGIN, PRODUCT_COPYRIGHT);
   }


   if (pci_enable_device(dev))
   {
      iph_TRACEK(TRCLVL_0, "error enabling pci device %p\n", dev);
      return(-EIO);
   }

   /* Force the PCI bus master capability */
   pci_set_master(dev);

   /* read all the PCI registers content */
   /* ATTENTION: the pci_config_word routines perform swapping from */
   /* PCI Little Endian to native host format */
   memset(PCIConf, 0, MAX_PCI_CONF);
   READ_PCI_CONF_WORD(dev, VID_INDX, &PCIConf[VID_INDX]);
   READ_PCI_CONF_WORD(dev, DID_INDX, &PCIConf[DID_INDX]);
   READ_PCI_CONF_WORD(dev, PCICMD_INDX, &PCIConf[PCICMD_INDX]);
   READ_PCI_CONF_WORD(dev, PCISTS_INDX, &PCIConf[PCISTS_INDX]);
   READ_PCI_CONF_BYTE(dev, RID_INDX, &PCIConf[RID_INDX]);
   READ_PCI_CONF_BYTE(dev, CLDEV_INDX, &PCIConf[CLDEV_INDX]);
   READ_PCI_CONF_BYTE(dev, CALN_INDX, &PCIConf[CALN_INDX]);
   READ_PCI_CONF_BYTE(dev, LAT_INDX, &PCIConf[LAT_INDX]);
   READ_PCI_CONF_BYTE(dev, HDR_INDX, &PCIConf[HDR_INDX]);
   READ_PCI_CONF_BYTE(dev, BIST_INDX, &PCIConf[BIST_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR0_INDX, &PCIConf[BADDR0_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR1_INDX, &PCIConf[BADDR1_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR2_INDX, &PCIConf[BADDR2_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR3_INDX, &PCIConf[BADDR3_INDX]);
   READ_PCI_CONF_WORD(dev, SUBVID_INDX, &PCIConf[SUBVID_INDX]);
   READ_PCI_CONF_WORD(dev, SUBSYS_INDX, &PCIConf[SUBSYS_INDX]);
   READ_PCI_CONF_BYTE(dev, INTLN_INDX, &PCIConf[INTLN_INDX]);
   READ_PCI_CONF_BYTE(dev, INTPIN_INDX, &PCIConf[INTPIN_INDX]);
   READ_PCI_CONF_BYTE(dev, MINGNT_INDX, &PCIConf[MINGNT_INDX]);
   READ_PCI_CONF_BYTE(dev, MAXLAT_INDX, &PCIConf[MAXLAT_INDX]);

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_1, "IPHPQ3 [iph_attach]: irq=%d\n", dev->irq);
   iph_TRACEK(TRCLVL_1, "IPHPQ3 [iph_attach]: Content of PCI configuration space :\n");
   iph_TRACEK(TRCLVL_1, " VID    %02x : 0x%x", 
              VID_INDX, *(word *)&PCIConf[VID_INDX]);
   iph_TRACEK(TRCLVL_1, " DID    %02x : 0x%x", 
              DID_INDX, *(word *)&PCIConf[DID_INDX]);
   iph_TRACEK(TRCLVL_1, " PCICMD %02x : 0x%x", 
              PCICMD_INDX, *(word *)&PCIConf[PCICMD_INDX]);
   iph_TRACEK(TRCLVL_1, " PCISTS %02x : 0x%x", 
              PCISTS_INDX, *(word *)&PCIConf[PCISTS_INDX]);
   iph_TRACEK(TRCLVL_1, " RID    %02x : 0x%x", 
              RID_INDX, PCIConf[RID_INDX]);
   iph_TRACEK(TRCLVL_1, " CLDEV  %02x : 0x%x", 
              CLDEV_INDX, PCIConf[CLDEV_INDX]);
   iph_TRACEK(TRCLVL_1, " CALN   %02x : 0x%x", 
              CALN_INDX, PCIConf[CALN_INDX]);
   iph_TRACEK(TRCLVL_1, " LAT    %02x : 0x%x", 
              LAT_INDX, PCIConf[LAT_INDX]);
   iph_TRACEK(TRCLVL_1, " HDR    %02x : 0x%x", 
              HDR_INDX, PCIConf[HDR_INDX]);
   iph_TRACEK(TRCLVL_1, " BIST   %02x : 0x%x", 
              BIST_INDX, PCIConf[BIST_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR0 %02x : 0x%x", 
              BADDR0_INDX, *(dword *)&PCIConf[BADDR0_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR1 %02x : 0x%x", 
              BADDR1_INDX, *(dword *)&PCIConf[BADDR1_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR2 %02x : 0x%x", 
              BADDR2_INDX, *(dword *)&PCIConf[BADDR2_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR3 %02x : 0x%x", 
              BADDR3_INDX, *(dword *)&PCIConf[BADDR3_INDX]);
   iph_TRACEK(TRCLVL_1, " SUBVID %02x : 0x%x", 
              SUBVID_INDX, *(word *)&PCIConf[SUBVID_INDX]);
   iph_TRACEK(TRCLVL_1, " SUBSYS %02x : 0x%x", 
              SUBSYS_INDX, *(word *)&PCIConf[SUBSYS_INDX]);
   iph_TRACEK(TRCLVL_1, " INTLN  %02x : 0x%x", 
              INTLN_INDX, PCIConf[INTLN_INDX]);
   iph_TRACEK(TRCLVL_1, " INTPIN %02x : 0x%x", 
              INTPIN_INDX, PCIConf[INTPIN_INDX]);
   iph_TRACEK(TRCLVL_1, " MINGNT %02x : 0x%x", 
              MINGNT_INDX, PCIConf[MINGNT_INDX]);
   iph_TRACEK(TRCLVL_1, " MAXLAT %02x : 0x%x", 
              MAXLAT_INDX, PCIConf[MAXLAT_INDX]);
#endif

   switch (*(u16 *)&PCIConf[DID_INDX])
   {
      case IPH_3639_PCI_ID:
#ifdef LINUX_2_4
         if (allocDevCtxt(dev, &pDev) != 0)
         {
            return(-ENOMEM);
         }
         pDev->DetachPoint = DP_CTX_ALLOCATED;
         wCount = pDev->Index;

         if ( (cr=iph_attach_pex(pDev, dev->bus->self)) != 0)
            return(cr);
#else /* LINUX_2_4 */
         for (wCount = 0; wCount < MAX_CARD; wCount++)
         {
            if (iph_gMinorMap[wCount] != (IphWanDevPtr)NULL &&
                iph_gMinorMap[wCount]->sDev.iDev->subordinate == dev->bus)
            {
               break;
            }
         }
         if (wCount == MAX_CARD)
            return(-ENODEV);
         pDev = (IphWanDevPtr)iph_gMinorMap[wCount]; 
#endif

         /* copy the PCI configuration data */
         memcpy(pDev->PCIConf, PCIConf, MAX_PCI_CONF);

         /* new initialize resource region*/
         /* BAR 0 access to Core register*/
         strcpy(pDev->Region[CORE_REGION].Name,"Core Registers"); 
         pDev->Region[CORE_REGION].HostBaseAddr   = pci_resource_start(dev,0);
         pDev->Region[CORE_REGION].WinSize        = pci_resource_len(dev,0);
         pDev->Region[CORE_REGION].WinLimit       = 
            pDev->Region[CORE_REGION].WinSize - 1;
         pDev->Region[CORE_REGION].WinMask        = 
            ~(pDev->Region[CORE_REGION].WinSize - 1);
         pDev->Region[CORE_REGION].CurWin         = 0xFFFFFFFF;
         pDev->Region[CORE_REGION].MaxSize        = 0x100000;
         pDev->Region[CORE_REGION].WinShift       = 0;
         pDev->Region[CORE_REGION].CardBaseAddr   = 0xd8000000;
         pDev->Region[CORE_REGION].Cfg            =  0;
         pDev->Region[CORE_REGION].Ops.read32     = generic_read32;
         pDev->Region[CORE_REGION].Ops.write32    = generic_write32;           
         pDev->Region[CORE_REGION].Ops.read16     = generic_read16;
         pDev->Region[CORE_REGION].Ops.write16    = generic_write16;
         pDev->Region[CORE_REGION].Ops.read8      = generic_read8;
         pDev->Region[CORE_REGION].Ops.write8     = generic_write8;
         pDev->Region[CORE_REGION].Ops.readbuf    = generic_nopsrbuf;
         pDev->Region[CORE_REGION].Ops.writebuf   = generic_nopswbuf;
         pDev->Region[CORE_REGION].Mapped = 
            ioremap(pDev->Region[CORE_REGION].HostBaseAddr, 
                    pDev->Region[CORE_REGION].WinSize);
         if (pDev->Region[CORE_REGION].Mapped == 0)
         {
            iph_TRACEK(TRCLVL_0,  " Error mapping CORE_REGION");
            iph_gMinorMap[wCount] = 0;
#ifdef LINUX_2_4
            iph_detach_device(pDev);
#endif
            return(-ENOMEM);
         }
         pDev->Region[CORE_REGION].Priv = pDev;
         pDev->Region[CORE_REGION].Index = CORE_REGION;
         pDev->Region[CORE_REGION].BigEnd = TRUE;
         pDev->Region[CORE_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[CORE_REGION].Access, 1, "Core");*/

         /* Check whether it is an Interphase Card */
         pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],
                                              CARD_MPC856X_REG_ID,
                                              &regVal);

         regVal = HOST_CORE32(regVal);

         if ((regVal & 0x0000FFFF) != CARD_3639_DID &&
             (regVal & 0x0000FFFF) != CARD_5639_DID &&
             (regVal & 0x0000FFFF) != CARD_5639E_DID &&
             (regVal & 0x0000FFFF) != CARD_5639L_DID)
         {
            iph_TRACEK(TRCLVL_0,  " found a MPC856X but not a supported device. Skip it (0x%08x)", regVal);
            iph_gMinorMap[pDev->Index] = 0;
#ifdef LINUX_2_4
            iph_detach_device(pDev);
#endif
            return(-ENODEV);
         }

         pDev->Type  = (regVal & 0x0000FFFF);

         strcpy(pDev->Region[FLASH_REGION].Name,"Flash memory"); 
         pDev->Region[FLASH_REGION].HostBaseAddr = pci_resource_start(dev,1);
         pDev->Region[FLASH_REGION].WinSize      = pci_resource_len(dev,1);
         pDev->Region[FLASH_REGION].WinLimit     = 
            pDev->Region[FLASH_REGION].WinSize - 1;
         pDev->Region[FLASH_REGION].WinMask      = 
            ~(pDev->Region[FLASH_REGION].WinSize - 1);
         pDev->Region[FLASH_REGION].CurWin       = 0xFFFFFFFF;
         pDev->Region[FLASH_REGION].MaxSize      = 0x1000000;
         pDev->Region[FLASH_REGION].WinShift     = 12;
         pDev->Region[FLASH_REGION].Cfg          = MPC856X_PITAR1;
         pDev->Region[FLASH_REGION].Ops.read16   = generic_nopsr16;
         pDev->Region[FLASH_REGION].Ops.write16  = generic_nopsw16;
         pDev->Region[FLASH_REGION].Ops.read32   = generic_nopsr32;
         pDev->Region[FLASH_REGION].Ops.write32  = generic_nopsw32;
         pDev->Region[FLASH_REGION].Ops.read8    = generic_read8;
         pDev->Region[FLASH_REGION].Ops.write8   = generic_write8;
         pDev->Region[FLASH_REGION].Ops.readbuf  = generic_readbuf;
         pDev->Region[FLASH_REGION].Ops.writebuf = generic_nopswbuf;
         pDev->Region[FLASH_REGION].Ops.moveWindow = MovePQ3Window;
         pDev->Region[FLASH_REGION].Mapped = 
            ioremap(pDev->Region[FLASH_REGION].HostBaseAddr, 
                    pDev->Region[FLASH_REGION].WinSize);
         if (pDev->Region[FLASH_REGION].Mapped == 0)
         {
            iounmap((void *)pDev->Region[CORE_REGION].Mapped);
            pDev->Region[CORE_REGION].Mapped = 0;
            iph_TRACEK(TRCLVL_0,  " Error mapping FLASH_REGION");
            iph_gMinorMap[wCount] = 0;
#ifdef LINUX_2_4
            iph_detach_device(pDev);
#endif
            return(-ENOMEM);
         }
         pDev->Region[FLASH_REGION].Priv = pDev;
         pDev->Region[FLASH_REGION].Index = FLASH_REGION;
         pDev->Region[FLASH_REGION].BigEnd = TRUE;
         pDev->Region[FLASH_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[FLASH_REGION].Access, 1, "Flash");*/


         strcpy(pDev->Region[MEM_REGION].Name,"Main memory"); 
         pDev->Region[MEM_REGION].HostBaseAddr = pci_resource_start(dev,2);
         pDev->Region[MEM_REGION].WinSize      = pci_resource_len(dev,2);
         pDev->Region[MEM_REGION].WinLimit     = 
            pDev->Region[MEM_REGION].WinSize - 1;
         pDev->Region[MEM_REGION].WinMask      = 
            ~(pDev->Region[MEM_REGION].WinSize - 1);
         pDev->Region[MEM_REGION].CurWin       = 0xFFFFFFFF;
         pDev->Region[MEM_REGION].MaxSize      = 0x8000000;
         pDev->Region[MEM_REGION].WinShift     = 12;
         pDev->Region[MEM_REGION].CardBaseAddr = 0;
         pDev->Region[MEM_REGION].Cfg          = MPC856X_PITAR2;
         pDev->Region[MEM_REGION].Ops.read16   = generic_read16;
         pDev->Region[MEM_REGION].Ops.write16  = generic_write16;
         pDev->Region[MEM_REGION].Ops.read32   = generic_read32;
         pDev->Region[MEM_REGION].Ops.write32  = generic_write32;
         pDev->Region[MEM_REGION].Ops.read8    = generic_read8;
         pDev->Region[MEM_REGION].Ops.write8   = generic_write8;
         pDev->Region[MEM_REGION].Ops.readbuf  = generic_readbuf;
         pDev->Region[MEM_REGION].Ops.writebuf = generic_writebuf;
         pDev->Region[MEM_REGION].Ops.moveWindow = MovePQ3Window;
         pDev->Region[MEM_REGION].Mapped = 
            ioremap(pDev->Region[MEM_REGION].HostBaseAddr, 
                    pDev->Region[MEM_REGION].WinSize);
         if (pDev->Region[MEM_REGION].Mapped == 0)
         {
            iounmap((void *)pDev->Region[CORE_REGION].Mapped);
            pDev->Region[CORE_REGION].Mapped = 0;
            iounmap((void *)pDev->Region[FLASH_REGION].Mapped);
            pDev->Region[FLASH_REGION].Mapped = 0;
            iph_TRACEK(TRCLVL_0,  " Error mapping MEM_REGION");
            iph_gMinorMap[wCount] = 0;
#ifdef LINUX_2_4
            iph_detach_device(pDev);
#endif
            return(-ENOMEM);
         }
         pDev->Region[MEM_REGION].Index = MEM_REGION;
         pDev->Region[MEM_REGION].BigEnd = TRUE;
         pDev->Region[MEM_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[MEM_REGION].Access, 1, "Mem");*/
         pDev->Region[MEM_REGION].Priv = pDev;

         pDev->DetachPoint = DP_PCI_REGISTERS_MAPPED;

         /* complete attach */
         pDev->sDev.Dev = dev;
         iError = iph_attach_device(pDev);

         /* associate device context to the pci_dev structure */
         if (iError == 0)
         {
            pci_set_drvdata(dev, pDev);
            pDev->DetachPoint = DP_ALL;
            iph_gbAttachedCard++;
         }
         else 
         {
            iph_gMinorMap[pDev->Index] = 0;
            iph_detach_device(pDev);
            return(-ENODEV);
         }

         break;

      case IPH_PEX1_PCI_ID:
      case IPH_PEX2_PCI_ID:

         if (allocDevCtxt(dev, &pDev) != 0)
         {
            return(-ENOMEM);
         }
         pDev->DetachPoint = DP_CTX_ALLOCATED;

         if ( (cr=iph_attach_pex(pDev, dev)) != 0)
            return(cr);


         return(0);

      default:
         return(-ENODEV);


   }

   return(iError);
}

/**************************************************************************
* NAME : iph_detach
* DESCRIPTION : detach entry point
* PARAMETERS :
*    Input   : dev = device information structure
* RETURN : DDI_SUCCESS if all is OK, DDI_FAILURE else
* REVISION :
*    - Version 1.0 : 05/04/02 Creation
**************************************************************************/
static void iph_detach(struct pci_dev *dev)
{
   IphWanDevPtr pDev;
   int devIndex;

   /* get the pointer to the context of the device */
   pDev =  pci_get_drvdata(dev); 

   if (pDev == 0)
   {
      return;
   }
   if (pDev->Index >= MAX_CARD)
   {
      iph_TRACEK(TRCLVL_0, "device out of range during detach");
      return;
   }
   iph_TRACEK(TRCLVL_1, "iph_detach for dev %08x - index %d - Dev=%08x - iDev=%08x", (dword)(unsigned long)dev, pDev->Index, (dword)(unsigned long)pDev->sDev.Dev, (dword)(unsigned long)pDev->sDev.iDev);

   devIndex = pDev->Index;
#ifdef LINUX_2_4
   iph_gMinorMap[devIndex] = 0;
#endif
   iph_detach_device(pDev);
#ifndef LINUX_2_4
   iph_gMinorMap[devIndex] = 0;
#endif

   return;
}

#ifdef SEQ_PROC
/**************************************************************************
* NAME : iph_proc_start/iph_proc_stop/iph_proc_next
* DESCRIPTION :  proc/iphwae file management
* PARAMETERS :
*    Input   : 
* RETURN :  
* REVISION :
*    - Version 1.0 : 02/03/06 Creation
**************************************************************************/
static void *iph_proc_start(struct seq_file *sq, loff_t *pos)
{
   return(*pos < 1 ? (void *)1 : NULL);
}

static void iph_proc_stop(struct seq_file *sq, void *v)
{
}

static void *iph_proc_next(struct seq_file *sq, void *v, loff_t *pos)
{
   return NULL;
}

/**************************************************************************
* NAME : iph_proc_show
* DESCRIPTION :  Provides information via proc file eg : cat /proc/iphwae
* PARAMETERS :
*    Input   : 
* RETURN : 0
* REVISION :
*    - Version 1.0 : 02/03/06 Creation
**************************************************************************/
#ifdef IPH_PERF_PROC_INFO 
#define PRINT_VARIABLE(desc, item)                                      \
   iph_TRACEK(TRCLVL_1,                                                 \
               "    " desc "(" #item "): %d",                           \
               iph_gMinorMap[i]->item                                   \
             );

#endif
static int iph_proc_show(struct seq_file *p, void *v)
{
   char *tmp;
   int NbrCard = 0;
   short i, j, k;
   int CustomInfoFound;
   IphWanDevPtr pDev;

   seq_printf(p, "Interphase base driver Version "_VERSION_" :\n");

   for (i = 0; i < MAX_CARD; i++)
   {
      pDev = (IphWanDevPtr)iph_gMinorMap[i]; 
      if (pDev != 0 && pDev->DetachPoint == DP_ALL )
      {
         NbrCard++;
      }
   }

   seq_printf(p, "Number of supported Interphase card detected= %d\n\n", (NbrCard));

   for (i = 0; i < MAX_CARD; i++)
   {
      pDev = (IphWanDevPtr)iph_gMinorMap[i];      
      if (pDev != 0 && pDev->DetachPoint == DP_ALL)
      {
         seq_printf(p, "Card %d - %s\n", 
                    i, iph_gMinorMap[i]->Rsrc->CardName);
         seq_printf(p, "PCI Bridge location: %s\n",
                    pci_name(iph_gMinorMap[i]->sDev.iDev));
         seq_printf(p, "Power PC   location: %s\n",
                    pci_name(iph_gMinorMap[i]->sDev.Dev));
         seq_printf(p, "Resource list:\n");
         for (j = 0; j < MAX_REGION; j++)
         {
            if (iph_gMinorMap[i]->Region[j].Mapped)
            {
               seq_printf(p, 
                          "    Region name   : %s\n", 
                          iph_gMinorMap[i]->Region[j].Name);
               seq_printf(p,
                          "      HostAddr    : %08x\n", 
                          iph_gMinorMap[i]->Region[j].HostBaseAddr);
               seq_printf(p,
                          "      Mapped at   : %p\n", 
                          iph_gMinorMap[i]->Region[j].Mapped);
               seq_printf(p,
                          "      WinSize     : %08d  (MaxSize %08d)\n", 
                          iph_gMinorMap[i]->Region[j].WinSize, 
                          iph_gMinorMap[i]->Region[j].MaxSize);
            }
         }
         seq_printf(p, 
                    "Serial number: %d\n", 
                    iph_gMinorMap[i]->Serial);
         /* Display the customer information if available */
         CustomInfoFound = 0;
         if ( iph_gMinorMap[i]->CustInfo[0] != 0 )
         {
            for ( k=1; k<CARD_PQ3_CUSTOM_INFO_SIZE; k++ )
            {
               if ( iph_gMinorMap[i]->CustInfo[k] == 0 )
               {
                  CustomInfoFound = 1;
                  break;
               }
            }
         }
         if ( CustomInfoFound )
         {
            seq_printf(p, 
                       "Custom information: %s\n", 
                       iph_gMinorMap[i]->CustInfo);
         }

         seq_printf(p,
                    "Revision number: %d\n", 
                    iph_gMinorMap[i]->Rsrc->BoardRevisionId);

         switch (iph_gMinorMap[i]->Status)
         {
            case CARD_POST_FAILED: tmp = "CARD_POST_FAILED"; break;
            case CARD_RESET: tmp = "CARD_RESET"; break;
            case CARD_WATCHDOG: tmp = "CARD_WATCHDOG"; break;
            case CARD_LOADED: tmp = "CARD_LOADED"; break;
            case CARD_RUNNING: tmp = "CARD_RUNNING"; break;
            case CARD_RESETTING: tmp = "CARD_RESETTING"; break;
            default: tmp = "Invalid"; break;
         }
         iph_TRACEK(TRCLVL_2, "Status: %s\n", tmp);
#ifdef IPH_PERF_PROC_INFO 
         PRINT_VARIABLE("Number of ITs between 2 calls of Dpc", ITCount);
         PRINT_VARIABLE("Number of IT Dpc calls",ITDpcCount);
         PRINT_VARIABLE("Number of primitives waiting to be sent", SendNb);
         PRINT_VARIABLE("Maximum number of primitives waiting to be sent", MaxSendNb);
         PRINT_VARIABLE("Number of times the card"
                        " had to be re-signaled", MaxSendLoop);
         PRINT_VARIABLE("Number of times a sending user"
                        " application waited for a transfer desc", SendWait);
         PRINT_VARIABLE("Number of pending chained received primitives", RecvChainNb);
         PRINT_VARIABLE("Maximum number of chained"
                        " received primitives", MaxRecvChainNb);
         PRINT_VARIABLE("Interrupts per bottom half", ITPerDpc); 
         PRINT_VARIABLE("Maximum number of ITs between 2 calls of Dpc", MaxITPerDpc);
         PRINT_VARIABLE("Number of times several ITs occurred before Dpc", ITBeforeDpc);
         PRINT_VARIABLE("Number of sent messages", SendMsgNb);
         PRINT_VARIABLE("Number of received messages", RecvMsgNb);
         PRINT_VARIABLE("Number of times that several"
                        " received messages are chained",  RecvChainCount);
         PRINT_VARIABLE("Number of times that a lack of "
                        "receive prim are detected", NbrLackRecvPrim);
         PRINT_VARIABLE("Number of times that a lack of "
                        "receive buffer are detected", NbrLackRecvBuffer);
         PRINT_VARIABLE("Current maximum MGR session number", MaxSession);   
#endif

         seq_printf(p,
                    "=======================================\n");
      }
   }

   return(0);
}

static struct seq_operations iph_seq_op = 
{   
   .start  = iph_proc_start,
   .next   = iph_proc_next, 
   .stop   = iph_proc_stop,
   .show   = iph_proc_show,
};

static int iph_seq_open(struct inode *inode, struct file *file)
{
   return(seq_open(file, &iph_seq_op));
}

static struct file_operations proc_iph_operations = 
{
   .open    = iph_seq_open,
   .read    = seq_read,
   .llseek  = seq_lseek,
   .release = seq_release,

};

static int iph_proc_init(void)
{
   struct proc_dir_entry *entry;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0))
   entry = proc_create_data(DRIVER_NAME, 0, NULL, &proc_iph_operations, NULL);
   if (entry)
   {
      return(0);
   }
#else
   entry = create_proc_entry(DRIVER_NAME, 0, NULL);
   if (entry)
   {
      entry->proc_fops = &proc_iph_operations;
      return(0);
   }
#endif
   else
   {
      iph_TRACEK(TRCLVL_0, "[init_module]: create_proc_entry NOK");
      return(EINVAL);
   }
}

#else /* old /proc/iphwae management */

/**************************************************************************
* NAME : iph_proc_info
* DESCRIPTION :  Provides information via proc file eg : cat /proc/iphwan
* PARAMETERS :
*    Input   : 
* RETURN : mod_info return code 
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
#ifdef IPH_PERF_PROC_INFO 
#define PRINT_VARIABLE(desc, item)                                      \
   iph_TRACEK(TRCLVL_1,                                                 \
               "    " desc "(" #item "): %d",                           \
               iph_gMinorMap[i]->item                                   \
             );

#endif
static int iph_proc_info(char *buff, char **start, off_t offset,
                         int count, int *eof, void *data )
{
   char *buffpos = buff;
   char *tmp;
   int NbrCard = 0;
   short i, j;

   buffpos += sprintf(buffpos, "Interphase base driver Version "_VERSION_" :\n" );

   for (i = 0; i < MAX_CARD; i++)
   {
      if (iph_gMinorMap[i] != 0)
      {
         NbrCard++;
      }
   }

   buffpos += sprintf(buffpos, "Number of supported Interphase card detected= %d\n", (NbrCard));

   for (i = 0; i < MAX_CARD; i++)
   {
      if (iph_gMinorMap[i] != 0)
      {
         iph_TRACEK(TRCLVL_1, "Card %d - %s", 
                    i, iph_gMinorMap[i]->Rsrc->CardName);
         iph_TRACEK(TRCLVL_1, "Resource list:");
         for (j = 0; j < MAX_REGION; j++)
         {
            if (iph_gMinorMap[i]->Region[j].Mapped)
            {
               iph_TRACEK(TRCLVL_1, 
                          "    Region name   : %s", 
                          iph_gMinorMap[i]->Region[j].Name);
               iph_TRACEK(TRCLVL_1, 
                          "    HostAddr      : %08x", 
                          iph_gMinorMap[i]->Region[j].HostBaseAddr);
               iph_TRACEK(TRCLVL_1, 
                          "    Mapped at     : %p", 
                          iph_gMinorMap[i]->Region[j].Mapped);
               iph_TRACEK(TRCLVL_1, 
                          "    WinSize %08d  MaxSize %08d", 
                          iph_gMinorMap[i]->Region[j].WinSize, 
                          iph_gMinorMap[i]->Region[j].MaxSize);
            }
         }
         iph_TRACEK(TRCLVL_2, 
                    "Applications registered: %d", 
                    iph_gMinorMap[i]->NbAppli);
         iph_TRACEK(TRCLVL_1, 
                    "Serial number: %d", 
                    iph_gMinorMap[i]->Serial);
         iph_TRACEK(TRCLVL_1, 
                    "Revision number: %d", 
                    iph_gMinorMap[i]->Rsrc->BoardRevisionId);

         switch (iph_gMinorMap[i]->Status)
         {
            case CARD_POST_FAILED: tmp = "CARD_POST_FAILED"; break;
            case CARD_RESET: tmp = "CARD_RESET"; break;
            case CARD_WATCHDOG: tmp = "CARD_WATCHDOG"; break;
            case CARD_LOADED: tmp = "CARD_LOADED"; break;
            case CARD_RUNNING: tmp = "CARD_RUNNING"; break;
            case CARD_RESETTING: tmp = "CARD_RESETTING"; break;
            default: tmp = "Invalid"; break;
         }
         iph_TRACEK(TRCLVL_1, "Status: %s", tmp);
#ifdef IPH_PERF_PROC_INFO 
         PRINT_VARIABLE("Number of ITs between 2 calls of Dpc", ITCount);
         PRINT_VARIABLE("Number of IT Dpc calls",ITDpcCount);
         PRINT_VARIABLE("Number of primitives waiting to be sent", SendNb);
         PRINT_VARIABLE("Maximum number of primitives waiting to be sent", MaxSendNb);
         PRINT_VARIABLE("Number of times the card"
                        " had to be re-signaled", MaxSendLoop);
         PRINT_VARIABLE("Number of times a sending user"
                        " application waited for a transfer desc", SendWait);
         PRINT_VARIABLE("Number of pending chained received primitives", RecvChainNb);
         PRINT_VARIABLE("Maximum number of chained"
                        " received primitives", MaxRecvChainNb);
         PRINT_VARIABLE("Interrupts per bottom half", ITPerDpc); 
         PRINT_VARIABLE("Maximum number of ITs between 2 calls of Dpc", MaxITPerDpc);
         PRINT_VARIABLE("Number of times several ITs occurred before Dpc", ITBeforeDpc);
         PRINT_VARIABLE("Number of sent messages", SendMsgNb);
         PRINT_VARIABLE("Number of received messages", RecvMsgNb);
         PRINT_VARIABLE("Number of times that several"
                        " received messages are chained",  RecvChainCount);
         PRINT_VARIABLE("Number of times that a lack of "
                        "receive prim are detected", NbrLackRecvPrim);
         PRINT_VARIABLE("Number of times that a lack of "
                        "receive buffer are detected", NbrLackRecvBuffer);
         PRINT_VARIABLE("Current maximum MGR session number", MaxSession);   
#endif

         iph_TRACEK(TRCLVL_1, 
                    "=======================================");
      }
   }

   *eof = 1;
   return(buffpos - buff);
}

#endif

/**************************************************************************
* NAME : iph_module_init
* DESCRIPTION : load entry point, called by the kernel when the module
*               is loaded.  
* PARAMETERS :
* RETURN : 0 if succes 
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static int iph_module_init(void)
{
   word wCount;
   int iError = 0;

   /* initialize the global variables */
   iph_gpucTrace = (byte *)0;

   for (wCount = 0; wCount < 256; wCount++)
      iph_gpucTraceMask[wCount] = FALSE;

#ifdef DEBUG_START
   iph_gpucTraceMask[IPHWAN_ID] = TRUE;
#endif

   for (wCount = 0; wCount < MAX_CARD; wCount++)
   {
      iph_gMinorMap[wCount] = 0;
   }

   for (wCount = 0; wCount < TOTAL_APPLI; wCount++)
   {
      gpAppliMinor[wCount] = (ApplCtxtPtr)0;
   }

   /* initalize the blobal mutex */
   MUTEX_INIT(&gAccessMutex, 1, "Global");

   iph_gbAttachedCard = 0;
   iph_gvInitQueue(&gWanDevQueue);
   gwNbAppli = 0;

   /* export entry points and characteristics  */
   /* Try to register the driver with automatic assignment of the major */
   giMajor = register_chrdev(0, DRIVER_NAME, &gfops);

   if (giMajor < 0) /* an error of some form has occured*/
   {
      iph_TRACEK(TRCLVL_0, "[init_module]: register_chrdev failed with error %d", giMajor);
      iError = giMajor;
   }
   else
   {
      /* initialize the driver to the pci module */
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,18) 
      iError = pci_module_init(&gIphwanDriver);
#else
      iError = pci_register_driver(&gIphwanDriver);
#endif

      /* if attach device failed */
      if (iError != 0 )
      {
         /* unregister the driver from chrdev */
         unregister_chrdev(giMajor, DRIVER_NAME);
      }
      else
      {
         /* create an entry point to get back information about driver */
         /* and devices attached. */
#ifdef SEQ_PROC
         iph_proc_init();
#else
         create_proc_read_entry(DRIVER_NAME, 0, 0, iph_proc_info, 0 );
#endif
      }
   }

#ifdef OLD_COMPAT_IOCTL
   register_ioctl32_conversion(CTL_CLOSE_DEVICE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_SEND_PRIM, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GIVE_RX_PRIM, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GIVE_RX_BUFFER, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_RECV_PRIM, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_MAX_RX_QUEUE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_NO_OF_DEVICES, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CARD_ID, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_MAX_RX_CHAIN, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CONTROL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_FREE_CONTROL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_MEM, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_WRITE_MEM, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_PLX_REG, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_WRITE_PLX_REG, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_PCI_CONF, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_WRITE_PCI_CONF, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_DRV_VER, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_CPU_USAGE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_POOL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_DRV_POOL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GIVE_RX_DATA_BUFFER, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_MAX_TRANSFER_SIZE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_INIT_PRIM_POOL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_INIT_BUFFER_POOL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_INIT_MAX_APPLI, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_INIT_MAX_SESSION, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_INIT_DRV_TRACE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_START_DRV_TRACE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_STOP_DRV_TRACE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_DRV_TRACE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_HOST, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_RESET_HOST_STAT, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_TRACE_CONSOLE_LEVEL, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_TRACE, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_STATUS, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CARD_STATUS, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_SET_CARD_STATUS, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CARD_RSRC, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_USING_APPLI, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_CHECK_CARD_STATUS, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CUSTOM_INFO, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_TIME, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_SET_HOST_TIME_OFFSET, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_CONTROL_DBG, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_WRITE_FLASH, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_READ_FLASH, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_WRITE_CORE_REG, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_DUMP_CORE_REG, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_RESET_BOARD, iph_compat_ioctl);
   register_ioctl32_conversion(CTL_GET_TEMP_INFO, iph_compat_ioctl);
#endif

   return(iError);
}

/**************************************************************************
* NAME : iphwan_module_cleanup
* DESCRIPTION : unload entry point, called by the kernel when the driver
                is unloaded.
* PARAMETERS :
* RETURN : mod_remove return code
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void iph_module_cleanup(void)
{
   int iError = 0;
   void *pTraceHead;

#ifdef OLD_COMPAT_IOCTL
   unregister_ioctl32_conversion(CTL_CLOSE_DEVICE);
   unregister_ioctl32_conversion(CTL_SEND_PRIM);
   unregister_ioctl32_conversion(CTL_GIVE_RX_PRIM);
   unregister_ioctl32_conversion(CTL_GIVE_RX_BUFFER);
   unregister_ioctl32_conversion(CTL_RECV_PRIM);
   unregister_ioctl32_conversion(CTL_MAX_RX_QUEUE);
   unregister_ioctl32_conversion(CTL_NO_OF_DEVICES);
   unregister_ioctl32_conversion(CTL_GET_CARD_ID);
   unregister_ioctl32_conversion(CTL_MAX_RX_CHAIN);
   unregister_ioctl32_conversion(CTL_GET_CONTROL);
   unregister_ioctl32_conversion(CTL_FREE_CONTROL);
   unregister_ioctl32_conversion(CTL_DUMP_MEM);
   unregister_ioctl32_conversion(CTL_WRITE_MEM);
   unregister_ioctl32_conversion(CTL_DUMP_PLX_REG);
   unregister_ioctl32_conversion(CTL_WRITE_PLX_REG);
   unregister_ioctl32_conversion(CTL_DUMP_PCI_CONF);
   unregister_ioctl32_conversion(CTL_WRITE_PCI_CONF);
   unregister_ioctl32_conversion(CTL_GET_DRV_VER);
   unregister_ioctl32_conversion(CTL_DUMP_CPU_USAGE);
   unregister_ioctl32_conversion(CTL_DUMP_POOL);
   unregister_ioctl32_conversion(CTL_DUMP_DRV_POOL);
   unregister_ioctl32_conversion(CTL_GIVE_RX_DATA_BUFFER);
   unregister_ioctl32_conversion(CTL_MAX_TRANSFER_SIZE);
   unregister_ioctl32_conversion(CTL_INIT_PRIM_POOL);
   unregister_ioctl32_conversion(CTL_INIT_BUFFER_POOL);
   unregister_ioctl32_conversion(CTL_INIT_MAX_APPLI);
   unregister_ioctl32_conversion(CTL_INIT_MAX_SESSION);
   unregister_ioctl32_conversion(CTL_INIT_DRV_TRACE);
   unregister_ioctl32_conversion(CTL_START_DRV_TRACE);
   unregister_ioctl32_conversion(CTL_STOP_DRV_TRACE);
   unregister_ioctl32_conversion(CTL_DUMP_DRV_TRACE);
   unregister_ioctl32_conversion(CTL_DUMP_HOST);
   unregister_ioctl32_conversion(CTL_RESET_HOST_STAT);
   unregister_ioctl32_conversion(CTL_TRACE_CONSOLE_LEVEL);
   unregister_ioctl32_conversion(CTL_DUMP_TRACE);
   unregister_ioctl32_conversion(CTL_GET_STATUS);
   unregister_ioctl32_conversion(CTL_GET_CARD_STATUS);
   unregister_ioctl32_conversion(CTL_SET_CARD_STATUS);
   unregister_ioctl32_conversion(CTL_GET_CARD_RSRC);
   unregister_ioctl32_conversion(CTL_GET_USING_APPLI);
   unregister_ioctl32_conversion(CTL_CHECK_CARD_STATUS);
   unregister_ioctl32_conversion(CTL_GET_CUSTOM_INFO);
   unregister_ioctl32_conversion(CTL_GET_TIME);
   unregister_ioctl32_conversion(CTL_SET_HOST_TIME_OFFSET);
   unregister_ioctl32_conversion(CTL_GET_CONTROL_DBG);
   unregister_ioctl32_conversion(CTL_WRITE_FLASH);
   unregister_ioctl32_conversion(CTL_READ_FLASH);
   unregister_ioctl32_conversion(CTL_WRITE_CORE_REG);
   unregister_ioctl32_conversion(CTL_DUMP_CORE_REG);
   unregister_ioctl32_conversion(CTL_RESET_BOARD);
   unregister_ioctl32_conversion(CTL_GET_TEMP_INFO);
#endif

   /* Deregister the driver from the pci module list */
   pci_unregister_driver(&gIphwanDriver);

   /* Remove entry points and characteristics from the char module list */
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,18)
   iError = unregister_chrdev(giMajor, DRIVER_NAME);
#else
          unregister_chrdev(giMajor, DRIVER_NAME);
#endif


   /* remove the /proc/iphxxx file */
   remove_proc_entry(DRIVER_NAME, 0);

   if (iError == 0)
   {
      /* if the trace are active, we must destroy the mutex and release */
      /* the trace buffer */
      if (iph_gpucTrace != (byte *)0)
      {
#ifdef SOLARIS
         MUTEX_DESTROY(&iph_gTraceMutex);
#endif
         pTraceHead = (void *)iph_gpucTrace;
         iph_gpucTrace = NULL;
         TMP_FREE(pTraceHead);
      }
   }
   else
   {
      iph_TRACEK(TRCLVL_0, "[cleanup_module]: failed to unregister the char device");
   } 
}

/*
 * These two macros below are used to declare the two entry point of 
 * the driver. All loadable module must use theirs.
 */
module_init(iph_module_init);
module_exit(iph_module_cleanup);
#endif  /* LINUX */

#ifdef SOLARIS
/**************************************************************************
* NAME : iph_attach
* DESCRIPTION : attach entry point
* PARAMETERS :
*    Input   : dip = device information structure
*    Input   : cmd = command argument
* RETURN : 0 if all is OK else an error code 
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static int iph_attach(dev_info_t *dev, ddi_attach_cmd_t cmd)
{
   IphWanDevPtr pDev;
   word wCount;
   int iError = 0;
   byte PCIConf[MAX_PCI_CONF];
   off_t mem_size;
   dword regVal;
   dev_info_t *parent;
   int iRegs;
   /* characteristics to access the PCI registers */
   ddi_device_acc_attr_t dev_le_attr = {
      DDI_DEVICE_ATTR_V0,        /* version number */
      DDI_STRUCTURE_LE_ACC,      /* the registers are Little Endian */
      DDI_STRICTORDER_ACC        /* strict ordering */
   };
   /* characteristics to access the core registers */
   ddi_device_acc_attr_t dev_be_attr = {
      DDI_DEVICE_ATTR_V0,        /* version number */
      DDI_STRUCTURE_BE_ACC,      /* the registers are Big Endian */
      DDI_STRICTORDER_ACC        /* strict ordering */
   };
   /* characteristics to access DRAM */
   ddi_device_acc_attr_t dram_attr = {
      DDI_DEVICE_ATTR_V0,        /* version number */
      DDI_NEVERSWAP_ACC,         /* the DRAM uses Big Endian */
      DDI_STRICTORDER_ACC        /* strict ordering */
   };
   ddi_dma_attr_t dma_attr = {
      DMA_ATTR_V0,               /* version number */
      0,                         /* lower accessible address for DMA */
#if defined(DSIPRODUCT_DPK_SOLARIS_X86) && DKOS_SOL_VERSION == 11
      0x7FFFFFFF,                /* highest accessible address for DMA */
#else
      0xFFFFFFFF,                /* highest accessible address for DMA */
#endif
      0xFFFFFFFF,                /* maximum transfer count in one cookie */
      1,                         /* alignment */
      1,                         /* burst size */
      1,                         /* minimum transfer size */
      0xFFFFFFFF,                /* maximum transfer size */
      0xFFFFFFFF,                /* upper bound of the DMA engine's add reg */
      1,                         /* no scatter-gather */
      1,                         /* granularity */
      0                          /* reserved flag */
   };
   char DeviceName[20];

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_attach]: entry (cmd=0x%x) dev=0x%x", cmd, dev);
#endif

   iError = DDI_FAILURE;

   if (cmd != DDI_ATTACH)
   {
      return(iError);
   }
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[iph_attach] DDI_ATTACH");
#endif
   /* read all the PCI registers content */
   /* ATTENTION: the pci_config_word routines perform swapping from */
   /* PCI Little Endian to native host format */
   READ_PCI_CONF_WORD(dev, VID_INDX, &PCIConf[VID_INDX]);
   READ_PCI_CONF_WORD(dev, DID_INDX, &PCIConf[DID_INDX]);
   READ_PCI_CONF_WORD(dev, PCICMD_INDX, &PCIConf[PCICMD_INDX]);
   READ_PCI_CONF_WORD(dev, PCISTS_INDX, &PCIConf[PCISTS_INDX]);
   READ_PCI_CONF_BYTE(dev, RID_INDX, &PCIConf[RID_INDX]);
   READ_PCI_CONF_BYTE(dev, CLDEV_INDX, &PCIConf[CLDEV_INDX]);
   READ_PCI_CONF_BYTE(dev, CALN_INDX, &PCIConf[CALN_INDX]);
   READ_PCI_CONF_BYTE(dev, LAT_INDX, &PCIConf[LAT_INDX]);
   READ_PCI_CONF_BYTE(dev, HDR_INDX, &PCIConf[HDR_INDX]);
   READ_PCI_CONF_BYTE(dev, BIST_INDX, &PCIConf[BIST_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR0_INDX, &PCIConf[BADDR0_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR1_INDX, &PCIConf[BADDR1_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR2_INDX, &PCIConf[BADDR2_INDX]);
   READ_PCI_CONF_DWORD(dev, BADDR3_INDX, &PCIConf[BADDR3_INDX]);
   READ_PCI_CONF_WORD(dev, SUBVID_INDX, &PCIConf[SUBVID_INDX]);
   READ_PCI_CONF_WORD(dev, SUBSYS_INDX, &PCIConf[SUBSYS_INDX]);
   READ_PCI_CONF_BYTE(dev, INTLN_INDX, &PCIConf[INTLN_INDX]);
   READ_PCI_CONF_BYTE(dev, INTPIN_INDX, &PCIConf[INTPIN_INDX]);
   READ_PCI_CONF_BYTE(dev, MINGNT_INDX, &PCIConf[MINGNT_INDX]);
   READ_PCI_CONF_BYTE(dev, MAXLAT_INDX, &PCIConf[MAXLAT_INDX]);

   /*
    * Dialogic copyright banner.
    */
#if DEVO_REV==4
   cmn_err(CE_CONT, "DSI SS7MD11 Release %d.%d.%d (Build %d)\n", 
    PRODUCT_MAJREV, PRODUCT_MINREV, PRODUCT_SPKREV, PRODUCT_BLDREV);
#else
   cmn_err(CE_CONT, "DSI SS7MD Release %d.%d.%d (Build %d)\n", 
    PRODUCT_MAJREV, PRODUCT_MINREV, PRODUCT_SPKREV, PRODUCT_BLDREV);
#endif

   cmn_err(CE_CONT, "Part of the Dialogic(R) %s\n", PRODUCT_BUILDSTR);

   if (COPYRIGHT_BEGIN == PRODUCT_COPYRIGHT)
   {
     cmn_err(CE_CONT, "Copyright (C) Dialogic Corporation %d\n", COPYRIGHT_BEGIN);
   }
   else
   {
     cmn_err(CE_CONT, 
        "Copyright (C) Dialogic Corporation %d-%d\n", COPYRIGHT_BEGIN, PRODUCT_COPYRIGHT);
   }

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_1, "IPHPQ3 [iph_attach]: Content of PCI configuration space :\n");
   iph_TRACEK(TRCLVL_1, " VID    %02x : 0x%x", 
              VID_INDX, *(word *)&PCIConf[VID_INDX]);
   iph_TRACEK(TRCLVL_1, " DID    %02x : 0x%x", 
              DID_INDX, *(word *)&PCIConf[DID_INDX]);
   iph_TRACEK(TRCLVL_1, " PCICMD %02x : 0x%x", 
              PCICMD_INDX, *(word *)&PCIConf[PCICMD_INDX]);
   iph_TRACEK(TRCLVL_1, " PCISTS %02x : 0x%x", 
              PCISTS_INDX, *(word *)&PCIConf[PCISTS_INDX]);
   iph_TRACEK(TRCLVL_1, " RID    %02x : 0x%x", 
              RID_INDX, PCIConf[RID_INDX]);
   iph_TRACEK(TRCLVL_1, " CLDEV  %02x : 0x%x", 
              CLDEV_INDX, *(word *)&PCIConf[CLDEV_INDX]);
   iph_TRACEK(TRCLVL_1, " CALN   %02x : 0x%x", 
              CALN_INDX, PCIConf[CALN_INDX]);
   iph_TRACEK(TRCLVL_1, " LAT    %02x : 0x%x", 
              LAT_INDX, PCIConf[LAT_INDX]);
   iph_TRACEK(TRCLVL_1, " HDR    %02x : 0x%x", 
              HDR_INDX, PCIConf[HDR_INDX]);
   iph_TRACEK(TRCLVL_1, " BIST   %02x : 0x%x", 
              BIST_INDX, PCIConf[BIST_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR0 %02x : 0x%x", 
              BADDR0_INDX, *(dword *)&PCIConf[BADDR0_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR1 %02x : 0x%x", 
              BADDR1_INDX, *(dword *)&PCIConf[BADDR1_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR2 %02x : 0x%x", 
              BADDR2_INDX, *(dword *)&PCIConf[BADDR2_INDX]);
   iph_TRACEK(TRCLVL_1, " BADDR3 %02x : 0x%x", 
              BADDR3_INDX, *(dword *)&PCIConf[BADDR3_INDX]);
   iph_TRACEK(TRCLVL_1, " SUBVID %02x : 0x%x", 
              SUBVID_INDX, *(word *)&PCIConf[SUBVID_INDX]);
   iph_TRACEK(TRCLVL_1, " SUBSYS %02x : 0x%x", 
              SUBSYS_INDX, *(word *)&PCIConf[SUBSYS_INDX]);
   iph_TRACEK(TRCLVL_1, " INTLN  %02x : 0x%x", 
              INTLN_INDX, PCIConf[INTLN_INDX]);
   iph_TRACEK(TRCLVL_1, " INTPIN %02x : 0x%x", 
              INTPIN_INDX, PCIConf[INTPIN_INDX]);
   iph_TRACEK(TRCLVL_1, " MINGNT %02x : 0x%x", 
              MINGNT_INDX, PCIConf[MINGNT_INDX]);
   iph_TRACEK(TRCLVL_1, " MAXLAT %02x : 0x%x", 
              MAXLAT_INDX, PCIConf[MAXLAT_INDX]);
#endif

   switch (*(word *)&PCIConf[DID_INDX])
   {
      case IPH_3639_PCI_ID:
         if (allocDevCtxt(dev, &pDev) != 0)
         {
            return(iError);
         }
         pDev->DetachPoint = DP_CTX_ALLOCATED;

         if ((parent = ddi_get_parent(dev)) != NULL)
         {
#ifdef DEBUG_INIT
            iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_attach]: get_parent 0x%x", parent);
#endif

            if (ddi_dev_nregs(parent, &iRegs) == DDI_SUCCESS && iRegs >= 2)
            {
               strcpy(pDev->Region[BRIDGE_REGION].Name,"Bridge Registers");
               if (ddi_regs_map_setup(parent, 1, 
                                      (caddr_t *)&pDev->Region[BRIDGE_REGION].Mapped, 
                                      0, 0, &dev_le_attr, 
                                      &pDev->Region[BRIDGE_REGION].AccHandle) != DDI_SUCCESS)
               {
#ifdef DEBUG_INIT
                  iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_attach]: failed to map parent reg");
#endif
                  iph_detach_device(pDev);
                  break;
               }
               ddi_dev_regsize(parent, 1, &mem_size);
               pDev->Region[BRIDGE_REGION].HostBaseAddr = 0;
               pDev->Region[BRIDGE_REGION].WinSize      = mem_size;
               pDev->Region[BRIDGE_REGION].WinLimit      = mem_size-1;
               pDev->Region[BRIDGE_REGION].WinMask      = ~(mem_size-1);
               pDev->Region[BRIDGE_REGION].CurWin       = 0xFFFFFFFF;
               pDev->Region[BRIDGE_REGION].MaxSize      = mem_size;
               pDev->Region[BRIDGE_REGION].WinShift     = 0;
               pDev->Region[BRIDGE_REGION].CardBaseAddr = 0;
               pDev->Region[BRIDGE_REGION].Ops.read32   = generic_read32;
               pDev->Region[BRIDGE_REGION].Ops.write32  = generic_write32;
               pDev->Region[BRIDGE_REGION].Ops.read16   = generic_nopsr16;
               pDev->Region[BRIDGE_REGION].Ops.write16  = generic_nopsw16;
               pDev->Region[BRIDGE_REGION].Ops.read8    = generic_nopsr8;
               pDev->Region[BRIDGE_REGION].Ops.write8   = generic_nopsw8;
               pDev->Region[BRIDGE_REGION].Ops.readbuf  = generic_nopsrbuf;
               pDev->Region[BRIDGE_REGION].Ops.writebuf = generic_nopswbuf;
               pDev->Region[BRIDGE_REGION].Index = BRIDGE_REGION;
               pDev->Region[BRIDGE_REGION].BigEnd = FALSE;
               pDev->Region[BRIDGE_REGION].ProtAccess = FALSE;
               /*MUTEX_INIT(&pDev->Region[BRIDGE_REGION].Access,
                            "IphWan region mutex", MUTEX_DRIVER, (void *)0);*/
               pDev->Region[BRIDGE_REGION].Priv = pDev;
            }
            else
            {
               pDev->Region[BRIDGE_REGION].WinSize      = 0;
            }
            pDev->sDev.iDev = parent;
            pDev->DetachPoint = DP_PCI_REGISTERS_MAPPED; 
         }

         /* copy the PCI configuration data */
         memcpy(pDev->PCIConf, PCIConf, MAX_PCI_CONF);

         /* new initialize resource region*/
         /* BAR 0 access to Core register*/
         strcpy(pDev->Region[CORE_REGION].Name,"Core Registers"); 
         if (ddi_regs_map_setup(dev, 1, 
                                (caddr_t *)&pDev->Region[CORE_REGION].Mapped, 
                                0, 0, &dev_be_attr, 
                                &pDev->Region[CORE_REGION].AccHandle) != DDI_SUCCESS)
         {
            iph_detach_device(pDev);
            break;
         }
         ddi_dev_regsize(dev, 1, &mem_size);
         pDev->Region[CORE_REGION].HostBaseAddr   = 0;
         pDev->Region[CORE_REGION].WinSize        = mem_size;
         pDev->Region[CORE_REGION].WinLimit        = mem_size-1;
         pDev->Region[CORE_REGION].WinMask        = ~(mem_size-1);
         pDev->Region[CORE_REGION].CurWin         = 0xFFFFFFFF;
         pDev->Region[CORE_REGION].MaxSize        = 0x100000;
         pDev->Region[CORE_REGION].WinShift       = 0;
         pDev->Region[CORE_REGION].CardBaseAddr   = 0xd8000000;
         pDev->Region[CORE_REGION].Cfg            =  0;
         pDev->Region[CORE_REGION].Ops.read32     = generic_read32;
         pDev->Region[CORE_REGION].Ops.write32    = generic_write32;           
         pDev->Region[CORE_REGION].Ops.read16     = generic_read16;
         pDev->Region[CORE_REGION].Ops.write16    = generic_write16;
         pDev->Region[CORE_REGION].Ops.read8      = generic_read8;
         pDev->Region[CORE_REGION].Ops.write8     = generic_write8;
         pDev->Region[CORE_REGION].Ops.readbuf    = generic_nopsrbuf;
         pDev->Region[CORE_REGION].Ops.writebuf   = generic_nopswbuf;
         pDev->Region[CORE_REGION].Priv = pDev;
         pDev->Region[CORE_REGION].Index = CORE_REGION;
         pDev->Region[CORE_REGION].BigEnd = TRUE;
         pDev->Region[CORE_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[CORE_REGION].Access,
                      "IphWan region mutex", MUTEX_DRIVER, (void *)0);*/

         /* Check whether it is an Interphase Card */
         pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],
                                              CARD_MPC856X_REG_ID,
                                              &regVal);

         regVal = HOST_CORE32(regVal);

         if ((regVal & 0x0000FFFF) != CARD_3639_DID &&
             (regVal & 0x0000FFFF) != CARD_5639_DID &&
             (regVal & 0x0000FFFF) != CARD_5639E_DID &&
             (regVal & 0x0000FFFF) != CARD_5639L_DID)
         {
            iph_TRACEK(TRCLVL_0,  " found a MPC856X but not a supported device. Skip it");
            iph_detach_device(pDev);
            return(-ENODEV);
         }
         if ((regVal & 0x0000FFFF) != CARD_5639_DID &&
             (regVal & 0x0000FFFF) != CARD_5639E_DID &&
             (regVal & 0x0000FFFF) != CARD_5639L_DID &&
             pDev->Region[BRIDGE_REGION].WinSize == 0)
         {
            iph_TRACEK(TRCLVL_0,  " found an Interphase card but PCI bridge is not reachable => Skip it");
            iph_detach_device(pDev);
            return(-ENODEV);
         }

         pDev->Type  = (regVal & 0x0000FFFF);

         strcpy(pDev->Region[FLASH_REGION].Name,"Flash memory"); 
         if (ddi_regs_map_setup(dev, 2, 
                                (caddr_t *)&pDev->Region[FLASH_REGION].Mapped, 
                                0, 0, &dram_attr, 
                                &pDev->Region[FLASH_REGION].AccHandle) != DDI_SUCCESS)
         {
            ddi_regs_map_free(&pDev->Region[CORE_REGION].AccHandle);
            iph_detach_device(pDev);
            break;
         }
         ddi_dev_regsize(dev, 2, &mem_size);
         pDev->Region[FLASH_REGION].HostBaseAddr = 0;
         pDev->Region[FLASH_REGION].WinSize      = mem_size;
         pDev->Region[FLASH_REGION].WinLimit      = mem_size-1;
         pDev->Region[FLASH_REGION].WinMask      = ~(mem_size-1);
         pDev->Region[FLASH_REGION].CurWin       = 0xFFFFFFFF;
         pDev->Region[FLASH_REGION].MaxSize      = 0x1000000;
         pDev->Region[FLASH_REGION].WinShift     = 12;
         pDev->Region[FLASH_REGION].CardBaseAddr = 0xFF000000;
         pDev->Region[FLASH_REGION].Cfg          = MPC856X_PITAR1;
         pDev->Region[FLASH_REGION].Ops.read16   = generic_nopsr16;
         pDev->Region[FLASH_REGION].Ops.write16  = generic_nopsw16;
         pDev->Region[FLASH_REGION].Ops.read32   = generic_nopsr32;
         pDev->Region[FLASH_REGION].Ops.write32  = generic_nopsw32;
         pDev->Region[FLASH_REGION].Ops.read8    = generic_read8;
         pDev->Region[FLASH_REGION].Ops.write8   = generic_write8;
         pDev->Region[FLASH_REGION].Ops.readbuf  = generic_readbuf;
         pDev->Region[FLASH_REGION].Ops.writebuf = generic_nopswbuf;
         pDev->Region[FLASH_REGION].Ops.moveWindow = MovePQ3Window;
         pDev->Region[FLASH_REGION].Priv = pDev;
         pDev->Region[FLASH_REGION].Index = FLASH_REGION;
         pDev->Region[FLASH_REGION].BigEnd = TRUE;
         pDev->Region[FLASH_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[FLASH_REGION].Access,
                      "IphWan region mutex", MUTEX_DRIVER, (void *)0);*/


         strcpy(pDev->Region[MEM_REGION].Name,"Main memory"); 
         if (ddi_regs_map_setup(dev, 3, 
                                (caddr_t *)&pDev->Region[MEM_REGION].Mapped, 
                                0, 0, &dram_attr, 
                                &pDev->Region[MEM_REGION].AccHandle) != DDI_SUCCESS)
         {
            ddi_regs_map_free(&pDev->Region[CORE_REGION].AccHandle);
            ddi_regs_map_free(&pDev->Region[FLASH_REGION].AccHandle);
            iph_detach_device(pDev);
            break;
         }
         ddi_dev_regsize(dev, 3, &mem_size);
         pDev->Region[MEM_REGION].HostBaseAddr = 0;
         pDev->Region[MEM_REGION].WinSize      = mem_size;
         pDev->Region[MEM_REGION].WinLimit      = mem_size-1;
         pDev->Region[MEM_REGION].WinMask      = ~(mem_size-1);
         pDev->Region[MEM_REGION].CurWin       = 0xFFFFFFFF;
         pDev->Region[MEM_REGION].MaxSize      = 0x8000000;
         pDev->Region[MEM_REGION].WinShift     = 12;
         pDev->Region[MEM_REGION].CardBaseAddr = 0;
         pDev->Region[MEM_REGION].Cfg          = MPC856X_PITAR2;
         pDev->Region[MEM_REGION].Ops.read16   = generic_read16;
         pDev->Region[MEM_REGION].Ops.write16  = generic_write16;
         pDev->Region[MEM_REGION].Ops.read32   = generic_read32;
         pDev->Region[MEM_REGION].Ops.write32  = generic_write32;
         pDev->Region[MEM_REGION].Ops.read8    = generic_read8;
         pDev->Region[MEM_REGION].Ops.write8   = generic_write8;
         pDev->Region[MEM_REGION].Ops.readbuf  = generic_readbuf;
         pDev->Region[MEM_REGION].Ops.writebuf = generic_writebuf;
         pDev->Region[MEM_REGION].Ops.moveWindow = MovePQ3Window;
         pDev->Region[MEM_REGION].ProtAccess = FALSE;
         pDev->Region[MEM_REGION].Index = MEM_REGION;
         pDev->Region[MEM_REGION].BigEnd = TRUE;
         /*MUTEX_INIT(&pDev->Region[MEM_REGION].Access,
                      "IphWan region mutex", MUTEX_DRIVER, (void *)0);*/
         pDev->Region[MEM_REGION].Priv = pDev;

         /* check the reset command is supported without PEX */
         if (pDev->Region[BRIDGE_REGION].WinSize == 0)
         {
            if (pDev->Type == CARD_5639_DID || pDev->Type == CARD_5639E_DID)
            {
               pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
               pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
               if (pDev->Type == CARD_5639E_DID)
               {
                  READ_MEM_DWORD(pDev, 0x80018, &regVal);
               }
               else
               {
                  READ_MEM_DWORD(pDev, 0x20018, &regVal);
               }
               if ((regVal & 0x04000000) == 0)
               {
#ifdef CHECK_RESET_CAPABILITY
                  iph_TRACEK(TRCLVL_0,  " found an Interphase card but it cannot be reset through EPLD => Skip it");
                  iph_detach_device(pDev);
                  return(-ENODEV);
#else
                  iph_TRACEK(TRCLVL_0,  " found an Interphase card that may not support reset through EPLD");
#endif
               }
               pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
               pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
               pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
            }
            else if (pDev->Type == CARD_5639L_DID)
            {
               pDev->Region[MEM_REGION].CardBaseAddr = 0xD0000000;
               pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
               READ_MEM_DWORD(pDev, 0x44000, &regVal);
               if ((regVal & 0x00000010) == 0)
               {
#ifdef CHECK_RESET_CAPABILITY
                  iph_TRACEK(TRCLVL_0,  " found an Interphase card but it cannot be reset through FPGA => Skip it");
                  iph_detach_device(pDev);
                  return(-ENODEV);
#else
                  iph_TRACEK(TRCLVL_0,  " found an Interphase card that may not support reset through FPGA");
#endif
               }
               pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
               pDev->Region[MEM_REGION].CardBaseAddr = 0x00000000;
               pDev->Region[MEM_REGION].CurWin   = 0xFFFFFFFF;
            }
         }

         /* complete attach */
         pDev->sDev.Dev = dev;
         bcopy(&dma_attr, &pDev->sDev.dma_attr, sizeof(ddi_dma_attr_t));
         bcopy(&dram_attr, &pDev->sDev.dram_attr, sizeof(ddi_device_acc_attr_t));
         if (iph_attach_device(pDev) == 0)
         {
            pDev->DetachPoint = DP_ALL;
            iph_gbAttachedCard++;

            /* report device attachment */
            ddi_report_dev(dev);

            iError = DDI_SUCCESS;
         }

         break;

#if 0
      case IPH_PEX1_PCI_ID:
      case IPH_PEX2_PCI_ID:

         if (allocDevCtxt(dev, &pDev) != 0)
         {
            return(iError);
         }
         pDev->DetachPoint = DP_CTX_ALLOCATED;

         strcpy(pDev->Region[BRIDGE_REGION].Name,"Bridge Registers");
         if (ddi_regs_map_setup(dev, 1, 
                                (caddr_t *)&pDev->Region[BRIDGE_REGION].Mapped, 
                                0, 0, &dev_le_attr, 
                                &pDev->Region[BRIDGE_REGION].AccHandle) != DDI_SUCCESS)
         {
            break;
         }
         ddi_dev_regsize(dev, 1, &mem_size);
         pDev->Region[BRIDGE_REGION].HostBaseAddr = 0;
         pDev->Region[BRIDGE_REGION].WinSize      = mem_size;
         pDev->Region[BRIDGE_REGION].WinLimit      = mem_size-1;
         pDev->Region[BRIDGE_REGION].WinMask      = ~(mem_size-1);
         pDev->Region[BRIDGE_REGION].CurWin       = 0xFFFFFFFF;
         pDev->Region[BRIDGE_REGION].MaxSize      = mem_size;
         pDev->Region[BRIDGE_REGION].WinShift     = 0;
         pDev->Region[BRIDGE_REGION].CardBaseAddr = 0;
         pDev->Region[BRIDGE_REGION].Ops.read32   = generic_read32;
         pDev->Region[BRIDGE_REGION].Ops.write32  = generic_write32;
         pDev->Region[BRIDGE_REGION].Ops.read16   = generic_nopsr16;
         pDev->Region[BRIDGE_REGION].Ops.write16  = generic_nopsw16;
         pDev->Region[BRIDGE_REGION].Ops.read8    = generic_nopsr8;
         pDev->Region[BRIDGE_REGION].Ops.write8   = generic_nopsw8;
         pDev->Region[BRIDGE_REGION].Ops.readbuf  = generic_nopsrbuf;
         pDev->Region[BRIDGE_REGION].Ops.writebuf = generic_nopswbuf;
         pDev->Region[BRIDGE_REGION].Index = BRIDGE_REGION;
         pDev->Region[BRIDGE_REGION].BigEnd = FALSE;
         pDev->Region[BRIDGE_REGION].ProtAccess = FALSE;
         /*MUTEX_INIT(&pDev->Region[BRIDGE_REGION].Access,
                      "IphWan region mutex", MUTEX_DRIVER, (void *)0);*/
         pDev->Region[BRIDGE_REGION].Priv = pDev;

         /* report device attachment */
         pDev->sDev.iDev = dev;
         pDev->DetachPoint = DP_PCI_REGISTERS_MAPPED; 

         ddi_report_dev(dev);
         iError = DDI_SUCCESS;

         break;
#endif

      default:
         break;
   }

   return(iError);
}

#if DEVO_REV == 4
static int iph_quiesce(dev_info_t *dip)
{
  int instance;
  int i;
  int MinorNum;
  IphWanDevPtr pDev;

  /* get the device instance */
  instance = ddi_get_instance(dip);
  for (i=0; i < MAX_CARD; i++)
  {
    /*
     * MH 04Mar11
     * There should always be a minor->instance mapping present.
     */
    if (minor2instance[i] == instance)
    {
      MinorNum = i;
      break;
    }
  }

  /* get the device structure */
  pDev = ddi_get_soft_state(gpvState, MinorNum);

  iph_gdwResetBoard(pDev);

  return(DDI_SUCCESS);
}
#endif


/**************************************************************************
* NAME : iph_detach
* DESCRIPTION : detach entry point
* PARAMETERS :
*    Input   : dip = device information structure
*    Input   : cmd = command argument
* RETURN : DDI_SUCCESS if all is OK, DDI_FAILURE else
* REVISION :
*    - Version 1.0 : 05/04/02 Creation
**************************************************************************/
static int iph_detach(dev_info_t *dip, ddi_detach_cmd_t cmd)
{
   IphWanDevPtr pDev;
   int iError;
   int iInstance;
   int MinorNum;
   int i;

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, 
              DRIVER_NAME" [iph_detach]: entry (cmd %d)", cmd);
#endif

   iError = DDI_FAILURE;

   if (cmd != DDI_DETACH)
   {
      return(iError);
   }
   /* get the device instance */
   iInstance = ddi_get_instance(dip);
   for (i=0; i < MAX_CARD; i++)
   {
     /*
      * MH 04Mar11
      * There should always be a minor->instance mapping present.
      */
     if (minor2instance[i] == iInstance)
     {
       MinorNum = i;
       break;
     }
   }

   iph_TRACEK(TRCLVL_0, DRIVER_NAME" DETACH for device %s%d", 
             DEVICE_NAME, MinorNum);

   /* get the device structure */
   pDev = ddi_get_soft_state(gpvState, MinorNum);

   /* Check that no application is currently using this device */
   if ( pDev->UsingAppliQueue.FirstPtr != (QueueItemPtr)&pDev->UsingAppliQueue)
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" device %s%d is still busy",
                 DEVICE_NAME, MinorNum);
   }
   else
   {
      iph_detach_device(pDev);
      iph_gMinorMap[MinorNum] = 0;

      /* switch on the BLUE LED */
      /* TO COMPLETE */

      iError = DDI_SUCCESS;

      iph_TRACEK(TRCLVL_0, DRIVER_NAME" device %s%d is detached",
                 DEVICE_NAME, MinorNum);
   }

   return(iError);
}

/**************************************************************************
* NAME : iph_getinfo
* DESCRIPTION : getinfo entry point
* PARAMETERS :
*    Input   : dip = device information structure (do not use)
*    Input   : cmd = command argument
*    Input   : arg = command specific argument
*    Output  : resultp = pointer where to store the result
* RETURN : DDI_SUCCESS if all is OK, DDI_FAILURE else
* REVISION :
*    - Version 1.0 : 10/19/99 Creation
**************************************************************************/
static int iph_getinfo(dev_info_t *dip, ddi_info_cmd_t cmd, void *arg,
                       void **resultp)
{
   IphWanDevPtr pDev;
   int iInstance;
   int iError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[iph_getinfo] entry (cmd)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, cmd);
#endif
#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [iph_getinfo]: cmd 0x%x", cmd);
#endif

   iError = DDI_FAILURE;

   switch(cmd)
   {
      case DDI_INFO_DEVT2INSTANCE:
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_getinfo] DDI_INFO_DEVT2INSTANCE");
#endif
         iInstance = getminor((dev_t)arg);
         if (iInstance < TOTAL_APPLI &&
             gpAppliMinor[iInstance] != NULL)
         {
            *resultp = (void *)gpAppliMinor[iInstance]->WanDevPtr->Index;
            iError = DDI_SUCCESS;
         }
         else
            *resultp = (void *)iInstance;
         break;
      case DDI_INFO_DEVT2DEVINFO:
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[iph_getinfo] DDI_INFO_DEVT2DEVINFO");
#endif
         pDev = NULL;
         iInstance = getminor((dev_t)arg);
         if (iInstance < TOTAL_APPLI &&
             gpAppliMinor[iInstance] != NULL)
            pDev = gpAppliMinor[iInstance]->WanDevPtr;
         else
            pDev = ddi_get_soft_state(gpvState, iInstance);
         if (pDev == NULL)
         {
            *resultp = NULL;
         }
         else
         {
            *resultp = (void *)pDev->sDev.Dev;
            iError = DDI_SUCCESS;
         }
         break;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[iph_getinfo] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, iError);
#endif

   return(iError);

}

/**************************************************************************
* NAME : _init
* DESCRIPTION : load entry point
* PARAMETERS :
* RETURN : mod_install return code 
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
int _init(void)
{
   int iError;
   word wCount;

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [_init]: entry");
#endif

   /* preallocate all the device state managements structures */
   ddi_soft_state_init(&gpvState, sizeof(IphWanDev_t), MAX_CARD);

   /* initialize the global variables */
   iph_gpucTrace = (byte *)0;
   for (wCount = 0; wCount < 256; wCount++)
      iph_gpucTraceMask[wCount] = FALSE;

#ifdef DEBUG_START
    iph_gpucTraceMask[IPHWAN_ID] = TRUE;
#endif

   MUTEX_INIT(&gAccessMutex, "IphWan global mutex", MUTEX_DRIVER, (void *)0);
   iph_gbAttachedCard = 0;
   iph_gvInitQueue(&gWanDevQueue);
   gwNbAppli = 0;
   for (wCount = 0; wCount < TOTAL_APPLI; wCount++)
      gpAppliMinor[wCount] = (ApplCtxtPtr)0;

   /* export entry points and characteristics */
   iError = mod_install(&gModlinkage);

   if (iError != 0)
   {
#ifdef DEBUG_INIT
      iph_TRACEK(TRCLVL_2, DRIVER_NAME" [_init]: mod_install failed with error %d",
                 iError);
#endif
      ddi_soft_state_fini(&gpvState);
   }

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [_init]: exit");
#endif

   return(iError);
}

/**************************************************************************
* NAME : _info
* DESCRIPTION : load entry point
* PARAMETERS :
*    Input   : modinfop
* RETURN : mod_info return code 
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
int _info(struct modinfo *modinfop)
{
   return(mod_info(&gModlinkage, modinfop));
}

/**************************************************************************
* NAME : _fini
* DESCRIPTION : unload entry point
* PARAMETERS :
* RETURN : mod_remove return code 
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
int _fini(void)
{
   int iError;
   void *pTraceHead;

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [_fini]: entry");
#endif

   /* remove entry points and characteristics */
   iError = mod_remove(&gModlinkage);

   if (iError == 0)
   {
      /* if the trace are active, we must destroy the mutex and release */
      /* the trace buffer */
      if (iph_gpucTrace != (byte *)0)
      {
         MUTEX_DESTROY(&iph_gTraceMutex);
         pTraceHead = (void *)iph_gpucTrace;
         iph_gpucTrace = NULL;
         TMP_FREE(pTraceHead);
      }

      MUTEX_DESTROY(&gAccessMutex);

      /* release all the device state managements structures */
      ddi_soft_state_fini(&gpvState);

   }

#ifdef DEBUG_INIT
   iph_TRACEK(TRCLVL_2, DRIVER_NAME" [_fini]: exit");
#endif

   return(iError);
}
#endif


