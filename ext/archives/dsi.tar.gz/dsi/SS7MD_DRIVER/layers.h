/****************************************************************************
 * NAME : layers.h
 * VERSION : 2.11
 * DESCRIPTION : References of all kinds of WanOS modules
 * REVISIONS :
 *    - Version 1.0 01/27/97 : Creation
 *    - Version 1.1 09/07/99 : Add new reference : REF_DM
 *                             Add PPP_PRIM, FR_PRIM ... definitions
 *    - Version 1.1 11/17/99 : Add LS_PRIM definition
 *    - Version 1.2 11/26/99 : Add ATM, LLC2 and XLA definitions
 *    - Version 1.3 03/16/00 : Add MTP2 definitions
 *    - Version 2.0 05/28/01 : Add Switcher layer definitions
 *    - Version 2.1 09/24/01 : Add AAL2 layers definitions
 *    - Version 2.2 06/07/02 : Add Ethernet layer definitions
 *    - Version 2.3 10/01/02 : Add IP, IoIP, SYS layers definitions
 *    - Version 2.4 12/02/02 : Add LAPD, SSCF, SSCOP layers definitions
 *    - Version 2.5 05/03/04 : Add M2PA layer definitions
 *    - Version 2.6 02/22/05 : Add IP and M2UA layer definitions
 *    - Version 2.7 01/27/06 : Add iTDM layer definitions
 *    - Version 2.8 04/17/07 : Add TRDA driver definitions
 *    - Version 2.9 09/14/07 : Add CAS and ISDNI layers definitions 
 *    - Version 2.10 09/25/07 : rename ISDNB to ISDNLB
 *    - Version 2.11 03/04/08 : Add BASE_REF_ISDNL3.
 ****************************************************************************/

#ifndef LAYERS_H
#define LAYERS_H

/* Protocol layers : references between 0x0010 and 0x003F */

#define  REF_ISDN                   0x0010   /* ISDN layer */
#define  REF_LAPB                   0x0011   /* LAPB layer */
#define  BASE_REF_x25               0x0012   /* X25 base layer */
#define  REF_x25                    0x0013   /* X25 multiplexed layer */
#define  BASE_REF_PPP               0x0014   /* PPP base layer */
#define  REF_PPP                    0x0015   /* PPP multiplexed layer */
#define  BASE_REF_XLA               0x0016   /* XLA base layer */
#define  REF_XLA                    0x0017   /* XLA multiplexed layer */
#define  REF_S16                    0x0018   /* Sapi 16 ISDN layer */
#define  REF_LS                     0x0019   /* LS module reference */
#define  BASE_REF_FR                0x001A   /* Frame Relay base layer */
#define  REF_FR                     0x001B   /* Frame Relay multiplexed layer*/
#define  BASE_REF_FRLA              0x001C   /* FRLA base layer */
#define  REF_FRLA                   0x001D   /* FRLA multiplexed layer */
#define  REF_MVIP                   0x001F   /* MVIP layer */
#define  BASE_REF_LLC2              0x0020   /* 802.2 base layer */
#define  REF_LLC2                   0x0021   /* 802.2 multiplexed layer */
#define  REF_DM                     0x0022   /* DM layer */
#define  REF_DDS                    0x0023   /* DDS layer */
#define  REF_ATM                    0x0024   /* ATM layer */
#define  REF_MTP2                   0x0025   /* MTP2 layer */
#define  REF_SWF                    0x0026   /* Switcher layer */
#define  BASE_REF_AAL2              0x0027   /* AAL2 base layer */
#define  REF_AAL2                   0x0028   /* AAL2 multiplexed layer */
#define  REF_ETH                    0x0029   /* Ethernet layer */
#define  BASE_REF_LAPD              0x002A   /* LAPD base layer */
#define  REF_LAPD                   0x002B   /* LAPD multiplexed layer */
#define  REF_SSCF                   0x002C   /* SSCF layer */
#define  REF_SSCOP                  0x002D   /* SSCOP layer */
#define  REF_M2PA                   0x002E   /* M2PA layer */
#define  REF_IWIP                   0x002F   /* IP iWARE interface */
#define  REF_M2UA                   0x0030   /* M2UA layer */
#define  REF_ITDM                   0x0031   /* ITDM layer */
#define  REF_TRDA                   0x0032   /* driver TRDA */
#define  REF_ISDNL3                 0x0033   /* ISDNL3 layer */
#define  REF_CAS                    0x0034   /* driver CAS */
#define  BASE_REF_ISDNL3            0x0035   /* ISDNL3 layer */

/* Clients : references between 0x0040 a 0x005F */

#define  REF_SV6                    0x0040   /* WanOS client */
#define  REF_IP                     0x004B   /* IP layer */
#define  REF_IOIP                   0x004C   /* iWARE over IP layer */
#define  REF_SNMPA                  0x004D   /* SNMP Agent over IP module  */
#define  REF_M2UAIW                 0x004E   /* M2UA interworking layer */
#define  REF_ITDMIW                 0x004F   /* ITDM interworking layer */
#define  REF_ISDNLB                 0x0050   /* ISDNLB */
#define  REF_ISDNI                  0x0051   /* ISDNI user module          */

/* Link manager reference */
#define  REF_SYS                    0x007F

/* Protocol layers: specialized primitives discriminators */
#define  PPP_PRIM                   (REF_PPP << 8)    /* PPP               */
#define  FR_PRIM                    (REF_FR << 8)     /* Frame Relay       */
#define  MVIP_PRIM                  (REF_MVIP << 8)   /* MVIP              */
#define  DM_PRIM                    (REF_DM << 8)     /* Digital Modem     */
#define  DDS_PRIM                   (REF_DDS << 8)    /* DDS               */
#define  ISDN_PRIM                  (REF_ISDN << 8)   /* ISDN              */
#define  LS_PRIM                    (REF_LS << 8)     /* LS                */
#define  MTP2_PRIM                  (REF_MTP2 << 8)   /* MTP2              */
#define  ATM_PRIM                   (REF_ATM << 8)    /* ATM               */
#define  SSCF_PRIM                  (REF_SSCF << 8)   /* SSCF              */
#define  SSCOP_PRIM                 (REF_SSCOP << 8)  /* SSCOP             */
#define  M2PA_PRIM                  (REF_M2PA << 8)   /* M2PA              */
#define  IWIP_PRIM                  (REF_IWIP << 8)   /* IWIP              */
#define  M2UA_PRIM                  (REF_M2UA << 8)   /* M2UA              */
#define  ITDM_PRIM                  (REF_ITDM << 8)   /* ITDM              */
#define  TRDA_PRIM                  (REF_TRDA << 8)   /* TRDA              */
#define  ISDNL3_PRIM                (REF_ISDNL3 << 8) /* ISDNL3            */
#define  CAS_PRIM                   (REF_CAS << 8)    /* CAS               */


#endif

