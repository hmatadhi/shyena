#!/bin/bash

#######################################################
#
# This file update the following variables:
# MK_BASE, ARCH_KERNEL_BUILDDIR, TARGET_USR_INCDIR
# CROSS_COMPILE in the file config.$ARCH
# for rpm rebuild before calling the makefile
#######################################################
#set -x
CUR_DIR=`pwd`
KERNEL_VER=`uname -r`
BUILD_FOR_RUNNING=/lib/modules/$KERNEL_VER/build
BUILD_SRC_LINUX=/usr/src/linux
BUILD_STD=/usr

ARCH=`uname -m | sed -e s/i.86/intel/ \
                              -e s/x86_64/intel/      \
                              -e s/i*86/intel/      \
                              -e s/*pentium*/intel/ \
                              -e s/sun4u/sparc64/ \
                              -e s/arm.*/arm/ \
                              -e s/sa110/arm/`
                               
# Determine the Linux version
LINUX_VERSION=`echo $KERNEL_VER | awk -F . '
   {
      if ( $1 == 2 && $2 == 4 )
      {
         print "2.4"
      }
      if ( $1 == 2 && $2 == 6 )
      {
         print "2.6"
      }
      if ( $1 == 3 )
      {
         print "3.x"
      }
   }'`

case "$LINUX_VERSION" in
  "3.x")
    # General SDS makefile
    rm Makefile >& /dev/null
    cp Makefile_2_6 Makefile
    ;;

  "2.6")
    # General SDS makefile
    rm Makefile >& /dev/null
    cp Makefile_2_6 Makefile
    ;;

  "2.4")
   # Kernel 2.4
   # General SDS makefile
   rm Makefile >& /dev/null
   cp Makefile_2_4 Makefile
   ;;

  *)
    echo Unsupported Linux revision $LINUX_VERSION
    exit
esac

#allow write attribute to the file
echo rm config_$ARCH
cp config.$ARCH config_$ARCH

#detect the more apropriate kernel header files
if [ -d $BUILD_FOR_RUNNING ]
then
  KERNEL_BUILD=$BUILD_FOR_RUNNING
else 
  if [ -d $BUILD_SRC_LINUX ]
  then 
    KERNEL_BUILD=$BUILD_SRC_LINUX
  else
    echo "Build failed -> kernel header files not found (\"$BUILD_FOR_RUNNING\" or \"$BUILD_SRC_LINUX\")"
    exit -1
  fi
fi


#update the field ARCH_KERNEL_BUILDDIR= 
########################################
echo "$KERNEL_BUILD"  |  awk '{ gsub("/", "\\/", $1); print $1}' > tmp-1
KERNEL_BUILD=`cat tmp-1`
cp config_intel tmp-1
sed -e "s/ARCH_KERNEL_BUILDDIR=/ARCH_KERNEL_BUILDDIR= $KERNEL_BUILD/g" tmp-1 > tmp-2
cp tmp-2 config_intel
cp tmp-2 kernel 

#update the field  TARGET_USR_INCDIR 
########################################
USR_INCLUDE=`echo '\/usr\/include'`
cp config_intel tmp-1
sed -e "s/TARGET_USR_INCDIR=/TARGET_USR_INCDIR= $USR_INCLUDE/g" tmp-1 > tmp-2
cp tmp-2 config_intel
cp tmp-2 usr 

#detect the right path off the compiler 
########################################
COMPILER_PATH=`whereis gcc  | awk '{  print $2 }'`
echo "$COMPILER_PATH"  |  awk '{ gsub("/", "\\/", $1); print $1}' > tmp-1
COMPILER_PATH=`cat tmp-1`
cp config_intel tmp-1
sed -e "s/CROSS_COMPILE=/CROSS_COMPILER= $COMPILER_PATH/g" tmp-1 > tmp-2
sed -e '/^CROSS_COMPILE/s/\/gcc//' tmp-2 > tmp-3 
cp tmp-3 config_intel

#Build the Driver
#######################################
make IPHARCH=intel $1

exit 0

