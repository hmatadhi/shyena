/****************************************************************************
*  (C) Copyright Interphase Corp 2005-2010.
*
* NAME : ppcperf.c
* VERSION : 1.12.4.3
*
* DESCRIPTION : 
*    Procedures to monitor the local processor
*
* FUNCTIONS LIST :
*    Local functions :
*       bAdapterSemTake_PQ3
*       vAdapterSemGive_PQ3
*       Mpc856xI2cAck
*       Mpc856xI2cStop
*       Mpc856xI2cStart
*       Mpc856xI2cRestart
*       Mpc856xI2cReset
*       Mpc865xDataWrite
*
*    Public functions :
*       drv_gdwAdapterSerialNum_PQ3
*       drv_gdwAdapterBoardEquipReg_PQ3
*       drv_gbAdapterRev_PQ3
*       drv_gvSearchWorkingArea
*       drv_gbCheckCardStatus_PQ3
*       drv_gdwI2CByteRead_PQ3
*       drv_gdwI2CByteWrite_PQ3
*
* REVISIONS :
*    - Version 1.00 10/04/05 : Creation
*    - Version 1.01 02/06/06 : Add drv_gbAdapterRev_PQ3 routine
*    - Version 1.02 02/14/06 : Remove message when card is found ready but 
*      pools are not initialized
*    - Version 1.03 03/14/06 : Ignore low bits in MSGR1 when getting DRAM size
*    - Version 1.04 05/02/06 : Fix the eeprom semaphore acquisition procedure
*    - Version 1.05 09/13/06 : Reset the I2C state machine before accessing
*                              the EEPROM
*    - Version 1.06 12/20/06 : drv_gvSearchWorkingArea: Get the working area 
*                              location from the exchange memory instead of
*                              scanning the card memory
*                              Suppress Linux compilation warnings
*    - Version 1.07 01/16/07 : drv_gvSearchWorkingArea supports both old 
*                              (pattern search) and new method (address located
*                              in the exchange memory)
*    - Version 1.08 07/19/07 : Add the customer information retrieval
*                              Change the AdapterSerialNum prototype
*    - Version 1.09 08/13/07 : Check that the custom information is a string
*    - Version 1.10 08/11/08 : Custom info offset and size are retrieved from
*                              the card resource
*    - Version 1.11 10/16/08 : If Serial Number is 1, displays Custom info 
*    - Version 1.12 01/30/09 : Log the POST value when non zero value is 
*                              detected
*                              Log the CodeReady field value when wrong value
*                              is detected
*    - Version 1.12.1 02/12/09 : Log the bad signature or bad interface offset
*                              only if card status > CARD_RESET
*    - Version 1.12.2 04/03/09 : drv_gbCheckCardStatus_PQ3 shutdowns the 
*                              adapter if new status is <= CARD_RESET and not
*                              only = CARD_RESET
*    - Version 1.12.3 05/13/09 : 
*         - Add the LM75 sensor device access routine
*         - I2C device access routine become generic
*    - Version 1.12.4 05/29/09 : 
*         - Add the temperature sensor checking process in the 
*           CheckCardStatus function
*    - Version 1.12.4.1 06/29/10 : 
*         - Take the I2C bus semaphore before accessing the temperature sensor
*         - Peterson's algorithm implementation for accessing the i2c bus
*    - Version 1.12.4.2 07/05/10 : 
*         - Take/Release the I2C bus semaphore at each byte I2C bus access
*         - Add the i2c byte write access function
*         - Swap data on register Read/Write access when dealing with the
*           i2c bus access semaphore
*    - Version 1.12.4.3 07/09/10 : 
*         - Fix the i2c SemTake timeout management
*    - Version x.xx.x.x 12/05/11 :
*         - Dont process temperature values of 127
*    - Version x.xx.x.x 04/09/13 :
*         - Increase error checking on I2C acccesses
*    - Version x.xx.x.x 05/09/13 :
*         - Ignore the TOS reading from the thermal sensor (default to 90)
*         - Only use the over temperature reading if seen 'n' times
****************************************************************************/
#define PPCPERF_C
#include "iphwan.h"
#include "iphwantr.h"
#include "ppcperf.h"
#include "cfgflash.h"
#include "iphtrace.h"
#include "iphmsys.h"


#define TMP_SIZE  1024

/* Signature of the beginning of working area */
#define SYNMTR_SIGNATURE            "###SynMTR###"

/* First character of signature */
#define SYNMTR_SIGNATURE_FIRST_CHAR '#'

#define MAX(a,b)     (((a) > (b) ) ? (a) : (b))
#define MIN(a,b)     (((a) < (b) ) ? (a) : (b))

#define MPC856X_LOOP_DELAY 1000
#define SEE_SEM_HOST_TAG   0x00000004
#define SEE_SEM_BOARD_TAG  0x00000002
#define SEE_SEM_TAG_MASK   (SEE_SEM_HOST_TAG | SEE_SEM_BOARD_TAG)
#define SEE_SEM_TAKE_BIT   0x00000001
#define SEE_SEM_BY_HOST    (SEE_SEM_HOST_TAG | SEE_SEM_TAKE_BIT)
#define SEE_SEM_BY_BOARD   (SEE_SEM_BOARD_TAG | SEE_SEM_TAKE_BIT)

static unsigned char i2c_device = 0;

static byte bAdapterSemTake_PQ3(IphWanDevPtr pDev)
{
   dword semVal;
   dword BoardWant, Turn;
   int maxRetry = 1000;

   /* Only one thread can access the I2C hardware semaphore */
   MUTEX_ENTER(&pDev->I2CMutex);

   /* Find which method to use */
   pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION], MPC856X_MSGR3, &semVal);
   if ( (HOST_CORE32(semVal) & PETERSON_PATTERN_MASK) == PETERSON_ALGORITHM )
   {
      /* Peterson's algorithm implementation */
      pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION], I2C_SEM_HOST_WANT, HOST_CORE32(I2C_SEM_ENTER));
      pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION], I2C_SEM_TURN_ID  , HOST_CORE32(I2C_SEM_BOARD_ID));

      do
      {
         pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION], I2C_SEM_BOARD_WANT, &BoardWant);
         pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION], I2C_SEM_TURN_ID   , &Turn);
      }
      while ( ((HOST_CORE32(BoardWant) & 0x1) == I2C_SEM_ENTER) &&
              ((HOST_CORE32(Turn) & 0x1) == I2C_SEM_BOARD_ID)   &&
              (--maxRetry > 0) );

      if ( maxRetry == 0 )
      {
         /* The semaphore is not acquired */
         pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION], I2C_SEM_HOST_WANT, HOST_CORE32(I2C_SEM_EXIT));
         MUTEX_EXIT(&pDev->I2CMutex);
         return(FALSE);
      }

      return(TRUE);
   }
   else
   {
      while (maxRetry-- > 0)
      {
         /* SEEPROM semaphore is bit 3 to 5 and should be equal to 2 */
         pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],
                                              MPC856X_MSGR3, &semVal);
         semVal = HOST_CORE32(semVal);
         switch (semVal & (SEE_SEM_TAG_MASK | SEE_SEM_TAKE_BIT))
         {
            case SEE_SEM_BY_HOST:
               return(TRUE);
            case SEE_SEM_BY_BOARD:
               break;
            default:
               semVal |= SEE_SEM_BY_HOST;
               pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION],
                                                     MPC856X_MSGR3, HOST_CORE32(semVal));
               pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],
                                                    MPC856X_MSGR3, &semVal);
               if ((HOST_CORE32(semVal) & (SEE_SEM_TAG_MASK | SEE_SEM_TAKE_BIT)) ==
                   SEE_SEM_BY_HOST)
               {
                  return(TRUE);
               }
               break;
         }
         UDELAY(10);
      }
      MUTEX_EXIT(&pDev->I2CMutex);
      return(FALSE);
   }
}

static void vAdapterSemGive_PQ3(IphWanDevPtr pDev)
{
   dword semVal;

   /* Release the hardware semaphore following the original method */
   pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],
                                        MPC856X_MSGR3, &semVal);
   semVal = HOST_CORE32(semVal);
   semVal &= ~(SEE_SEM_TAG_MASK | SEE_SEM_TAKE_BIT);
   pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION],
                                         MPC856X_MSGR3, HOST_CORE32(semVal));

   /* Release the hardware semaphore following the Peterson method */
   pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION], I2C_SEM_HOST_WANT, HOST_CORE32(I2C_SEM_EXIT));

   /* Release the global I2C access semaphore */
   MUTEX_EXIT(&pDev->I2CMutex);
}

static int Mpc856xI2cAck(IphWanDevPtr pDev) 
{
   unsigned short i;
   unsigned char v;

   for (i=0; i<MPC856X_LOOP_DELAY; i++)
   {
      UDELAY(10);
      pDev->Region[CORE_REGION].Ops.read8(&pDev->Region[CORE_REGION],
                                          MPC856X_I2CSR, &v);
      /* check the MFC bit for transfert completed */
      if (v & 0x80)
         break;
   }

   if (i == MPC856X_LOOP_DELAY)
   {
      iph_TRACEK(TRCLVL_0, "dev %d: Timeout on End of Transfer Polling - Ack", pDev->Index);
      return(-1);
   }
   if (v & 1)
   {
      return(1);
   }
   return(0);
}

static void Mpc856xI2cReset(IphWanDevPtr pDev)
{
   UDELAY(10);
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                        MPC856X_I2CCR, (0x00));
   UDELAY(100);
}

static void Mpc856xI2cStop(IphWanDevPtr pDev)
{
   UDELAY(10);
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                        MPC856X_I2CCR, (0x90));
}

static void Mpc856xI2cStart(IphWanDevPtr pDev)
{
   UDELAY(10);
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                        MPC856X_I2CCR, (0xB0));
}

static void Mpc856xI2cRestart(IphWanDevPtr pDev)
{
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                        MPC856X_I2CCR, (0xB4));
   UDELAY(10);
}   

static int Mpc865xDataWrite(IphWanDevPtr pDev, unsigned char data)
{
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                        MPC856X_I2CDR, data);
   UDELAY(10);
   return(Mpc856xI2cAck(pDev));

}

/**************************************************************************
* NAME : drv_gdwI2CByteRead_PQ3
* DESCRIPTION : read a byte from an I2C device of the PQ3
* PARAMETERS :
* RETURN : 
*    0  if success
*    -1 if failure
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static int drv_gdwI2CByteRead_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte *pdata)
{
   unsigned short i;
   byte bSemaphore, MaxRetry = 0;
   int res;

   do
   {
      bSemaphore= bAdapterSemTake_PQ3(pDev);
      MaxRetry++;
   }while ((bSemaphore == FALSE) && (MaxRetry < 100));

   if (bSemaphore == TRUE)
   {
      res = 0;

      /* Reset the I2C state machine */
      Mpc856xI2cReset(pDev);

      /* Wait for first Ack by device */
      Mpc856xI2cStop(pDev);
      for (i=0; i<MPC856X_LOOP_DELAY; i++)
      {
         Mpc856xI2cStart(pDev);
         if (!Mpc865xDataWrite(pDev, (I2CAddr + (i2c_device<<1)))) break;
         Mpc856xI2cStop(pDev);
         UDELAY(10);
      }
      if (i==MPC856X_LOOP_DELAY)
      {
         res = -1;
         iph_TRACEK(TRCLVL_0, "Read dev %d: Timeout on ACK I2CAddr=0x%x", pDev->Index, I2CAddr);
      }

      /* MSByte Address*/
      if ( OffSize == 2 )
      {
         if (Mpc865xDataWrite(pDev, (Offset >> 8)) != 0)
         {
            res = -1;
         }
      }

      /* LSByte Address*/
      if (Mpc865xDataWrite(pDev, (Offset & 0xFF)) != 0)
      { 
         res = -1;
      }

      Mpc856xI2cRestart(pDev);

      /* Read Command*/
      if (Mpc865xDataWrite(pDev, (I2CAddr + 1 + (i2c_device<<1))))
      {
         res = -1;
         iph_TRACEK(TRCLVL_0, "Read dev %d: Expected an Acknowledge here I2CAddr=0x%x\n", pDev->Index, I2CAddr);
      }

      /* Receive - no ack */
      pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                           MPC856X_I2CCR, (0xA8));     

      /* Launches the read*/
      pDev->Region[CORE_REGION].Ops.read8(&pDev->Region[CORE_REGION],
                                          MPC856X_I2CDR, pdata);

      /* Nack for single read.*/
      Mpc856xI2cAck(pDev);

      /* Transmit to avoid next read;*/
      pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],
                                           MPC856X_I2CCR, (0x88));     
      pDev->Region[CORE_REGION].Ops.read8(&pDev->Region[CORE_REGION],
                                          MPC856X_I2CDR, pdata);
      /* Effective data read*/
      Mpc856xI2cStop(pDev);

      vAdapterSemGive_PQ3(pDev);

      return(res);
   }
   else
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" : failed to get semaphore on card %d", pDev->Index);
      return(-1);
   }
}


/**************************************************************************
* NAME : drv_gdwI2CByteWrite_PQ3
* DESCRIPTION : write a byte to an I2C device of the PQ3
* PARAMETERS :
* RETURN : 
*    0  if success
*    -1 if failure
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static int drv_gdwI2CByteWrite_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte data)
{
   unsigned short i;
   byte bSemaphore, MaxRetry = 0;
   int res;

   do
   {
      bSemaphore= bAdapterSemTake_PQ3(pDev);
      MaxRetry++;
   }while ((bSemaphore == FALSE) && (MaxRetry < 100));

   if (bSemaphore == TRUE)
   {
      res = 0;

      /* Reset the I2C state machine */
      Mpc856xI2cReset(pDev);

      /* Wait for first Ack by device */
      Mpc856xI2cStop(pDev);

      for (i=0; i<MPC856X_LOOP_DELAY; i++)
      {
         Mpc856xI2cStart(pDev);
         if (!Mpc865xDataWrite(pDev, (I2CAddr + (i2c_device<<1)))) break;
         Mpc856xI2cStop(pDev);
         UDELAY(10);
      }
      if (i==MPC856X_LOOP_DELAY)
      {
         res = -1;
         iph_TRACEK(TRCLVL_0, "Read dev %d: Timeout on ACK I2CAddr=0x%x", pDev->Index, I2CAddr);
      }

      /* MSByte Address*/
      if ( OffSize == 2 )
      {
         if (Mpc865xDataWrite(pDev, (Offset >> 8)) != 0) 
         {
            res = -1;
         }
      }

      /* LSByte Address*/
      if (Mpc865xDataWrite(pDev, (Offset & 0xFF)) != 0)
      {
         res = -1;
      }

      if (Mpc865xDataWrite(pDev, (data)))
      {
         res = -1;
         iph_TRACEK(TRCLVL_0, "Write dev %d: Expected an Acknowledge here I2CAddr=0x%x\n", pDev->Index, I2CAddr);
      }

      Mpc856xI2cStop(pDev);

      MDELAY(20);

      vAdapterSemGive_PQ3(pDev);

      return(res);
   }
   else
   {
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" : failed to get semaphore on card %d", pDev->Index);
      return(-1);
   }
}


/**************************************************************************
* NAME : drv_gdwAdapterSerialNum_PQ3
* DESCRIPTION : read the serial number and the additional serial number
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gdwAdapterSerialNum_PQ3(IphWanDevPtr pDev)
{
   dword Serial;
   byte  data;
   int i;

   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, CARD_PQ3_SERIAL_H+1, sizeof(word), &data) != 0 )
      goto SerialNumError;
   Serial = data << 8;
   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, CARD_PQ3_SERIAL_H, sizeof(word), &data) != 0 )
      goto SerialNumError;
   Serial += data;
   Serial<<= 8;
   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, CARD_PQ3_SERIAL_L+1, sizeof(word), &data) != 0 )
      goto SerialNumError;
   Serial += data;
   Serial<<= 8;
   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, CARD_PQ3_SERIAL_L, sizeof(word), &data) != 0 )
      goto SerialNumError;
   Serial += data;

   pDev->Serial = Serial; 

   /* Read the customer information */
   for ( i=0; i<pDev->Rsrc->CustInfoSize; i++ )
   {
      if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, pDev->Rsrc->CustInfoOff+i, sizeof(word), (byte *)&(pDev->CustInfo[i])) != 0 )
         goto SerialNumError;
   }
   /* Check that the custom info format is a string */
   for ( i = 0;
         (i < pDev->Rsrc->CustInfoSize) && (pDev->CustInfo[i] != 0);
         i++ )
   {
      if ( (pDev->CustInfo[i] < ' ') || (pDev->CustInfo[i] > '}') )
      {
         /* Wrong string format ==> return a null string instead */
         pDev->CustInfo[0] = 0;
         break;
      }
   }
   if ( i == pDev->Rsrc->CustInfoSize )
   {
      /* Wrong string format ==> return a null string instead */
      pDev->CustInfo[0] = 0;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwAdapterSerialNum_PQ3] : return (Serial number)\n");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, Serial);
#endif
   if (Serial == 1 && pDev->CustInfo[0] != 0)
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" : found card %d - type 0x%x - SN %s", 
                 pDev->Index, pDev->Type, pDev->CustInfo);
   else
      iph_TRACEK(TRCLVL_0, DRIVER_NAME" : found card %d - type 0x%x - SN %d", 
                 pDev->Index, pDev->Type, Serial);
   if (pDev->Rsrc != NULL)
      iph_TRACEK(TRCLVL_0, "         type 0x%x => %s", 
                 pDev->Type, pDev->Rsrc->CardName);

   return;

SerialNumError:
   pDev->Serial = 0; 
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwAdapterSerialNum_PQ3] : Error reading Serial number\n");
#endif
   iph_TRACEK(TRCLVL_0, DRIVER_NAME" : Error reading serial number on card", pDev->Index);

   return;
}

/**************************************************************************
* NAME : drv_gdwAdapterBoardEquipReg_PQ3
* DESCRIPTION : read the Board Equipment Register in the Serial EEPROM for
*               PQ3-based cards
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwAdapterBoardEquipReg_PQ3(IphWanDevPtr pDev, dword Offset)
{
   dword Reg;
   byte  data;
   int   i;

   for (Reg=0, i=sizeof(dword)-1; i>=0; i--)
   {
      Reg <<= 8;
      if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, Offset+i, sizeof(word), &data) != 0 )
         goto BER_Error;
      Reg += data;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwAdapterBoardEquipReg_PQ3] : return (BER content)\n");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, Reg);
#endif
   return(Reg);

BER_Error:
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gdwAdapterBoardEquipReg_PQ3] : Error reading BER\n");
#endif
   iph_TRACEK(TRCLVL_0, DRIVER_NAME" : Error reading BER on card", pDev->Index);
   return(0);
}

/**************************************************************************
* NAME : drv_gbAdapterRev_PQ3
* DESCRIPTION : read the revision number in the Serial EEPROM for
*               PQ3-based cards
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static byte drv_gbAdapterRev_PQ3(IphWanDevPtr pDev)
{
   byte bRev;

   if (drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, 0x10B, sizeof(word), &bRev) != 0)
      goto AdapterRevError;

   if (bRev == 'X')
   {
      if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_SEEPROM_ADDR, 0x10C, sizeof(word), &bRev) != 0)
         goto AdapterRevError;
   }

   if (bRev == 0xFF)
      bRev = 0;
   else
      bRev -= 'A';

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gbAdapterRev_PQ3] : return\n");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, bRev);
#endif
   return(bRev);

AdapterRevError:
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gbAdapterRev_PQ3] : Error reading Adapter revision\n");
#endif
   iph_TRACEK(TRCLVL_0, DRIVER_NAME" : Error reading Adapter revision on card", pDev->Index);
   return(0);

}

/**************************************************************************
* NAME : drv_gbCurTemp
* DESCRIPTION : read the current temperature
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 05/15/09 Creation
**************************************************************************/
static byte drv_gbCurTemp(IphWanDevPtr pDev)
{
   byte Temp;

   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_LM75_ADDR, LM75_TEMP_ADDR, sizeof(byte), &Temp) != 0)
      goto CurTempError;
   Temp &= 0x7F;

   return(Temp);

CurTempError:
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gbCurTemp] : Error reading current temperature\n");
#endif
   iph_TRACEK(TRCLVL_0, DRIVER_NAME" : Error reading current temperature on card", pDev->Index);
   return(0);
}

/**************************************************************************
* NAME : drv_gbTOS
* DESCRIPTION : read the TOS temperature value
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 05/15/09 Creation
**************************************************************************/
static byte drv_gbTOS(IphWanDevPtr pDev)
{
   byte Temp;

   if ( drv_gdwI2CByteRead_PQ3(pDev, I2C_LM75_ADDR, LM75_TOS_ADDR, sizeof(byte), &Temp) != 0)
      goto TOSError;
   Temp &= 0x7F;

   return(Temp);

TOSError:
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gbTOS] : Error reading TOS temperature\n");
#endif
   iph_TRACEK(TRCLVL_0, DRIVER_NAME" : Error reading TOS temperature on card", pDev->Index);
   return(0xFF);
}

/**************************************************************************
* NAME : drv_gvSearchWorkingArea
* DESCRIPTION : search in DRAM the position of the local processor working
*               area; it is found by searching its signature : ###SynMTR###
* PARAMETERS :
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvSearchWorkingArea(IphWanDevPtr pDev)
{
   dword ulCurrAdd;
   dword ulEndAdd;
   dword ulLengthRead;
   byte *Ptr;
   dword ulCurrIndex;
   dword ulFoundIndex;
   byte pucTmpBuffer[TMP_SIZE];
   word wCount; 
   DevRegionPtr RegPtr = &pDev->Region[MEM_REGION];


   /* Get the working area location from the exchange memory */
   READ_EXCH_WORKING_AREA_PTR(pDev, pDev->ExchArea, &ulCurrAdd);
   if ( ulCurrAdd != 0 )
   {
      pDev->ProcAreaStart = OFFSET_CARD_TO_HOST(ulCurrAdd);
   }
   else
   {
      /* Search begins at the beginning of code*/
      READ_MEM_DWORD(pDev, EXCH_AREA_ADDR_INDX, &ulCurrAdd);
      ulCurrAdd = OFFSET_CARD_TO_HOST(ulCurrAdd);

      /* Search ends at the end of code (ie. begin of heap) */
      READ_EXCH_HEAP_START_PTR(pDev, pDev->ExchArea, &ulEndAdd);
      ulEndAdd = OFFSET_CARD_TO_HOST(ulEndAdd);

      /* For all the memory containing the code */
      while (ulCurrAdd < (ulEndAdd - strlen(SYNMTR_SIGNATURE)))
      {
         /* Compute the size of memory to read and tranfer it into the buffer */
         ulLengthRead = (dword)MIN(TMP_SIZE, ulEndAdd - ulCurrAdd);

         /* read some data */
         RegPtr->Ops.readbuf(RegPtr, ulCurrAdd, ulLengthRead, pucTmpBuffer);

         ulCurrIndex = 0UL;
         while (ulCurrIndex < (ulLengthRead - strlen(SYNMTR_SIGNATURE)))
         {
            /* Search the first char of the string in the buffer */
            Ptr = (byte *)0;
            for (wCount = 0;
                wCount < ulLengthRead - ulCurrIndex - strlen(SYNMTR_SIGNATURE);
                wCount++)
            {
               if (pucTmpBuffer[ulCurrIndex + wCount] ==
                   SYNMTR_SIGNATURE_FIRST_CHAR)
               {
                  Ptr = &pucTmpBuffer[ulCurrIndex + wCount];
                  break;
               }
            }
            if (Ptr == (byte *)0)
            {
               /* The char does not exist in the buffer, so prepare to read the*/
               /* next one */
               ulCurrAdd += ulLengthRead - ulCurrIndex -
                            strlen(SYNMTR_SIGNATURE);

               /* Get out of the inner loop */
               ulCurrIndex = TMP_SIZE;
            }
            else
            {
               ulFoundIndex = (dword)(Ptr - pucTmpBuffer);

               /* Check if the complete pattern is present */
               if (memcmp(&pucTmpBuffer[ulFoundIndex],
                          SYNMTR_SIGNATURE,
                          strlen(SYNMTR_SIGNATURE)) == 0)
               {
                  /* Ok, we found it, compute the address and return it */
                  ulCurrAdd += ulFoundIndex - ulCurrIndex;

                  pDev->ProcAreaStart = OFFSET_CARD_TO_HOST(ulCurrAdd);

                  /* Note : return at the middle of the function is not very */
                  /* good!!! */
                  return;
               }
               else
               { /* Not found */
                  /* Update index and pointer to remember what is already */
                  /* examined */
                  ulCurrAdd += ulFoundIndex - ulCurrIndex + 1;
                  ulCurrIndex = ulFoundIndex + 1;
               }
            }
         }
      }

   }
}

/**************************************************************************
* NAME : drv_gbCheckCardStatus_PQ3
* DESCRIPTION : check whether the firmware is loaded and/or configured
* PARAMETERS :
*    Input  : pLock = protection against interrupts from this device
*    Input  : pDev = pointer to the device context
* RETURN : CARD_RESET, CARD_LOADED, or CARD_RUNNING
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static byte drv_gbCheckCardStatus_PQ3(kmutex_t *pLock, IphWanDevPtr pDev)
{
   dword dwVal;
   dword dwOffset;
   dword pExch;
   byte bNewStatus = CARD_RESET;
   byte bVal;

   IPH_LOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gbCheckCardStatus_PQ3] entry (Index - Status)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->Status);
#endif

   /* if serial number not got yet, retry to get it */
   if (pDev->SerialNumberRead == FALSE)
   {
      if (pDev->Serial == 0)
      {
         pDev->SerialNumberRead = FALSE;
      }
      else
      {
         pDev->SerialNumberRead = TRUE;
      }
   }

   /* Check the current temperature if necessary */
   if ( pDev->TempSensorPresent && (pDev->Status != CARD_UNAVAILABLE) )
   {
      if ( pDev->TempSensorPresent == TEMP_CHECK_CYCLES_NB )
      {
         pDev->StopThreshold = 90 - STOP_MARGIN;
         /*
          * Read the current temperature
          * If we are over temp for the 'n'th time in a row keep the result
          * else tell the user but ignore it
          */
         bVal = iph_gbCurTemp(pDev);
         if (bVal >= pDev->StopThreshold)
         {
            if (++pDev->ThermalCount < 3)
            {
              iph_TRACEK(TRCLVL_0,
                       DRIVER_NAME": device %d reports %i.%i",
                       pDev->Index,
                       bVal, pDev->ThermalCount);
                bVal = pDev->CurTemp;
            }
         }
         else
         {
            pDev->ThermalCount = 0;
         }
         pDev->CurTemp = bVal;

         /* Shutdown the card if the temperature threshold is reached */
         if ( pDev->CurTemp >= pDev->StopThreshold )
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gbCheckCardStatus_PQ3]!!!!! Card too hot !!!!!");
            iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pDev->Index);
#endif
            iph_TRACEK(TRCLVL_0,
                       DRIVER_NAME": device %d is too hot (%i >= %i) ! => the card becomes unavailable",
                       pDev->Index,
                       pDev->CurTemp,
                       pDev->StopThreshold);

            IPH_UNLOCK(pLock);
            iph_gvShutdownAdapter(NULL, pDev, CARD_UNAVAILABLE);
            pDev->Status = CARD_UNAVAILABLE;
            return(CARD_UNAVAILABLE);
         }

         /* Reset the cycle counter */
         pDev->TempSensorPresent = 1;
      }
      else
         pDev->TempSensorPresent++;
   }

   /* if the card is in WATCHDOG, it needs to be externally reset */
   /* => don't check the status */
   if (pDev->Status == CARD_WATCHDOG)
   {
      IPH_UNLOCK(pLock);
      return(CARD_WATCHDOG);
   }

   /* check whether the card is in reset */
   if (pDev->Rsrc->IsCardInReset(pDev) == TRUE)
   {
      if (pDev->Status != CARD_RESETTING)
      {
         iph_TRACEK(TRCLVL_0, 
                    DRIVER_NAME": CheckCardStatus about to access a reset card (ControlAppli=0x%x)", 
                    (dword)(unsigned long)pDev->ControlAppli);
         bNewStatus = CARD_POST_FAILED;
      }
      else
      {
         bNewStatus = pDev->Status;
      }
   }
   else
   {
      if (pDev->Status == CARD_POST_FAILED || pDev->Status == CARD_RESET)
      {
         /* check POST result again */
         READ_CORE_DWORD(pDev, MPC856X_MSGR2, &dwVal);
         if (dwVal == 0)
         {
            bNewStatus = CARD_RESET;
            /* get DRAM size in MSGR1 */
            READ_CORE_DWORD(pDev, MPC856X_MSGR1, &dwVal);
            if (dwVal != 0xFFFFFFFF &&
                (dwVal & 0xFFFFFF00)> pDev->Region[MEM_REGION].MaxSize)
               pDev->Region[MEM_REGION].MaxSize = (dwVal & 0xFFFFFF00);
         }
         else
         {
            iph_TRACEK(TRCLVL_0,
                    "POST failed detected for dev %d - POST result 0x%08X",
                    pDev->Index, dwVal);
            bNewStatus = CARD_POST_FAILED;
         }
      }
      /* check interface status only if POST OK */
      if (bNewStatus != CARD_POST_FAILED)
      {
         /* first get the exchange area address*/
         READ_MEM_DWORD(pDev, EXCH_AREA_ADDR_INDX, &dwOffset);
         dwOffset = OFFSET_CARD_TO_HOST(dwOffset);

#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gbCheckCardStatus_PQ3] start of exchange (offset)");
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwOffset);
#endif
         if ((dwOffset % sizeof(dword)) == 0 &&
             dwOffset < pDev->Region[MEM_REGION].WinSize)
         {
            pExch = dwOffset;

            /* check interface signature */
            READ_EXCH_INTF_SIGN(pDev, pExch, &dwVal);
            if (dwVal == INTF_SIGNATURE)
            {
               READ_EXCH_CODE_READY(pDev, pExch, &dwVal);
               if (dwVal == CODE_RDY)
               {
                  READ_EXCH_CONFIG_STATUS(pDev, pExch, &dwVal);

                  if (dwVal == CFG_OK)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gbCheckCardStatus_PQ3] : config successfully loaded");
#endif
                     bNewStatus = CARD_RUNNING;
                  }
                  else
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gbCheckCardStatus_PQ3] : read config status");
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwVal);
#endif
                     bNewStatus = CARD_LOADED;
                  }
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gbCheckCardStatus_PQ3] : read bad CodeReady");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwVal);
#endif
                  if (bNewStatus != pDev->Status)
                  {
                     iph_TRACEK(TRCLVL_0, 
                                DRIVER_NAME" read bad CodeReady for dev %d - value 0x%08X",
                                pDev->Index, dwVal);
                  }
               }
            }
            else
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gbCheckCardStatus_PQ3] bad signature");
#endif
               if (bNewStatus != pDev->Status && pDev->Status > CARD_RESET)
               {
                  iph_TRACEK(TRCLVL_0,
                             DRIVER_NAME" read bad signature for dev %d",
                             pDev->Index);
               }
            }
         }
         else
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gbCheckCardStatus_PQ3] exchange area offset OUT OF RANGE");
#endif
            if (bNewStatus != pDev->Status && pDev->Status > CARD_RESET)
            {
               iph_TRACEK(TRCLVL_0,
                          DRIVER_NAME" exchange area offset OUT OF RANGE for dev %d",
                          pDev->Index);
            }
         }
      }

   }

   if (bNewStatus != pDev->Status)
   {
      /* if card is reset, reset the device context */
      /*if (bNewStatus == CARD_RESET)*/
      if (bNewStatus <= CARD_RESET)
      {
         /*iph_gvShutdownAdapter(NULL, pDev, CARD_RESET);*/
         iph_gvShutdownAdapter(NULL, pDev, bNewStatus);
      }
      /* end initialization if new status is CARD_RUNNING BUT last */
      /* status is NOT CARD_LOADED (or else end of init is done twice) */
      if ((bNewStatus == CARD_LOADED) || 
          (bNewStatus == CARD_RUNNING && pDev->Status != CARD_LOADED))
      {
         pDev->OpenPrimToDo = TRUE;
      }
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gbCheckCardStatus_PQ3] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, bNewStatus);
#endif

   return(bNewStatus);
}


