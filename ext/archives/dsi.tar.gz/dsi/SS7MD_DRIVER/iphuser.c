/****************************************************************************
 * (C) Copyright Interphase Corp 2005-2010.
 *
 * NAME : iphuser.c
 * VERSION : 1.18.2.1
 * DESCRIPTION : 
 *    Functions to manage the application interface
 * REVISIONS :
 *    - Version 1.00 10/04/05 : Creation
 *    - Version 1.01 03/06/06 :
 *       - in drv_gdwCtlDumpPCIConf/drv_gdwCtlWritePCIConf, if offset
 *         is >= 0x10000, use PCI configuration register for PQ3
 *    - Version 1.02 03/14/06 :
 *       - add a dummy buffer in device context for defaut outbound window 0
 *    - Version 1.03 04/12/06 :
 *       - Update for Solaris
 *       - Use gdwAllocDmaMem/gdwFreeDmaMem to allocate/free DMA buffers
 *       - Use DMA_MEM_ALLOC/DMA_MEM_FREE macros to allocate/free memory 
 *         suitable for access from the card
 *    - Version 1.04 05/23/06 :
 *       - Add mutex protection for access to MEM_REGION to avoid unexpected
 *         window translation
 *    - Version 1.05 07/11/06 :
 *       - If SendPrim fails for a kernel application, do not give back 
 *         the primitive with kd_free
 *       - in drv_gdwCtlInitBufferPool, checks whether InitCount != 1
 *         and set MaxCount >= InitCount
 *       - in drv_gdwInitOnLoadEnd, if OutbDataNb needs to be reduced, add a
 *         log message and reduce InitNumber in buffer pools as needed
 *       - in drv_gdwCtlDumpHostArea, add control on received buffer size
 *       - drv_gdwCtlSetCardStatus(CARD_LOADED) returns error given by 
 *         drv_gdwInitOnLoadEnd
 *       - drv_gdwCtlSetCardStatus(CARD_RUNNING) returns error if current 
 *         status if CARD_RESET
 *       - Use MUTEX_xx and CV_xx macros
 *    - Version 1.06 07/18/06 :
 *       - fix a bug in drv_gdwCtlInitDrvTrace when reallocating a trace buffer
 *         and copying existing traces in new buffer
 *    - Version 1.07 09/13/06 :
 *       - In drv_gdwInitOnLoadEnd, add protection against re-entrancy
 *       - drv_gdwCtlDumpHostArea allows dump by an appli that owns the control
 *       - in drv_gdwCtlSetCardStatus(CARD_LOADED), after drv_gdwInitOnLoadEnd
 *         and update of Status, update CardToHostEchoCount (in case the host
 *         is signaled before the Status is updated, the signal was not acked)
 *       - in drv_gdwCtlRecvPrim, add protection until the primitive is
 *         extracted from the reception queue
 *    - Version 1.08 12/27/2006:
 *      - Suppress many Linux compilation warnings
 *    - Version 1.09 04/03/2007:
 *      - Add the DATA_IND dedicated buffer support (CTL_GIVE_RX_DATA_BUFFER)
 *    - Version 1.10 09/27/2007:
 *      - CTL_GET_CARD_ID returns PCI bus and slot id (Linux only)
 *      - Add support for 32-bit applis on 64-bit systems (Linux 2.6 only)
 *    - Version 1.11 01/07/2008:
 *      - Eliminate compilation warnings on 64-bit systems.
 *    - Version 1.12 06/27/2008:
 *      - Log a system message in case of application memory shortage
 *    - Version 1.13 08/01/2008:
 *      - drv_gdwCtlDumpPool: Add the dump of the primitive pool and the 
 *        buffer descriptor pool
 *    - Version 1.14 09/11/2008:
 *      - drv_gdwInitOnLoadEnd & drv_gdwCtlSetCardStatus: before deleting 
 *        a timer, release any lock
 *    - Version 1.15 01/07/2009:
 *      - limit the number of events notified regarding pb with MAX_RX_QUEUE
 *        (number of events logged is reset on RECV_PRIM)
 *      - New: drv_gdwCtlGetTime and drv_gdwCtlSetHostTimeOffset
 *    - Version 1.16 01/19/2009:
 *      - Timestamps are now 64-bit values instead of 8 byte tables
 *        and timestamp values follow the host representation instead of
 *        the card representation (big endian)
 *    - Version 1.17 01/23/2009:
 *      - Check the adapter status in CtlGetTime and CtlSetHostTimeOffset
 *    - Version 1.18 01/29/2009:
 *      - Add the ULL prefix to every 64-bit constants to allow 64-bit 
 *        timestamp computation on Linux 32-bit kernels
 *      - Remove unused variables
 *    - Version 1.18.1 03/02/2009:
 *      - Manage card access when getting current card time
 *    - Version 1.18.2 05/11/2009:
 *      - Add support for 32-bit applis on 64-bit systems for Linux 2.4
 *      - Add the CARD_UNAVAILABLE status support
 *      - Add the CTL_GET_TEMP_INFO ioctl support
 *    - Version 1.18.2.1 07/02/2010:
 *      - Add the CTL_DUMP_SEEPROM_BYTE and CTL_WRITE_SEEPROM_BYTE
 *        ioctl command support
 *
 * FUNCTIONS LIST :
 *    Local functions :
 *    Public functions :
 *       drv_gdwInitOnLoadEnd
 *       drv_gdwCtlSendPrim
 *       drv_gdwCtlGiveRxPrim
 *       drv_gdwCtlGiveRxBuffer
 *       drv_gdwCtlRecvPrim
 *       drv_gdwCtlMaxRxQueue
 *       drv_gdwCtlMaxRxChain
 *       drv_gdwCtlNoOfDev
 *       drv_gdwCtlGetCardId
 *       drv_gdwCtlFreeControl
 *       drv_gdwCtlDumpMem
 *       drv_gdwCtlWriteMem
 *       drv_gdwCtlDumpReg
 *       drv_gdwCtlWriteReg
 *       drv_gdwCtlDumpPCIConf
 *       drv_gdwCtlWritePCIConf
 *       drv_gdwCtlGetDrvVer
 *       drv_gdwCtlDumpCPUUsage
 *       drv_gdwCtlDumpPool
 *       drv_gdwCtlDumpDrvPool
 *       drv_gdwCtlDumpSeepromByte
 *       drv_gdwCtlWriteSeepromByte
 *       drv_gdwCtlMaxTransferSize
 *       drv_gdwCtlInitPrimPool
 *       drv_gdwCtlInitBufferPool
 *       drv_gdwCtlInitMaxAppli
 *       drv_gdwCtlInitMaxSession
 *       drv_gdwCtlInitDrvTrace
 *       drv_gdwCtlSetDrvTrace
 *       drv_gdwCtlDumpDrvTrace
 *       drv_gdwCtlDumpTrace
 *       drv_gdwCtlGetStatus
 *       drv_gdwCtlSetCardStatus
 *       drv_gdwCtlDumpHostArea
 *       drv_gdwCtlResetHostStat
 *       drv_gdwCtlGetTime
 *       drv_gdwCtlSetHostTimeOffset
 * 
 ****************************************************************************/
#define IPHUSER_C
#include "iphwan.h"
#include "poolqueu.h"
#include "sendprim.h"
#include "ppcperf.h"
#include "iphwantr.h"
#include "layers.h"
#include "ithandle.h"
#include "Driver.Version"
#include "iphtrace.h"
#include "iphmsys.h"
#include "iphmain.h"
#include "iphuser.h"

#define IPH_MAX_VMALLOC_SIZE   (2 << 20) /* 2Mbytes */

/**************************************************************************
* NAME : drv_gdwInitOnLoadEnd
* DESCRIPTION : check firmware status and initialize some variables at the end
*               of the firmware load
* PARAMETERS :
*    Input  : pLock = protection against interrupts from this device
*    Input  : pDev = pointer to the device context
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if allocation failed
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 09/04/06 Add protection against re-entrancy
**************************************************************************/
static dword drv_gdwInitOnLoadEnd(kmutex_t *pLock, IphWanDevPtr pDev)
{
   dword dwError;
   dword dwCardAreaOffset;
   dword dwOffset;
   dword ulNbAppli;
   word wCount, wPool;
   PoolItemPtr pItem;
   PoolItemPtr pNextItem;
   MGRSessionCorr_t *pCorr;
   DrvPool_t *pPool;
   dword tmp32, cpt;
   DrvDataDesc_t *pDrvData;
   PrimDesc_t *pPrim;
   V5_HostCtrlArea_t ToGetSize;
   static int initPending = 0;
#ifdef SOLARIS
   size_t real_len;
#endif
#ifdef LINUX
   int real_len;
#endif

   dwError = 0;

   IPH_LOCK(pLock);

   /* check re-entrancy */
   if (initPending != 0)
   {
      IPH_UNLOCK(pLock);
      return(dwError);
   }
   initPending = 1;

   /* disable interrupt  (it will be re-enabled in iph_gvInitDialogWithCard */
   if (pDev->Rsrc != NULL && pDev->Rsrc->PCIDevType == PQ3)
   {
      /* - by resetting E1 bit in MER register */
      READ_CORE_DWORD(pDev, MPC856X_MER, &tmp32);
      tmp32 &= ~(0x00000002);
      WRITE_CORE_DWORD(pDev, MPC856X_MER, tmp32);
      /* - by resetting EP bit in MIDR1 register */
      READ_CORE_DWORD(pDev, MPC856X_MIDR1, &tmp32);
      tmp32 &= ~(0x80000000);
      WRITE_CORE_DWORD(pDev, MPC856X_MIDR1, tmp32);
   }

   READ_MEM_DWORD(pDev, EXCH_AREA_ADDR_INDX, &dwCardAreaOffset);
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwInitOnLoadEnd] start of exchange (offset)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwCardAreaOffset);
#endif
   dwCardAreaOffset = OFFSET_CARD_TO_HOST(dwCardAreaOffset);
   /* CodeReady offset must be in the first mapped window */
   if (dwCardAreaOffset < pDev->Region[MEM_REGION].WinSize)
      pDev->ExchArea = dwCardAreaOffset;
   else
   {
      pDev->ExchArea = 0;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwInitOnLoadEnd] exchange area offset OUT OF RANGE");
#endif
   }

   if (pDev->ExchArea == 0)
   {
      iph_TRACEK(TRCLVL_1,
                 DRIVER_NAME" : adapter %d failed to boot on firmware (not started)", 
                 pDev->Index);
      dwError = EBUSY;
   }
   else
   {
      READ_EXCH_CODE_READY(pDev, pDev->ExchArea, &tmp32);
      /* check the CodeReady value */
      if (tmp32 != CODE_RDY)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] FIRMWARE NOT READY");
#endif
         iph_TRACEK(TRCLVL_1,
                    DRIVER_NAME" : adapter %d failed to boot on firmware (CodeReady 0x%x)", 
                    pDev->Index, 
                    tmp32);

         /* return an error */
         dwError = EBUSY;
      }
   }
   if (dwError == 0)
   {
      /* get the number of embedded functions */
      READ_EXCH_NB_FUNCTION(pDev, pDev->ExchArea, &ulNbAppli);

      /* find the index in RefFunction of the REF_SV6 function */
      for (wCount = 0; wCount < (word)ulNbAppli; wCount++)
      {
         READ_EXCH_REF_FUNCTION_I(pDev, pDev->ExchArea, wCount, &tmp32);
         if (tmp32 == REF_SV6)
         {
            break;
         }
      }
      /* if the index of the V6 function cannot be found, */
      /* the driver will not work!! */
      if (wCount == (word)ulNbAppli)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] didn't found the V6 function");
#endif
         dwError = ENODEV;
      }
      else
      {
         /* the suitable function is found, so remember the index */
         pDev->RefIndex = wCount;

         /* read information about the local processor */
         iph_gvSearchWorkingArea(pDev);

#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] working area");
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                      (dword)pDev->ProcAreaStart);
#endif
         /* get the DRAM real size */
         READ_EXCH_HEAP_END_PTR(pDev, pDev->ExchArea, &tmp32);
         tmp32 += 1;
         dwOffset = OFFSET_CARD_TO_HOST(tmp32);
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] heap end");
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwOffset);
#endif

         if (dwOffset > pDev->Region[MEM_REGION].MaxSize)
            pDev->Region[MEM_REGION].MaxSize = dwOffset;

         /* init default parameters if not already done */
         if (pDev->MaxAppli == 0)
         {
            pDev->MaxAppli = pDev->Rsrc->DefParmPtr->DefMaxAppli;
         }
         if (pDev->MaxSession == 0)
         {
            pDev->MaxSession = pDev->Rsrc->DefParmPtr->DefMaxSession;
         }
         if (pDev->InbCtrlNb == 0)
         {
            pDev->InbCtrlNb = pDev->Rsrc->DefParmPtr->DefInbCtrlNb;
         }
         if (pDev->InbDataNb == 0)
         {
            pDev->InbDataNb = pDev->Rsrc->DefParmPtr->DefInbDataNb;
         }
         if (pDev->OutbCtrlNb == 0)
         {
            pDev->OutbCtrlNb = pDev->Rsrc->DefParmPtr->DefOutbCtrlNb;
         }

         /* inititalize pool for primitive headers */
         pPool = &pDev->FreePrimHeadPool;
         /* assume the pool is not initialized if MaxCount=0 */
         if (pPool->MaxCount == 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] initialize primitive pool (DEFAULT)");
#endif
            /* default settings are part of ressources */
            pPool->PoolSize = pDev->Rsrc->DefParmPtr->DefPrimPool.Size;
            pPool->InitCount = pDev->Rsrc->DefParmPtr->DefPrimPool.Nb;
            pPool->MaxCount = pDev->Rsrc->DefParmPtr->DefPrimPool.MaxNb;
            pPool->TotalCount = 0;
         }

         /* inititalize pool for data descriptors (without attached buffer) */
         pPool = &pDev->FreeDataDescPool;
         /* assume the pool is not initialized if MaxCount=0 */
         if (pPool->MaxCount == 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] initialize desc pool (DEFAULT)");
#endif
            /* default settings are part of ressources */
            pPool->PoolSize = 0;
            pPool->InitCount = 0;
            pPool->MaxCount = 0xFFFF;
            pPool->TotalCount = 0;
         }

         /* inititalize pool for data descriptors (with attached buffer) */
         for (wPool = 0; wPool < MAX_DRV_POOL && dwError == 0; wPool++)
         {
            pPool = &pDev->FreeDataPools[wPool];
            /* assume the pool is not initialized if MaxCount=0 */
            if (pPool->MaxCount == 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwInitOnLoadEnd] initialize data pool (DEFAULT) - index");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, wPool);
#endif
               /* default settings are part of ressources */
               pPool->PoolSize =
                  pDev->Rsrc->DefParmPtr->DefDataPool[wPool].Size;
               pPool->InitCount = 
                  pDev->Rsrc->DefParmPtr->DefDataPool[wPool].Nb;
               pPool->MaxCount = 
                  pDev->Rsrc->DefParmPtr->DefDataPool[wPool].MaxNb;
               pPool->TotalCount = 0;
               if (wPool > pDev->LastPool);
               {
                  pDev->LastPool = wPool;
               }
            }
         }
         /* number of outbound DMA buffers is computed thanks to the pools*/
         /* definition, that is, the sum of InitCount */
         if (pDev->OutbDataNb == 0)
         {
            for (wPool = 0; wPool < MAX_DRV_POOL && dwError == 0; wPool++)
            {
               pPool = &pDev->FreeDataPools[wPool];
               pDev->OutbDataNb += pPool->InitCount;
            }
         }
         /* in the case the user has not configured the size and number */
         /* of DMA buffers to provide for reception, we use the default */
         /* number value in ressource with a size >= MaxTransferSize */
         if (pDev->OutbDataNb == 0)
         {
            pDev->OutbDataNb = pDev->Rsrc->DefParmPtr->DefOutbDataNb;
            for (wPool = 0; wPool < MAX_DRV_POOL && dwError == 0; wPool++)
            {
               pPool = &pDev->FreeDataPools[wPool];
               if (pPool->PoolSize >= pDev->MaxTransferSize)
               {
                  pPool->InitCount = pDev->OutbDataNb;
                  break;
               }
            }
         }

         /* check some limits in Card Control Area */
         READ_EXCH_INB_CTRL_MAX(pDev, pDev->ExchArea, &tmp32);
         if (tmp32 < pDev->InbCtrlNb)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] limit InbCtrlNb - defined - max");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pDev->InbCtrlNb, tmp32);
#endif
            pDev->InbCtrlNb = tmp32;
         }
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] InbCtrlMax - InbCtrlNb");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, tmp32, pDev->InbCtrlNb);
#endif
         READ_EXCH_INB_DATA_MAX(pDev, pDev->ExchArea, &tmp32);
         if (tmp32 < pDev->InbDataNb)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] limit InbDataNb - defined - max");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pDev->InbDataNb, tmp32);
#endif
            pDev->InbDataNb = tmp32;
         }
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] InbDataMax - InbDataNb");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, tmp32, pDev->InbDataNb);
#endif

         READ_EXCH_OUTB_CTRL_MAX(pDev, pDev->ExchArea, &tmp32);
         if (tmp32 < pDev->OutbCtrlNb)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] limit OutbCtrlNb - defined - max");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pDev->OutbCtrlNb, tmp32);
#endif
            pDev->OutbCtrlNb = tmp32;
         }
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] OutbCtrlMax - OutbCtrlNb");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, tmp32, pDev->OutbCtrlNb);
#endif

         READ_EXCH_OUTB_DATA_MAX(pDev, pDev->ExchArea, &tmp32);
         if (tmp32 < pDev->OutbDataNb)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] limit OutbDataNb - defined - max");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, pDev->OutbDataNb, tmp32);
#endif
            iph_TRACEK(TRCLVL_0,
                       DRIVER_NAME" device %d - limit OutbDataNb to %d (instead of %d)", 
                       pDev->Index, tmp32, pDev->OutbDataNb);
            pDev->OutbDataNb = tmp32;
            for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
            {
               pPool = &pDev->FreeDataPools[wPool];
               if (pPool->InitCount > tmp32)
               {
                  pPool->InitCount = tmp32;
               }
               tmp32 -= pPool->InitCount;
            }
         }
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] OutbDataMax - OutbDataNb");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, tmp32, pDev->OutbDataNb);
#endif

         /* get address of all the tables in Card Control Area */
         READ_EXCH_INB_CTRL_OFFSET(pDev, pDev->ExchArea, &tmp32);
         tmp32 = OFFSET_CARD_TO_HOST(tmp32);
         pDev->InbCtrl = (V5_TransferCtrlPtr)(unsigned long)(tmp32 + dwCardAreaOffset);
         READ_EXCH_INB_SEND_OFFSET(pDev, pDev->ExchArea, &tmp32);
         tmp32 = OFFSET_CARD_TO_HOST(tmp32);
         pDev->InbSend = (V5_InboundSendPtr)(unsigned long)(tmp32 + dwCardAreaOffset);
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] InbCtrl - InbSend");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                      (dword)(unsigned long)pDev->InbCtrl, (dword)(unsigned long)pDev->InbSend);
#endif

         READ_EXCH_OUTB_STATUS_OFFSET(pDev, pDev->ExchArea, &tmp32);
         tmp32 = OFFSET_CARD_TO_HOST(tmp32);
         pDev->OutbStatus = (V5_TransferStatusPtr)(unsigned long)(tmp32 + dwCardAreaOffset);
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwInitOnLoadEnd] OutbStatus");
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                      (dword)(unsigned long)pDev->OutbStatus);
#endif

         for (wCount = 0; wCount < V5_OUTB_POOL_MAX; wCount++)
         {
            READ_EXCH_OUTB_POOL_OFFSET(pDev, pDev->ExchArea, &tmp32, wCount);
            tmp32 = OFFSET_CARD_TO_HOST(tmp32);
            pDev->OutbPool[wCount] = 
               (V5_OutboundPoolPtr)(unsigned long)(tmp32 + dwCardAreaOffset);
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] pool index - addr");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                         (dword)(unsigned long)wCount, (dword)(unsigned long)pDev->OutbPool[wCount]);
#endif

         }

         /* allocate all the buffers to use in DMA */
         if (dwError == 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwInitOnLoadEnd] FirstDmaDesc - LastDmaDesc");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                         (dword)(unsigned long)pDev->FirstDmaDesc, (dword)(unsigned long)pDev->LastDmaDesc);
#endif
            if (pDev->SendDmaDesc == NULL)
            {
               dwError = iph_gdwAllocDmaMem(pLock, pDev);
               if (dwError != 0)
               {
                  iph_TRACEK(TRCLVL_0,
                             DRIVER_NAME" : adapter %d failed to allocate memory for DMA",
                             pDev->Index);

               }
            }
         }
         if (dwError == 0)
         {
            /* initialize the pools of primitive if not already done */
            pPool = &pDev->FreePrimHeadPool;
            if (pPool->TotalCount < pPool->InitCount)
            {
               dwError = iph_gdwNewPrimPool(NULL,
                                            pPool,
                                            pPool->InitCount - pPool->TotalCount);
            }
         }

         if (dwError == 0 && pDev->SendingPrim == NULL)
         {
            IPH_UNLOCK(pLock);
            pDev->SendingPrim =
               (PrimDescPtr *)iph_gpMemAlloc((sizeof(PrimDescPtr) *
                                              pDev->InbCtrlNb), 1,
                                             ALLOC_KERNEL, 1);
            IPH_LOCK(pLock);
            if (pDev->SendingPrim == NULL)
            {
               dwError = ENOMEM;
            }
            else
            {
               /* number of simultaneous primitives being sent is variable */
               for (wCount = 0; wCount < pDev->InbCtrlNb; wCount++)
               {
                  pDev->SendingPrim[wCount] = NULL;
               }
            }
         }

         if (dwError == 0 && pDev->MGRSessionCorrTable == NULL)
         {
            IPH_UNLOCK(pLock);
            pDev->MGRSessionCorrTable =
               (MGRSessionCorr_t **)iph_gpMemAlloc(sizeof(MGRSessionCorr_t *) *
                                                   pDev->MaxSession, 1,
                                                   ALLOC_KERNEL, 1);
            IPH_LOCK(pLock);
            if (pDev->MGRSessionCorrTable == NULL)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwInitOnLoadEnd] allocation failed");
#endif
               dwError = ENOMEM;
            }
            else
            {
               IPH_UNLOCK(pLock);
               pItem = (PoolItemPtr)iph_gpMemAlloc(sizeof(MGRSessionCorr_t),
                                                   pDev->MaxSession,
                                                   ALLOC_KERNEL, 1);
               IPH_LOCK(pLock);
               if (pItem != (PoolItemPtr)0)
               {
                  wCount = 0;
                  while (pItem != (PoolItemPtr)0)
                  {
                     /* save the next allocated structure */
                     pNextItem = pItem->NextPtr;

                     pCorr = (MGRSessionCorr_t *)pItem;
                     pDev->MGRSessionCorrTable[wCount] = pCorr;
                     pCorr->CardMGRSession = wCount;
                     iph_gvPutQueue(NULL,
                                    &pDev->FreeMGRSessionCorrQueue,
                                    (QueueItemPtr)pCorr);

                     /* try next structure */
                     pItem = pNextItem;
                     wCount++;
                  }
               }
               else
               {
                  iph_gvMemFree((void *)pDev->MGRSessionCorrTable);
                  pDev->MGRSessionCorrTable = NULL;
               }
            }
         }
         /* allocate the Dummy Area */
         if (dwError == 0 && pDev->DummyAreaDesc.VirtAddr == NULL)
         {
            wCount = 0x1000;

            DMA_ALLOC_HANDLE(pDev, &pDev->DummyAreaDesc);
            if (pDev->DummyAreaDesc.PhysAddr != 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwInitOnLoadEnd] failed to allocate DMA handle");
#endif
               pDev->DummyAreaDesc.VirtAddr = NULL;
               dwError = ENOMEM;
            }
            IPH_UNLOCK(pLock);
            DMA_ALLOC_MEM(pDev, &pDev->DummyAreaDesc, wCount, &real_len);
            IPH_LOCK(pLock);
            if (pDev->DummyAreaDesc.VirtAddr == NULL)
            {
               DMA_FREE_HANDLE(pDev, &pDev->DummyAreaDesc);
               dwError = ENOMEM;
            }
            else
            {
               DMA_BIND_RECEIVE_HANDLE(pDev, &pDev->DummyAreaDesc, 
                                       pDev->DummyAreaDesc.VirtAddr, 
                                       real_len);
               if (pDev->DummyAreaDesc.PhysAddr == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwInitOnLoadEnd] failed to bind DMA buffer");
#endif
                  DMA_FREE_MEM(pDev, &pDev->DummyAreaDesc);
                  pDev->DummyAreaDesc.VirtAddr = NULL;
                  DMA_FREE_HANDLE(pDev, &pDev->DummyAreaDesc);
                  dwError = ENOMEM;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwInitOnLoadEnd] DummyArea - VirtAddr/PhysAddr");
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                               (dword)(unsigned long)pDev->DummyAreaDesc.VirtAddr,
                               (dword)(unsigned long)pDev->DummyAreaDesc.PhysAddr);
#endif
                  pDev->DummyAreaDesc.Size = wCount;
               }
            }
         }
         /* allocate the Host Control Area */
         if (dwError == 0 && pDev->HostArea == NULL)
         {
            /* get Host Control Area header size*/
            wCount = ((byte *)&ToGetSize.InbOutbTables - 
                      (byte *)&ToGetSize);
            /* add OutbCtrl size */
            wCount += (pDev->OutbCtrlNb * sizeof(V5_TransferCtrl_t));
            /* add OutbSend size */
            wCount += (pDev->OutbDataNb * sizeof(V5_OutboundSend_t));
            /* add InbStatus size */
            wCount += pDev->InbCtrlNb;

            DMA_ALLOC_HANDLE(pDev, &pDev->HostAreaDesc);
            if (pDev->HostAreaDesc.PhysAddr != 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwInitOnLoadEnd] failed to allocate DMA handle");
#endif
               dwError = ENOMEM;
            }

            IPH_UNLOCK(pLock);
            DMA_ALLOC_MEM(pDev, &pDev->HostAreaDesc, wCount, &real_len);
            pDev->HostArea = (volatile V5_HostCtrlAreaPtr)pDev->HostAreaDesc.VirtAddr;
            IPH_LOCK(pLock);
            if (pDev->HostArea == NULL)
            {
               DMA_FREE_HANDLE(pDev, &pDev->HostAreaDesc);
               dwError = ENOMEM;
            }
            else
            {
               DMA_BIND_RECEIVE_HANDLE(pDev, &pDev->HostAreaDesc, 
                                       pDev->HostAreaDesc.VirtAddr, 
                                       real_len);
               if (pDev->HostAreaDesc.PhysAddr == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwInitOnLoadEnd] failed to bind DMA buffer");
#endif
                  DMA_FREE_MEM(pDev, &pDev->HostAreaDesc);
                  DMA_FREE_HANDLE(pDev, &pDev->HostAreaDesc);
                  dwError = ENOMEM;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwInitOnLoadEnd] HostArea - VirtAddr/PhysAddr");
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                               (dword)(unsigned long)pDev->HostArea,
                               (dword)(unsigned long)pDev->HostAreaDesc.PhysAddr);
#endif
                  pDev->HostAreaDesc.Size = wCount;
                  wCount = ((byte *)&ToGetSize.InbOutbTables - 
                            (byte *)&ToGetSize);
                  pDev->OutbCtrl = (V5_TransferCtrlPtr)&((byte *)pDev->HostArea)[wCount];
                  wCount += (pDev->OutbCtrlNb * sizeof(V5_TransferCtrl_t));
                  pDev->OutbSend = (V5_OutboundSendPtr)&((byte *)pDev->HostArea)[wCount];
                  wCount += (pDev->OutbDataNb * sizeof(V5_OutboundSend_t));
                  pDev->InbStatus = (V5_TransferStatusPtr)&((byte *)pDev->HostArea)[wCount];
               }
            }
         }

         if (dwError == ENOMEM)
         {
            iph_gdwFreeDmaMem(pDev);

            pPool = &pDev->FreePrimHeadPool;
            pPrim = (PrimDesc_t *)pPool->UsedQueue[0];
            while (pPrim != (PrimDesc_t *)pPool->UsedQueue)
            {
               pPool->UsedQueue[0] = (void *)pPrim->NextPtr;
               iph_gvMemFree(pPrim);
               pPrim = (PrimDesc_t *)pPool->UsedQueue[0];
            }
            pPrim = (PrimDesc_t *)pPool->FreeQueue[0];
            while (pPrim != (PrimDesc_t *)pPool->FreeQueue)
            {
               pPool->FreeQueue[0] = (void *)pPrim->NextPtr;
               iph_gvMemFree(pPrim);
               pPrim = (PrimDesc_t *)pPool->FreeQueue[0];
            }
            pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
            pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
            pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
            pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
            pPool->TotalCount = 0;
            pPool->UsedCount = 0;
            pPool->FreeCount = 0;
            pPool->MaxUsedCount = 0;

            pPool = &pDev->FreeDataDescPool;
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
            while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
            {
               pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
               iph_gvMemFree(pDrvData);
               pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
            }
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
            while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
            {
               pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
               iph_gvMemFree(pDrvData);
               pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
            }
            pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
            pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
            pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
            pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
            pPool->TotalCount = 0;
            pPool->UsedCount = 0;
            pPool->FreeCount = 0;
            pPool->MaxUsedCount = 0;

            if (pDev->SendingPrim != NULL)
            {
               iph_gvMemFree(pDev->SendingPrim);
               pDev->SendingPrim = NULL;
            }

            if (pDev->MGRSessionCorrTable != NULL)
            {
               for (cpt = 0; cpt < pDev->MaxSession; cpt++)
               {
                  if (pDev->MGRSessionCorrTable[cpt] != NULL)
                  {
                     iph_gvMemFree(pDev->MGRSessionCorrTable[cpt]);
                  }
               }
               iph_gvMemFree(pDev->MGRSessionCorrTable);
               pDev->MGRSessionCorrTable = NULL;
            }

            if (pDev->HostArea != NULL)
            {
               DMA_UNBIND_HANDLE(pDev, &pDev->HostAreaDesc);
               DMA_FREE_MEM(pDev, &pDev->HostAreaDesc);
               DMA_FREE_HANDLE(pDev, &pDev->HostAreaDesc);
               pDev->HostArea = NULL;
            }
            if (pDev->DummyAreaDesc.VirtAddr != NULL)
            {
               DMA_UNBIND_HANDLE(pDev, &pDev->DummyAreaDesc);
               DMA_FREE_MEM(pDev, &pDev->DummyAreaDesc);
               DMA_FREE_HANDLE(pDev, &pDev->DummyAreaDesc);
               pDev->DummyAreaDesc.VirtAddr = NULL;
            }
            pDev->Status = CARD_RESET;
            IPH_UNLOCK(pLock);
            iph_gdwResetBoard(pDev);
            IPH_LOCK(pLock);
         }

         if (dwError == 0)
         {
            /* initialize the dialog with the card */
            iph_gvInitDialogWithCard(NULL, pDev);
#ifdef TRACE
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MAX_APPLI,
                         pDev->Index, 
                         pDev->MaxAppli); 
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MAX_SESSION,
                         pDev->Index, 
                         pDev->MaxSession); 
#endif
            iph_gvDumpDrvPool(&pDev->FreePrimHeadPool);
            for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
               iph_gvDumpDrvPool(&pDev->FreeDataPools[wCount]);

            /* stop Watchdog timeout if running */
            if (pDev->WatchdogTimer == TRUE)
            {
               pDev->WatchdogTimer = FALSE;
               if (pLock == NULL)
               {
                  MUTEX_EXIT(&pDev->DevMutex);
               }
               else
               {
                  IPH_UNLOCK(pLock);
               }
               IPH_DEL_TIMER(&pDev->Watchdog);
               if (pLock == NULL)
               {
                  MUTEX_ENTER(&pDev->DevMutex);
               }
               else
               {
                  IPH_LOCK(pLock);
               }
            }

            /* start the Watchdog function */
            pDev->WatchdogTimeout = FALSE;
            pDev->WatchdogTimer = TRUE;
            IPH_START_TIMER(&pDev->Watchdog, iph_gvITWatchdog, pDev, 
                            WATCHDOG_TIMEOUT);
         }
      }
   }
   initPending = 0;
   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwInitOnLoadEnd] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlSendPrim
* DESCRIPTION : handle a CTL_SEND_PRIM ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer on the primitive to send
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 07/11/06 If SendPrim fails for a kernel application, 
*                     do not give back the primitive with kd_free
**************************************************************************/
static dword drv_gdwCtlSendPrim(ApplCtxtPtr pAppli, int iFlags, 
                                PrimDesc_t *pMem)
{
   dword dwError=0;
   PrimDesc_t *pPrim;
   DataDesc_t *pSrcDesc;
   DataDesc_t *pDesc = NULL;
   DataDesc_t *pLastDesc;
   DataDesc_t MyDataDesc;
   dword dwCopied;
   dword dwSize;
   int count;
   word wPrimId;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlSendPrim] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlSendPrim] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status */
   /* give rights to the controlling application */
   /* allow also if card is just loaded but primitive is for PCI interface */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
      dwError = EBUSY;
      if (pAppli->WanDevPtr->Status == CARD_LOADED)
      {
         wPrimId = 0;
         if (pAppli->Type == TYPE_KERNEL)
         {
            wPrimId = HOST_CARD16(pMem->PrimId);
         }
         else
         {
            GET_PRIM_DESC_WORDFIELD(pMem, &wPrimId, PrimId,
                                    iFlags, &dwError);
            wPrimId = HOST_CARD16(wPrimId);
         }
         if ((wPrimId & 0xFF00) == 0x4000)
            dwError = 0;
         else
            dwError = EBUSY;
      }
   }
   if (dwError == 0)
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* convert PrimId&Ref into host format */
         pMem->PrimId = HOST_CARD16(pMem->PrimId);
         pMem->PrimRef = HOST_CARD16(pMem->PrimRef);
         /* evaluate the number of required buffers to send primtive */
         pMem->BuffInPool = 0;
         pDesc = pMem->DataDescPtr;
         while (pDesc != NULL)
         {
            count = pDesc->Size / pAppli->WanDevPtr->MaxTransferSize;
            if (pDesc->Size > 0 &&
                (pDesc->Size % pAppli->WanDevPtr->MaxTransferSize) != 0)
            {
               count++;
            }
            pMem->BuffInPool+=count;
            pDesc = pDesc->NextPtr;
         }
         dwError = 
         pAppli->WanDevPtr->Rsrc->CardSendPrim(&pAppli->WanDevPtr->DevMutex,
                                               pAppli->WanDevPtr, 
                                               pAppli, 
                                               pMem);
      }
      else
      {
         pPrim = iph_gpGetPrimPool(&pAppli->WanDevPtr->DevMutex,
                                   &pAppli->WanDevPtr->FreePrimHeadPool);
         if (pPrim == NULL)
         {
            /* display error on console */
            iph_TRACEK(TRCLVL_0,
                       DRIVER_NAME" device %d - NO AVAILABLE PRIM => check pool size %d", 
                       pAppli->WanDevPtr->Index, 
                       pAppli->WanDevPtr->FreePrimHeadPool.MaxCount);
            dwError = EAGAIN;
         }
         else
         {
            /* copy the primitive content */
            /* pMem is a pointer to a primitive */
            GET_PRIM_DESC_WORDFIELD(pMem, &pPrim->PrimId, PrimId,
                                    iFlags, &dwError);
            GET_PRIM_DESC_WORDFIELD(pMem, &pPrim->PrimRef, PrimRef,
                                    iFlags, &dwError);
            /* convert PrimId&Ref into host format */
            pPrim->PrimId = HOST_CARD16(pPrim->PrimId);
            pPrim->PrimRef = HOST_CARD16(pPrim->PrimRef);
            GET_PRIM_DESC_PRIMINFO(pMem, pPrim->PrimInfo,
                                   iFlags, &dwError);
            GET_PRIM_DESC_PTRFIELD(pMem, &pPrim->DataDescPtr, DataDescPtr,
                                   iFlags, &dwError, DataDesc_t);

            pPrim->BuffInPool = 0;

            if (dwError == 0)
            {
               /* copy the data descriptors and evaluate the number */
               /* of required buffers to send primtive */
               pSrcDesc = pPrim->DataDescPtr;
               pLastDesc = NULL;
               pPrim->DataDescPtr = NULL;
               while (pSrcDesc != NULL && dwError == 0)
               {
                  /* copy the data descriptor */
                  GET_DATA_DESC(pSrcDesc, &MyDataDesc, iFlags, &dwError);

                  dwCopied = 0;
#ifdef TRACE
                  if (dwError == 0)
                  {
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, 
                                      (byte *)"[gdwCtlSendPrim] new data block");
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_SIZE,
                                  MyDataDesc.Size);
                  }
                  else
                  {
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, 
                                      (byte *)"[gdwCtlSendPrim] failed to copy descriptor");
                  }
#endif
                  while (dwCopied < MyDataDesc.Size && dwError == 0)
                  {
                     dwSize = MyDataDesc.Size - dwCopied;
                     if (dwSize > pAppli->WanDevPtr->MaxTransferSize)
                        dwSize = pAppli->WanDevPtr->MaxTransferSize;

#ifdef _DRV_LOOPBACK
                     /* for a loopback in driver, copy the data too */
                     if (pPrim->PrimId == 0x4010)
                     {
                        pDesc = iph_gpGetDataDesc(&pAppli->WanDevPtr->DevMutex, 
                                                  pAppli, dwSize);
                        if (pDesc != NULL)
                        {
                           pDesc->Size = (word)dwSize;
                           pDesc->Offset = 0;
                           ((DrvDataDescPtr)pDesc)->iFlags = iFlags;
                           if (dwError == 0)
                           {
                              pDesc->Size = dwSize;
                              pDesc->Offset = 0;
                              dwCopied+=dwSize;
                              if (pPrim->DataDescPtr == NULL)
                                 pPrim->DataDescPtr = pDesc;
                              else
                                 pLastDesc->NextPtr = pDesc;
                              pPrim->BuffInPool++;
                              pLastDesc = pDesc;
                              GET_DATA_USER(&MyDataDesc.DataPtr[MyDataDesc.Offset + dwCopied],
                                            pDesc->DataPtr,
                                            dwSize,
                                            iFlags, &dwError);
                           }
                           else
                           {
                              dwError = EFAULT;
                           }
                        }
                        else
                        {
                           iph_TRACEK(TRCLVL_0,
                                      DRIVER_NAME" device %d - NO AVAILABLE BUFFER DESC => check pools size", 
                                      pAppli->WanDevPtr->Index);
                           dwError = EAGAIN;
                        }/* end if (pDesc != NULL) */
                     }
                     else
#endif /* _DRV_LOOPBACK */
                     {
                        pDesc = iph_gpGetDataDescPool(&pAppli->WanDevPtr->DevMutex, 
                                                      &pAppli->WanDevPtr->FreeDataDescPool);
                        if (pDesc != NULL)
                        {
                           pDesc->DataPtr = &MyDataDesc.DataPtr[MyDataDesc.Offset + dwCopied];
                           pDesc->Size = (word)dwSize;
                           pDesc->Reserved = (pDesc->Reserved & 0x00FF) | USER_BUFFER;
                           pDesc->Offset = 0;
                           ((DrvDataDescPtr)pDesc)->iFlags = iFlags;

                           if (dwError == 0)
                           {
                              pDesc->Size = dwSize;
                              pDesc->Offset = 0;
                              dwCopied+=dwSize;
                              if (pPrim->DataDescPtr == NULL)
                                 pPrim->DataDescPtr = pDesc;
                              else
                                 pLastDesc->NextPtr = pDesc;
                              pPrim->BuffInPool++;
                              pLastDesc = pDesc;
                           }
                           else
                           {
                              dwError = EFAULT;
                           }
                        }
                        else
                        {
                           iph_TRACEK(TRCLVL_0,
                                      DRIVER_NAME" device %d - NO AVAILABLE BUFFER DESC => check pools size", 
                                      pAppli->WanDevPtr->Index);
                           dwError = EAGAIN;
                        }/* end if (pDesc != NULL) */

                     }/* while (dwCopied < MyDataDesc.Size && dwError == 0)*/
                  }

                  /* next descriptor to copy */
                  if (dwError == 0)
                  {
                     pSrcDesc = MyDataDesc.NextPtr;
                  }
               }/* end  while (pSrcDesc != NULL && dwError == 0)*/
            }/* if (dwError == 0) after get primitive filled*/

            /* if the primitive could be successfully copied, send it */
            if (dwError == 0)
            {
#ifdef _DRV_LOOPBACK
               /* for a loopback in driver, notify application */
               if (pPrim->PrimId == 0x4010)
               {
                  iph_gvSendPrimToAppli(pAppli, pPrim, NULL);
               }
               else
#endif /* _DRV_LOOPBACK */
               {
                  dwError = 
                     pAppli->WanDevPtr->Rsrc->CardSendPrim(&pAppli->WanDevPtr->DevMutex,
                                                           pAppli->WanDevPtr, 
                                                           pAppli, pPrim);
               }
            }
            if (dwError != 0 && pPrim != NULL)
            {
               /* release the primitive structure and its attached buffers */
               iph_gvReleaseDrvPrim(&pAppli->WanDevPtr->DevMutex, pAppli,
                                    pAppli->WanDevPtr, pPrim);
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSendPrim] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGiveRxPrim
* DESCRIPTION : handle a CTL_GIVE_RX_PRIM ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOSPC if the pool is full
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlGiveRxPrim(ApplCtxtPtr pAppli, int iFlags, 
                                  MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwArgSize;
   PrimDesc_t *pPrim;
   PrimDesc_t *pNextPrim;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwGiveRxPrim] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size != sizeof(PrimDesc_t) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(PrimDesc_t))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxPrim] argument is not a PrimDesc_t");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxPrim] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         pPrim = (PrimDescPtr)pMem->DataPtr;
         while (pPrim != NULL && dwError == 0)
         {
            if (pAppli->ChainGiveRx != 0)
            {
               pNextPrim = pPrim->NextPtr;
            }
            else
            {
               pNextPrim = NULL;
            }
            pPrim->PrimInPool = KERN_BUFFER;
            dwError = iph_gvPutPool(&pAppli->AppliMutex, &pAppli->FreePrimHeadPool,
                                    (PoolItemPtr)pPrim);
            pPrim = pNextPrim;
         }
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);

      if (dwError == 0)
      {
         dwArgSize = sizeof(PrimDesc_t);

#if defined(SOLARIS) && defined(_MULTI_DATAMODEL)
         if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)
         {
            dwArgSize = sizeof(PrimDesc32_t);
         }
#endif
#ifdef LINUX
         if (iFlags == MODE_32)
         {
            dwArgSize = sizeof(PrimDesc32_t);
         }
#endif

         if (MyMem.Size != dwArgSize || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != dwArgSize)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGiveRxPrim] argument is not a PrimDesc_t");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGiveRxPrim] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            pPrim = (PrimDescPtr)MyMem.DataPtr;
            while (pPrim != NULL && dwError == 0)
            {
               dwArgSize = 0;
               if (pAppli->ChainGiveRx != 0)
               {
                  GET_PRIM_DESC_PTRFIELD(pPrim, &pNextPrim, NextPtr, 
                                         iFlags, &dwError, PrimDesc_t);
               }
               else
               {
                  pNextPrim = NULL;
               }
               dwError = iph_gvPutPoolUser(&pAppli->AppliMutex, &pAppli->CondVar,
                                           &pAppli->PoolInUse, &pAppli->FreePrimHeadPool,
                                           (PoolItemPtr)pPrim, iFlags);
               pPrim = pNextPrim;
            }
         }
      }
#ifdef TRACE
      else
      {
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwCtlGiveRxPrim] copy from user space failed");

      }
#endif
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGiveRxPrim] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGiveRxBuffer
* DESCRIPTION : handle a CTL_GIVE_RX_BUFFER ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlGiveRxBuffer(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   DataDesc_t MyDataDesc;
   DataDesc_t *pDesc;
   DataDesc_t *pNextDesc;
   word wCount, wDescNb;
   dword dwArgSize;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwGiveRxBuffer] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size != sizeof(DataDesc_t) || pMem->DataPtr == (byte *)0 ||
          ((DataDesc_t *)(pMem->DataPtr))->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(DataDesc_t))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxBuffer] argument is not a DataDesc_t");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxBuffer] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         /* check buffer addr & length for each descriptor */
         pDesc = ((DataDesc_t *)(pMem->DataPtr));
         while (pDesc != NULL && dwError == 0)
         {
            /* The buffer is rejected if it is smaller than the smallest */
            /* buffer pool */
            if (pDesc->MaxSize < pAppli->FreeDataPools[0].PoolSize)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGiveRxBuffer] Buffer too small"); 
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, 
                            pDesc->MaxSize); 
#endif
               dwError = EINVAL;
            }
            if (pAppli->ChainGiveRx != 0)
            {
               pDesc = pDesc->NextPtr;
            }
            else
            {
               pDesc = NULL;
            }
         }
         if (dwError == 0)
         {
            /* descriptors are correct; now store them in pools */
            /* check buffer addr & length for each descriptor */
            pDesc = ((DataDesc_t *)(pMem->DataPtr));
            while (pDesc != NULL && dwError == 0)
            {
               /* find in which pool the buffer is going to be stored */
               for (wCount = 0; wCount <= pAppli->WanDevPtr->LastPool; wCount++)
               {
                  if (pAppli->FreeDataPools[wCount].PoolSize > pDesc->MaxSize)
                     break;
               }
               if (wCount > 0)
                  wCount--;

               if (pAppli->ChainGiveRx != 0)
               {
                  pNextDesc = pDesc->NextPtr;
               }
               else
               {
                  pNextDesc = NULL;
               }
               pDesc->Reserved = wCount | KERN_BUFFER;
               dwError = iph_gvPutPool(&pAppli->AppliMutex, 
                                       &pAppli->FreeDataPools[wCount],
                                       (PoolItemPtr)pDesc);
               pDesc = pNextDesc;
            }
         }
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         dwArgSize = sizeof(DataDesc_t);
#if defined(SOLARIS) && defined(_MULTI_DATAMODEL)
         if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)
         {
            dwArgSize = sizeof(DataDesc32_t);
         }
#endif
#ifdef LINUX
         if (iFlags == MODE_32)
         {
            dwArgSize = sizeof(DataDesc32_t);
         }
#endif
         if (MyMem.Size != dwArgSize || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != dwArgSize)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGiveRxBuffer] argument is not a DataDesc_t");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGiveRxBuffer] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            MyDataDesc.NextPtr = NULL;
            wDescNb = 0;
            /* check buffer addr & length for each descriptor */
            pDesc = (DataDesc_t *)MyMem.DataPtr;
            while (pDesc != NULL && dwError == 0)
            {
               /* get data buffer address */
               GET_DATA_DESC_PTRFIELD(pDesc, &MyDataDesc.DataPtr, DataPtr,
                                      iFlags, &dwError, byte);
               if (dwError == 0)
               {
                  if (MyDataDesc.DataPtr == (byte *)0)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlGiveRxBuffer] no data buffer!");
#endif
                     dwError = EINVAL;
                  }
                  else
                  {
                     /* get buffer size */
                     GET_DATA_DESC_WORDFIELD(pDesc, &MyDataDesc.MaxSize,
                                             MaxSize, iFlags, &dwError);
                     /* The buffer is rejected if it is smaller than */
                     /* the smallest buffer pool */
                     if (MyDataDesc.MaxSize < pAppli->FreeDataPools[0].PoolSize)
                     {
#ifdef TRACE
                        iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                         (byte *)"[gdwCtlGiveRxBuffer] Buffer too small"); 
                        iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, 
                                     MyDataDesc.MaxSize);
#endif
                        dwError = EINVAL;
                     }
                  }
                  if (pAppli->ChainGiveRx != 0)
                  {
                     /* get address of next descriptor */
                     GET_DATA_DESC_PTRFIELD(pDesc, &MyDataDesc.NextPtr, 
                                            NextPtr, iFlags, &dwError, DataDesc_t);
                  }
                  pDesc = MyDataDesc.NextPtr;
                  wDescNb++;
               }
            }
            if (dwError == 0)
            {
               /* descriptors are correct; now store them in pools */
               pDesc = (DataDesc_t *)MyMem.DataPtr;
               while (pDesc != (DataDesc_t *)0 && dwError == 0)
               {
                  if (wDescNb > 1)
                  {
                     /* get buffer size */
                     GET_DATA_DESC_WORDFIELD(pDesc, &MyDataDesc.MaxSize,
                                             MaxSize, iFlags, &dwError);
                     if (pAppli->ChainGiveRx != 0)
                     {
                        /* get address of next descriptor */
                        GET_DATA_DESC_PTRFIELD(pDesc, 
                                               &MyDataDesc.NextPtr, 
                                               NextPtr, iFlags, 
                                               &dwError, DataDesc_t);
                     }
                  }
                  if (dwError == 0)
                  {
                     /* find in which pool the buffer is going to be */
                     /* stored */
                     for (wCount = 0; 
                          wCount <= pAppli->WanDevPtr->LastPool; 
                          wCount++)
                     {
                        if (pAppli->FreeDataPools[wCount].PoolSize >
                            MyDataDesc.MaxSize)
                           break;
                     }

                     if (wCount > 0)
                        wCount--;

                     /* update the Reserved field in the descriptor so */
                     /* that we can easily store the structure in the */
                     /* correct pool when a CTL_RECV_PRIM fails */
                     PUT_DATA_DESC_WORDFIELD(pDesc,
                                             &wCount,
                                             Reserved,
                                             iFlags,
                                             &dwError);
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwGiveRxBuffer] add new item to application pool");
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_SIZE, 
                                  MyDataDesc.MaxSize);
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_POOL_SIZE, 
                                  pAppli->FreeDataPools[wCount].PoolSize);
#endif
                     dwError = iph_gvPutPoolUser(&pAppli->AppliMutex, 
                                                 &pAppli->CondVar,
                                                 &pAppli->PoolInUse, 
                                                 &pAppli->FreeDataPools[wCount],
                                                 (PoolItemPtr)pDesc, 
                                                 iFlags);
                     pDesc = MyDataDesc.NextPtr;
                  }
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGiveRxBuffer] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}


/**************************************************************************
* NAME : drv_gdwCtlGiveRxDataBuffer
* DESCRIPTION : handle a CTL_GIVE_RX_DATA_BUFFER ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          ENOSPC if the application pool is full
* REVISION :
*    - Version 1.0 : 04/04/07 Creation
**************************************************************************/
static dword drv_gdwCtlGiveRxDataBuffer(ApplCtxtPtr pAppli, int iFlags, 
                                        MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   DataDesc_t MyDataDesc;
   DataDesc_t *pDesc;
   dword dwArgSize;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwGiveRxDataBuffer] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* copy the memory descriptor */
   GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
   if (dwError == 0)
   {
      dwArgSize = sizeof(DataDesc_t);
#if defined(SOLARIS) && defined(_MULTI_DATAMODEL)
      if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)
      {
         dwArgSize = sizeof(DataDesc32_t);
      }
#endif
#ifdef LINUX
      if (iFlags == MODE_32)
      {
         dwArgSize = sizeof(DataDesc32_t);
      }
#endif
      if (MyMem.Size != dwArgSize || MyMem.DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (MyMem.Size != dwArgSize)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxDataBuffer] argument is not a DataDesc_t");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGiveRxDataBuffer] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         MyDataDesc.NextPtr = NULL;
         /* check buffer addr & length for each descriptor */
         pDesc = (DataDesc_t *)MyMem.DataPtr;
         while (pDesc != NULL && dwError == 0)
         {
            /* get data buffer address */
            GET_DATA_DESC_PTRFIELD(pDesc, &MyDataDesc.DataPtr, DataPtr,
                                   iFlags, &dwError, byte);
            if (dwError == 0)
            {
               if (MyDataDesc.DataPtr == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlGiveRxDataBuffer] no data buffer!");
#endif
                  dwError = EINVAL;
               }
               pDesc = MyDataDesc.NextPtr;
            }
         }
         if (dwError == 0)
         {
            /* descriptors are correct; now store them in the circular pool */
            pDesc = (DataDesc_t *)MyMem.DataPtr;
            while (pDesc != (DataDesc_t *)0 && dwError == 0)
            {
               /* get buffer size */
               GET_DATA_DESC_WORDFIELD(pDesc, &MyDataDesc.MaxSize,
                                       MaxSize, iFlags, &dwError);
               if (dwError == 0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwGiveRxDataBuffer] add new item to application pool");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_SIZE, 
                               MyDataDesc.MaxSize);
#endif
                  MUTEX_ENTER(&pAppli->AppliMutex);
                  if ( pAppli->DataIndPool.MaxBuff != MAX_CIRC_POOL_SIZE )
                  {
                     pAppli->DataIndPool.BuffPtr[pAppli->DataIndPool.MaxBuff] = pDesc;
                     pAppli->DataIndPool.MaxBuff++;
                  }
                  else
                  {
                     dwError = ENOSPC;
                  }
                  MUTEX_EXIT(&pAppli->AppliMutex);
                  pDesc = MyDataDesc.NextPtr;
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGiveRxDataBuffer] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlRecvPrim
* DESCRIPTION : handle a CTL_RECV_PRIM ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = address where to return the pointer on the primitive
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 09/12/06
*      - For a USER application, add protection until the primitive is
*        extracted from the reception queue
* NOTE: for a USER application, we first try to organize the data as in the
* original primitive, that is same number of buffers; but if one buffer
* cannot be copied in a single buffer the data are splitted in more buffers.
* On the other hand, the data are not reassembled because the firmware may
* wish to provide the data in several buffers (like MGR_SUBMIT_IDENT).
**************************************************************************/
static dword drv_gdwCtlRecvPrim(ApplCtxtPtr pAppli, int iFlags, 
                                PrimDesc_t **pMem)
{
   dword dwError, dwTmpError;
   PrimDesc_t *pSrcPrim;
   PrimDesc_t *pPrim;
   PrimDesc_t *pFirstPrim;
   PrimDesc_t *pLastPrim;
   DataDesc_t *pSrcDesc;
   DataDesc_t *pDesc;
   DataDesc_t *pFirstDesc;
   DataDesc_t *pLastDesc;
   word wCopied;
   word wSize;
   word wPool;
   word wMaxPool;
   byte *pSrc;
   byte *MyAddr;
   word wVal;
   IphWanDevPtr pDev;
   dword FreeCount[MAX_DRV_POOL];
   word wChain;
   word wOff;
   word CurIndx;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlRecvPrim] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      pFirstPrim = (PrimDesc_t *)0;
      pLastPrim = (PrimDesc_t *)0;
      wChain = 0;
      MUTEX_ENTER(&pAppli->AppliMutex);
      pSrcPrim = (PrimDescPtr)pAppli->RecvQueue.FirstPtr;
      MUTEX_EXIT(&pAppli->AppliMutex);
      while (dwError == 0 && wChain < pAppli->MaxChainRecvNb && 
             pSrcPrim != (PrimDescPtr)&pAppli->RecvQueue)
      {
         /* extract a primitive from the pending queue */
         pPrim = (PrimDescPtr)iph_gpGetQueue(&pAppli->AppliMutex, 
                                             &pAppli->RecvQueue);
         if (pPrim == NULL)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlRecvPrim] no pending primitive");
#endif
            /* there is no primitive, but we don't return an error */
            dwError = 0;
            break;
         }
         else
         {
            MUTEX_ENTER(&pAppli->AppliMutex);
            pAppli->RecvNb--;
            pAppli->PbMaxRxQueue = 0;
            MUTEX_EXIT(&pAppli->AppliMutex);
            *pMem = pPrim;
            /* updates the PrimInPool, SizeInPool and BuffInPool fields */
            pPrim->PrimInPool = pAppli->FreePrimHeadPool.PoolCount;
            pPrim->SizeInPool = 0;
            pPrim->BuffInPool = 0;
            pDesc = pPrim->DataDescPtr;
            if (pDesc != NULL)
            {
               pPrim->BuffInPool = 
                  pAppli->FreeDataPools[pDesc->Reserved & 0xFF].PoolCount;
               pPrim->SizeInPool =
                  pAppli->FreeDataPools[pDesc->Reserved & 0xFF].PoolSize;
               pDesc = pDesc->NextPtr;
               while (pDesc != NULL)
               {
                  if (pAppli->FreeDataPools[pDesc->Reserved & 0xFF].PoolCount <
                      pPrim->BuffInPool)
                  {
                     pPrim->BuffInPool =
                        pAppli->FreeDataPools[pDesc->Reserved & 0xFF].PoolCount;
                     pPrim->SizeInPool =
                        pAppli->FreeDataPools[pDesc->Reserved & 0xFF].PoolSize;
                  }
                  pDesc = pDesc->NextPtr;
               }
            }
            if (pAppli->RecvQueue.FirstPtr != (QueueItemPtr)&pAppli->RecvQueue)
               pPrim->MorePrim = 1;
            else
               pPrim->MorePrim = 0;

            if (pFirstPrim == NULL)
            {
               pFirstPrim = pPrim;
            }
            else
            {
               pLastPrim->NextPtr = pPrim;
            }
            pPrim->PrevPtr = pLastPrim;
            pPrim->NextPtr = NULL;
            pLastPrim = pPrim;
            wChain++;
         }
         MUTEX_ENTER(&pAppli->AppliMutex);
         pSrcPrim = (PrimDescPtr)pAppli->RecvQueue.FirstPtr;
         MUTEX_EXIT(&pAppli->AppliMutex);
      }
      if (dwError == 0)
      {
         *pMem = (PrimDesc_t *)pFirstPrim;
      }
   }
   else  /* USER */
   {
      pDev = pAppli->WanDevPtr;
      pFirstPrim = (PrimDesc_t *)0;
      pLastPrim = (PrimDesc_t *)0;
      wChain = 0;
      while (dwError == 0 && wChain < pAppli->MaxChainRecvNb)
      {
         MUTEX_ENTER(&pAppli->AppliMutex);
         pSrcPrim = (PrimDescPtr)pAppli->RecvQueue.FirstPtr;
         if (pSrcPrim == (PrimDescPtr)&pAppli->RecvQueue)
         {
            MUTEX_EXIT(&pAppli->AppliMutex);
            break;
         }
         if (pAppli->FreePrimHeadPool.PoolCount > 0)
         {
            if (pSrcPrim->DataDescPtr != NULL)
            {
               /* check whether the primitive can be copied in */
               /* application buffers */
               /* if it is not a DATA_IND primitive or there is no DATA_IND */
               /* dedicated buffer given by the application */
               if ( (pSrcPrim->PrimId != SWAP16((DATA_PRIM|DATA_IND))) || 
                    (pAppli->DataIndPool.MaxBuff == 0) )
               {
                  for (wPool = 0; wPool <= pDev->LastPool; wPool++)
                  {
                     FreeCount[wPool] = pAppli->FreeDataPools[wPool].PoolCount;
                  }
                  pSrcDesc = pSrcPrim->DataDescPtr;
                  while (pSrcDesc != NULL && dwError == 0)
                  {
                     wCopied = 0;
                     wMaxPool = pDev->LastPool;
                     /* keep unaligned data */
                     wOff = pSrcDesc->Offset;

                     while (wCopied < pSrcDesc->Size && dwError == 0)
                     {
                        wSize = pSrcDesc->Size - wCopied;
                        /* the size of copy is limited to the maximum size */
                        /* of user buffers */
                        if ((wSize + wOff) > 
                            pAppli->FreeDataPools[wMaxPool].PoolSize)
                        {
                           wSize = pAppli->FreeDataPools[wMaxPool].PoolSize - 
                                   wOff;
                        }
                        for (wPool = 0; wPool <= wMaxPool ; wPool++)
                        {
                           if ((pAppli->FreeDataPools[wPool].PoolSize >= (dword)(wSize+wOff)) && 
                               (FreeCount[wPool] > 0))
                           {
   
                              break;
                           }
                        }
                        if (wPool <= wMaxPool)
                        {
                           FreeCount[wPool]--;
                           /* update Size and Offset fields */
                           wVal = 0;
                           wOff = 0;
                           wCopied+=wSize;
                        }
                        else
                        {
                           /* there is no buffer to contain this piece */
                           /* of data so we decrease the piece size */
                           if (wMaxPool > 0)
                           {
                              wMaxPool--;
                           }
                           else
                           {
                              iph_TRACEK(TRCLVL_0, DRIVER_NAME" no available buffer structure, (see CTL_GIVE_RX_BUFFER)");
                              dwError = EAGAIN;
                           }
                        }
                     }
                     pSrcDesc = pSrcDesc->NextPtr;
                  }
               }
               else
               {
                  /* Check that the received DATA_IND primitive is not */
                  /* a chained buffer primitive and offset is null */
                  pSrcDesc = pSrcPrim->DataDescPtr;
                  if ( pSrcDesc->NextPtr != NULL || pSrcDesc->Offset != 0 )
                  {
                     dwError = EIO;
                  }
                  /* Check that the first application available buffer */
                  /* is large enough */
                  if ( pAppli->DataIndPool.BuffPtr[pAppli->DataIndPool.CurIndx]->MaxSize < pSrcDesc->Size )
                  {
                     dwError = ENOMEM;
                  }
               }
            }
         }
         else
         {
            /* if at least one primitive was sucessfully copied */
            /* there is no error to return */
            /* else, we continue to release (and loose) the first */
            /* primitive in reception queue */
            if (wChain > 0)
            {
               MUTEX_EXIT(&pAppli->AppliMutex);
               break;
            }
            else
            {
               iph_TRACEK(TRCLVL_0, DRIVER_NAME" no available primitive structure, (see CTL_GIVE_RX_PRIM)");
               dwError = EAGAIN;
            }
         }
         if (dwError != 0)
         {
            MUTEX_EXIT(&pAppli->AppliMutex);
            break;
         }

#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwCtlRecvPrim] ressources OK");
#endif
         /* here we are sure that the primitive can be copied, so do it */
         /* extract a primitive from the pending queue */
         pSrcPrim = (PrimDescPtr)iph_gpGetQueue(NULL, 
                                                &pAppli->RecvQueue);
         if (pSrcPrim == NULL)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlRecvPrim] no pending primitive!!");
#endif
            /* there is no primitive, but we don't return an error */
            dwError = 0;
            MUTEX_EXIT(&pAppli->AppliMutex);
            break;
         }
         else
         {
            pAppli->RecvNb--;
            pAppli->PbMaxRxQueue = 0;
            MUTEX_EXIT(&pAppli->AppliMutex);

            /* extract a user primitive header structure */
            pPrim = (PrimDesc_t *)iph_gpGetPoolUser(&pAppli->AppliMutex,
                                                    &pAppli->CondVar,
                                                    &pAppli->PoolInUse, 
                                                    &pAppli->FreePrimHeadPool,
                                                    iFlags);
            if (pPrim == NULL)
            {
               /* if we get here, it is because there is no primitive */
               /* structure for the first primitive extracted from */
               /* reception queue => remove primitive */
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlRecvPrim] no available primitive structure => LOST");
#endif

               iph_TRACEK(TRCLVL_0, DRIVER_NAME" no available primitive structure, (see CTL_GIVE_RX_PRIM)");

               /* return NULL address for primitive */
               pPrim = (PrimDesc_t *)0;
               PUT_PTRFIELD(pMem, &pPrim, iFlags, &dwError);
               dwError = EAGAIN;
            }
            else
            {
               pFirstDesc = NULL;
               /* updates the PrimInPool, SizeInPool and BuffInPool fields */
               pSrcPrim->PrimInPool = pDev->FreePrimHeadPool.FreeCount;
               pSrcPrim->SizeInPool = 0;
               pSrcPrim->BuffInPool = 0;
               if (pAppli->RecvQueue.FirstPtr != (QueueItemPtr)&pAppli->RecvQueue)
               {
                  pSrcPrim->MorePrim = 1;
               }
               else
               {
                  pSrcPrim->MorePrim = 0;
               }

               pLastDesc = NULL;
               /* copy the primitive header to user space*/
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->PrimId, PrimId,
                                          iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->PrimRef, PrimRef,
                                          iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_PRIMINFO(pPrim, pSrcPrim->PrimInfo,
                                         iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_PTRFIELD(pPrim, &pLastDesc, DataDescPtr,
                                         iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->PrimInPool,
                                          PrimInPool, iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->SizeInPool,
                                          SizeInPool, iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->BuffInPool,
                                          BuffInPool, iFlags, &dwError);
               }
               if (dwError == 0)
               {
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->MorePrim,
                                          MorePrim, iFlags, &dwError);
               }

               if (dwError == 0)
               {
                  /* start the copy of data */
                  /* NOTE: we first try to organize the data as in the */
                  /* original primitive, that is same number of buffers; */
                  /* but if one buffer cannot be copied in a single buffer */
                  /* the data are splitted in more buffers. */
                  /* On the other hand, the data are not reassembled */

                  pSrcDesc = pSrcPrim->DataDescPtr;

                  if (pSrcDesc != NULL)
                  {
                     pSrcPrim->BuffInPool =
                        (word)pDev->FreeDataPools[pSrcDesc->Reserved & 0xFF].FreeCount;
                     pSrcPrim->SizeInPool =
                        (word)pDev->FreeDataPools[pSrcDesc->Reserved & 0xFF].PoolSize;
                  }

                  /* Copy data to dedicated DATA_IND buffers if the received */
                  /* primitive is DATA_IND and there are dedicated buffers */
                  /* given by the application */
                  if ( (pSrcPrim->PrimId == SWAP16((DATA_PRIM|DATA_IND))) && 
                       (pAppli->DataIndPool.MaxBuff != 0) )
                  {
                     CurIndx = pAppli->DataIndPool.CurIndx;
                     pDesc = pAppli->DataIndPool.BuffPtr[CurIndx];
                     pSrc = pSrcDesc->DataPtr;
                     wSize = pSrcDesc->Size;

                     /* get DataPtr in user space field value */
                     GET_DATA_DESC_PTRFIELD(pDesc, &MyAddr, DataPtr,
                                            iFlags, &dwError, byte);
                     if (dwError == 0)
                     {
                        /* copy the data */
                        PUT_DATA_USER((void *)MyAddr,
                                      (void *)pSrc,
                                      wSize, iFlags, &dwError);
                     }
                     if (dwError == 0)
                     {
                        /* update Size and Offset fields */
                        PUT_DATA_DESC_WORDFIELD(pDesc, &wSize, Size,
                                                iFlags, &dwError);

                        wOff = 0;  
                        PUT_DATA_DESC_WORDFIELD(pDesc, &wOff, Offset,
                                                iFlags, &dwError);

                        /* update DataDescPtr field in primitive */
                        PUT_PRIM_DESC_PTRFIELD(pPrim, &pDesc,
                                               DataDescPtr,
                                               iFlags, &dwError);
                     }
                     if (dwError == 0)
                     {
                        /* Next application buffer */
                        pAppli->DataIndPool.CurIndx = (CurIndx+1)%pAppli->DataIndPool.MaxBuff;
                     }
                  }
                  else
                  {

                     while (pSrcDesc != NULL && dwError == 0)
                     {
                        /* check current status of the internal pools */
                        if (pDev->FreeDataPools[pSrcDesc->Reserved & 0xFF].FreeCount <
                            pSrcPrim->BuffInPool)
                        {
                           pSrcPrim->BuffInPool =
                              (word)pDev->FreeDataPools[pSrcDesc->Reserved & 0xFF].FreeCount;
                           pSrcPrim->SizeInPool =
                              (word)pDev->FreeDataPools[pSrcDesc->Reserved & 0xFF].PoolSize;
                        }
                        wCopied = 0;
                        wMaxPool = pDev->LastPool;
                        /* the copy starts at the first byte of useful data */
                        pSrc = &pSrcDesc->DataPtr[pSrcDesc->Offset];
      
                        /*  keep unaligned data */
                        wOff = pSrcDesc->Offset;
   
                        while (wCopied < pSrcDesc->Size && dwError == 0)
                        {
                           wSize = pSrcDesc->Size - wCopied;
                           /* the size of copy is limited to the maximum size */
                           /* of user buffers */
                           if ((wSize + wOff) > 
                               pAppli->FreeDataPools[wMaxPool].PoolSize)
                           {
                              wSize = pAppli->FreeDataPools[wMaxPool].PoolSize - wOff;
                           }

                           pDesc = NULL;

                           for (wPool = 0; wPool <= wMaxPool ; wPool++)
                           {
                              if ((pAppli->FreeDataPools[wPool].PoolSize >= (dword)(wSize+wOff)) && 
                                  (pAppli->FreeDataPools[wPool].PoolCount > 0))
                              {
                                 pDesc =(DataDesc_t *) iph_gpGetPoolUser(&pAppli->AppliMutex,
                                                                         &pAppli->CondVar,
                                                                         &pAppli->PoolInUse, 
                                                                         &pAppli->FreeDataPools[wPool],
                                                                         iFlags);
                                 if (pDesc != NULL)
                                    break;
                              }
                           }

                           /* At this point only the pDesc are mapped in kernel */
                           /* space, other fields of the structure DataDesc_t */
                           /* remain in user space, then some of them need */
                           /* to be mapped*/
                           if (pDesc != NULL)
                           {
                              /* get DataPtr in user space field value */
                              GET_DATA_DESC_PTRFIELD(pDesc, &MyAddr, DataPtr,
                                                  iFlags, &dwError, byte);
                              if (dwError == 0)
                              {
                                 /* copy the data */
                                 PUT_DATA_USER((void *)&MyAddr[wOff],
                                               (void *)&pSrc[wCopied],
                                               wSize, iFlags, &dwError);
                              }
                              if (dwError == 0)
                              {
                                 /* update Size and Offset fields */
                                 wVal = 0;
                                 PUT_DATA_DESC_WORDFIELD(pDesc, &wSize, Size,
                                                         iFlags, &dwError);
#ifdef TRACE
                                 iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ALIGNMENT, 
                                              wOff);
#endif

                                 PUT_DATA_DESC_WORDFIELD(pDesc, &wOff, Offset,
                                                         iFlags, &dwError);

                                 /* reset offset for next descriptor */
                                 wOff = 0;

                                 wCopied+=wSize;
                                 if (pLastDesc == NULL)
                                 {
                                    pFirstDesc = pDesc;

                                    /* update DataDescPtr field in primitive */
                                    PUT_PRIM_DESC_PTRFIELD(pPrim, &pDesc,
                                                           DataDescPtr,
                                                           iFlags, &dwError);
                                 }
                                 else
                                 {
#ifdef TRACE
                                    iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                                     (byte *)"[gdwCtlRecvPrim] chain a new DataDesc");
#endif
                                    /* update NextPtr field in data descriptor */
                                    PUT_DATA_DESC_PTRFIELD(pLastDesc, &pDesc,
                                                           NextPtr,
                                                           iFlags, &dwError);
                                 }
                                 pLastDesc = pDesc;
                              }
                              else
                              {
                                 dwError = EFAULT;
                              }
                           }
                           else
                           {
                              /* there is no buffer to contain this piece of */
                              /* data so we decrease the piece size */
                              if (wMaxPool > 0)
                              {
                                 wMaxPool--;
                              }
                              else
                              {
                                 iph_TRACEK(TRCLVL_0, DRIVER_NAME" no available buffer structure, (see CTL_GIVE_RX_BUFFER)");
                                 dwError = EAGAIN;
                              }
                           }
                        }
                        /* next descriptor to copy */
                        if (dwError == 0)
                        {
                           pSrcDesc = pSrcDesc->NextPtr;
                        }
                     }
                  }
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlRecvPrim] failed to copy the primitive header");
#endif
               }
               if (dwError == 0)
               {
                  /* update SizeInPool, and BuffInPool fields */
                  /* in primitive */
                  PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->SizeInPool,
                                          SizeInPool, iFlags, &dwError);

                  if (dwError == 0)
                  {
                     PUT_PRIM_DESC_WORDFIELD(pPrim, &pSrcPrim->BuffInPool,
                                             BuffInPool, iFlags, &dwError);
                  }
                  /* return primitive address */
                  PUT_PTRFIELD(pMem, &pPrim, iFlags, &dwError);

                  /* chain the primitive with the other primitives */
                  pLastDesc = NULL;
                  PUT_PRIM_DESC_PTRFIELD(pPrim, &pLastDesc, NextPtr,
                                         iFlags, &dwError);
                  if (dwError == 0)
                  {
                     PUT_PRIM_DESC_PTRFIELD(pPrim, &pLastPrim, PrevPtr,
                                            iFlags, &dwError);
                  }
                  if (dwError == 0 && pLastPrim != (PrimDesc_t *)0)
                  {
                     PUT_PRIM_DESC_PTRFIELD(pLastPrim, &pPrim, NextPtr,
                                            iFlags, &dwError);
                  }
                  if (dwError == 0)
                  {
                     if (pFirstPrim == (PrimDesc_t *)0)
                     {
                        pFirstPrim = pPrim;
                     }
                     pLastPrim = pPrim;
                     wChain++;
                  }
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlRecvPrim] failed to copy the DataDesc");
#endif
                  /* the primitive could not be completely copied so */
                  /* we release all the newly extracted structures */
                  while (pFirstDesc != NULL)
                  {
                     /* get NextPtr and Reserved fields in data descriptor */
                     GET_DATA_DESC_PTRFIELD(pFirstDesc, &pLastDesc, NextPtr,
                                            iFlags, &dwTmpError, DataDesc_t);
                     GET_DATA_DESC_WORDFIELD(pFirstDesc, &wVal, Reserved,
                                             iFlags, &dwTmpError);

                     /* release the data descriptor */
                     iph_gvPutPoolUser(&pAppli->AppliMutex,
                                       &pAppli->CondVar,
                                       &pAppli->PoolInUse, 
                                       &pAppli->FreeDataPools[wVal],
                                       (PoolItemPtr)pFirstDesc, 
                                       iFlags);
                     pFirstDesc = pLastDesc;
                  }
                  iph_gvPutPoolUser(&pAppli->AppliMutex,
                                    &pAppli->CondVar,
                                    &pAppli->PoolInUse, 
                                    &pAppli->FreePrimHeadPool,
                                    (PoolItemPtr)pPrim,
                                    iFlags);
                  /* return NULL address for primitive */
                  pPrim = (PrimDesc_t *)0;
                  PUT_PTRFIELD(pMem, &pPrim, iFlags, &dwTmpError);
               }
            }
            /* free the internal primitive */
            iph_gvReleaseDrvPrim(&pDev->DevMutex, pAppli, pDev, pSrcPrim);
         }
      }
      if (dwError == 0)
      {
         /* return primitive address */
         PUT_PTRFIELD(pMem, &pFirstPrim, iFlags, &dwError);
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlRecvPrim] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlMaxRxQueue
* DESCRIPTION : handle a CTL_MAX_RX_QUEUE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlMaxRxQueue(ApplCtxtPtr pAppli, int iFlags, 
                                  MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxRxQueue] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status */
   /* but allow operation for the controlling application */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the size of the received buffer (reject null value) */
         if (pMem->Size != sizeof(dword) || 
             pMem->DataPtr == (byte *)0 || 
             (word)(*(dword *)pMem->DataPtr) == 0)
         {
#ifdef TRACE
            if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxQueue] no data buffer!");
            else if ((word)(*(dword *)pMem->DataPtr) == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxQueue] unexpected size 0");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxQueue] unexpected argument size");
#endif
            dwError = EINVAL;
         }
         else
         {
            pAppli->MaxRecvNb = (word)(*(dword *)pMem->DataPtr);
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(dword) || 
                MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxRxQueue] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxRxQueue] unexpected argument size");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&dwVal,
                             sizeof(dword), iFlags, &dwError);
               if (dwError == 0)
               {
                  /* reject null value */
                  if (dwVal != 0)
                  {
                     pAppli->MaxRecvNb = (word)dwVal;
                  }
                  else
                     dwError = EINVAL;
               }
               else
                  dwError = EFAULT;
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxRxQueue] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlMaxRxChain
* DESCRIPTION : handle a CTL_MAX_RX_CHAIN ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlMaxRxChain(ApplCtxtPtr pAppli, int iFlags, 
                                  MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxRxChain] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status */
   /* but allow operation for the controlling application */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the size of the received buffer (reject null value) */
         if ((pMem->Size != sizeof(dword) && 
              pMem->Size != (2 * sizeof(dword))) || 
             pMem->DataPtr == (byte *)0 || 
             (word)(*(dword *)pMem->DataPtr) == 0)
         {
#ifdef TRACE
            if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxChain] no data buffer!");
            else if ((word)(*(dword *)pMem->DataPtr) == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxChain] unexpected size 0");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlMaxRxChain] unexpected argument size");
#endif
            dwError = EINVAL;
         }
         else
         {
            pAppli->MaxChainRecvNb = (word)(*(dword *)pMem->DataPtr);
            if (pMem->Size == 2*sizeof(dword))
            {
               pAppli->ChainGiveRx = (word)(((dword *)pMem->DataPtr)[1]);
            }
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if ((MyMem.Size != sizeof(dword) && 
                 MyMem.Size != (2 * sizeof(dword))) || 
                MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxRxChain] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxRxChain] unexpected argument size");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&dwVal,
                             sizeof(dword), iFlags, &dwError);
               if (dwError == 0)
               {
                  /* reject null value */
                  if (dwVal != 0)
                  {
                     pAppli->MaxChainRecvNb = (word)dwVal;
                     if (MyMem.Size == 2 * sizeof(dword))
                     {
                        GET_DATA_USER((void *)&MyMem.DataPtr[sizeof(dword)],
                                      (void *)&dwVal,
                                      sizeof(dword), iFlags, &dwError);
                        pAppli->ChainGiveRx = (word)dwVal;
                     }
                  }
                  else
                     dwError = EINVAL;
               }
               else
                  dwError = EFAULT;
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxRxChain] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlNoOfDev
* DESCRIPTION : handle a CTL_NO_OF_DEVICES ioctl
* PARAMETERS :
*    Input  : bAppliType = type of requesting application
*    Input  : iFlags = flags for copy
*    I/O    : pMem = pointer to a memory descriptor
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlNoOfDev(byte bAppliType, int iFlags, MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlNoOfDev] entry (appli type)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, bAppliType);
#endif

   dwError = 0;

   if (bAppliType == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size != sizeof(dword) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(dword))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlNoOfDev] argument is not a dword");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlNoOfDev] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
#ifdef TRACE
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_NO_OF_DEV, iph_gbAttachedCard);
#endif
         *(dword *)pMem->DataPtr = iph_gbAttachedCard;
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(dword) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(dword))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlNoOfDev] argument is not a dword");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlNoOfDev] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            dwVal = iph_gbAttachedCard;
            PUT_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&dwVal,
                          sizeof(dword), iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlNoOfDev] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGetCardId
* DESCRIPTION : handle a CTL_GET_CARD_ID ioctl
* PARAMETERS :
*    Input  : bAppliType = type of requesting application
*    Input  : iFlags = flags for copy
*    Input  : pWanDev = pointer on the device structure
*    I/O    : pMem = pointer to a memory descriptor
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlGetCardId(byte bAppliType, int iFlags,
                                 IphWanDevPtr pWanDev, MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   CardId_t CardId;
   CardId_t *pCardId;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetCardId] entry (appli type)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, bAppliType);
#endif

   dwError = 0;

   if (bAppliType == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size != sizeof(CardId_t) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(CardId_t))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGetCardId] argument is not a CardId_t");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGetCardId] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         pCardId = (CardId_t *)pMem->DataPtr;
         pCardId->Type = pWanDev->Type;
         pCardId->SerialNum = pWanDev->Serial;
         pCardId->ModemNb = pWanDev->PCIConf[RID_INDX];
         pCardId->Index = pWanDev->Index;
#ifdef LINUX
         pCardId->BusNum = pWanDev->sDev.iDev->bus->number;
         pCardId->SlotNum = PCI_SLOT(pWanDev->sDev.iDev->devfn);
#endif
#ifdef TRACE
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pWanDev->Index);
#endif
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(CardId_t) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(CardId_t))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetCardId] argument is not a CardId_t");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetCardId] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            CardId.Index = pWanDev->Index;
            CardId.Type = pWanDev->Type;
            CardId.SerialNum = pWanDev->Serial;
            CardId.ModemNb = pWanDev->PCIConf[RID_INDX];
#ifdef LINUX
            CardId.BusNum = pWanDev->sDev.iDev->bus->number;
            CardId.SlotNum = PCI_SLOT(pWanDev->sDev.iDev->devfn);
#endif
            PUT_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&CardId,
                          sizeof(CardId_t), iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetCardId] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlFreeControl
* DESCRIPTION : handle a CTL_FREE_CONTROL ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
* RETURN : 0 if all is OK
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlFreeControl(ApplCtxtPtr pAppli)
{
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlFreeControl] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);

   /* check control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlFreeControl] application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         pAppli->WanDevPtr->ControlAppli = (ApplCtxtPtr)0;
      }
   }

   MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlFreeControl] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpMem
* DESCRIPTION : handle a CTL_DUMP_MEM/CTL_READ_FLASH ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
*    Input  : iRegion = region index
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpMem(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem,
                               int iRegion)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte *pucMyBuff;
   long long val, limit=0xFFFFFFFF;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[iRegion];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlDumpMem] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpMem] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlDumpMem] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the parameter value and the offset */
         if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
             (pAppli->WanDevPtr->Region[MEM_REGION].MaxSize > 0 &&
              (pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[MEM_REGION].MaxSize))
         {
#ifdef TRACE
            if (pMem->Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpMem] argument size is 0");
            else if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpMem] no data buffer!");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpMem] offset out of range");
#endif
            dwError = EINVAL;
         }
         else
         {
            /* call to reading function that handles mapped window */
            MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
            dwError = RegPtr->Ops.readbuf(RegPtr, pMem->Offset, 
                                          pMem->Size, pMem->DataPtr);
            MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            /* (offset + size) must be within memory space limit */
            val = (long long)MyMem.Offset + (long long)MyMem.Size;

            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (pAppli->WanDevPtr->ControlAppli != pAppli &&
                 pAppli->WanDevPtr->Region[MEM_REGION].MaxSize > 0 &&
                 ((MyMem.Offset + MyMem.Size) > pAppli->WanDevPtr->Region[MEM_REGION].MaxSize)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpMem] argument size is 0");
               else if (pMem->DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpMem] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpMem] offset out of range");
#endif
               dwError = EINVAL;
            }
#if defined(LINUX) && defined(__powerpc__)
            else if (MyMem.Size > (128 << 10))
            {
#ifdef TRACE   
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpMem] argument size is > 128k");


#endif
               dwError = EINVAL;

            }
#endif
            else if ((val == 0) || (val > limit))
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpMem] (offset+size) exceeds 0xFFFFFFFF");
#endif
               dwError = EINVAL;
            }
            else
            {
               /* allocate a temporary buffer to dump the DRAM content */
               /*pucMyBuff = (byte *)TMP_ALLOC(MyMem.Size + (MyMem.Size % sizeof(dword)));*/
               TMP_ALLOC(MyMem.Size + (MyMem.Size % sizeof(dword)), &pucMyBuff);
               if (pucMyBuff == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpMem] memory allocation failed");
#endif
                  MyMem.Size = 0;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
                  dwError = ENOMEM;
               }
               else
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpMem] ready to read (offset-length");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Size);
#endif
                  /* call to reading function that handles mapped window */
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  dwError = RegPtr->Ops.readbuf(RegPtr, MyMem.Offset, 
                                                MyMem.Size, pucMyBuff);
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

                  if (dwError == 0)
                  {
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)pucMyBuff,
                                   MyMem.Size, iFlags, &dwError);
                  }

                  TMP_FREE(pucMyBuff);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlDumpMem] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlWriteMem
* DESCRIPTION : handle a CTL_WRITE_MEM/CTL_WRITE_FLASH ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
*    Input  : iRegion = region index
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlWriteMem(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem,
                                int iRegion)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte *pucMyB;
   long long val, limit=0xFFFFFFFF;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[iRegion];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gdwCtlWriteMem] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlWriteMem] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlWriteMem] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the parameter value and the offset */
         if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
             ((pMem->Offset + pMem->Size) >= pAppli->WanDevPtr->Region[MEM_REGION].MaxSize))
         {
#ifdef TRACE
            if (pMem->Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteMem] argument size is 0");
            else if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteMem] no data buffer!");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteMem] offset out of range");
#endif
            dwError = EINVAL;
         }
         else
         {
            /* call to writing function that handles mapped window */
            MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
            dwError = RegPtr->Ops.writebuf(RegPtr, pMem->Offset, 
                                           pMem->Size, pMem->DataPtr);
            MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
         }
      }
      else
      {
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            /* (offset + size) must be within memory space limit */
            val = (long long)MyMem.Offset + (long long)MyMem.Size;

            /* do not check for control appli */
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (pAppli->WanDevPtr->ControlAppli != pAppli &&
                 ((MyMem.Offset + MyMem.Size) >= pAppli->WanDevPtr->Region[MEM_REGION].MaxSize)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteMem] argument size is 0");
               else if (pMem->DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteMem] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteMem] offset out of range");
#endif
               dwError = EINVAL;
            }
#if defined(LINUX) && defined(__powerpc__)
            else if (MyMem.Size > (128 << 10))
            {
#ifdef TRACE   
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteMem] argument size is > 128k");

#endif
               dwError = EINVAL;

            }
#endif
            else if ((val == 0) || (val > limit))
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteMem] (offset+size) exceeds 0xFFFFFFFF");
#endif
               dwError = EINVAL;
            }
            else
            {
               /* allocate a temporary buffer to dump the DRAM content */
               pucMyB = (byte *)0;
#if defined(LINUX) && defined(__x86__)
               /* limite the size allocated by vmalloc to avoid */
               /* Linux 2.4.x vmalloc bug. The function causes */ 
               /* exception if size too big                     */
               if (MyMem.Size > IPH_MAX_VMALLOC_SIZE)
               {
                  dwError = ENOMEM;
               }
#endif
               if (dwError == 0)
               {
                  /*pucMyB = (byte *)TMP_ALLOC(MyMem.Size+(MyMem.Size % sizeof(dword)));*/
                  TMP_ALLOC(MyMem.Size+(MyMem.Size % sizeof(dword)), &pucMyB);
               }
               if (pucMyB == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteMem] memory allocation failed");
#endif
                  MyMem.Size = 0;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
                  dwError = ENOMEM;
               }
               else
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)pucMyB,
                                MyMem.Size, iFlags, &dwError);
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteMem] ready to write (offset-length");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Size);
#endif
                  /* call to writing function that handles mapped window */
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  switch (MyMem.Size)
                  {
                     case 1:
                        dwError = RegPtr->Ops.write8(RegPtr, 
                                                     MyMem.Offset, 
                                                     *pucMyB);
                        break;
                     case 2:
                        dwError = RegPtr->Ops.write16(RegPtr, 
                                                      MyMem.Offset, 
                                                      *(word *)pucMyB);
                        break;
                     case 4:
                        dwError = RegPtr->Ops.write32(RegPtr, 
                                                      MyMem.Offset, 
                                                      *(dword *)pucMyB);
                        break;
                     default:
                        dwError = RegPtr->Ops.writebuf(RegPtr, 
                                                       MyMem.Offset, 
                                                       MyMem.Size, 
                                                       pucMyB);
                        break;
                  }
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

                  TMP_FREE(pucMyB);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlWriteMem] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpReg
* DESCRIPTION : handle a CTL_DUMP_PLX_REG/CTL_DUMP_CORE_REG ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
*    Input  : iRegion = region index
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpReg(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem,
                               int iRegion)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal=0;
   word wVal;
   dword dwVal=0;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[iRegion];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpReg] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpReg] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   if (pAppli->Type == TYPE_KERNEL)
   {
      /* check the parameter value and the offset */
      if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
          (pMem->Size != sizeof(byte) && pMem->Size != sizeof(word) &&
           pMem->Size != sizeof(dword)) ||
          ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize))
      {
#ifdef TRACE
         if (pMem->Size == 0)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpReg] argument size is 0");
         else if (pMem->DataPtr == (byte *)0)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpReg] no data buffer!");
         else if ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpReg] offset out of range");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpReg] argument is not a byte, word, or dword");
#endif
         dwError = EINVAL;
      }
      else
      {
         if (pMem->Size == sizeof(byte))
         {
            RegPtr->Ops.read8(RegPtr, pMem->Offset, &ucVal);
            *pMem->DataPtr = ucVal;
         }
         else if (pMem->Size == sizeof(word))
         {
            RegPtr->Ops.read16(RegPtr, pMem->Offset, &wVal);
            wVal = REG_PCI16_TO_APPLIS(wVal);
#ifdef SOLARIS
            if (RegPtr->BigEnd == TRUE)
               wVal = HOST_CARD16(wVal);
#endif
            *(word *)pMem->DataPtr = wVal;
         }
         else
         {
            RegPtr->Ops.read32(RegPtr, pMem->Offset, &dwVal);
            dwVal = REG_PCI32_TO_APPLIS(dwVal);
#ifdef SOLARIS
            if (RegPtr->BigEnd == TRUE)
               dwVal = HOST_CARD32(dwVal);
#endif
            *(dword *)pMem->DataPtr = dwVal;
         }
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         /* check the parameter value and the offset */
         if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
             (MyMem.Size != sizeof(byte) && MyMem.Size != sizeof(word) &&
              MyMem.Size != sizeof(dword)) ||
             ((MyMem.Offset + MyMem.Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize))
         {
#ifdef TRACE
            if (pMem->Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpReg] argument size is 0");
            else if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpReg] no data buffer!");
            else if ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpReg] offset out of range");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpReg] argument is not a byte, word, or dword");
#endif
            dwError = EINVAL;
         }
         else
         {
#ifdef TRACE 
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpReg] ready to read register (offset-length");
            iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
            iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Size);
#endif
            if (MyMem.Size == sizeof(byte))
            {
               RegPtr->Ops.read8(RegPtr, MyMem.Offset, &ucVal);
               PUT_DATA_USER((void *)MyMem.DataPtr, 
                             (void *)&ucVal, 
                             MyMem.Size, iFlags, &dwError);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                                (byte *)"[gdwCtlDumpReg] Value Read byte ");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, ucVal);
#endif
            }
            else if ((MyMem.Size == sizeof(word)))
            {
               RegPtr->Ops.read16(RegPtr, MyMem.Offset, &wVal);
               wVal = REG_PCI16_TO_APPLIS(wVal);
#ifdef SOLARIS
               if (RegPtr->BigEnd == TRUE)
                  wVal = HOST_CARD16(wVal);
#endif
               PUT_DATA_USER((void *)MyMem.DataPtr, 
                             (void *)&wVal,  
                             MyMem.Size, iFlags, &dwError);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                                (byte *)"[gdwCtlDumpReg] Value Read dword ");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, wVal);
#endif
            }
            else
            {
               RegPtr->Ops.read32(RegPtr, MyMem.Offset, &dwVal);
               dwVal = REG_PCI32_TO_APPLIS(dwVal);
#ifdef SOLARIS
               if (RegPtr->BigEnd == TRUE)
                  dwVal = HOST_CARD32(dwVal);
#endif
               PUT_DATA_USER((void *)MyMem.DataPtr, 
                             (void *)&dwVal,  
                             MyMem.Size, iFlags, &dwError);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                                (byte *)"[gdwCtlDumpReg] Value Read dword ");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwVal);
#endif
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpReg] return ");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);

#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlWriteReg
* DESCRIPTION : handle a CTL_WRITE_PLX_REG/CTL_WRITE_CORE_REG ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
*    Input  : iRegion = region index
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV is the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlWriteReg(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem,
                                int iRegion)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[iRegion];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlWriteReg] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlWriteReg] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlWriteReg] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the parameter value and the offset */
         if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
             (pMem->Size != sizeof(byte) && pMem->Size != sizeof(word) &&
              pMem->Size != sizeof(dword)) ||
             ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize))
         {
#ifdef TRACE
            if (pMem->Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteReg] argument size is 0");
            else if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteReg] no data buffer!");
            else if ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteReg] offset out of range");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWriteReg] argument is not a byte, word, or dword");
#endif
            dwError = EINVAL;
         }
         else
         {
            if (pMem->Size == sizeof(byte))
            {
               ucVal = *pMem->DataPtr;
               RegPtr->Ops.write8(RegPtr, pMem->Offset, ucVal);
            }
            else if (pMem->Size == sizeof(word))
            {
               wVal = *(word *)pMem->DataPtr;
#ifdef SOLARIS
               if (RegPtr->BigEnd == TRUE)
                  wVal = HOST_CARD16(wVal);
#endif
               wVal = REG_PCI16_FROM_APPLIS(wVal);
               RegPtr->Ops.write16(RegPtr, pMem->Offset, wVal);
            }
            else
            {
               dwVal = *(dword *)pMem->DataPtr;
#ifdef SOLARIS
               if (RegPtr->BigEnd == TRUE)
                  dwVal = HOST_CARD32(dwVal);
#endif
               dwVal = REG_PCI32_FROM_APPLIS(dwVal);
               RegPtr->Ops.write32(RegPtr, pMem->Offset, dwVal);
            }
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (MyMem.Size != sizeof(byte) && MyMem.Size != sizeof(word) &&
                 MyMem.Size != sizeof(dword)) ||
                ((MyMem.Offset + MyMem.Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize))
            {
#ifdef TRACE
               if (pMem->Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] argument size is 0");
               else if (pMem->DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] no data buffer!");
               else if ((pMem->Offset + pMem->Size) > pAppli->WanDevPtr->Region[iRegion].MaxSize)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] offset out of range");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] argument is not a byte, word, or dword");
#endif
               dwError = EINVAL;
            }
            else
            {
               if (MyMem.Size == sizeof(byte))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr, 
                                (void *)&ucVal,  
                                MyMem.Size, iFlags, &dwError);
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] ready to write 8-bit register (offset-value");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, ucVal);
#endif
                  RegPtr->Ops.write8(RegPtr, MyMem.Offset, ucVal);

                  dwError = 0;
               }
               else if (MyMem.Size == sizeof(word))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr, 
                                (void *)&wVal,  
                                MyMem.Size, iFlags, &dwError);
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] ready to write 16-bit register (offset-value");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, wVal);
#endif
#ifdef SOLARIS
                  if (RegPtr->BigEnd == TRUE)
                     wVal = HOST_CARD16(wVal);
#endif
                  wVal = REG_PCI16_FROM_APPLIS(wVal);
                  RegPtr->Ops.write16(RegPtr, MyMem.Offset, wVal);

                  dwError = 0;
               }
               else
               {
                  GET_DATA_USER((void *)MyMem.DataPtr, 
                                (void *)&dwVal,  
                                MyMem.Size, iFlags, &dwError);
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWriteReg] ready to write 32-bit register (offset-value");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwVal);
#endif
#ifdef SOLARIS
                  if (RegPtr->BigEnd == TRUE)
                     dwVal = HOST_CARD32(dwVal);
#endif
                  dwVal = REG_PCI32_FROM_APPLIS(dwVal);
                  RegPtr->Ops.write32(RegPtr, MyMem.Offset, dwVal);

                  dwError = 0;
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlWriteReg] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpPCIConf
* DESCRIPTION : handle a CTL_DUMP_PCI_CONF ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 02/06/06 
*      - If offset is >= 0x10000, dump PCI configuration register for PQ3
**************************************************************************/
static dword drv_gdwCtlDumpPCIConf(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpPCIConf] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpPCIConf] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   if (pAppli->Type == TYPE_KERNEL)
   {
      /* check the parameter value */
      if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
          (pMem->Size != sizeof(byte) &&
           pMem->Size != sizeof(word) &&
           pMem->Size != sizeof(dword)))
      {
#ifdef TRACE
         if (pMem->Size == 0)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpPCIConf] argument size is 0");
         else if (pMem->DataPtr == (byte *)0)
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpPCIConf] no data buffer!");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpPCIConf] argument is not a byte, word or dword");
#endif
         dwError = EINVAL;
      }
      else
      {
         if (dwError == 0)
         {
            if (pMem->Offset < 0x10000)
            {
               if (pMem->Size == sizeof(byte))
               {
                  READ_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.iDev, 
                                     pMem->Offset,
                                     &ucVal);
                  *pMem->DataPtr = ucVal;
               }
               else if (pMem->Size == sizeof(word))
               {
                  READ_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.iDev, 
                                     pMem->Offset,
                                     &wVal);
                  *(word *)pMem->DataPtr = REG_PCI16_TO_APPLIS(wVal);
               }
               else
               {
                  READ_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.iDev, 
                                      pMem->Offset,
                                      &dwVal);
                  *(dword *)pMem->DataPtr = REG_PCI32_TO_APPLIS(dwVal);
               }
            }
            else
            {
               if (pMem->Size == sizeof(byte))
               {
                  ucVal = pAppli->WanDevPtr->PCIConf[pMem->Offset - 0x10000];
                  *pMem->DataPtr = ucVal;
               }
               else if (pMem->Size == sizeof(word))
               {
                  wVal = *((word *)&pAppli->WanDevPtr->PCIConf[pMem->Offset - 0x10000]);
                  *(word *)pMem->DataPtr = REG_PCI16_TO_APPLIS(wVal);
               }
               else
               {
                  dwVal = *((dword *)&pAppli->WanDevPtr->PCIConf[pMem->Offset - 0x10000]);
                  *(dword *)pMem->DataPtr = REG_PCI32_TO_APPLIS(dwVal);
               }
            }
         }
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
             (MyMem.Size != sizeof(byte) &&
              MyMem.Size != sizeof(word) &&
              MyMem.Size != sizeof(dword)))
         {
#ifdef TRACE
            if (MyMem.Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPCIConf] argument size is 0");
            else if (MyMem.DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPCIConf] no data buffer!");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPCIConf] argument is not a byte, word or dword");
#endif
            dwError = EINVAL;
         }
         else
         {
            dwError = 0;

            if (dwError == 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPCIConf] ready to dump offset-size (val)");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                            MyMem.Offset, MyMem.Size);
#endif
               if (MyMem.Offset < 0x10000)
               {
                  if (MyMem.Size == sizeof(byte))
                  {
                     READ_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.iDev, 
                                        MyMem.Offset,
                                        &ucVal);
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)ucVal);
#endif
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&ucVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
                  else if (MyMem.Size == sizeof(word))
                  {
                     READ_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.iDev, 
                                        MyMem.Offset,
                                        &wVal);
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)wVal);
#endif
                     wVal = REG_PCI16_TO_APPLIS(wVal);
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&wVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
                  else
                  {
                     READ_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.iDev, 
                                         MyMem.Offset,
                                         &dwVal);
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)dwVal);
#endif
                     dwVal = REG_PCI32_TO_APPLIS(dwVal);
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&dwVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
               }
               else
               {
                  if (MyMem.Size == sizeof(byte))
                  {
                     ucVal = pAppli->WanDevPtr->PCIConf[MyMem.Offset - 0x10000];
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)ucVal);
#endif
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&ucVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
                  else if (MyMem.Size == sizeof(word))
                  {
                     wVal = *((word *)&pAppli->WanDevPtr->PCIConf[MyMem.Offset - 0x10000]);
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)wVal);
#endif
                     wVal = REG_PCI16_TO_APPLIS(wVal);
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&wVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
                  else
                  {
                     dwVal = *((dword *)&pAppli->WanDevPtr->PCIConf[MyMem.Offset - 0x10000]);
#ifdef TRACE
                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                                  (dword)dwVal);
#endif
                     dwVal = REG_PCI32_TO_APPLIS(dwVal);
                     PUT_DATA_USER((void *)MyMem.DataPtr,
                                   (void *)&dwVal,
                                   MyMem.Size, iFlags, &dwError);
                  }
               }
            }
         }
      }
   }
#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpPCIConf] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlWritePCIConf
* DESCRIPTION : handle a CTL_WRITE_PCI_CONF ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 02/06/06 
*      - If offset is >= 0x10000, update PCI configuration register for PQ3
**************************************************************************/
static dword drv_gdwCtlWritePCIConf(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlWritePCIConf] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlWritePCIConf] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlWritePCIConf] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the parameter value */
         if (pMem->Size == 0 || pMem->DataPtr == (byte *)0 ||
             (pMem->Size != sizeof(byte) &&
              pMem->Size != sizeof(word) &&
              pMem->Size != sizeof(dword)))
         {
#ifdef TRACE
            if (pMem->Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWritePCIConf] argument size is 0");
            else if (pMem->DataPtr == (byte *)0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWritePCIConf] no data buffer!");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlWritePCIConf] argument is not a byte, word or dword");
#endif
            dwError = EINVAL;
         }
         else
         {
            if (dwError == 0)
            {
               if (pMem->Offset < 0x10000)
               {
                  if (pMem->Size == sizeof(byte))
                  {
                     ucVal = *pMem->DataPtr;
                     WRITE_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.iDev, 
                                         pMem->Offset,
                                         ucVal);
                  }
                  else if (pMem->Size == sizeof(word))
                  {
                     wVal = REG_PCI16_FROM_APPLIS(*(word *)pMem->DataPtr);
                     WRITE_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.iDev, 
                                         pMem->Offset,
                                         wVal);
                  }
                  else
                  {
                     dwVal = REG_PCI32_FROM_APPLIS(*(dword *)pMem->DataPtr);
                     WRITE_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.iDev, 
                                          pMem->Offset,
                                          dwVal);
                  }
               }
               else
               {
                  if (pMem->Size == sizeof(byte))
                  {
                     ucVal = *pMem->DataPtr;
                     WRITE_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.Dev, 
                                         pMem->Offset - 0x10000,
                                         ucVal);
                  }
                  else if (pMem->Size == sizeof(word))
                  {
                     wVal = REG_PCI16_FROM_APPLIS(*(word *)pMem->DataPtr);
                     WRITE_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.Dev, 
                                         pMem->Offset - 0x10000,
                                         wVal);
                  }
                  else
                  {
                     dwVal = REG_PCI32_FROM_APPLIS(*(dword *)pMem->DataPtr);
                     WRITE_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.Dev, 
                                          pMem->Offset - 0x10000,
                                          dwVal);
                  }
               }
            }
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (MyMem.Size != sizeof(byte) &&
                 MyMem.Size != sizeof(word) &&
                 MyMem.Size != sizeof(dword)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWritePCIConf] argument size is 0");
               else if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *) "[gdwCtlWritePCIConf] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlWritePCIConf] argument is not a byte, word or dword");
#endif
               dwError = EINVAL;
            }
            else
            {
               if (dwError == 0)
               {
                  if (MyMem.Offset < 0x10000)
                  {
                     if (MyMem.Size == sizeof(byte))
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&ucVal,
                                      MyMem.Size, iFlags, &dwError);

                        WRITE_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.iDev, 
                                            MyMem.Offset,
                                            ucVal);
                     }
                     else if (MyMem.Size == sizeof(word))
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&wVal,
                                      MyMem.Size, iFlags, &dwError);
                        wVal = REG_PCI16_FROM_APPLIS(wVal);
                        WRITE_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.iDev, 
                                            MyMem.Offset,
                                            wVal);
                     }
                     else
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&dwVal,
                                      MyMem.Size, iFlags, &dwError);
                        dwVal = REG_PCI32_FROM_APPLIS(dwVal);
                        WRITE_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.iDev, 
                                             MyMem.Offset,
                                             dwVal);
                     }
                  }
                  else
                  {
                     if (MyMem.Size == sizeof(byte))
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&ucVal,
                                      MyMem.Size, iFlags, &dwError);

                        WRITE_PCI_CONF_BYTE(pAppli->WanDevPtr->sDev.Dev, 
                                            MyMem.Offset - 0x10000,
                                            ucVal);
                     }
                     else if (MyMem.Size == sizeof(word))
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&wVal,
                                      MyMem.Size, iFlags, &dwError);
                        wVal = REG_PCI16_FROM_APPLIS(wVal);
                        WRITE_PCI_CONF_WORD(pAppli->WanDevPtr->sDev.Dev, 
                                            MyMem.Offset - 0x10000,
                                            wVal);
                     }
                     else
                     {
                        GET_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&dwVal,
                                      MyMem.Size, iFlags, &dwError);
                        dwVal = REG_PCI32_FROM_APPLIS(dwVal);
                        WRITE_PCI_CONF_DWORD(pAppli->WanDevPtr->sDev.Dev, 
                                             MyMem.Offset - 0x10000,
                                             dwVal);
                     }
                  }
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlWritePCIConf] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGetDrvVer
* DESCRIPTION : handle a CTL_GET_DRV_VER ioctl
* PARAMETERS :
*    Input  : ucAppliType = application type
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlGetDrvVer(byte ucAppliType, int iFlags, MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   word wVal;
   char bTmp[4];
   byte bCount;
   char *pbTmp;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetDrvVer] entry");
#endif

   dwError = 0;

   for (bCount = 0; bCount < strlen(_VERSION_) && _VERSION_[bCount] != '.'; 
        bCount++)
   {
      bTmp[bCount] = _VERSION_[bCount];
   }
   bTmp[bCount] = 0;
   pbTmp = bTmp;
   wVal = (word)stoi(&pbTmp);
   strcpy(bTmp, &_VERSION_[bCount+1]);
   pbTmp = bTmp;
   wVal = (wVal << 8) + (word)stoi(&pbTmp);

   if (ucAppliType == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size != sizeof(word) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(word))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGetDrvVer] argument is not a word");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlGetDrvVer] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
#ifdef TRACE
         iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_NO_OF_DEV, iph_gbAttachedCard);
#endif
         *(word *)pMem->DataPtr = wVal;
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(word) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(word))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetDrvVer] argument is not a word");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetDrvVer] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            PUT_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&wVal,
                          sizeof(word), iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetDrvVer] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpCPUUsage
* DESCRIPTION : handle a CTL_DUMP_CPU_USAGE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpCPUUsage(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   word wVal;
   ProcArea_t Area;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[MEM_REGION];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpCPUUsage] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpCPUUsage] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlDumpCPUUsage] bad status");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the size of the received buffer */
         if (pMem->Size != sizeof(word) || pMem->DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (pMem->Size != sizeof(word))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpCPUUsage] argument is not a word");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpCPUUsage] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            /* call to reading function that handles mapped window */
            MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
            RegPtr->Ops.readbuf(RegPtr, 
                                pAppli->WanDevPtr->ProcAreaStart +
                                (dword)((char *)&Area.CPUUsage - (char *)&Area),
                                sizeof(word), (byte *)&wVal);
            MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
            wVal = HOST_CARD16(wVal);
            *(word *)pMem->DataPtr = wVal;
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(word) || MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(word))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpCPUUsage] argument is not a word");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpCPUUsage] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
               RegPtr->Ops.readbuf(RegPtr, 
                                   pAppli->WanDevPtr->ProcAreaStart +
                                   (dword)((char *)&Area.CPUUsage - (char *)&Area),
                                   sizeof(word), (byte *)&wVal);
               MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
               wVal = HOST_CARD16(wVal);
               PUT_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&wVal, 
                             sizeof(word), iFlags, &dwError);
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpCPUUsage] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpPool
* DESCRIPTION : handle a CTL_DUMP_POOL ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpPool(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem)
{
   dword dwError=0;
#ifdef _LITTLE_ENDIAN
   dword i,*pDword;
#endif
   MemDesc_t MyMem;
   byte *pucBuff, *pucPrimBuff, *pucBuffDesc;
   byte *pucMyBuff;
   dword dwSizeToDump;
   dword NbBuffPool;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[MEM_REGION];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpPool] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpPool] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlDumpPool] adapter not ready status");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         /* check the size of the received buffer */
         if (pMem->Size < sizeof(AdapterPool_t) ||
             pMem->DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (pMem->Size != sizeof(AdapterPool_t))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPool] size too short ");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpPool] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
            /* get information about what to dump */
            READ_EXCH_NB_SYSBUFF_POOL(pAppli->WanDevPtr,
                                      pAppli->WanDevPtr->ExchArea, 
                                      &NbBuffPool);
            /* Add the primitive and buffer descriptor pools */
            if ((NbBuffPool+2) > (pMem->Size / sizeof(AdapterPool_t)))
            {
               dwSizeToDump = pMem->Size / sizeof(AdapterPool_t);
            }
            dwSizeToDump = (NbBuffPool+2) * sizeof(AdapterPool_t);

            /* get the direct offset of what to dump */
            pucBuff = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->SysBuffPool);
            pucPrimBuff = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->PrimBuffPool);
            pucBuffDesc = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->DescrBuffPool);
            /* Dump the buffer pools */
            RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucBuff, 
                                (NbBuffPool*sizeof(AdapterPool_t)), pMem->DataPtr);
            /* Dump the primitive pool */
            RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucPrimBuff, 
                                sizeof(AdapterPool_t), pMem->DataPtr+(NbBuffPool*sizeof(AdapterPool_t)));
            /* Dump the buffer descriptor pool */
            RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucBuffDesc, 
                                sizeof(AdapterPool_t), pMem->DataPtr+((NbBuffPool+1)*sizeof(AdapterPool_t)));
            MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
            pMem->Size = dwSizeToDump;
#ifdef _LITTLE_ENDIAN
            /* Swap the data to have the right endian */
            pDword = (dword *)pMem->DataPtr;
            dwSizeToDump = dwSizeToDump /4;
            for (i = 0; i < dwSizeToDump; i++)
            {
               pDword[i] = HOST_CARD32(pDword[i]);
            }
#endif
         }
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size < sizeof(AdapterPool_t) ||
                MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size < sizeof(AdapterPool_t))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpPool] size too short");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpPool] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
               /* get information about what to dump */
               READ_EXCH_NB_SYSBUFF_POOL(pAppli->WanDevPtr,
                                         pAppli->WanDevPtr->ExchArea,
                                         &NbBuffPool);
               MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
               /* Add the primitive and buffer descriptor pools */
               if ((NbBuffPool+2) > (MyMem.Size / sizeof(AdapterPool_t)))
               {
                  dwSizeToDump = MyMem.Size / sizeof(AdapterPool_t);
               }
               dwSizeToDump = (NbBuffPool+2) * sizeof(AdapterPool_t);

               /* allocate a temporary buffer to dump the DRAM content */
               TMP_ALLOC(dwSizeToDump, &pucMyBuff);
               if (pucMyBuff == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpPool] memory allocation failed");
#endif
                  MyMem.Size = 0;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
                  dwError = ENOMEM;
               }
               else
               {
                  /* get the direct offset of what to dump */
                  pucBuff = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->SysBuffPool);
                  pucPrimBuff = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->PrimBuffPool);
                  pucBuffDesc = (byte *)&(((V5_CardCtrlArea_t *)(unsigned long)(pAppli->WanDevPtr->ExchArea))->DescrBuffPool);
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  /* Dump the buffer pools */
                  RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucBuff, 
                                      (NbBuffPool*sizeof(AdapterPool_t)), pucMyBuff);
                  /* Dump the primitive pool */
                  RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucPrimBuff, 
                                      sizeof(AdapterPool_t), pucMyBuff+(NbBuffPool*sizeof(AdapterPool_t)));
                  /* Dump the buffer descriptor pool */
                  RegPtr->Ops.readbuf(RegPtr, (dword)(unsigned long)pucBuffDesc, 
                                      sizeof(AdapterPool_t), pucMyBuff+((NbBuffPool+1)*sizeof(AdapterPool_t)));
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
                  MyMem.Size = dwSizeToDump;
#ifdef _LITTLE_ENDIAN
                  /* Swap the data to have the right endian */
                  pDword = (dword *)pucMyBuff;
                  dwSizeToDump = dwSizeToDump /4;
                  for (i = 0; i < dwSizeToDump; i++)
                  {
                     pDword[i] = HOST_CARD32(pDword[i]);
                  }
#endif
                  PUT_DATA_USER((void *)MyMem.DataPtr,
                                (void *)pucMyBuff, 
                                MyMem.Size, iFlags, &dwError);
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);

                  TMP_FREE(pucMyBuff);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpDrvPool
* DESCRIPTION : handle a CTL_DUMP_DRV_POOL ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpDrvPool(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwSizeToDump;
   dword dwSizeCopied;
   dword dwArgSize;
   word wCount;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpDrvPool] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      /* check the size of the received buffer */
      if (pMem->Size < sizeof(DrvPool_t) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(DrvPool_t))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpDrvPool] size too short ");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlDumpDrvPool] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         /* get information about what to dump */
         dwSizeToDump = (1 + MAX_DRV_POOL) * sizeof(DrvPool_t);
         if (dwSizeToDump > (pMem->Size / sizeof(DrvPool_t)))
            dwSizeToDump = pMem->Size / sizeof(DrvPool_t);
         dwSizeToDump = dwSizeToDump * sizeof(DrvPool_t);

         bcopy((void *)&pAppli->WanDevPtr->FreePrimHeadPool,
               (void *)pMem->DataPtr, sizeof(DrvPool_t));
         if (dwSizeToDump > sizeof(DrvPool_t))
            bcopy((void *)&pAppli->WanDevPtr->FreeDataPools,
                  (void *)&pMem->DataPtr[sizeof(DrvPool_t)], 
                  dwSizeToDump - sizeof(DrvPool_t));
         pMem->Size = dwSizeToDump;
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         dwArgSize = sizeof(DrvPool_t);
#if defined(SOLARIS) && defined(_MULTI_DATAMODEL)
         if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)
         {
            dwArgSize = sizeof(DrvPool32_t);
         }
#endif
#ifdef LINUX
         if (iFlags == MODE_32)
         {
            dwArgSize = sizeof(DrvPool32_t);
         }
#endif
         if (MyMem.Size < dwArgSize || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size < dwArgSize)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpDrvPool] size too short");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpDrvPool] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            /* get information about what to dump */
            dwSizeToDump = (1 + MAX_DRV_POOL) * dwArgSize;
            if (dwSizeToDump > (MyMem.Size / dwArgSize))
               dwSizeToDump = MyMem.Size / dwArgSize;
            dwSizeToDump = dwSizeToDump * dwArgSize;

            dwSizeCopied = 0;
            PUT_DRV_POOL(&pAppli->WanDevPtr->FreePrimHeadPool,
                         &MyMem.DataPtr[dwSizeCopied],
                         iFlags, &dwArgSize, &dwError);
            if (dwError == 0)
            {
               dwSizeCopied+=dwArgSize;
               wCount = 0;
               while (wCount < MAX_DRV_POOL &&
                      dwSizeCopied < dwSizeToDump &&
                      dwError == 0)
               {
                  PUT_DRV_POOL(&pAppli->WanDevPtr->FreeDataPools[wCount],
                               &MyMem.DataPtr[dwSizeCopied],
                               iFlags, &dwArgSize, &dwError);
                  dwSizeCopied+=dwArgSize;
                  wCount++;
               }
               MyMem.Size = dwSizeCopied;
            }
            else
            {
               MyMem.Size = 0;
            }
            /* copy the memory descriptor */
            PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpDrvPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpSeepromByte
* DESCRIPTION : handle a CTL_DUMP_SEEPROM_BYTE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
**************************************************************************/
static dword drv_gdwCtlDumpSeepromByte(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal=0;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gdwCtlDumpSeepromByte] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[drv_gdwCtlDumpSeepromByte] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         /* check the parameter value and the offset */
         if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 )
         {
#ifdef TRACE
            if (MyMem.Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[drv_gdwCtlDumpSeepromByte] argument size is 0 !");
            else 
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[drv_gdwCtlDumpSeepromByte] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
#ifdef TRACE 
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[drv_gdwCtlDumpSeepromByte] ready to read seeprom (offset)");
            iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
#endif

            if ( iph_gdwI2CByteRead_PQ3 ( pAppli->WanDevPtr, I2C_SEEPROM_ADDR, MyMem.Offset, sizeof(word), &ucVal ) != 0 )
               dwError = EBUSY;
            else
            {
               PUT_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&ucVal, sizeof(byte), iFlags, &dwError);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                                (byte *)"[drv_gdwCtlDumpSeepromByte] Value Read byte ");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, ucVal);
#endif
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gdwCtlDumpSeepromByte] return ");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);

#endif
   return(dwError);
}


/**************************************************************************
* NAME : drv_gdwCtlWriteSeepromByte
* DESCRIPTION : handle a CTL_DUMP_SEEPROM_BYTE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENODEV if the device is not accessible
* REVISION :
**************************************************************************/
static dword drv_gdwCtlWriteSeepromByte(ApplCtxtPtr pAppli, int iFlags, MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gdwCtlWriteSeepromByte] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[drv_gdwCtlWriteSeepromByte] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[drv_gdwCtlWriteSeepromByte] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(byte) || MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(byte))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[drv_gdwCtlWriteSeepromByte] argument size is not 1");
               else 
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[drv_gdwCtlWriteSeepromByte] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr, 
                             (void *)&ucVal,  
                             MyMem.Size, iFlags, &dwError);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[drv_gdwCtlWriteSeepromByte] ready to write a serial eeprom byte (offset-value");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, MyMem.Offset);
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, ucVal);
#endif
               if ( iph_gdwI2CByteWrite_PQ3 ( pAppli->WanDevPtr, I2C_SEEPROM_ADDR, MyMem.Offset, sizeof(word), ucVal ) != 0 )
                  dwError = EBUSY;

               dwError = 0;
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[drv_gdwCtlWriteSeepromByte] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}


/**************************************************************************
* NAME : drv_gdwCtlMaxTransferSize
* DESCRIPTION : handle a CTL_MAX_TRANSFER_SIZE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlMaxTransferSize(ApplCtxtPtr pAppli, int iFlags, 
                                       MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxTransferSize] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlMaxTransferSize] Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (MyMem.Size != sizeof(byte) &&
                 MyMem.Size != sizeof(word) &&
                 MyMem.Size != sizeof(dword)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxTransferSize] argument size is 0");
               else if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxTransferSize] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlMaxTransferSize] argument is not a byte, word or dword");
#endif
               dwError = EINVAL;
            }
            else
            {
               if (MyMem.Size == sizeof(byte))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&ucVal, 
                                MyMem.Size, iFlags, &dwError);
                  wVal = ucVal;
               }
               else if (MyMem.Size == sizeof(word))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&wVal, 
                                MyMem.Size, iFlags, &dwError);
               }
               else
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&dwVal, 
                                MyMem.Size, iFlags, &dwError);
                  /* Check that the specified value is a 16-bit value */
                  if (dwVal > 0xFFFF)
                  {
                     dwError = EINVAL;
                  }
                  else
                  {
                     wVal = dwVal;
                  }
               }

               if (dwError == 0)
               {
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  pAppli->WanDevPtr->MaxTransferSize = wVal;
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlMaxTransferSize] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlInitPrimPool
* DESCRIPTION : handle a CTL_INIT_PRIM_POOL ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlInitPrimPool(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   AllocPool_t MyAllocPool;
   DrvPool_t *pPool;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitPrimPool] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlInitPromPool] Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(AllocPool_t) ||
                MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(AllocPool_t))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitPrimPool] argument is not a AllocPool_t");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitPrimPool] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&MyAllocPool, 
                             MyMem.Size, iFlags, &dwError);

               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
               pPool = &pAppli->WanDevPtr->FreePrimHeadPool;
               pPool->PoolSize = sizeof(PrimDesc_t);
               pPool->InitCount = MyAllocPool.Nb;
               pPool->MaxCount = MyAllocPool.MaxNb;
               if (pPool->TotalCount > pPool->MaxCount)
                  pPool->MaxCount = pPool->TotalCount;
               MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

               /* allocation is completed in gdwInitOnLoadEnd */

               if (dwError == 0)
               {
                  /* update the user structure */
                  MyAllocPool.MaxNb = (word)pPool->MaxCount;
                  PUT_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&MyAllocPool, 
                                MyMem.Size, iFlags, &dwError);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitPrimPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlInitBufferPool
* DESCRIPTION : handle a CTL_INIT_BUFFER_POOL ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlInitBufferPool(ApplCtxtPtr pAppli, int iFlags, 
                                      MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   AllocPool_t MyAllocPool;
   DrvPool_t *pPool;
   word wCount;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitBufferPool] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlInitBufferPool] Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(AllocPool_t) ||
                MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(AllocPool_t))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitBufferPool] argument is not a AllocPool_t");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitBufferPool] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&MyAllocPool, 
                             MyMem.Size, iFlags, &dwError);
               /* check the pool index */
               if (MyAllocPool.Index >= MAX_DRV_POOL)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitBufferPool] invalid pool index");
#endif
                  dwError = EINVAL;
               }
               else
               {
                  pPool = &pAppli->WanDevPtr->FreeDataPools[MyAllocPool.Index];

                  /* checks whether this is a redefinition and */
                  /* the redefinition is compatible */
                  if (pPool->MaxCount != 0 &&
                      pPool->PoolSize != MyAllocPool.Size)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] inconsistent pool redefinition");
#endif
                     dwError = EINVAL;
                  }
                  else if ((MyAllocPool.Index > 0) &&
                           (pAppli->WanDevPtr->FreeDataPools[MyAllocPool.Index -1].PoolSize >= 
                            MyAllocPool.Size))
                  {

#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] inconsistent pool definition");

                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] pool size <= previous pool");

#endif
                     dwError = EINVAL;
                  }
                  else if ((MyAllocPool.Index < (MAX_DRV_POOL -1)) &&
                           ((pAppli->WanDevPtr->FreeDataPools[MyAllocPool.Index + 1].PoolSize > 0 ) &&
                            (pAppli->WanDevPtr->FreeDataPools[MyAllocPool.Index + 1].PoolSize <= MyAllocPool.Size)))
                  {

#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] inconsistent pool definition");

                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] pool size >= next pool");

#endif
                     dwError = EINVAL;
                  }
                  else if (MyAllocPool.Nb == 1)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] InitCount must be != 1");
#endif
                     dwError = EINVAL;
                  }
                  else
                  {
                     for (wCount = 0; wCount < MyAllocPool.Index; wCount++)
                     {
                        if (pAppli->WanDevPtr->FreeDataPools[wCount].PoolSize == 0 )
                        {

#ifdef TRACE
                           iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                            (byte *)"[gdwCtlInitBufferPool] inconsistent pool definition");

                           iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                            (byte *)"[gdwCtlInitBufferPool] one previous pool not defined");
#endif
                           dwError = EINVAL;
                           break;
                        }
                     }
                  }

                  if (dwError == 0)
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitBufferPool] received");

                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_POOL_SIZE, MyAllocPool.Size);

                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_INIT_COUNT, MyAllocPool.Nb);

                     iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_MAX_COUNT, MyAllocPool.MaxNb);
#endif

                     MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                     pPool->PoolSize = MyAllocPool.Size;
                     if (pPool->InitCount == 0 || pPool->TotalCount == 0)
                     {
                        pPool->InitCount = MyAllocPool.Nb;
                     }
                     pPool->MaxCount = MyAllocPool.MaxNb;
                     if (pPool->TotalCount > pPool->MaxCount)
                        pPool->MaxCount = pPool->TotalCount;
                     if (pPool->InitCount > pPool->MaxCount)
                        pPool->MaxCount = pPool->InitCount;
                     if (pPool->PoolIndex > pAppli->WanDevPtr->LastPool)
                        pAppli->WanDevPtr->LastPool = (word)pPool->PoolIndex;
                     MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

                     /* allocation is completed in gdwInitOnLoadEnd */

                     if (dwError == 0)
                     {
                        /* update the user structure */
                        MyAllocPool.MaxNb = (word)pPool->MaxCount;
                        PUT_DATA_USER((void *)MyMem.DataPtr,
                                      (void *)&MyAllocPool, 
                                      MyMem.Size, iFlags, &dwError);
                     }
                  }
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitBufferPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlInitMaxAppli
* DESCRIPTION : handle a CTL_INIT_MAX_APPLI ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlInitMaxAppli(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitMaxAppli] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlInitMaxAppli] Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (MyMem.Size != sizeof(byte) &&
                 MyMem.Size != sizeof(word) &&
                 MyMem.Size != sizeof(dword)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxAppli] argument size is 0");
               else if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxAppli] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxAppli] argument is not a byte, word or dword");
#endif
               dwError = EINVAL;
            }
            else
            {
               if (MyMem.Size == sizeof(byte))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&ucVal, 
                                MyMem.Size, iFlags, &dwError);
                  wVal = ucVal;
               }
               else if (MyMem.Size == sizeof(word))
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&wVal, 
                                MyMem.Size, iFlags, &dwError);
               }
               else
               {
                  GET_DATA_USER((void *)MyMem.DataPtr,
                                (void *)&dwVal, 
                                MyMem.Size, iFlags, &dwError);
                  /* Check that the specified value is a 16-bit value */
                  if (dwVal > 0xFFFF)
                  {
                     dwError = EINVAL;
                  }
                  else
                  {
                     wVal = dwVal;
                  }
               }

               if (dwError == 0)
               {
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  if (wVal >= pAppli->WanDevPtr->NbAppli)
                     pAppli->WanDevPtr->MaxAppli = wVal;
                  else
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitMaxAppli] too many working applications");
#endif
                     dwError = EINVAL;
                  }
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitMaxAppli] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlInitMaxSession
* DESCRIPTION : handle a CTL_INIT_MAX_SESSION ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*****************************************************************************/
static dword drv_gdwCtlInitMaxSession(ApplCtxtPtr pAppli, int iFlags, 
                                      MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   byte ucVal;
   word wVal;
   dword dwVal;
   PoolItemPtr pItem;
   PoolItemPtr pNextItem;
   MGRSessionCorr_t *pCorr;
   MGRSessionCorr_t **OldMGRSessionCorrTable;
   word wCount;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitMaxSession] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlInitMaxSession] Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0 ||
                (MyMem.Size != sizeof(byte) &&
                 MyMem.Size != sizeof(word) &&
                 MyMem.Size != sizeof(dword)))
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxSession] argument size is 0");
               else if (MyMem.DataPtr == (byte *)0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxSession] no data buffer!");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxSession] argument is not a byte, word or dword");
#endif
               dwError = EINVAL;
            }
         }
         if (dwError == 0)
         {
            if (MyMem.Size == sizeof(byte))
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&ucVal, 
                             MyMem.Size, iFlags, &dwError);
               wVal = ucVal;
            }
            else if (MyMem.Size == sizeof(word))
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&wVal, 
                             MyMem.Size, iFlags, &dwError);
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&dwVal, 
                             MyMem.Size, iFlags, &dwError);
               /* Check that the specified value is a 16-bit value */
               if (dwVal > 0xFFFF)
               {
                  dwError = ENOMEM;
               }
               else
               {
                  wVal = dwVal;
               }
            }
         }
         if (dwError == 0)
         {
            if (((pAppli->WanDevPtr->MaxSession != 0) &&
                 (pAppli->WanDevPtr->MaxSession > wVal)) || 
                wVal == 0 )
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlInitMaxSession] inconsistent definition");
#endif
               dwError = EINVAL;
            }
            else if (pAppli->WanDevPtr->MaxSession < wVal)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlInitMaxSession] current definiton");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MAX_SESSION, 
                            pAppli->WanDevPtr->Index, pAppli->WanDevPtr->MaxSession);
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlInitMaxSession] new definiton");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MAX_SESSION, 
                            pAppli->WanDevPtr->Index, wVal);
#endif

               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);

               /* If needed increase max session */
               /* first allocate a temporary table */
               OldMGRSessionCorrTable = pAppli->WanDevPtr->MGRSessionCorrTable;

               pAppli->WanDevPtr->MGRSessionCorrTable = 
                  (MGRSessionCorr_t **)iph_gpMemAlloc(sizeof(MGRSessionCorr_t *) * wVal, 
                                                      1, ALLOC_KERNEL, 1);

               if (pAppli->WanDevPtr->MGRSessionCorrTable == NULL)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitMaxSession] allocation new table failed");
#endif
                  /* restore old */
                  pAppli->WanDevPtr->MGRSessionCorrTable = OldMGRSessionCorrTable;
                  dwError = ENOMEM;
               }
               else
               {
                  pItem = (PoolItemPtr)iph_gpMemAlloc(sizeof(MGRSessionCorr_t),
                                                      (wVal - pAppli->WanDevPtr->MaxSession), 
                                                      ALLOC_KERNEL, 1);

                  if (pItem != (PoolItemPtr)0)
                  {
                     wCount = pAppli->WanDevPtr->MaxSession;

                     while (pItem != (PoolItemPtr)0)
                     {
                        /* save the next allocated structure */
                        pNextItem = pItem->NextPtr;

                        pCorr = (MGRSessionCorr_t *)pItem;
                        pAppli->WanDevPtr->MGRSessionCorrTable[wCount] = pCorr;
                        pCorr->CardMGRSession = wCount;
                        iph_gvPutQueue(NULL,
                                       &pAppli->WanDevPtr->FreeMGRSessionCorrQueue,
                                       (QueueItemPtr)pCorr);

                        /* try next structure */
                        pItem = pNextItem;
                        wCount++;
                     }

                     if (pAppli->WanDevPtr->MaxSession > 0)
                     {
                        /* Now copy old session in the new table */
                        /* session previously allocated*/
                        for (wCount = 0; wCount < pAppli->WanDevPtr->MaxSession; wCount++)
                        {
                           pAppli->WanDevPtr->MGRSessionCorrTable[wCount] =
                              OldMGRSessionCorrTable[wCount];
                        }
                        iph_gvMemFree((void *)OldMGRSessionCorrTable);
                     }
                     pAppli->WanDevPtr->MaxSession = wVal;
                  }
                  else
                  {
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwCtlInitMaxSession] allocation new item failed");
#endif
                     iph_gvMemFree((void *)pAppli->WanDevPtr->MGRSessionCorrTable);

                     /* restore old table */
                     pAppli->WanDevPtr->MGRSessionCorrTable = OldMGRSessionCorrTable;
                     dwError = ENOMEM;
                  }
               }
               MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitMaxSession] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlInitDrvTrace
* DESCRIPTION : handle a CTL_INIT_DRV_TRACE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlInitDrvTrace(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   InitTrace_t MyInitTrace;
   TraceBuffHead_t *pTrcHead;
   TraceBuffHead_t *pOldTrcHead;
   byte *pucOldTrace;
   TrcMsg_t *pOldFirst;
   TrcMsg_t *pNewLast;
   byte *TmpAddress;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitDrvTrace] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(InitTrace_t) ||
             MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(InitTrace_t))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlInitDrvTrace] argument is not a InitTrace_t");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlInitDrvTrace] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            GET_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&MyInitTrace, 
                          MyMem.Size, iFlags, &dwError);
            pucOldTrace = (byte *)0;
            /* checks whether this is a redefinition */
            if (iph_gpucTrace != (byte *)0)
            {
               pTrcHead = (TraceBuffHead_t *)iph_gpucTrace;
               if (pTrcHead->Size < MyInitTrace.Size)
               {
                  /* we must reallocate a larger buffer */
                  pucOldTrace = iph_gpucTrace;
                  iph_gpucTrace = (byte *)0;
               }
            }
            else
            {
               /* create the trace mutex */
#ifdef LINUX
               MUTEX_INIT(&iph_gTraceMutex, 1, "IphWan trace mutex");
#endif
#ifdef SOLARIS
               MUTEX_INIT(&iph_gTraceMutex, "IphWan trace mutex",
                          MUTEX_DRIVER, 
                          (void *)(uintptr_t)pAppli->WanDevPtr->sDev.intPri);
#endif
            }

            /* allocate the trace buffer if necessary */
            if (iph_gpucTrace == (byte *)0)
            {
               /*TmpAddress = (byte *)TMP_ALLOC(MyInitTrace.Size);*/
               TMP_ALLOC(MyInitTrace.Size, &TmpAddress);
               MUTEX_ENTER(&pAppli->AppliMutex);
               iph_gpucTrace = TmpAddress;
               if (iph_gpucTrace == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlInitDrvTrace] memory allocation failed");
#endif
                  if (pucOldTrace != (byte *)0)
                     iph_gpucTrace = pucOldTrace;
                  dwError = ENOMEM;
               }
               else
               {
                  pTrcHead = (TraceBuffHead_t *)iph_gpucTrace;
                  bcopy(TRACE_TAG, iph_gpucTrace, 32);
                  bcopy(TRACE_TAG, &iph_gpucTrace[MyInitTrace.Size - 32], 32);
                  pTrcHead->Size = MyInitTrace.Size;
                  pTrcHead->Method = MyInitTrace.Method;
                  pTrcHead->FirstTrace = sizeof(TraceBuffHead_t);
                  pTrcHead->LastTrace = sizeof(TraceBuffHead_t);
                  pNewLast = (TrcMsg_t *)&iph_gpucTrace[pTrcHead->LastTrace];
                  pNewLast->NextPtr = sizeof(TraceBuffHead_t);
                  pNewLast->TraceType = NO_TRC;

                  /* copy the previous traces if necessary */
                  if (pucOldTrace != (byte *)0)
                  {
                     pOldTrcHead = (TraceBuffHead_t *)pucOldTrace;
                     pOldFirst = (TrcMsg_t *)&pucOldTrace[pOldTrcHead->FirstTrace];
                     pNewLast = (TrcMsg_t *)&iph_gpucTrace[pTrcHead->LastTrace];
                     while (pOldTrcHead->FirstTrace != pOldTrcHead->LastTrace ||
                            pOldFirst->TraceType != NO_TRC)
                     {
                        bcopy(&pucOldTrace[pOldTrcHead->FirstTrace],
                              &iph_gpucTrace[pTrcHead->LastTrace],
                              (sizeof(TrcMsg_t) + pOldFirst->Len));
                        pOldFirst->TraceType = NO_TRC;
                        /* update offset of next trace in new trace buffer */
                        pNewLast->NextPtr = pTrcHead->LastTrace +
                                            (sizeof(TrcMsg_t) + pOldFirst->Len);
                        /* ATTENTION: the structures must be aligned */
                        if ((pNewLast->NextPtr & (sizeof(dword) - 1)) != 0)
                        {
                           pNewLast->NextPtr = (pNewLast->NextPtr & ~(sizeof(dword) - 1)) + sizeof(dword);
                        }

                        if (pOldTrcHead->FirstTrace != pOldTrcHead->LastTrace)
                        {
                           pTrcHead->LastTrace = pNewLast->NextPtr;
                           pOldTrcHead->FirstTrace = pOldFirst->NextPtr;
                           pOldFirst = (TrcMsg_t *)&pucOldTrace[pOldTrcHead->FirstTrace];
                        }
                        pNewLast = (TrcMsg_t *)&iph_gpucTrace[pTrcHead->LastTrace];
                     }

                     TMP_FREE(pucOldTrace);
                  }
               }
               MUTEX_EXIT(&pAppli->AppliMutex);
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlInitDrvTrace] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlSetDrvTrace
* DESCRIPTION : handle a CTL_START_DRV_TRACE or CTL_STOP_DRV_TRACE ioctl
* PARAMETERS :
*    Input  : ucAppliType = application type
*    Input  : pLock = pointer to a protection mutex
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
*    Input  : ucTraceOn = trace activation mode
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlSetDrvTrace(byte ucAppliType, kmutex_t *pLock, 
                                   int iFlags, MemDesc_t *pMem, byte ucTraceOn)
{
   dword dwError;
   MemDesc_t MyMem;
   byte ucVal;
   byte ucCount;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetDrvTrace] entry");
#endif

   dwError = 0;

   if (ucAppliType == TYPE_KERNEL)
   {
      /* check the parameter value */
      if (pMem->Size != sizeof(byte) || pMem->DataPtr == (byte *)0)
      {
#ifdef TRACE
         if (pMem->Size != sizeof(byte))
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlSetDrvTrace] argument is not a byte");
         else
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwCtlSetDrvTrace] no data buffer!");
#endif
         dwError = EINVAL;
      }
      else
      {
         ucVal = *pMem->DataPtr;

         IPH_LOCK(pLock);

         if (ucVal == MODULE_ALL)
         {
            for (ucCount = 0; ucCount < MODULE_ALL; ucCount++)
               iph_gpucTraceMask[ucCount] = ucTraceOn;
         }
         else
         {
            iph_gpucTraceMask[ucVal] = ucTraceOn;
         }

         IPH_UNLOCK(pLock);
      }
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(byte) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(byte))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlSetDrvTrace] argument is not a byte");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlSetDrvTrace] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            GET_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&ucVal, 
                          MyMem.Size, iFlags, &dwError);

            IPH_LOCK(pLock);

            if (ucVal == MODULE_ALL)
            {
               for (ucCount = 0; ucCount < MODULE_ALL; ucCount++)
                  iph_gpucTraceMask[ucCount] = ucTraceOn;
            }
            else
               iph_gpucTraceMask[ucVal] = ucTraceOn;

            IPH_UNLOCK(pLock);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetDrvTrace] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpDrvTrace
* DESCRIPTION : handle a CTL_DUMP_DRV_TRACE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpDrvTrace(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   TraceBuffHead_t *pTrcHead;
   TrcMsg_t *pFirst;
   dword dwCopiedBytes;
   byte *pucMyBuff;

#ifdef TRACE_CONSOLE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpDrvTrace] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL || iph_gpucTrace == (byte *)0)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE_CONSOLE
            if (MyMem.Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpDrvTrace] argument size is 0");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpDrvTrace] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            dwCopiedBytes = 0;
            /* check whether the traces are initialized */
            if (iph_gpucTrace != NULL)
            {
               /*pucMyBuff = (byte *)TMP_ALLOC(MyMem.Size);*/
               TMP_ALLOC(MyMem.Size, &pucMyBuff);
               if (pucMyBuff == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpDrvTrace] memory allocation failed");
#endif
                  MyMem.Size = 0;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
                  dwError = ENOMEM;
               }
               else
               {
                  MUTEX_ENTER(&iph_gTraceMutex);

                  pTrcHead = (TraceBuffHead_t *)iph_gpucTrace;
                  pFirst = (TrcMsg_t *)&iph_gpucTrace[pTrcHead->FirstTrace];
                  while ((pTrcHead->FirstTrace != pTrcHead->LastTrace ||
                          pFirst->TraceType != NO_TRC) &&
                         (dwCopiedBytes + sizeof(TrcMsg_t) + pFirst->Len <= 
                          MyMem.Size))
                  {
                     /* update offset of first trace */
                     if (pTrcHead->FirstTrace != pTrcHead->LastTrace)
                     {
                        pTrcHead->FirstTrace = pFirst->NextPtr;
                     }

                     /* update offset of next trace in the destination buffer */
                     pFirst->NextPtr = dwCopiedBytes +
                                       (sizeof(TrcMsg_t) + pFirst->Len);
                     if ((pFirst->NextPtr & (sizeof(dword) - 1)) != 0)
                        pFirst->NextPtr = (pFirst->NextPtr & ~(sizeof(dword) - 1))
                                          + sizeof(dword);
                     bcopy((void *)pFirst,
                           (void *)&pucMyBuff[dwCopiedBytes],
                           sizeof(TrcMsg_t) + pFirst->Len);
                     dwCopiedBytes = pFirst->NextPtr;
                     pFirst->TraceType = NO_TRC;
                     pFirst = (TrcMsg_t *)&iph_gpucTrace[pTrcHead->FirstTrace];
                  }
                  MUTEX_EXIT(&iph_gTraceMutex);

                  PUT_DATA_USER((void *)MyMem.DataPtr,
                                (void *)pucMyBuff, dwCopiedBytes,
                                iFlags, &dwError);

                  /* free the dynamically allocated buffer */
                  TMP_FREE(pucMyBuff);

                  MyMem.Size = dwCopiedBytes;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
               }
            }
         }
      }
   }

#ifdef TRACE_CONSOLE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpDrvTrace] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpTrace
* DESCRIPTION : handle a CTL_DUMP_TRACE ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
*          ENOMEM if memory allocation failed
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlDumpTrace(ApplCtxtPtr pAppli, int iFlags, 
                                 MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte *pucMyBuff;
   dword ulTraceBufferOffset;
   dword ulTraceBufferSize;
   dword ulStartIndx = 0;
   dword ulEndIndx = 0;
   dword ulBytesToCopy;
   dword ulBytesCopied;
   IphWanDevPtr pDev;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[MEM_REGION];

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpTrace] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlDumpTrace] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status and control ownership */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED &&
       pAppli->WanDevPtr->Status != CARD_WATCHDOG &&
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlDumpTrace] adapter not ready or Application has not the control");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size == 0)
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpTrace] argument size is 0");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpTrace] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               /* allocate a temporary buffer to dump the DRAM content */
               /*pucMyBuff = (byte *)TMP_ALLOC(MyMem.Size);*/
               TMP_ALLOC(MyMem.Size, &pucMyBuff);
               if (pucMyBuff == (byte *)0)
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlDumpTrace] memory allocation failed");
#endif
                  MyMem.Size = 0;
                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
                  dwError = ENOMEM;
               }
               else
               {
                  pDev = pAppli->WanDevPtr;
                  MUTEX_ENTER(&pDev->DevMutex);
                  ulBytesCopied = 0;

                  /* Getting information about trace buffer */
                  READ_EXCH_TRACE_BUFFER_PTR(pDev, pDev->ExchArea, 
                                             &ulTraceBufferOffset);

                  READ_EXCH_TRACE_BUFFER_SIZE(pDev, pDev->ExchArea, 
                                              &ulTraceBufferSize);

                  READ_EXCH_TRACE_BUFFER_END(pDev, pDev->ExchArea, &ulEndIndx);
                  READ_EXCH_TRACE_BUFFER_START(pDev, pDev->ExchArea, &ulStartIndx);

                  /* Reading the trace buffer */
                  if (ulEndIndx > ulStartIndx )
                  {
                     /* first case : the valid data area is in one piece */
                     ulBytesToCopy =  ulEndIndx - ulStartIndx + 1;

                     if (ulBytesToCopy > MyMem.Size)
                     {
                        ulBytesToCopy = MyMem.Size;
                     }
                     /* call to reading function that handles mapped window */
                     RegPtr->Ops.readbuf(RegPtr, 
                                         OFFSET_CARD_TO_HOST(ulTraceBufferOffset) + ulStartIndx,
                                         ulBytesToCopy, pucMyBuff);
                     ulBytesCopied = ulBytesToCopy;
                     ulStartIndx+=ulBytesToCopy;
                  }
                  else if (ulEndIndx < ulStartIndx )
                  {
                     /* second case : the valid data area is in two pieces */
                     ulBytesToCopy = ulTraceBufferSize - ulStartIndx;

                     if (ulBytesToCopy > MyMem.Size)
                     {
                        ulBytesToCopy = MyMem.Size;
                     }

                     RegPtr->Ops.readbuf(RegPtr, 
                                         OFFSET_CARD_TO_HOST(ulTraceBufferOffset) + ulStartIndx,
                                         ulBytesToCopy, pucMyBuff);

                     ulBytesCopied = ulBytesToCopy;
                     ulStartIndx+=ulBytesToCopy;
                     if (ulStartIndx == ulTraceBufferSize)
                        ulStartIndx = 0;
                     if (ulBytesCopied < MyMem.Size)
                     {
                        /* second piece */
                        ulBytesToCopy = ulEndIndx + 1;

                        if (ulBytesToCopy > (MyMem.Size - ulBytesCopied))
                        {
                           ulBytesToCopy = MyMem.Size - ulBytesCopied;
                        }

                        /* call to reading function that handles mapped window */
                        RegPtr->Ops.readbuf(RegPtr, 
                                            OFFSET_CARD_TO_HOST(ulTraceBufferOffset),
                                            ulBytesToCopy, &pucMyBuff[ulBytesCopied]);

                        ulBytesCopied+=ulBytesToCopy;
                        ulStartIndx = ulBytesToCopy;
                     }
                     /* The last case where TraceBufferEnd=TraceBufferStart */
                     /* corresponds to an empty trace buffer */
                  }
                  if (ulBytesCopied > 0UL)
                  {
                     /* adjust the pointer to the first trace byte */
                     /* Note : take care not to exceed TraceBufferEnd */
                     READ_EXCH_TRACE_BUFFER_END(pDev, pDev->ExchArea, &ulEndIndx);
                     ulEndIndx += 1;

                     if (ulStartIndx == ulEndIndx)
                     {
                        ulStartIndx--;
                     }

                     WRITE_EXCH_TRACE_BUFFER_START(pDev, pDev->ExchArea,
                                                   ulStartIndx);
                  }

                  MUTEX_EXIT(&pDev->DevMutex);

                  /* copy the trace in the user buffer */
                  PUT_DATA_USER((void *)MyMem.DataPtr,
                                (void *)pucMyBuff,
                                ulBytesCopied, iFlags, &dwError);

                  /* free the dynamically allocated buffer */
                  TMP_FREE(pucMyBuff);

                  /* update the size of copied data */
                  MyMem.Size = ulBytesCopied;

                  /* copy the memory descriptor */
                  PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
               }
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpTrace] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGetStatus
* DESCRIPTION : handle a CTL_GET_STATUS ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlGetStatus(ApplCtxtPtr pAppli, int iFlags, 
                                 MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetStatus] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size < sizeof(IphWanDev_t) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size < sizeof(IphWanDev_t))
            {
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetStatus] size too short");
               iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, sizeof(IphWanDev_t));
            }
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetStatus] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            MyMem.Size = sizeof(IphWanDev_t);
            PUT_DATA_USER((void *)MyMem.DataPtr,
                          (void *)pAppli->WanDevPtr,
                          MyMem.Size, iFlags, &dwError);
            /* copy the memory descriptor */
            PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetStatus] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlSetCardStatus
* DESCRIPTION : handle a CTL_SET_CARD_STATUS ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          ENODEV if the device is not accessible
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlSetCardStatus(ApplCtxtPtr pAppli, int iFlags, 
                                     MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   byte ucStatus;
   word wCount;
   dword tmp32;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetCardStatus] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlSetCardStatus] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   if (pAppli->Type == TYPE_KERNEL ||
       pAppli->WanDevPtr->ControlAppli != pAppli)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);

      if (dwError == 0)
      {
         if (MyMem.Size < sizeof(byte) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size < sizeof(byte))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlSetCardStatus] size too short");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlSetCardStatus] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            GET_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&ucStatus,
                          MyMem.Size, iFlags, &dwError);

            switch (ucStatus)
            {
               case CARD_RESET:
                  /* reset the adapter with protection on device */
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);

                  /* check whether the card is not in reset */
                  if (pAppli->WanDevPtr->Rsrc->IsCardInReset(pAppli->WanDevPtr) == FALSE && 
                      (pAppli->WanDevPtr->ExchArea != 0))
                  {
                     /* Reset CodeReady before resetting the card */
                     tmp32 = 0x52535421;
                     WRITE_EXCH_CODE_READY(pAppli->WanDevPtr, 
                                           pAppli->WanDevPtr->ExchArea, 
                                           tmp32);
                     /* reset also ConfigStatus */
                     WRITE_EXCH_CONFIG_STATUS(pAppli->WanDevPtr, 
                                              pAppli->WanDevPtr->ExchArea, 
                                              0);
                  }

                  if (pAppli->WanDevPtr->PollTimer == TRUE)
                  {
                     pAppli->WanDevPtr->PollTimer = FALSE;
                     /* release any lock */
                     MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
                     IPH_DEL_TIMER(&pAppli->WanDevPtr->StatusPoll);
                     MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                     pAppli->WanDevPtr->PollTimeout = TRUE;
                  }
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);

                  iph_gvShutdownAdapter(&pAppli->WanDevPtr->DevMutex, 
                                        pAppli->WanDevPtr, CARD_RESET);

                  /* set to 0 the return code */
                  dwError = 0;

                  break;

               case CARD_LOADED:
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  if (pAppli->WanDevPtr->Status == CARD_RESETTING)
                  {
                     pAppli->WanDevPtr->Status = CARD_RESET;
                  }
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
                  dwError = drv_gdwInitOnLoadEnd(&pAppli->WanDevPtr->DevMutex, 
                                                 pAppli->WanDevPtr);
                  if (dwError == 0)
                  {
                     MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
#ifdef SOLARIS
                     ddi_dma_sync(pAppli->WanDevPtr->HostAreaDesc.Handle, 0, 
                                  0, DDI_DMA_SYNC_FORKERNEL);
#endif
                     /* acknowlege signal */
                     WRITE_EXCH_ECHO_COUNT(pAppli->WanDevPtr, 
                                           pAppli->WanDevPtr->ExchArea,
                                           HOST_CARD32(pAppli->WanDevPtr->HostArea->CardToHostSigCount));

                     pAppli->WanDevPtr->Status = CARD_LOADED;
                     /* initialize application pools for the current */
                     /* appli */
                     for (wCount = 0; wCount < MAX_DRV_POOL; wCount++)
                     {
                        pAppli->FreeDataPools[wCount].PoolSize =
                           (word)pAppli->WanDevPtr->FreeDataPools[wCount].PoolSize;
                     }
                     /* restart polling timer */
                     if (pAppli->WanDevPtr->PollTimer == FALSE)
                     {
                        IPH_START_TIMER(&pAppli->WanDevPtr->StatusPoll,
                                        iph_gvITPollStatus, 
                                        pAppli->WanDevPtr,
                                        POLL_STATUS_TIMEOUT*10);
                        pAppli->WanDevPtr->PollTimeout = FALSE;
                        pAppli->WanDevPtr->PollTimer = TRUE;
                     }
                     MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
                  }

                  break;

               case CARD_RUNNING:
                  if (pAppli->WanDevPtr->Status == CARD_RESET ||
                      pAppli->WanDevPtr->Status == CARD_WATCHDOG)
                  {
                     iph_TRACEK(TRCLVL_0, DRIVER_NAME" : adapter %d is RESET and cannot be set to RUNNING", 
                                pAppli->WanDevPtr->Index); 
                     return(EINVAL);
                  }
                  pAppli->WanDevPtr->Status = CARD_RUNNING;
                  iph_TRACEK(TRCLVL_1, DRIVER_NAME" : adapter %d successfully loaded", 
                             pAppli->WanDevPtr->Index); 

                  /* set to 0 the return code */
                  dwError = 0;

                  break;

               default:
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlSetCardStatus] unknown status to set");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, ucStatus);
#endif
                  dwError = EINVAL;
                  break;
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetCardStatus] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlDumpHostArea
* DESCRIPTION : handle a CTL_DUMP_HOST_AREA ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 12/07/06 Add control on received buffer size
*    - Version 1.2 : 09/04/06 Allow dump by an appli that owns the control
**************************************************************************/
static dword drv_gdwCtlDumpHostArea(ApplCtxtPtr pAppli, int iFlags, 
                                    MemDesc_t *pMem)
{
   dword dwError;
   MemDesc_t MyMem;
   dword dwCopiedBytes;
   IphWanDevPtr pDev;
   byte *pucMyBuff;
   dword dwVal;


#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpHostArea] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
      /* check adapter status and control ownership */
      if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
          pAppli->WanDevPtr->Status != CARD_LOADED &&
          (pAppli->WanDevPtr->ControlAppli != pAppli ||
           pAppli->WanDevPtr->HostArea == NULL))
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwCtlDumpHostArea] adapter not ready");
#endif
         dwError = EBUSY;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      }
      if (dwError == 0)
      {
         if (MyMem.Size == 0 || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size == 0)
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpHostArea] argument size is 0");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpHostArea] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            /*pucMyBuff = (byte *)TMP_ALLOC(MyMem.Size);*/
            TMP_ALLOC(MyMem.Size, &pucMyBuff);
            if (pucMyBuff == (byte *)0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlDumpHostArea] memory allocation failed");
#endif
               MyMem.Size = 0;
               /* copy the memory descriptor */
               PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
               dwError = ENOMEM;
            }
            else
            {
               pDev = pAppli->WanDevPtr;
               MUTEX_ENTER(&pDev->DevMutex);
               dwCopiedBytes = 0;
               /* dump of HostArea counters and transfer indexes */
               if (MyMem.Offset == 0 || MyMem.Offset == 1)
               {
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     bcopy(&pDev->HostArea->CardToHostSigCount, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     bcopy(&pDev->HostArea->HostToCardEchoCount, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     dwVal = pDev->InbCtrlIndex;
                     bcopy(&dwVal, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     dwVal = pDev->InbStatusIndex;
                     bcopy(&dwVal, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     dwVal = pDev->OutbCtrlIndex;
                     bcopy(&dwVal, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
                  if (MyMem.Size - dwCopiedBytes >= sizeof(dword))
                  {
                     dwVal = pDev->OutbSendIndex;
                     bcopy(&dwVal, 
                           &pucMyBuff[dwCopiedBytes], sizeof(dword));
                     dwCopiedBytes+=sizeof(dword);
                  }
               }
               /* dump of InbStatus table */
               if (MyMem.Offset == 0 || MyMem.Offset == 2)
               {
                  if (MyMem.Size - dwCopiedBytes > 0)
                  {
                     dwVal = sizeof(V5_TransferStatus_t)*pDev->InbCtrlNb;
                     if (MyMem.Size - dwCopiedBytes < dwVal)
                     {
                        dwVal = ((MyMem.Size - dwCopiedBytes) / 
                                 sizeof(V5_TransferStatus_t)) *
                                sizeof(V5_TransferStatus_t);
                     }
                     bcopy(pDev->InbStatus, 
                           &pucMyBuff[dwCopiedBytes], dwVal);
                     dwCopiedBytes+=dwVal;
                  }
               }
               /* dump of OutbCtrl table */
               if (MyMem.Offset == 0 || MyMem.Offset == 3)
               {
                  if (MyMem.Size - dwCopiedBytes > 0)
                  {
                     dwVal = sizeof(V5_TransferCtrl_t)*pDev->OutbCtrlNb;
                     if (MyMem.Size - dwCopiedBytes < dwVal)
                     {
                        dwVal = ((MyMem.Size - dwCopiedBytes) /
                                 sizeof(V5_TransferCtrl_t)) *
                                sizeof(V5_TransferCtrl_t);
                     }
                     bcopy(pDev->OutbCtrl, 
                           &pucMyBuff[dwCopiedBytes], dwVal);
                     dwCopiedBytes+=dwVal;
                  }
               }
               /* dump of OutbSend table */
               if (MyMem.Offset == 0 || MyMem.Offset == 4)
               {
                  if (MyMem.Size - dwCopiedBytes > 0)
                  {
                     dwVal = sizeof(V5_OutboundSend_t)*pDev->OutbDataNb;
                     if (MyMem.Size - dwCopiedBytes < dwVal)
                     {
                        dwVal = ((MyMem.Size - dwCopiedBytes) /
                                 sizeof(V5_OutboundSend_t)) *
                                sizeof(V5_OutboundSend_t);
                     }
                     bcopy(pDev->OutbSend, 
                           &pucMyBuff[dwCopiedBytes], dwVal);
                     dwCopiedBytes+=dwVal;
                  }
               }
#ifdef DEBUG_PERF
               /* dump of performance counters table */
               if (MyMem.Offset == 0 || MyMem.Offset == 5)
               {
                  if (MyMem.Size - dwCopiedBytes > 0)
                  {
                     dwVal = (byte *)&pDev->NbrLackRecvBuffer -
                             (byte *)&pDev->ITCount + sizeof(dword);
                     if (MyMem.Size - dwCopiedBytes < dwVal)
                     {
                        dwVal = ((MyMem.Size - dwCopiedBytes) /
                                 sizeof(dword)) * sizeof(dword);
                     }
                     bcopy(&pDev->ITCount, 
                           &pucMyBuff[dwCopiedBytes], dwVal);
                     dwCopiedBytes+= dwVal;
                  }
               }
#endif
               MUTEX_EXIT(&pDev->DevMutex);
               PUT_DATA_USER((void *)MyMem.DataPtr,
                             (void *)pucMyBuff, dwCopiedBytes,
                             iFlags, &dwError);

               /* free the dynamically allocated buffer */
               TMP_FREE(pucMyBuff);

               MyMem.Size = dwCopiedBytes;
            }
            /* copy the memory descriptor */
            PUT_MEM_DESC(&MyMem, pMem, iFlags, &dwError);
         }
      }
   }

#ifdef TRACE_CONSOLE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlDumpHostArea] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlResetHostStat
* DESCRIPTION : handle a CTL_RESET_HOST_STAT ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the device is not ready
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_gdwCtlResetHostStat(ApplCtxtPtr pAppli, int iFlags, 
                                     MemDesc_t *pMem)
{
   dword dwError;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlResetHostStat] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   dwError = 0;

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
#ifdef DEBUG_PERF
      pAppli->WanDevPtr->ITCount = 0;
      pAppli->WanDevPtr->ITDpcCount = 0;
      pAppli->WanDevPtr->SendNb = 0;
      pAppli->WanDevPtr->MaxSendNb = 0;
      pAppli->WanDevPtr->MaxSendLoop = 0;
      pAppli->WanDevPtr->SendWait = 0;
      pAppli->WanDevPtr->RecvChainNb = 0;
      pAppli->WanDevPtr->MaxRecvChainNb = 0;
      pAppli->WanDevPtr->ITPerDpc = 0;
      pAppli->WanDevPtr->MaxITPerDpc = 0;
      pAppli->WanDevPtr->ITBeforeDpc = 0;
      pAppli->WanDevPtr->SendMsgNb = 0;
      pAppli->WanDevPtr->RecvMsgNb = 0;
      pAppli->WanDevPtr->RecvChainCount = 0;
      pAppli->WanDevPtr->NbrLackRecvPrim = 0;
      pAppli->WanDevPtr->NbrLackRecvBuffer = 0;
      pAppli->WanDevPtr->SendPendingWait = 0;
#endif
   }

#ifdef TRACE_CONSOLE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlResetHostStat] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwCtlGetTime
* DESCRIPTION : handle a CTL_GET_CARD_TIME ioctl
* PARAMETERS :
*    Input  : ucAppliType = application type
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the card is not available
*          ENODEV if the card is not accessible
**************************************************************************/
static dword drv_gdwCtlGetTime(ApplCtxtPtr pAppli, int iFlags, 
                               MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   ddword ddwval;
   ddword tmp_ddwval=0ULL;
   TimeInfo_t MyTimeInfo;
   DevRegionPtr RegPtr = &pAppli->WanDevPtr->Region[CORE_REGION];
   dword RegVal, lsb_time;
#ifdef LINUX
   struct timeval SystemHostTime;
#endif


#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetTime] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlGetTime] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlGetTime] adapter not ready status");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(TimeInfo_t) || MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(TimeInfo_t))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlGetTime] wrong argument size specified");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlGetTime] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);

               /* Read the current host time offset */
               READ_EXCH_HOST_TIME_OFFSET(pAppli->WanDevPtr, 
                                          pAppli->WanDevPtr->ExchArea, 
                                          &MyTimeInfo.HostOffset); 

               /* Read the current card time information from the exchange area */
               /* until the 4 significant bytes are stable */
               READ_EXCH_CARD_TIME(pAppli->WanDevPtr, 
                                   pAppli->WanDevPtr->ExchArea, 
                                   &ddwval);
               ddwval = ddwval & 0xFFFFFFFF00000000ULL;
               do
               {
                  if ( tmp_ddwval != 0ULL )
                     MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);

                  memcpy ( &tmp_ddwval, &ddwval, sizeof(ddword) );
                  READ_EXCH_CARD_TIME(pAppli->WanDevPtr, 
                                      pAppli->WanDevPtr->ExchArea, 
                                      &ddwval);
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
                  lsb_time = (dword)(ddwval & 0x00000000FFFFFFFFULL);
                  ddwval = ddwval & 0xFFFFFFFF00000000ULL;
               } 
               while( ddwval != tmp_ddwval );

               /* Read the timestamp register to get the LSB */
               MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
               RegPtr->Ops.read32(RegPtr, MPC856X_RTSR, &RegVal);
               MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
#ifdef LINUX
               RegVal = HOST_CARD32(RegVal);
#endif

               /* Adjust the MSB if necessary */
               if ( lsb_time < RegVal )
                  MyTimeInfo.Card = (ddwval - 0x0000000100000000ULL) | RegVal;
               else
                  MyTimeInfo.Card = ddwval | RegVal;

               /* Get the system host time (Linux only) */
#ifdef LINUX
               IPH_GET_TIME(&SystemHostTime);
               /* Compute the number of usec */
               MyTimeInfo.Host = (SystemHostTime.tv_sec * 1000000ULL) + SystemHostTime.tv_usec;
#else
               memset(&MyTimeInfo.Host, 0, sizeof(ddword));
#endif

               PUT_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&MyTimeInfo,
                             sizeof(TimeInfo_t), iFlags, &dwError);

            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetTime] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}


/**************************************************************************
* NAME : drv_gdwCtlSetHostTimeOffset
* DESCRIPTION : handle a CTL_SET_HOST_TIME_OFFSET ioctl
* PARAMETERS :
*    Input  : pAppli = pointer to the application context
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          EBUSY if the card is not available
*          ENODEV if the device is not accessible
**************************************************************************/
static dword drv_gdwCtlSetHostTimeOffset(ApplCtxtPtr pAppli, int iFlags, 
                                         MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   ddword Offset;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetHostTimeOffset] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlSetHostTimeOffset] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* check adapter status */
   if (pAppli->WanDevPtr->Status != CARD_RUNNING &&
       pAppli->WanDevPtr->Status != CARD_LOADED)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwCtlSetHostTimeOffset] adapter not ready status");
#endif
      dwError = EBUSY;
   }
   else
   {
      if (pAppli->Type == TYPE_KERNEL)
      {
         dwError = EPERM;
      }
      else
      {
         /* copy the memory descriptor */
         GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);

         if (dwError == 0)
         {
            if (MyMem.Size != sizeof(ddword) || MyMem.DataPtr == (byte *)0)
            {
#ifdef TRACE
               if (MyMem.Size != sizeof(ddword))
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlSetHostTimeOffset] wrong argument size specified");
               else
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwCtlSetHostTimeOffset] no data buffer!");
#endif
               dwError = EINVAL;
            }
            else
            {
               GET_DATA_USER((void *)MyMem.DataPtr,
                             (void *)&Offset,
                             MyMem.Size, iFlags, &dwError);

               if ( dwError == 0 )
               {
                  /* Write the time offset to the card */
                  MUTEX_ENTER(&pAppli->WanDevPtr->DevMutex);
                  WRITE_EXCH_HOST_TIME_OFFSET(pAppli->WanDevPtr, 
                                              pAppli->WanDevPtr->ExchArea, 
                                              Offset);
                  MUTEX_EXIT(&pAppli->WanDevPtr->DevMutex);
               }
               else
                  dwError = EFAULT;
            }
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlSetHostTimeOffset] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}


/**************************************************************************
* NAME : drv_gdwCtlGetTempInfo
* DESCRIPTION : handle a CTL_GET_TEMP_INFO ioctl
* PARAMETERS :
*    Input  : ucAppliType = application type
*    Input  : iFlags = flags for copy
*    Input  : pMem = pointer to the memory descriptor given by the application
* RETURN : 0 if all is OK
*          EINVAL if one parameter is incorrect
*          ENOTTY if the card is not equipped with a thermal sensor
*          ENODEV if the card is not accessible
*          EPERM if the command is issued by a kernel application
**************************************************************************/
static dword drv_gdwCtlGetTempInfo(ApplCtxtPtr pAppli, int iFlags, 
                                   MemDesc_t *pMem)
{
   dword dwError=0;
   MemDesc_t MyMem;
   TempInfo_t MyTempInfo;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetTempInfo] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   /* Return is the card is not equipped with a temperature sensor device */
   if ( ! pAppli->WanDevPtr->TempSensorPresent )
   {
      dwError = ENOTTY;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlGetTempInfo] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   /* return if the card is not available */
   if (pAppli->WanDevPtr->Status == CARD_UNAVAILABLE)
   {
      dwError = ENODEV;
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                       (byte *)"[gdwCtlGetTempInfo] return");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

      return(dwError);
   }

   if (pAppli->Type == TYPE_KERNEL)
   {
      dwError = EPERM;
   }
   else
   {
      /* copy the memory descriptor */
      GET_MEM_DESC(pMem, &MyMem, iFlags, &dwError);
      if (dwError == 0)
      {
         if (MyMem.Size != sizeof(TempInfo_t) || MyMem.DataPtr == (byte *)0)
         {
#ifdef TRACE
            if (MyMem.Size != sizeof(TempInfo_t))
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetTempInfo] wrong argument size specified");
            else
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwCtlGetTempInfo] no data buffer!");
#endif
            dwError = EINVAL;
         }
         else
         {
            /* Copy the current temperature information */
            MyTempInfo.CurTemp = pAppli->WanDevPtr->CurTemp;
            MyTempInfo.StopThreshold = pAppli->WanDevPtr->StopThreshold;

            PUT_DATA_USER((void *)MyMem.DataPtr,
                          (void *)&MyTempInfo,
                          sizeof(TempInfo_t), iFlags, &dwError);
         }
      }
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gdwCtlGetTime] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif
   return(dwError);
}
