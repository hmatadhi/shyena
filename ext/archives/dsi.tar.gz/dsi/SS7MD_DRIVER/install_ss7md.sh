#!/bin/bash
#
#                       Copyright (C) Dialogic Corporation 2008-2012
#                       All Rights Reserved.
#
#   File:               install_ss7md.sh
#
#   Script to install:  Linux SS7MD device driver.
#   for use with:       Linux 2.4.x or Linux 2.6.x
#
#   -------+---------+------+------------------------------------------
#   Issue     Date      By    Description
#   -------+---------+------+------------------------------------------
#     1      04-Dec-08       - First version for external release 
#     2      06-Dec-08       - Change device node name to 'ss7md'.
#            19-Jan-09  MH   - Check if driver is loaded before running
#                              installation or removal sections.
#     3      31-Mar-09  IDP  - Change device name from iphwae to ss7md
#            06-Apr-11  MH   - Add 'create-devnode' command.
#            17-Nov-11  IDP  - CN524DPK - Correct node removal on insert
#            06-Feb-12  IDP  - TS004SLT - Support 8 boards
#
#   Usage:
#     ./install_ss7md.sh                - Load device driver module and create
#                                         device nodes
#     ./install_ss7md.sh remove         - Unload device driver and delete
#                                         device nodes
#     ./install_ss7md.sh create-devnode - Create the device nodes

# look up the version string
OS_VER=`uname -r`

# and read the minor version number
MAJVER=`echo $OS_VER | cut -f 1 -d "."`
MINVER=`echo $OS_VER | cut -f 2 -d "."`

DRIVER_NAME="ss7md"
NODE_NAME="ss7md"
DEVICE_NAME="ss7md"
MAX_NODENUM=7

# Function - Load the driver module
load_driver()
{
  /sbin/insmod -f ./${MODULE_NAME}${MODULE_EXT} || exit 1
}

# Function - Unload the driver module
unload_driver()
{
  /sbin/rmmod ${MODULE_NAME} || exit 1
}

# Function - Create the device nodes
create_devnodes()
{
  # determine the major device number and add the nodes
  MAJOR=`cat /proc/devices | awk "\\$2==\"${DEVICE_NAME}\" {print \\$1}"`

  node_num=0
  while [ $node_num -le $MAX_NODENUM ]
  do
    mknod -m0666 /dev/${NODE_NAME}$node_num c ${MAJOR} $node_num
    node_num=`expr $node_num + 1`
  done
}

# Function - Remove all added device nodes
remove_devnodes()
{
  rm -f /dev/${NODE_NAME}* > /dev/null
}

# Determine the kernel specific module name and extention
case "$MAJVER" in
  "2")
    case "$MINVER" in
      "4")
        MODULE_NAME="${DRIVER_NAME}"
        MODULE_EXT=".o"
        ;;

      "6")
        MODULE_NAME="${DRIVER_NAME}"
        MODULE_EXT=".ko"
        ;;

      *)
        echo Unsupported kernel revision $MAJVER.$MINVER
        exit 1
        ;;
    esac
    ;;

  "3")
    MODULE_NAME="${DRIVER_NAME}"
    MODULE_EXT=".ko"
    ;;

  *)
    echo Unsupported kernel revision $MAJVER.$MINVER
    exit 1
    ;;
esac

# Determine if the driver is already loaded.
found=`grep -c $DRIVER_NAME /proc/modules`
if [ '0' = $found ]
then
  driver_loaded=0
else
  driver_loaded=1
fi

# Do the action requested by the user
case "$1" in
  "remove")
    remove_devnodes
    if [ $driver_loaded = 0 ]
    then
      echo "Error: $DEVICE_NAME driver not loaded."
      exit 1
    fi
    unload_driver
    ;;

  "create-devnode")
    remove_devnodes
    create_devnodes
    ;;

  *)
    if [ $driver_loaded = 1 ]; then
      echo "Error: $DEVICE_NAME driver loaded."
      exit 1
    fi
    load_driver
    remove_devnodes
    create_devnodes
    ;;
esac

