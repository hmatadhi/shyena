/****************************************************************************
 * NAME : ppcsys.h
 * VERSION : 3.11.2
 * DESCRIPTION : 
 *    Constants, types for using the 4535, 4537, 6535 cards
 * REVISIONS :
 *    - Version 1.0 01/27/97 : Creation
 *    - Version 2.0 11/23/98 : Update for DMA master interface
 *    - Version 2.1 12/28/98 : Add ID for 4535 card
 *    - Version 2.2 12/07/99 : Add definitions to read the serial number
 *    - Version 3.0 06/21/00 : Add definitions for PowerSpan and 653x
 *    - Version 3.1 10/04/00 : Add definitions for serial number via PowerSpan
 *    - Version 3.2 01/08/01 : Add definitions for flashed configuration 
 *                             via PowerSpan
 *    - Version 3.3 01/11/01 : Add definitions for flashed firmware 
 *                             via PowerSpan
 *    - Version 3.4 05/10/01 : Add definitions for serial EEPROM
 *    - Version 3.5 06/22/01 : Add definitions for PLX Local Configuration Regs
 *    - Version 3.6 10/18/01 : Add default value for PSP IMR_DB register
 *    - Version 3.7 01/11/02 : Add Board Equipment Register offset in Serial
 *                             EEPROM (PSP)
 *    - Version 3.8 01/17/06 : Add definitions for PQ3-based controllers
 *    - Version 3.9 07/19/07 : Add the customer information offset 
 *                             #define CARD_PQ3_CUSTOM_INFO_OFFSET
 *    - Version 3.10 02/04/08 : Add the 3639 Port Number seeprom offset
 *                             #define CARD_PQ3_PORTNB_OFFSET
 *    - Version 3.11 08/11/08 : Add CARD_PQ3_CUSTOM_INFO32_OFFSET 
 *                              (32 byte size custom info)
 *                              Add the custom info size constants
 *                              CARD_PQ3_CUSTOM_INFO16_SIZE and
 *                              CARD_PQ3_CUSTOM_INFO32_SIZE
 *    - Version 3.11.1 05/12/09 : Add the I2C device address constants
 *                                Add the LM75 sensor device register addresses
 *    - Version 3.11.2 07/05/10 : Add the Peterson's algorithm implementation 
 *                                for i2c bus access
 ****************************************************************************/

#ifndef PPCSYS_H
#define PPCSYS_H

/***************************************************************************/
/* Definitions                                                             */
/***************************************************************************/

/* PCI configuration registers offset definition */
#define VID_INDX                       0x00
#define DID_INDX                       0x02
#define PCICMD_INDX                    0x04
#define PCISTS_INDX                    0x06
#define RID_INDX                       0x08
#define CLCD_INDX                      0x09
#define CLDEV_INDX                     0x0A
#define CALN_INDX                      0x0C
#define LAT_INDX                       0x0D
#define HDR_INDX                       0x0E
#define BIST_INDX                      0x0F
#define BADDR0_INDX                    0x10
#define BADDR1_INDX                    0x14
#define BADDR2_INDX                    0x18
#define BADDR3_INDX                    0x1C
#define SUBVID_INDX                    0x2C
#define SUBSYS_INDX                    0x2E
#define XRPB_INDX                      0x30
#define INTLN_INDX                     0x3C
#define INTPIN_INDX                    0x3D
#define MINGNT_INDX                    0x3E
#define MAXLAT_INDX                    0x3F

/* v3.5 PLX local configuration registers offset definition */
#define LSR_INDX                       0x00
#define LSLB_INDX                      0x04
#define LSAR_INDX                      0x08
#define ENDIAN_INDX                    0x0C
#define XRR_INDX                       0x10
#define XRLB_INDX                      0x14
#define LBD_INDX                       0x18
#define PR_INDX                        0x1C
#define PMLB_INDX                      0x20
#define PIOLB_INDX                     0x24
#define PPB_INDX                       0x28
#define PCCFG_INDX                     0x2C

/* PLX shared run time registers offset definition */
#define MBR0_INDX                      0x40
#define MBR1_INDX                      0x44
#define MBR2_INDX                      0x48
#define MBR3_INDX                      0x4C
#define MBR4_INDX                      0x50
#define MBR5_INDX                      0x54
#define MBR6_INDX                      0x58
#define MBR7_INDX                      0x5C
#define PLDB_INDX                      0x60
#define LPDB_INDX                      0x64
#define ICS_INDX                       0x68
#define RSCMD_INDX                     0x6C
#define VIDCID_INDX                    0x70
#define REVID_INDX                     0x74

/* PLX DMA registers offset definition */
#define DMAMODE0_INDX                  0x80
#define DMAPADR0_INDX                  0x84
#define DMALADR0_INDX                  0x88
#define DMASIZ0_INDX                   0x8C
#define DMADPR0_INDX                   0x90
#define DMAMODE1_INDX                  0x94
#define DMAPADR1_INDX                  0x98
#define DMALADR1_INDX                  0x9C
#define DMASIZ1_INDX                   0xA0
#define DMADPR1_INDX                   0xA4
#define DMACSR0_INDX                   0xA8
#define DMACSR1_INDX                   0xA9
#define DMAARB_INDX                    0xAC
#define DMATHR_INDX                    0xB0


/* Some bits value : */
/* - ATN in PLDB */
#define ATN                            0x00000001UL
/* - PL_XFER_REQ in PLDB */
#define PL_XFER_REQ                    0x00000002UL
/* - PL_WATCHDOG in PLDB */
#define PL_WATCHDOG                    0x00000004UL

/* - IRQ in LPDB */
#define IRQ                            0x00000001UL
/* - ResIRQ in LPDB */
#define RES_IRQ                        IRQ
/* - LP_XFER_REQ in LPDB */
#define LP_XFER_REQ                    0x00000002UL
/* - Res_LP_XFER_REQ in LPDB */
#define RES_LP_XFER_REQ                LP_XFER_REQ
/* - LP_WATCHDOG in LPDB */
#define LP_WATCHDOG                    0x00000004UL
/* - Res_LP_WATCHDOG in LPDB */
#define RES_LP_WATCHDOG                LP_WATCHDOG

/* - PCI Interrupt global enable in ICS */
#define GLOBAL_IRQ                     0x00000100UL
/* - PCI doorbell interrupt enable in ICS */
#define DB_IRQ                         0x00000200UL
/* - PCI doorbell interrupt state */
#define DB_IRQ_STATUS                  0x00002000UL
/* - DMA Channel 0 interrupt enable in ICS */
#define DMA0_IRQ                       0x00040000UL
/* - DMA Channel 0 interrupt state */
#define DMA0_IRQ_STATUS                0x00200000UL

/* - Running mode in RSCMD (when this bit is reset, the card is reset) */
#define SOFT_RUN                       0x00010000UL
/* - PCI Read Command Code for DMA in RSCMD */
#define DMA_READ_CDE                   0x0000000EUL
/* - PCI Write Command Code for DMA in RSCMD */
#define DMA_WRITE_CDE                  0x00000070UL
/* - PCI Memory Read Command Code for Direct Master in RSCMD */
#define MEM_READ_CDE                   0x00000600UL
/* - PCI Memory Write Command Code for Direct Master in RSCMD */
#define MEM_WRITE_CDE                  0x00007000UL
#define USERI_IN                       0x00040000UL
#define CNTRL_USER0                    0x00080000UL

/* - End of Chain in DMADPR */
#define END_OF_CHAIN                   0x00000002UL
/* - Transfer from local to PCI in DMADPR */
#define LOC_TO_PCI_XFER                0x00000008UL
/* - Transfer from PCI to local in DMADPR */
#define PCI_TO_LOC_XFER                0x00000000UL

/* - Channel enable in DMACSR */
#define CHANNEL_ENABLE                 0x01
/* - Channel start in DMACSR */
#define CHANNEL_START                  0x02
/* - Clear interrupt in DMACSR */
#define CLEAR_IT                       0x08

/* PLX Operation Register Offsets */
#define PLX_USER                       0x6E
#define PLX_EEPROM                     0x6F

/* Registers used to access serial number */
#define CARD_SERIAL_L                  56
#define CARD_SERIAL_H                  57

/* v3.4 Serial EEPROM offsets */
#define PLX_RUN_OFFSET   0x61
#define PLX_FWA_OFFSET   0x62
#define PLX_FWCA_OFFSET  0x64

/* v3.4 masks for running mode */
#define PLX_RUN_MASK     0x00C0
#define PLX_RUN_DISABLE  0x0000
#define PLX_RUN_FLASH    0x0040

/* PLX EEPROM Access */
#define USERO                          0x01
#define USERI                          0x02

#define EE_CK                          0x01
#define EE_CS                          0x02
#define EE_DI                          0x04
#define EE_DO                          0x08
#define EE_FND                         0x10
#define EE_RELOAD                      0x20

/* Regiters offset for Toundra PowerSpan chipset */
#define P1_TI0_CTL_INDX               0x100
#define P1_TI0_TADDR_INDX             0x104
#define P1_TI1_CTL_INDX               0x110
#define P1_TI1_TADDR_INDX             0x114
#define P1_TI2_CTL_INDX               0x120
#define P1_TI2_TADDR_INDX             0x124
#define P1_TI3_CTL_INDX               0x130
#define P1_TI3_TADDR_INDX             0x134
#define P1_CONF_INFO_INDX             0x144
#define P1_CONF_DATA_INDX             0x148
#define P1_IACK_INDX                  0x14C
#define P1_ERRCS_INDX                 0x150
#define P1_AERR_INDX                  0x154
#define P1_MISC_CSR_INDX              0x160
#define P1_ARB_CTRL_INDX              0x164

#define DMA0_SRC_ADDR_INDX            0x304
#define DMA0_DST_ADDR_INDX            0x30C
#define DMA0_TCR_INDX                 0x314
#define DMA0_CPP_INDX                 0x31C
#define DMA0_GCSR_INDX                0x320
#define DMA0_ATTR_INDX                0x324
#define DMA1_SRC_ADDR_INDX            0x334
#define DMA1_DST_ADDR_INDX            0x33C
#define DMA1_TCR_INDX                 0x344
#define DMA1_CPP_INDX                 0x34C
#define DMA1_GCSR_INDX                0x350
#define DMA1_ATTR_INDX                0x354
#define DMA2_SRC_ADDR_INDX            0x364
#define DMA2_DST_ADDR_INDX            0x36C
#define DMA2_TCR_INDX                 0x374
#define DMA2_CPP_INDX                 0x37C
#define DMA2_GCSR_INDX                0x380
#define DMA2_ATTR_INDX                0x384
#define DMA3_SRC_ADDR_INDX            0x394
#define DMA3_DST_ADDR_INDX            0x39C
#define DMA3_TCR_INDX                 0x3A4
#define DMA3_CPP_INDX                 0x3AC
#define DMA3_GCSR_INDX                0x3B0
#define DMA3_ATTR_INDX                0x3B4

#define MISC_CSR_INDX                 0x400
#define CLOCK_CTL_INDX                0x404
#define I2C_CSR_INDX                  0x408
#define RST_CSR_INDX                  0x40C
#define ISR0_INDX                     0x410
#define ISR1_INDX                     0x414
#define IER0_INDX                     0x418
#define IER1_INDX                     0x41C
#define IMR_MBOX_INDX                 0x420
#define IMR_DB_INDX                   0x424
#define IMR_DMA_INDX                  0x428
#define IMR_HW_INDX                   0x42C
#define IMR_P1_INDX                   0x430
#define IMR_P2_INDX                   0x434
#define IMR_PB_INDX                   0x438
#define IMR2_PB_INDX                  0x43C
#define IMR_MISC_INDX                 0x440
#define IDR_INDX                      0x444

#define MBOX0_INDX                    0x450
#define MBOX1_INDX                    0x454
#define MBOX2_INDX                    0x458
#define MBOX3_INDX                    0x45C
#define MBOX4_INDX                    0x460
#define MBOX5_INDX                    0x464
#define MBOX6_INDX                    0x468
#define MBOX7_INDX                    0x46C

#define SEMA0_INDX                    0x470
#define SEMA1_INDX                    0x474


/* Bits and mask values for Toundra PowerSpan chipset */
#define DMAx_TCR_SRC_PORT_P1_VAL      0x00000000
#define DMAx_TCR_SRC_PORT_P2_VAL      0x40000000
#define DMAx_TCR_SRC_PORT_PB_VAL      0x80000000
#define DMAx_TCR_DST_PORT_P1_VAL      0x00000000
#define DMAx_TCR_DST_PORT_P2_VAL      0x10000000
#define DMAx_TCR_DST_PORT_PB_VAL      0x20000000
#define DMAx_TCR_BC_MASK              0x00ffffff

#define DMAx_CPP_NCP_MASK             0xffffffe0
#define DMAx_CPP_LAST_MASK            0x00000001

#define DMAx_GCR_GO_MASK              0x80000000
#define DMAx_GCR_CHAIN_MASK           0x40000000
#define DMAx_GCR_DACT_MASK            0x00800000
#define DMAx_GCR_P1_ERR_MASK          0x00002000
#define DMAx_GCR_P2_ERR_MASK          0x00001000
#define DMAx_GCR_PB_ERR_MASK          0x00000800
#define DMAx_GCR_STOP_MASK            0x00000400
#define DMAx_GCR_HALT_MASK            0x00000200
#define DMAx_GCR_DONE_MASK            0x00000100
#define DMAx_GCR_DONE_EN_MASK         0x00000001

#define DMAx_ATTR_CPA_PORT_P1_VAL     0x00000000
#define DMAx_ATTR_CPA_PORT_P2_VAL     0x40000000
#define DMAx_ATTR_CPA_PORT_PB_VAL     0x80000000
#define DMAx_ATTR_GBL_MASK            0x10000000
#define DMAx_ATTR_CI_MASK             0x08000000
#define DMAx_ATTR_CPA_PORT_MASK       0xc0000000

#define I2C_CSR_ADDR_MASK             0xff000000
#define I2C_CSR_DATA_MASK             0x00ff0000
#define I2C_CSR_DEV_CODE_MASK         0x0000f000
#define I2C_CSR_CS_MASK               0x00000e00
#define I2C_CSR_RW_MASK               0x00000100
#define I2C_CSR_ACT_MASK              0x00000080
#define I2C_CSR_ERR_MASK              0x00000040

#define RST_CSR_PB_ARB_EN_MASK        0x40000000
#define RST_CSR_P1_ARB_EN_MASK        0x00400000
#define RST_CSR_P2_ARB_EN_MASK        0x00004000
#define RST_CSR_PRI_PCI_MASK          0x00000100

#define ISR0_ISR1_ACTV_MASK           0x80000000
#define ISR0_I2O_HOST_MASK            0x20000000
#define ISR0_I2O_IOP_MASK             0x10000000
#define ISR0_DMA3_MASK                0x08000000
#define ISR0_DMA2_MASK                0x04000000
#define ISR0_DMA1_MASK                0x02000000
#define ISR0_DMA0_MASK                0x01000000

#define ISR0_P2_HW_MASK               0x00800000
#define ISR0_P1_HW_MASK               0x00400000
#define ISR0_INT5_HW_MASK             0x00200000
#define ISR0_INT4_HW_MASK             0x00100000
#define ISR0_INT3_HW_MASK             0x00080000
#define ISR0_INT2_HW_MASK             0x00040000
#define ISR0_INT1_HW_MASK             0x00020000
#define ISR0_INT0_HW_MASK             0x00010000

#define ISR0_DB7_MASK                 0x00008000
#define ISR0_DB6_MASK                 0x00004000
#define ISR0_DB5_MASK                 0x00002000
#define ISR0_DB4_MASK                 0x00001000
#define ISR0_DB3_MASK                 0x00000800
#define ISR0_DB2_MASK                 0x00000400
#define ISR0_DB1_MASK                 0x00000200
#define ISR0_DB0_MASK                 0x00000100

#define ISR0_MBOX7_MASK               0x00000080
#define ISR0_MBOX6_MASK               0x00000040
#define ISR0_MBOX5_MASK               0x00000020
#define ISR0_MBOX4_MASK               0x00000010
#define ISR0_MBOX3_MASK               0x00000008
#define ISR0_MBOX2_MASK               0x00000004
#define ISR0_MBOX1_MASK               0x00000002
#define ISR0_MBOX0_MASK               0x00000001

#define ISR1_ISR0_ACTV_MASK           0x80000000
#define ISR1_PB_P1_RETRY_MASK         0x08000000
#define ISR1_PB_P2_RETRY_MASK         0x04000000
#define ISR1_PB_PB_RETRY_MASK         0x02000000

#define ISR1_PB_P1_ERR_MASK           0x00800000
#define ISR1_PB_P2_ERR_MASK           0x00400000
#define ISR1_PB_PB_ERR_MASK           0x00200000
#define ISR1_PB_A_PAR_MASK            0x00100000
#define ISR1_PB_P1_D_PAR_MASK         0x00080000
#define ISR1_PB_P2_D_PAR_MASK         0x00040000
#define ISR1_PB_PB_D_PAR_MASK         0x00020000

#define ISR1_P2_P1_ERR_MASK           0x00008000
#define ISR1_P2_PB_ERR_MASK           0x00004000
#define ISR1_P2_P2_ERR_MASK           0x00002000
#define ISR1_P2_A_PAR_MASK            0x00001000
#define ISR1_P2_P1_RETRY_MASK         0x00000800
#define ISR1_P2_PB_RETRY_MASK         0x00000400
#define ISR1_P2_P2_RETRY_MASK         0x00000200

#define ISR1_P1_P2_ERR_MASK           0x00000080
#define ISR1_P1_PB_ERR_MASK           0x00000040
#define ISR1_P1_P1_ERR_MASK           0x00000020
#define ISR1_P1_A_PAR_MASK            0x00000010
#define ISR1_P1_P2_RETRY_MASK         0x00000008
#define ISR1_P1_PB_RETRY_MASK         0x00000004
#define ISR1_P1_P1_RETRY_MASK         0x00000002

#define IER0_I2O_HOST_MASK_MASK       0x20000000
#define IER0_I2O_IOP_EN_MASK          0x10000000
#define IER0_DMA3_EN_MASK             0x08000000
#define IER0_DMA2_EN_MASK             0x04000000
#define IER0_DMA1_EN_MASK             0x02000000
#define IER0_DMA0_EN_MASK             0x01000000
#define IER0_P2_HW_EN_MASK            0x00800000
#define IER0_P1_HW_EN_MASK            0x00400000
#define IER0_INT5_HW_EN_MASK          0x00200000
#define IER0_INT4_HW_EN_MASK          0x00100000
#define IER0_INT3_HW_EN_MASK          0x00080000
#define IER0_INT2_HW_EN_MASK          0x00040000
#define IER0_INT1_HW_EN_MASK          0x00020000
#define IER0_INT0_HW_EN_MASK          0x00010000

#define IER0_DB7_EN_MASK              0x00008000
#define IER0_DB6_EN_MASK              0x00004000
#define IER0_DB5_EN_MASK              0x00002000
#define IER0_DB4_EN_MASK              0x00001000
#define IER0_DB3_EN_MASK              0x00000800
#define IER0_DB2_EN_MASK              0x00000400
#define IER0_DB1_EN_MASK              0x00000200
#define IER0_DB0_EN_MASK              0x00000100

#define IER0_MBOX7_EN_MASK            0x00000080
#define IER0_MBOX6_EN_MASK            0x00000040
#define IER0_MBOX5_EN_MASK            0x00000020
#define IER0_MBOX4_EN_MASK            0x00000010
#define IER0_MBOX3_EN_MASK            0x00000008
#define IER0_MBOX2_EN_MASK            0x00000004
#define IER0_MBOX1_EN_MASK            0x00000002
#define IER0_MBOX0_EN_MASK            0x00000001

#define IMR_MAP_P1_INTA_VAL           0x00000000
#define IMR_MAP_P2_INTA_VAL           0x22222222
#define IMR_MAP_INT0_VAL              0x44444444
#define IMR_MAP_INT1_VAL              0x66666666
#define IMR_MAP_INT2_VAL              0x88888888
#define IMR_MAP_INT3_VAL              0xaaaaaaaa
#define IMR_MAP_INT4_VAL              0xcccccccc
#define IMR_MAP_INT5_VAL              0xeeeeeeee

#define IMR_DB_DB7_MAP_MASK           0xe0000000
#define IMR_DB_DB6_MAP_MASK           0x0e000000
#define IMR_DB_DB5_MAP_MASK           0x00e00000
#define IMR_DB_DB4_MAP_MASK           0x000e0000
#define IMR_DB_DB3_MAP_MASK           0x0000e000
#define IMR_DB_DB2_MAP_MASK           0x00000e00
#define IMR_DB_DB1_MAP_MASK           0x000000e0
#define IMR_DB_DB0_MAP_MASK           0x0000000e

#define IMR_MBOX_MBOX7_MAP_MASK       0xe0000000
#define IMR_MBOX_MBOX6_MAP_MASK       0x0e000000
#define IMR_MBOX_MBOX5_MAP_MASK       0x00e00000
#define IMR_MBOX_MBOX4_MAP_MASK       0x000e0000
#define IMR_MBOX_MBOX3_MAP_MASK       0x0000e000
#define IMR_MBOX_MBOX2_MAP_MASK       0x00000e00
#define IMR_MBOX_MBOX1_MAP_MASK       0x000000e0
#define IMR_MBOX_MBOX0_MAP_MASK       0x0000000e

#define IMR_DMA_DMA3_MAP_MASK         0x0000e000
#define IMR_DMA_DMA2_MAP_MASK         0x00000e00
#define IMR_DMA_DMA1_MAP_MASK         0x000000e0
#define IMR_DMA_DMA0_MAP_MASK         0x0000000e

#define IMR_HW_P2_HW_MAP_MASK         0xe0000000
#define IMR_HW_P1_HW_MAP_MASK         0x0e000000
#define IMR_HW_INT5_HW_MAP_MASK       0x00e00000
#define IMR_HW_INT4_HW_MAP_MASK       0x000e0000
#define IMR_HW_INT3_HW_MAP_MASK       0x000000e0
#define IMR_HW_INT2_HW_MAP_MASK       0x0000000e
#define IMR_HW_INT1_HW_MAP_MASK       0x000000e0
#define IMR_HW_INT0_HW_MAP_MASK       0x0000000e

#define IMR_P1_P1_P2_ERR_MAP_MASK     0xe0000000
#define IMR_P1_P1_PB_ERR_MAP_MASK     0x0e000000
#define IMR_P1_P1_P1_ERR_MAP_MASK     0x00e00000
#define IMR_P1_P1_A_PAR_MAP_MASK      0x000e0000
#define IMR_P1_P1_P2_RETRY_MAP_MASK   0x0000e000
#define IMR_P1_P1_PB_RETRY_MAP_MASK   0x00000e00
#define IMR_P1_P1_P1_RETRY_MAP_MASK   0x000000e0

#define IMR_P2_P2_P1_ERR_MAP_MASK     0xe0000000
#define IMR_P2_P2_PB_ERR_MAP_MASK     0x0e000000
#define IMR_P2_P2_P2_ERR_MAP_MASK     0x00e00000
#define IMR_P2_P2_A_PAR_MAP_MASK      0x000e0000
#define IMR_P2_P2_P1_RETRY_MAP_MASK   0x0000e000
#define IMR_P2_P2_PB_RETRY_MAP_MASK   0x00000e00
#define IMR_P2_P2_P2_RETRY_MAP_MASK   0x000000e0

#define IMR_PB_PB_P1_ERR_MAP_MASK     0xe0000000
#define IMR_PB_PB_P2_ERR_MAP_MASK     0x0e000000
#define IMR_PB_PB_PB_ERR_MAP_MASK     0x00e00000
#define IMR_PB_PB_A_PAR_MAP_MASK      0x000e0000
#define IMR_PB_PB_P1_RETRY_MAP_MASK   0x0000e000
#define IMR_PB_PB_P2_RETRY_MAP_MASK   0x00000e00
#define IMR_PB_PB_PB_RETRY_MAP_MASK   0x000000e0

#define IMR2_PB_PB_P1_RETRY_MAP_MASK  0xe0000000
#define IMR2_PB_PB_P2_RETRY_MAP_MASK  0x0e000000
#define IMR2_PB_PB_PB_RETRY_MAP_MASK  0x00e00000

#define IMR_MISC_I2O_IOP_MAP_MASK     0xe0000000
#define IMR_MISC_I2O_HOST_MAP_MASK    0x0e000000

#define IDR_P2_HW_DIR_MASK            0x80000000
#define IDR_P1_HW_DIR_MASK            0x40000000
#define IDR_INT5_HW_DIR_MASK          0x20000000
#define IDR_INT4_HW_DIR_MASK          0x10000000
#define IDR_INT3_HW_DIR_MASK          0x08000000
#define IDR_INT2_HW_DIR_MASK          0x04000000
#define IDR_INT1_HW_DIR_MASK          0x02000000
#define IDR_INT0_HW_DIR_MASK          0x01000000

#define SEMA0_SEM3_MASK               0x80000000
#define SEMA0_SEM2_MASK               0x00800000
#define SEMA0_SEM1_MASK               0x00008000
#define SEMA0_SEM0_MASK               0x00000080
#define SEMA1_SEM7_MASK               0x80000000
#define SEMA2_SEM6_MASK               0x00800000
#define SEMA3_SEM5_MASK               0x00008000
#define SEMA4_SEM4_MASK               0x00000080

#define SEMA0_SEM3_TAG3_MASK          0xff000000
#define SEMA0_SEM2_TAG2_MASK          0x00ff0000
#define SEMA0_SEM1_TAG1_MASK          0x0000ff00
#define SEMA0_SEM0_TAG0_MASK          0x000000ff

#define SEMA1_SEM7_TAG7_MASK          0xff000000
#define SEMA1_SEM6_TAG6_MASK          0x00ff0000
#define SEMA1_SEM5_TAG5_MASK          0x0000ff00
#define SEMA1_SEM4_TAG4_MASK          0x000000ff

/* - MBOX_XFER_REQ in MBOX4 */
#define MBOX_XFER_REQ                 0x00000002UL
/* - MBOX_WATCHDOG in MBOX4 */
#define MBOX_WATCHDOG                 0x00000004UL

/* v3.6 default value for IMR_DB register: */
/* DB0 -> P1_INTA for PCI->host IT */
/* DB1 -> P2_INTA not used */
/* DB2 -> INT0 for ATN */
/* DB3 -> INT1 for -FLASH */
/* DB4 -> INT2 for -HRESET */
/* DB5 -> INT3 for -SRESET */
/* DB6 -> INT4 for -SCK */
/* DB7 -> INT5 not used */
#define IMR_DB_DEFAULT                0xeca86420

/* v3.7 Offset used to access Board Equipment Register via the PowerSpan */
#define CARD_PSP_BOARD_EQUIP_REG      0x40

/* v3.7 Masksused to decode Board Equipment Register */
#define CARD_PSP_BER_MPC_ID_MASK      0xF0000000
#define CARD_PSP_BER_IMA_PRSNT_MASK   0x00000008
#define CARD_PSP_BER_IMA_DEV_MASK     0x00000001

/* v3.1 Registers used to access serial number via the PowerSpan */
#define CARD_PSP_SERIAL_L             0xA0
#define CARD_PSP_SERIAL_H             0xA2

/* v3.3 New registers used to access firmware offset via the PowerSpan */
#define CARD_PSP_FWADD_L              0xC6
#define CARD_PSP_FWADD_H              0xC4

/* v3.2 New registers used to access configuration offset via the PowerSpan */
#define CARD_PSP_CFGADD_L             0xCA
#define CARD_PSP_CFGADD_H             0xC8

/* v3.4 Eeeprom offset for running mode */
#define CARD_PSP_RUN_OFFSET           0xC2

/* v3.4 Masks for running mode */
#define PSP_RUN_MASK     0xC0
#define PSP_RUN_DISABLE  0x00
#define PSP_RUN_FLASH    0x40

/* v3.2 Flash offset via the PowerSpan */
#define CARD_PSP_FLASH_BASE           0xFF800000

/* Vendor ID for Interphase Corporation */
#define IPH_VID                        0x107E

/* Device IDs for 5535 cards */
#define CARD_BASE_DID                  0x9000
#define CARD_5535_4P_BRI_ST_DID        0x9003
#define CARD_5535_4P_BRI_U_DID         0x9007
#define CARD_5535_1P_SR_DID            0x9008
#define CARD_5535_1P_SR_ST_DID         0x900C
#define CARD_5535_1P_SR_U_DID          0x900E
#define CARD_5535_1P_PRI_DID           0x9011
#define CARD_5535_2P_PRI_DID           0x9013

/* Device ID for 4535 card */
#define CARD_4535_MH_DID               0x9052
#define CARD_4535_SAR_DID              0x9053
#define CARD_4535_SAR_CAM_DID          0x9057

/* Device ID for 4534 card */
#define CARD_4534_DID                  0x9040

/* New registers used to access info in MPC856X serial eeprom */
#define CARD_PQ3_BOARD_EQUIP_REG       0x140
#define CARD_PQ3_SERIAL_L              0x1A0
#define CARD_PQ3_SERIAL_H              0x1A2
#define CARD_PQ3_CUSTOM_INFO_OFFSET    0x180
#define CARD_PQ3_CUSTOM_INFO16_SIZE    16
#define CARD_PQ3_CUSTOM_INFO32_OFFSET  0x170
#define CARD_PQ3_CUSTOM_INFO32_SIZE    32
#define CARD_PQ3_FWADD_L               0x1C6
#define CARD_PQ3_FWADD_H               0x1C4
#define CARD_PQ3_CFGADD_L              0x1CA
#define CARD_PQ3_CFGADD_H              0x1C8

/* Eeeprom offset for running mode */
#define CARD_PQ3_RUN_OFFSET            0x1C3

/* Masks for running mode */
#define PQ3_RUN_MASK                   0x0E
#define PQ3_RUN_DISABLE                0x00
#define PQ3_RUN_FLASH                  0x02

/* Eeprom offset for Port Number 3639 information */
#define CARD_PQ3_PORTNB_OFFSET         0x1BD

/* Flash offset via the PowerSpan */
#define CARD_PQ3_FLASH_BASE            0xFF000000

/* I2C device adddresses */
#define I2C_SEEPROM_ADDR               0xA0
#define I2C_LM75_ADDR                  0x92

/* LM75 sensor register addresses */
#define LM75_TEMP_ADDR                 0x00
#define LM75_TOS_ADDR                  0x03

/* i2c semaphore constants declaration */
#define PETERSON_ALGORITHM    0x5A5A0000
#define PETERSON_PATTERN_MASK 0xFFFF0000
/* PQIII registers used for implementing the Peterson's algorithm */
#define I2C_SEM_TURN_ID      MPC856X_LAWAR5
#define I2C_SEM_BOARD_WANT   MPC856X_LAWAR6
#define I2C_SEM_HOST_WANT    MPC856X_LAWAR7
/* Host/Board Ids */
#define I2C_SEM_BOARD_ID     0
#define I2C_SEM_HOST_ID      1
/* Actions */
#define I2C_SEM_ENTER        1
#define I2C_SEM_EXIT         0

#endif /* PPCSYS_H */

