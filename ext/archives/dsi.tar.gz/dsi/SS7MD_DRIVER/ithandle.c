/****************************************************************************
 * (C) Copyright Interphase Corp 2005-2009.
 *
 * NAME : ithandle.c
 * 
 * VERSION : 1.18.4
 * DESCRIPTION : 
 *    Functions to manage the interrupts (hardware and timer)
 * REVISIONS :
 *    - Version 1.0 10/18/05 : Creation
 *    - Version 1.1 01/25/06 : Do not anymore disable IT during IT processing
 *    - Version 1.2 02/13/06 : In drv_guiITHandler_PQ3, check in MER whether the
 *                             IT is for us.
 *                             Add processing of SHUTDOWN_PRIM
 *    - Version 1.3 03/14/06 : change some prototypes for Solaris
 *    - Version 1.4 03/21/06 : - change the way to stop echo timer to prevent 
 *                               handler from running (set EchoTimer to FALSE)
 *                             - Update for Solaris
 *                             - Fix bug in gvITPollStatus 
 *                               (timer was always restarted)
 *    - Version 1.05 05/23/06:
 *       - Add mutex protection for access to MEM_REGION to avoid unexpected
 *         window translation
 *       - In drv_guiITHandler_PQ3, Ack IT before updating CardToHostEchoCount 
 *         to prevent loss of IT in case of an event signalled while the handler
 *         is running (just after CardToHostSigCount is read by the handler 
 *         but before the IT is acknowledged)
 *    - Version 1.06 06/26/06: Change global prefix into iphwae
 *    - Version 1.07 07/12/06: - Use MUTEX_xx and CV_xx macros
 *    - Version 1.08 08/31/06: 
 *       - In ITHandlerDpc, add several attempts to release all the 
 *         successfully sent primitives to properly manage the following cases:
 *         - when a MGR_USER_CLOSED is received, release the corresponding 
 *           MGR_CLOSE_USER before releasing the correlator
 *         - when the reception queue is full and the faulty session is not
 *           completely opened (i.e. MGR_OPEN_USER is sent but not released yet)
 *       - When reception queue is full for an application, do not purge the
 *         queue anymore.
 *    - Version 1.09 12/27/2006:
 *       - Suppress Linux compilation warnings
 *    - Version 1.10 01/25/2007:
 *       - Do not set PollTimer in PollStatus. It caused the timer to restart
 *         even when the card is detaching
 *    - Version 1.11 07/12/2007:
 *       - Handler DPC returns immediately if the device context is not found
 *         (It may happen in hotplug case)
 *       - Change the lock/unlock strategy between the IT hander and the DPC
 *         to avoid  IT process lost
 *    - Version 1.12 07/20/2007:
 *       - Acknowledge IT before taking the semaphore
 *       - Echo the card to host sig count at each reception
 *    - Version 1.13 06/27/2008:
 *       - Log a system message in case of RX application queue full
 *    - Version 1.14 09/11/2008:
 *      - iMonitor: before deleting a timer, release any lock
 *      - iMonitor: if a sending process is waiting for a descriptor for a 
 *        long time, consider the card is failing and reset it
 *      - in IT handler, add a register read to flush pending write operations
 *        => this avoids "spurious IT" events on Solaris Sparc
 *      - in IT handler, do not process IT if card is resetting
 *      - Add support for Solaris 9 (SOL_9 option)
 *    - Version 1.15 10/30/2008:
 *      - since IPH_GET_TIME uses different structure type on Linux and 
 *        Solaris, fix SendWaiting device variable management
 *    - Version 1.16 11/19/2008:
 *      - gvReleaseCorr wakes up any closing application waiting for the end 
 *        of session
 *      - gvReleaseCorr extracts correlator from application context too
 *      - in gvReleaseP2LTransfer_PQ3, wake up the waiting application only 
 *        after the primitive is completely treated
 *      - in IThandler, release session correlator after sending the primitive 
 *        to the application
 *    - Version 1.17 01/07/2009:
 *      - limit the number of events notified regarding pb with MAX_RX_QUEUE
 *    - Version 1.18 01/30/2009:
 *      - Log the CodeReady location value in case of CARD_WATCHDOG
 *    - Version 1.18.1 04/08/2009:
 *      - In case of lack of buffer on reception for a user application, 
 *        do not use the the DMA buffer anymore but force session close
 *      - in IT handler, do not process IT if card is resetting but ack the IT
 *    - Version 1.18.2 05/20/2009:
 *      - Do not check status if the card is UNAVAILABLE
 *      - Add the temperature sensor support
 *    - Version 1.18.3 05/29/2009:
 *      - Move the temperature sensor checking process from the PollStatus 
 *        function to the CheckCardStatus function
 *    - Version 1.18.4 06/29/2009:
 *      - IT Handler: return "not owner" if the card is resetting
 *
 *                        
 * FUNCTIONS LIST :
 *    Local functions :
 *       iMonitor
 *       uiITHandlerDpc_PQ3_n (Linux)
 *    Public functions :
 *       drv_gpGetDataDesc
 *       drv_gvReleaseCorr
 *       drv_gpFindCtxtWithMGRSession
 *       drv_gvReleaseP2LTransfer_PQ3
 *       drv_guiITHandler_PQ3
 *       drv_guiITHandlerDpc_PQ3
 *       drv_gvITWatchdog
 *       drv_gvITPollStatus
 *       drv_gvITEchoPoll
 *       drv_guiCleanTasklet (Linux)
 *
 ****************************************************************************/
#define ITHANDLE_C
#include "iphwan.h"
#include "poolqueu.h"
#include "iphwantr.h"
#include "sendprim.h"
#include "ithandle.h"
#include "iphtrace.h"
#include "iphmsys.h"
#include "iphmain.h"


#ifdef LINUX
static void uiITHandlerDpc_PQ3_x(unsigned long Ctxt);
static void uiITHandlerDpc_PQ3_0(unsigned long Ctxt);
#endif

#ifdef USE_TASKLET 
static unsigned long  ulDpc_ctx;
DECLARE_TASKLET(iphwae_tasklet,   uiITHandlerDpc_PQ3_x, 0);
DECLARE_TASKLET(iphwae_tasklet_0, uiITHandlerDpc_PQ3_0, 0);
DECLARE_TASKLET(iphwae_tasklet_1, uiITHandlerDpc_PQ3_0, 1);
DECLARE_TASKLET(iphwae_tasklet_2, uiITHandlerDpc_PQ3_0, 2);
DECLARE_TASKLET(iphwae_tasklet_3, uiITHandlerDpc_PQ3_0, 3);
DECLARE_TASKLET(iphwae_tasklet_4, uiITHandlerDpc_PQ3_0, 4);
DECLARE_TASKLET(iphwae_tasklet_5, uiITHandlerDpc_PQ3_0, 5);
DECLARE_TASKLET(iphwae_tasklet_6, uiITHandlerDpc_PQ3_0, 6);
DECLARE_TASKLET(iphwae_tasklet_7, uiITHandlerDpc_PQ3_0, 7);
#endif

/**************************************************************************
* NAME : vMonitor
* DESCRIPTION : check whether the firmware has updated the echo count
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 0 if OK, -1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
* ATTENTION: device access semaphore must be hold!!
**************************************************************************/
static int iMonitor(IphWanDevPtr pDev)
{
   int needEcho = 0;
   dword dwVal;
   dword dwOffset;

#ifdef SOLARIS
   ddi_dma_sync(pDev->HostAreaDesc.Handle, 0, 0, DDI_DMA_SYNC_FORKERNEL);
#endif
   if (pDev->EchoTimeout == TRUE &&
       pDev->HostArea->HostToCardEchoCount == -1)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iMonitor]!!!!! WATCHDOG NOT OK !!!!!");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   HOST_CARD32(pDev->HostArea->CardToHostSigCount),
                   HOST_CARD32(pDev->HostArea->HostToCardEchoCount));
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   HOST_CARD32(pDev->HostArea->V5Spare[0]),
                   HOST_CARD32(pDev->HostArea->V5Spare[1]));
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iMonitor]first host-to-card desc index-status");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   pDev->InbStatusIndex,
                   pDev->InbStatus[pDev->InbStatusIndex].Status);
#endif
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME": !!! WATCHDOG on device %d => the card needs to be reset", 
                 pDev->Index);
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME": WatchdogTimeout %d", 
                 pDev->WatchdogTimeout);
      iph_TRACEK(TRCLVL_0, 
                 DRIVER_NAME": HostToCardSigCount %d - HostToCardEchoCount %d", 
                 pDev->HostToCardSigCount,
                 HOST_CARD32(pDev->HostArea->HostToCardEchoCount));

      /* first get the exchange area address*/
      READ_MEM_DWORD(pDev, EXCH_AREA_ADDR_INDX, &dwOffset);
      dwOffset = OFFSET_CARD_TO_HOST(dwOffset);
      if ((dwOffset % sizeof(dword)) == 0 &&
           dwOffset < pDev->Region[MEM_REGION].WinSize)
      {
         /* check interface signature */
         READ_EXCH_CODE_READY(pDev, dwOffset, &dwVal);
         iph_TRACEK(TRCLVL_0, DRIVER_NAME"[iMonitor] CodeReady device %d - Value=%08X",
                    pDev->Index, dwVal);
      }
      else
      {
         iph_TRACEK(TRCLVL_0, DRIVER_NAME"[iMonitor] bad exchange area offset - device %d - Value=%08X",
                    pDev->Index, dwOffset);
      }

      /* the adapter must be dead... */
      iph_gvShutdownAdapter(NULL, pDev, CARD_WATCHDOG);
      return(-1);
   }
   else if (pDev->EchoTimeout == TRUE &&
            HOST_CARD32(pDev->HostArea->HostToCardEchoCount) != 
            pDev->HostToCardSigCount)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[iMonitor] EchoCount - SigCount");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   HOST_CARD32(pDev->HostArea->HostToCardEchoCount),
                   pDev->HostToCardSigCount);
#endif
#ifdef DEBUG_PERF
      pDev->MaxSendLoop++;
#endif
      needEcho = 1;
   }
   else if (pDev->WatchdogTimeout == TRUE && 
            pDev->LastHostToCard == pDev->HostToCardSigCount)
   {
      pDev->HostToCardSigCount++;
      WRITE_EXCH_SIG_COUNT(pDev, pDev->ExchArea, pDev->HostToCardSigCount);
      needEcho = 1;
   }
   if (needEcho != 0)
   {
      pDev->HostArea->HostToCardEchoCount = -1;
      /* signal the card */
      WRITE_CORE_DWORD(pDev, MPC856X_MSGR0, 0xFFFFFFFF);

      if (pDev->EchoTimer == TRUE)
      {
         pDev->EchoTimer = FALSE;
         MUTEX_EXIT(&pDev->DevMutex);
         IPH_DEL_TIMER(&pDev->EchoPoll);
         MUTEX_ENTER(&pDev->DevMutex);
      }

      /* start the Echo timer */
      pDev->EchoTimeout = FALSE;
      pDev->EchoTimer = TRUE;
      IPH_START_TIMER(&pDev->EchoPoll, drv_gvITEchoPoll, pDev,
                      ECHO_TIMEOUT);
   }
   /*else*/
   {
      if (pDev->SendingPrim[pDev->InbStatusIndex] != NULL)
         pDev->Rsrc->ReleaseP2LTransfer(NULL, pDev);
   }

   return(0);
}

/**************************************************************************
* NAME : drv_gpGetDataDesc
* DESCRIPTION : extract a DataDesc_t structure for an application
* PARAMETERS :
*    Input   : pLock = protection against interrupts
*    Input   : pAppli = application context
*    Input   : wSize = size of data to put in the buffer
* RETURN : address of the structure or NULL if none is available
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static DataDesc_t *drv_gpGetDataDesc(kmutex_t *pLock, ApplCtxtPtr pAppli, 
                                     word wSize)
{
   word wPool;
   DataDesc_t *pDesc;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetDataDesc] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_SIZE, wSize);
#endif

   pDesc = NULL;

   if (pAppli->Type == TYPE_USER)
   {
      for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
      {
         if (pAppli->WanDevPtr->FreeDataPools[wPool].PoolSize >= wSize)
         {
            pDesc = iph_gpGetDataPool(pLock,
                                      &pAppli->WanDevPtr->FreeDataPools[wPool]);
            if (pDesc != NULL)
            {
               break;
            }
         }
      }
   }
   else
   {
      for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
      {
         if (pAppli->FreeDataPools[wPool].PoolSize >= wSize)
         {
            pDesc = (DataDescPtr)iph_gpGetPool(&pAppli->AppliMutex,
                                               &pAppli->FreeDataPools[wPool]);
            if (pDesc != NULL)
            {
               break;
            }
         }
      }
   }
   return(pDesc);
}

/**************************************************************************
* NAME : drv_gvReleaseCorr
* DESCRIPTION : release a correlator for a device
* PARAMETERS :
*    Input   : pLock = semaphore for protection on device
*    Input   : pDev = device context
*    Input   : pCorr = correlator to release
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvReleaseCorr(kmutex_t *pLock, IphWanDevPtr pDev, 
                              MGRSessionCorrPtr pCorr)
{
   MGRSessionCorrPtr pMyCorr;

   if (pCorr == NULL)
      return;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvReleaseCorr] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_SESSION,
                pDev->Index, pCorr->CardMGRSession);
#endif

   IPH_LOCK(pLock);
   /* check whether the session correlator is still in the hash table */
   pMyCorr = (MGRSessionCorrPtr)pDev->UsedMGRSessionCorrQueue.FirstPtr;
   while (pMyCorr != (MGRSessionCorrPtr)&pDev->UsedMGRSessionCorrQueue)
   {
      if (pMyCorr == pCorr)
         break;
      pMyCorr = pMyCorr->NextPtr;
   }
   if (pMyCorr == pCorr)
   {
      iph_gvExtractQueue(NULL, 
                         &pDev->UsedMGRSessionCorrQueue,
                         (QueueItemPtr)pCorr);
      /* release the MGR_OPEN_USER primitive if not already done */
      if (pCorr->OpenPrim != NULL)
      {
         if (pCorr->AppliPtr != NULL)
         {
            if (pCorr->AppliPtr->Type == TYPE_USER)
            {
               /* release the primitive structure and attached buffers */
               iph_gvReleaseDrvPrim(NULL, pCorr->AppliPtr, pDev, 
                                    pCorr->OpenPrim);
            }
            else
            {
               IPH_UNLOCK(pLock);
               /* give back the primitive to the kernel application */
               pCorr->AppliPtr->kd_free(pCorr->AppliPtr->Backref, 
                                        pCorr->AppliPtr->Minor, 
                                        SENT_PRIM,
                                        (void *)pCorr->OpenPrim);
               IPH_LOCK(pLock);
            }
         }
      }
      pCorr->OpenPrim = NULL;
      if (pCorr->AppliPtr != NULL)
      {
         IPH_UNLOCK(pLock);
         MUTEX_ENTER(&pCorr->AppliPtr->AppliMutex);
         pCorr->Status = SESS_CLOSED;
         if (pCorr->AppliPtr->Status != RESET)
         {
            /* check whether the session correlator is still in the hash table */
            pMyCorr = (MGRSessionCorrPtr)pCorr->AppliPtr->HashTable[pCorr->LogicalMGRSession % MODULO].FirstPtr;
            while (pMyCorr != NULL &&
                   pMyCorr != (MGRSessionCorrPtr)&pCorr->AppliPtr->HashTable[pCorr->LogicalMGRSession % MODULO])
            {
               if (pMyCorr == pCorr)
                  break;
               pMyCorr = pMyCorr->HashNextPtr;
            }
            if (pMyCorr == pCorr)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                                (byte *)"[gvReleaseCorr] gonna extract correlator from hash table");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_APPLI_SESSION,
                            pCorr->AppliPtr->Minor,
                            pCorr->LogicalMGRSession);
#endif
               iph_gvExtractCorrHash(NULL, 
                                     &pCorr->AppliPtr->HashTable[pCorr->LogicalMGRSession % MODULO],
                                     pCorr);
             }
         }
         else
            CV_SIGNAL(&pCorr->AppliPtr->CondVar);
         MUTEX_EXIT(&pCorr->AppliPtr->AppliMutex);
         IPH_LOCK(pLock);
         pCorr->AppliPtr = NULL;
      }
      pCorr->Status = SESS_CLOSED;
      iph_gvPutQueue(NULL, 
                     &pDev->FreeMGRSessionCorrQueue,
                     (QueueItemPtr)pCorr);
   }
   IPH_UNLOCK(pLock);
}

/**************************************************************************
* NAME : drv_gpFindCtxtWithMGRSession
* DESCRIPTION : find the context of the satisfied application according to
*               the MGR session reference
* PARAMETERS :
*    Input   : pLock = protection against interrupts
*    Input   : pDev = device context
*    Input   : uwSession = MGR session reference in the card
*    Output  : uwLogicalSession = MGR session reference for the application
*    Output  : ppCorr = address where to return the address of the involved
*                       session correlator
* RETURN : address of the application context if it is found, NULL else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static ApplCtxtPtr drv_gpFindCtxtWithMGRSession(kmutex_t *pLock, 
                                                IphWanDevPtr pDev, 
                                                word uwSession,
                                                word *uwLogicalSession,
                                                MGRSessionCorrPtr *ppCorr)
{
   ApplCtxtPtr pAppli;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpFindCtxtWithMGRSession] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_SESSION,
                pDev->Index, uwSession);
#endif

   pAppli = NULL;

   IPH_LOCK(pLock);

   if ((uwSession) < pDev->MaxSession &&
       pDev->MGRSessionCorrTable[(uwSession)] != NULL)
   {
      *uwLogicalSession =
         pDev->MGRSessionCorrTable[(uwSession)]->LogicalMGRSession;
      pAppli = pDev->MGRSessionCorrTable[(uwSession)]->AppliPtr;
      *ppCorr = pDev->MGRSessionCorrTable[(uwSession)];
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpFindCtxtWithMGRSession] return");
#endif

   /* return the found context */
   return(pAppli);
}

/**************************************************************************
* NAME : drv_gvReleaseP2LTransfer_PQ3
* DESCRIPTION : release the host to local transfer descriptors for
*               which the transfer is completed
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pDev = device context
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvReleaseP2LTransfer_PQ3(kmutex_t *pLock, IphWanDevPtr pDev)
{
   V5_TransferStatusPtr pTransf;
   ApplCtxtPtr pAppli;
   word wLogicalSession;
   PrimDesc_t *pPrim;
   MGRSessionCorrPtr pCorr;
   int toSignal = 0;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvReleaseP2LTransfer_PQ3] entry (Status-Ctrl)");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                pDev->Index, pDev->InbStatusIndex);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                pDev->Index, pDev->InbCtrlIndex);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)(unsigned long)pDev->SendingPrim[pDev->InbStatusIndex]);
#endif

   /* avoid any reentrance */
   IPH_LOCK(pLock);

#ifdef SOLARIS
   ddi_dma_sync(pDev->HostAreaDesc.Handle, 0, 0, DDI_DMA_SYNC_FORKERNEL);
#endif

   pTransf = &pDev->InbStatus[pDev->InbStatusIndex];
   while (pDev->SendingPrim[pDev->InbStatusIndex] != NULL &&
          pTransf->Status == TRANSFER_IDLE)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gvReleaseP2LTransfer_PQ3] transfer DONE (Status - Ctrl - Send)");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                   pDev->Index, pDev->InbStatusIndex);
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                   pDev->Index, pDev->InbCtrlIndex);
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                   pDev->Index, pDev->InbSendIndex);
#endif

      /* NOTE: at this point, pDev->DevMutex is hold */

#ifdef DEBUG_PERF
      pDev->SendNb--;
#endif
      pAppli = NULL;
      pPrim = pDev->SendingPrim[pDev->InbStatusIndex];
      if (pPrim != NULL)
      {
         pAppli = drv_gpFindCtxtWithMGRSession(NULL, pDev,
                                               pPrim->PrimRef,
                                               &wLogicalSession, &pCorr);
         /* we keep the MGR_OPEN_USER primitive to be able to force */
         /* a session closure */
         if (pAppli != NULL && pCorr != NULL &&
             pPrim->PrimId == (MGR_PRIM | MGR_OPEN_USER))
         {
            pCorr->OpenPrim = pPrim;
         }
         else
         {
            if (pAppli != NULL)
            {
               if (pAppli->Type == TYPE_USER)
               {
                  /* release the primitive structure and its attached buffers */
                  iph_gvReleaseDrvPrim(NULL, pAppli, pDev, pPrim);
               }
               else
               {
                  /* give back the primitive to the kernel application */
                  pAppli->kd_free(pAppli->Backref, pAppli->Minor, SENT_PRIM,
                                  (void *)pPrim);
               }
            }
            else if ((pAppli == NULL) && (pCorr != NULL) && (pCorr->AppliType == TYPE_USER))
            {
               /* release the primitive structure and its attached buffers */
               iph_gvReleaseDrvPrim(NULL, NULL, pDev, pPrim);
            }
         }

         pDev->InbTotalSendCount -= pPrim->BuffInPool;
      }

      pDev->SendingPrim[pDev->InbStatusIndex] = NULL;

      /* update index in InbSend */
      pDev->InbStatusIndex++;
      if (pDev->InbStatusIndex == pDev->InbCtrlNb)
      {
         pDev->InbStatusIndex = 0;
      }
      if (pAppli != NULL && pAppli->Status == WAIT_SEND_END)
      {
         MUTEX_EXIT(&pDev->DevMutex);
         MUTEX_ENTER(&pAppli->AppliMutex);
         CV_SIGNAL(&pAppli->CondVar);
         MUTEX_EXIT(&pAppli->AppliMutex);
         MUTEX_ENTER(&pDev->DevMutex);
      }
      pTransf = &pDev->InbStatus[pDev->InbStatusIndex];

      toSignal = 1;
   }

   if (toSignal != 0)
   {
      /* wake up any application waiting for a descriptor */
      CV_SIGNAL(&pDev->CondVar);
   }
   IPH_UNLOCK(pLock);

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvReleaseP2LTransfer_PQ3] return");
#endif
}

/**************************************************************************
* NAME : drv_guiITHandler_PQ3
* DESCRIPTION : manage a hardware interrupt from power quicc III based board
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : DDI_INTR_CLAIMED if the interrupt is treated,
*          DDI_INTR_UNCLAIMED else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.1 : 06/02/06 Ack IT before updating CardToHostEchoCount
**************************************************************************/
#ifdef LINUX
#ifdef LINUX_2_4
static void drv_guiITHandler_PQ3(int irq, void *dev_id, struct pt_regs *regs)
#else
static irqreturn_t drv_guiITHandler_PQ3(int irq, void *dev_id, 
                                        struct pt_regs *regs)
#endif
#endif
#ifdef SOLARIS
static u_int drv_guiITHandler_PQ3(caddr_t dev_id, caddr_t arg)
#endif
{
   IphWanDevPtr pDev = (IphWanDevPtr)dev_id;
   int SoftITNeeded = FALSE;
   dword tmp32;

   if (pDev->Status == CARD_RESETTING)
   {
#ifdef LINUX
#ifdef LINUX_2_4
      return;
#else
      return(IRQ_NONE);
#endif
#endif
#ifdef SOLARIS
      return(DDI_INTR_UNCLAIMED);
#endif
   }

   READ_CORE_DWORD(pDev, MPC856X_MSR, &pDev->IRQStatus);
   if ((pDev->IRQStatus & 0x00000002) == 0)
   {
#ifdef LINUX
#ifdef LINUX_2_4
      return;
#else
      return(IRQ_NONE);
#endif
#endif
#ifdef SOLARIS
      return(DDI_INTR_UNCLAIMED);
#endif
   }

   /* Acknowledge IT by setting S1 bit in MSR register */
   WRITE_CORE_DWORD(pDev, MPC856X_MSR, 0x00000002);

   /* to prevent Interrupt not serviced ??? */
   READ_CORE_DWORD(pDev, MPC856X_MSR, &tmp32);

   MUTEX_ENTER(&pDev->DevMutex);

#ifdef DEBUG_PERF
   pDev->ITCount++;
   pDev->ITPerDpc++;
   if (pDev->ITPerDpc > pDev->MaxITPerDpc)
      pDev->MaxITPerDpc = pDev->ITPerDpc;
#endif

   if (pDev->Status == CARD_LOADED || pDev->Status == CARD_RUNNING)
   {
#ifdef SOLARIS
      ddi_dma_sync(pDev->HostAreaDesc.Handle, 0, 0, DDI_DMA_SYNC_FORKERNEL);
#endif
      /* acknowlege signal */
      WRITE_EXCH_ECHO_COUNT(pDev, pDev->ExchArea, 
                            HOST_CARD32(pDev->HostArea->CardToHostSigCount));

      if (pDev->SoftITNeeded == FALSE &&
          pDev->OutbCtrl[pDev->OutbCtrlIndex].Status == TRANSFER_READY)
      {
         pDev->SoftITNeeded = TRUE;
         SoftITNeeded = TRUE;

#ifdef _MASK_IT
         READ_CORE_DWORD(pDev, MPC856X_MER, &tmp32);
         tmp32 &= ~(0x00000002);
         WRITE_CORE_DWORD(pDev, MPC856X_MER, tmp32);
#endif
      }
   }

   MUTEX_EXIT(&pDev->DevMutex);

   /* start software interrupt if needed */
   if (SoftITNeeded == TRUE)
   {
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[guiITHandler_PQ3] Start SOFT IT ");
#ifdef LINUX
#ifdef USE_TASKLET
      switch (pDev->Index)
      {
         case 0:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 0");
            tasklet_schedule(&iphwae_tasklet_0);
            break;

         case 1:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 1");
            tasklet_schedule(&iphwae_tasklet_1);
            break;

         case 2:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 2");
            tasklet_schedule(&iphwae_tasklet_2);
            break;

         case 3:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 3");
            tasklet_schedule(&iphwae_tasklet_3);
            break;

         case 4:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 4");
            tasklet_schedule(&iphwae_tasklet_4);
            break;

         case 5:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 5");
            tasklet_schedule(&iphwae_tasklet_5);
            break;

         case 6:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 6");
            tasklet_schedule(&iphwae_tasklet_6);
            break;

         case 7:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV 7");
            tasklet_schedule(&iphwae_tasklet_7);
            break;



         default:
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandler_PQ3] Start TASKLET  for DEV OTHER");
            ulDpc_ctx = (unsigned long) pDev;
            tasklet_schedule(&iphwae_tasklet);
            break;
      }

#else
      guiITHandlerDpc_PQ3((unsigned long)pDev);
#endif
#endif
#ifdef SOLARIS
#ifdef SOL_9
      ddi_trigger_softintr(pDev->SoftId);
#else
      ddi_intr_trigger_softint(pDev->SoftId, NULL);
#endif
#endif
   }


#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[guiITHandler_PQ3] END");
#endif

#ifdef LINUX
#ifdef LINUX_2_4
   return;
#else
   return(IRQ_HANDLED);
#endif
#endif
#ifdef SOLARIS
   return(DDI_INTR_CLAIMED);
#endif
}

/**************************************************************************
* NAME : drv_guiITHandlerDpc_PQ3
* DESCRIPTION : deferred routine for a hardware interrupt from a PQIII card
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
#ifdef LINUX
static void drv_guiITHandlerDpc_PQ3(unsigned long pCtxt)
#endif
#ifdef SOLARIS
static void drv_guiITHandlerDpc_PQ3(caddr_t pCtxt, caddr_t arg)
#endif
{
   IphWanDevPtr pDev = (IphWanDevPtr)pCtxt;
   word wCardSession, wLogicalSession, wPrimId, wErrId, wErrCause;
   PrimDescPtr pPrim;
   MGRSessionCorrPtr pCorr;
   DataDesc_t *pDesc;
   DataDesc_t *pLastDesc;
   byte ucDeleteMsg;
   V5_TransferCtrlPtr pCtrl;
   V5_OutboundSendPtr pOutbSend;
   word wCount, wSize, wDataIndex;
   ApplCtxtPtr pAppli;
   dword tmp32;
   byte nbPbBuff = 0;
#ifdef SOLARIS
   off_t offset;
#endif

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[guiITHandlerDpc_PQ3] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   /* release Host-to-card transfer descriptors */
   pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

   MUTEX_ENTER(&pDev->DevMutex);

#ifdef DEBUG_PERF
   pDev->ITDpcCount++;
   pDev->RecvChainNb = 0;
#endif

   if (pDev->SoftITNeeded == TRUE && pDev->SoftITRunning == FALSE)
   {
      pDev->SoftITRunning = TRUE;

#ifdef DEBUG_PERF
      if (pDev->ITPerDpc > 1)
         pDev->ITBeforeDpc++;
      pDev->ITPerDpc = 0;
#endif

      /* examine any received message */
      while (pDev->OutbCtrl[pDev->OutbCtrlIndex].Status == TRANSFER_READY)
      {
         MUTEX_EXIT(&pDev->DevMutex);
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiITHandlerDpc_PQ3] new message pending");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                      pDev->Index, pDev->OutbCtrlIndex);
#endif
         pPrim = NULL;
         pLastDesc = NULL;
         wCount = 0;
         ucDeleteMsg = FALSE;

         pCtrl = &pDev->OutbCtrl[pDev->OutbCtrlIndex];
         wCardSession = HOST_CARD16(pCtrl->PrimitiveRef);
         wPrimId = HOST_CARD16(pCtrl->PrimitiveId);
         bcopy(pCtrl->PrimitiveInfo, (void *)&wErrId, sizeof(word));
         wErrId = HOST_CARD16(wErrId);

         if (wPrimId == SHUTDOWN_PRIM)
         {
            MUTEX_ENTER(&pDev->DevMutex);
            if (pDev->ExchArea != 0)
            {
               /* Reset CodeReady before resetting the card */
               tmp32 = 0x52535421;
               WRITE_EXCH_CODE_READY(pDev, pDev->ExchArea, tmp32);
               /* reset also ConfigStatus */
               WRITE_EXCH_CONFIG_STATUS(pDev, pDev->ExchArea, 0);
            }
            MUTEX_EXIT(&pDev->DevMutex);
            iph_gvShutdownAdapter(&pDev->DevMutex, pDev, CARD_RESET);
         }

         /* initialize the pointer on the correlator */
         pCorr = NULL;
         /* find application & correlator concerned with the message */
         pAppli = iph_gpFindCtxtWithMGRSession(&pDev->DevMutex, pDev,
                                               wCardSession,
                                               &wLogicalSession, &pCorr);
         if (pAppli == NULL)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandlerDpc_PQ3] no application is concerned with this message");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF,
                         wPrimId, wCardSession);
            iph_TRACE_PACKET(IPHWAN_ID, TRC, IPHWAN_PRIM_INFO,
                             MAX_PRIM_INFO, pCtrl->PrimitiveInfo);
#endif
            ucDeleteMsg = TRUE;
         }
         else if (pCorr != NULL && pCorr->AppliReady == 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[guiITHandlerDpc_PQ3] application is no more concerned with this message");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF,
                         wPrimId, wCardSession);
#endif
            ucDeleteMsg = TRUE;
         }
         else
         {
            MUTEX_ENTER(&pAppli->AppliMutex);
            /* if the application has too many pending primitives, reset */
            /* the session */
            if (pAppli->RecvNb >= pAppli->MaxRecvNb)
            {
               MUTEX_EXIT(&pAppli->AppliMutex);
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[ucStartRecv_PQ3] too many pending primitives for this application");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                            pAppli->WanDevPtr->Index, pAppli->Minor);
#endif
               /* release Host-to-card transfer descriptors */
               pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

               /* purge the receive queue for this faulty session */
               /*iph_gvPurgeAppliSession(&pDev->DevMutex, pAppli, wLogicalSession);*/

               if (pAppli->PbMaxRxQueue < PB_MAX_RX_QUEUE)
               {
                  word wUserSession;

                  if (pDev->MGRSessionCorrTable[wCardSession] != NULL)
                    wUserSession = pDev->MGRSessionCorrTable[wCardSession]->CardMGRSession;
                  else
                    wUserSession = ~0;

                  iph_TRACEK(TRCLVL_0,
                             DRIVER_NAME" too many pending primitives to be received, close session %d (see CTL_MAX_RX_QUEUE) %04x %04x",
                             wCardSession, wPrimId, wUserSession);
                  pAppli->PbMaxRxQueue++;
               }

               /* force session closure */
               /*iph_gvCloseAppliSession(&pDev->DevMutex, pDev,
                                       pDev->MGRSessionCorrTable[wCardSession],
                                       MGR_DISC_NO_MEMORY);*/
               ucDeleteMsg = TRUE;
            }
            else
            {
               MUTEX_EXIT(&pAppli->AppliMutex);
               /* allocate a driver primitive to receive the message */
               /* the treatment depends on the type of application */
               if (pAppli->Type == TYPE_USER)
               {
                  pPrim = iph_gpGetPrimPool(&pDev->DevMutex, &pDev->FreePrimHeadPool);
               }
               else
               {
                  pPrim = (PrimDesc_t *)iph_gpGetPool(&pAppli->AppliMutex,
                                                      &pAppli->FreePrimHeadPool);
               }
               if (pPrim != NULL)
               {
                  pPrim->PrimId = wPrimId;
                  pPrim->PrimRef = wCardSession;
                  bcopy(pCtrl->PrimitiveInfo, pPrim->PrimInfo, MAX_PRIM_INFO);
                  pPrim->DataDescPtr = NULL;

                  for (wCount = 0; wCount < pCtrl->DataCount; wCount++)
                  {
                     pOutbSend = &pDev->OutbSend[pDev->OutbSendIndex];
                     wDataIndex = HOST_CARD16(pOutbSend->DataIndex);
                     wSize = HOST_CARD16(pOutbSend->ByteCount); 
                     /* get a RX buffer */
                     pDesc = iph_gpGetDataDesc(&pDev->DevMutex, pAppli, wSize);
#if 0
                     if (pDesc == NULL && pAppli->Type == TYPE_USER)
                     {
                        /* if no driver buffer could be allocated */
                        /* use the DMA buffer */
                        pDesc = pDev->RecvDmaDesc[wDataIndex].pDataDesc;
                     }
#endif
                     if (pDesc == NULL)
                     {
                        ucDeleteMsg = TRUE;
#ifdef DEBUG_PERF
                        pDev->NbrLackRecvBuffer++;
#endif
#ifdef TRACE
                        iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                         (byte *)"[ucStartRecv_PQ3] NO AVAILABLE BUFFER to receive message => close session");
                        iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                                     wCardSession, wSize);
#endif
                        if (nbPbBuff == 0)
                        {
                           nbPbBuff++;
                           /* display error on console */
                           if (pAppli->Type == TYPE_USER)
                           {
                              iph_TRACEK(TRCLVL_0,
                                         DRIVER_NAME" device %d - NO AVAILABLE BUFFER to receive message",
                                         pDev->Index);
                              iph_TRACEK(TRCLVL_0,
                                         DRIVER_NAME" PRIMITIVE LOST => check pool for size %d",
                                         wSize);
                           }
                           else
                           {
                              iph_TRACEK(TRCLVL_0,
                                         DRIVER_NAME" device %d - NO AVAILABLE BUFFER to receive message",
                                         pDev->Index);
                              iph_TRACEK(TRCLVL_0,
                                         DRIVER_NAME" PRIMITIVE LOST for kernel application %d",
                                         pAppli->Minor);
                           }
                           iph_TRACEK(TRCLVL_0,
                                      DRIVER_NAME" ==> close session %d",
                                      wCardSession);
                        }
                        break;
                     }
                     else
                     {
                        pDesc->NextPtr = NULL;
                        if (pPrim->DataDescPtr == NULL)
                           pPrim->DataDescPtr = pDesc;
                        else
                           pLastDesc->NextPtr = pDesc;
                        pLastDesc = pDesc;
                        pDesc->Offset = 0;
                        pDesc->Size = wSize;
#ifdef SOLARIS
                        /* synchronize data */
                        offset = pDev->RecvDmaDesc[wDataIndex].PhysAddr -
                                 pDev->DmaAreaDesc.PhysAddr;
                        ddi_dma_sync(pDev->DmaAreaDesc.Handle, offset,
                                     wSize, DDI_DMA_SYNC_FORCPU);
#endif
                        /* if the allocated buffer is not the DMA */
                        /* buffer, copy the data */
                        if ((pDesc->Reserved & DMA_BUFFER) == 0)
                        {
                           bcopy(pDev->RecvDmaDesc[wDataIndex].VirtAddr, 
                                 pDesc->DataPtr, wSize);
                           MUTEX_ENTER(&pDev->DevMutex);
                           /* give back the buffer to the card */
                           GIVE_BUFF_TO_CARD(pDev, 
                                             &pDev->RecvDmaDesc[wDataIndex]);
                           MUTEX_EXIT(&pDev->DevMutex);
#ifdef TRACE
                           iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                            (byte *)"[ucStartRecv_PQ3] copy data - first & size");
                           iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                                        pDesc->DataPtr[0], wSize);
#endif
                        }
                     }
                     pDev->OutbSendIndex++;
                     if (pDev->OutbSendIndex == pDev->OutbDataNb)
                     {
                        pDev->OutbSendIndex = 0;
                     }
                  }

                  if (ucDeleteMsg == FALSE)
                  {
                     iph_gvDumpPrim(pPrim, pDev, pAppli, FALSE);
                     /* translate the session number */
                     pPrim->PrimRef = wLogicalSession;
                     /* notify application */
                     iph_gvSendPrimToAppli(pAppli, pPrim, pCorr);
#ifdef DEBUG_PERF
                     pDev->RecvMsgNb++;
#endif
                  }
               }
               else
               {
                  ucDeleteMsg = TRUE;
#ifdef DEBUG_PERF
                  pDev->NbrLackRecvPrim++;
#endif
                  /* display error on console */
                  if (pAppli->Type == TYPE_USER)
                  {
                     iph_TRACEK(TRCLVL_0,
                                DRIVER_NAME" device %d - NO AVAILABLE PRIM to receive message",
                                pDev->Index);
                     iph_TRACEK(TRCLVL_0,
                                DRIVER_NAME" PRIMITIVE LOST => check pool size %d",
                                pDev->FreePrimHeadPool.MaxCount);
                  }
                  else
                  {
                     iph_TRACEK(TRCLVL_0,
                                DRIVER_NAME" device %d - NO AVAILABLE PRIM to receive message",
                                pDev->Index);
                     iph_TRACEK(TRCLVL_0,
                                DRIVER_NAME" PRIMITIVE LOST for kernel application %d",
                                pAppli->Minor);
                  }
               }
            }
         }
         /* check whether this is the end of a session and so the end */
         /* of a correlator */
         if (pCorr != NULL &&
             (wPrimId == (MGR_PRIM|MGR_USER_CLOSED) ||
              (wPrimId == (MGR_PRIM|MGR_USER_ERR) &&
               wErrId == (MGR_PRIM | MGR_OPEN_USER))))
         {
            /* if MGR_USER_ERR cause is MGR_ERR_INVALID_SESSION, add a */
            /* message to the console */
            bcopy(&pCtrl->PrimitiveInfo[sizeof(word)], 
                  (void *)&wErrCause, sizeof(word));
            wErrCause = HOST_CARD16(wErrCause);
            if (wPrimId == (MGR_PRIM|MGR_USER_ERR) &&
                wErrId == (MGR_PRIM | MGR_OPEN_USER) &&
                wErrCause == MGR_ERR_INVALID_SESSION)
            {
               iph_TRACEK(TRCLVL_0, 
                          DRIVER_NAME": failed to open session %d on device %d (MGR_ERR_INVALID_SESSION)", 
                          wCardSession, pDev->Index);
            }
            /* release Host-to-card transfer descriptors */
            pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

            /* release the correlator */
            iph_gvReleaseCorr(&pDev->DevMutex, pDev, pCorr);
         }
         if (ucDeleteMsg == TRUE)
         {
            /* release Host-to-card transfer descriptors */
            pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

            for (; wCount < pCtrl->DataCount; wCount++)
            {
               pOutbSend = &pDev->OutbSend[pDev->OutbSendIndex];
               wDataIndex = HOST_CARD16(pOutbSend->DataIndex);
               MUTEX_ENTER(&pDev->DevMutex);
               /* give back the buffer to the card */
               GIVE_BUFF_TO_CARD(pDev, 
                                 &pDev->RecvDmaDesc[wDataIndex]);
               MUTEX_EXIT(&pDev->DevMutex);
               pDev->OutbSendIndex++;
               if (pDev->OutbSendIndex == pDev->OutbDataNb)
               {
                  pDev->OutbSendIndex = 0;
               }
            }
            if (pPrim != NULL)
            {
               iph_gvReleaseDrvPrim(&pDev->DevMutex, pAppli, pDev, pPrim);
            }
            iph_gvCloseAppliSession(&pDev->DevMutex, pDev,
                                    pDev->MGRSessionCorrTable[wCardSession],
                                    MGR_DISC_NO_MEMORY);
         }

         /* free transfer descriptor in both host and card control areas */
         pCtrl->Status = TRANSFER_IDLE;
         MUTEX_ENTER(&pDev->DevMutex);
         WRITE_MEM_BYTE(pDev, &pDev->OutbStatus[pDev->OutbCtrlIndex].Status,
                        TRANSFER_IDLE);
         /* update transfer descriptor index */
         pDev->OutbCtrlIndex++;
         if (pDev->OutbCtrlIndex == pDev->OutbCtrlNb)
         {
            pDev->OutbCtrlIndex = 0;
         }
         MUTEX_EXIT(&pDev->DevMutex);
#ifdef DEBUG_PERF
         pDev->RecvChainNb++;
         if (pDev->RecvChainNb > 1)
            pDev->RecvChainCount++;
#endif
         MUTEX_ENTER(&pDev->DevMutex);
         /* acknowlege signal */
         WRITE_EXCH_ECHO_COUNT(pDev, pDev->ExchArea, 
                               HOST_CARD32(pDev->HostArea->CardToHostSigCount));
      }
      pDev->SoftITNeeded = FALSE;
      pDev->SoftITRunning = FALSE;
      MUTEX_EXIT(&pDev->DevMutex);

#ifdef DEBUG_PERF
      if (pDev->MaxRecvChainNb < pDev->RecvChainNb)
      {
         pDev->MaxRecvChainNb = pDev->RecvChainNb;
      }
#endif

#ifdef _MASK_IT
      /* enable interrupts from the card */
      /* - by setting E1 bit in MER register */
      READ_CORE_DWORD(pDev, MPC856X_MER, &tmp32);
      tmp32 |= 0x00000002;
      WRITE_CORE_DWORD(pDev, MPC856X_MER, tmp32);
#endif

      /* acknowlege signal */
      MUTEX_ENTER(&pDev->DevMutex);
      WRITE_EXCH_ECHO_COUNT(pDev, pDev->ExchArea, 
                            HOST_CARD32(pDev->HostArea->CardToHostSigCount));
      MUTEX_EXIT(&pDev->DevMutex);

      /* release Host-to-card transfer descriptors */
      pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

   }
   else
   {
      MUTEX_EXIT(&pDev->DevMutex);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[guiITHandlerDpc_PQ3] return");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

}

/**************************************************************************
* NAME : drv_gvITWatchdog
* DESCRIPTION : timeout routine for watchdog function
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
#ifdef LINUX
static void drv_gvITWatchdog(unsigned long ulArg)
#endif
#ifdef SOLARIS
static void drv_gvITWatchdog(void *ulArg)
#endif
{
   IphWanDevPtr pDev = (IphWanDevPtr)ulArg;
#ifdef LINUX
   struct timeval tNow;
#endif
#ifdef SOLARIS
   dword tNow;
#endif
   dword Now;

   MUTEX_ENTER(&pDev->DevMutex);
   if (pDev->WatchdogTimer != TRUE)
   {
      MUTEX_EXIT(&pDev->DevMutex);
      return;
   }

   pDev->WatchdogTimeout = TRUE;
   pDev->WatchdogTimer = FALSE;

   if (iMonitor(pDev) == 0)
   {
      if (pDev->SendWaiting != 0)
      {
         IPH_GET_TIME(&tNow);
#ifdef LINUX
         Now = tNow.tv_sec;
#endif
#ifdef SOLARIS
         Now = tNow;
#endif
         if (pDev->SendWaiting + 10 < Now)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gvITWatchdog]!!!!! PROBLEM on SENDING (Ctrl - Status - InbTotalSendCount) !!!!!");
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                         pDev->Index, pDev->InbCtrlIndex);
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                         pDev->Index, pDev->InbStatusIndex);
            iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_TRANSFER,
                         pDev->Index, pDev->InbTotalSendCount);
#endif
            iph_TRACEK(TRCLVL_0, 
                       DRIVER_NAME": !!! SENDING PROBLEM on device %d => the card needs to be reset", 
                       pDev->Index);
            /* the adapter must be dead... */
            iph_gvShutdownAdapter(NULL, pDev, CARD_WATCHDOG);
         }
      }
      pDev->LastHostToCard = pDev->HostToCardSigCount;
      /* start the Watchdog function */
      pDev->WatchdogTimeout = FALSE;
      pDev->WatchdogTimer = TRUE;
      IPH_START_TIMER(&pDev->Watchdog, drv_gvITWatchdog, pDev,
                      WATCHDOG_TIMEOUT);
   }

   MUTEX_EXIT(&pDev->DevMutex);

}

/**************************************************************************
* NAME : drv_gvITPollStatus
* DESCRIPTION : timeout routine for card status polling function
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
#ifdef LINUX
static void drv_gvITPollStatus(unsigned long ulArg)
#endif
#ifdef SOLARIS
static void drv_gvITPollStatus(void *ulArg)
#endif
{
   IphWanDevPtr pDev = (IphWanDevPtr)ulArg;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvITPollStatus] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->PollTimer);
#endif

   MUTEX_ENTER(&pDev->DevMutex);
   if (pDev->PollTimer != TRUE)
   {
      MUTEX_EXIT(&pDev->DevMutex);
      return;
   }

   pDev->PollTimeout = TRUE;

   /* check the status of the card */
   if (pDev->ControlAppli == NULL && 
       pDev->Rsrc->CheckCardStatus != NULL &&
       pDev->Status != CARD_UNAVAILABLE)
   {
      pDev->Status = pDev->Rsrc->CheckCardStatus(NULL, pDev);
   }

   /* poll card status all the time */
   if ((pDev->ControlAppli != NULL || pDev->Rsrc->CheckCardStatus != NULL) &&
       (pDev->PollTimeout == TRUE))
   {

      /* start the timer again */
      IPH_START_TIMER(&pDev->StatusPoll, drv_gvITPollStatus, pDev, 
                      POLL_STATUS_TIMEOUT);
      pDev->PollTimeout = FALSE;
   }

   MUTEX_EXIT(&pDev->DevMutex);
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gvITPollStatus] return");
}

/**************************************************************************
* NAME : drv_gvITEchoPoll
* DESCRIPTION : timeout routine to poll echo count
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
#ifdef LINUX
static void drv_gvITEchoPoll(unsigned long ulArg)
#endif
#ifdef SOLARIS
static void drv_gvITEchoPoll(void *ulArg)
#endif
{
   IphWanDevPtr pDev = (IphWanDevPtr)ulArg;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvITEchoPoll] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->EchoTimer);
#endif
   MUTEX_ENTER(&pDev->DevMutex);
   if (pDev->EchoTimer != TRUE)
   {
      MUTEX_EXIT(&pDev->DevMutex);
      return;
   }

   pDev->EchoTimeout = TRUE;
   pDev->EchoTimer = FALSE;

   iMonitor(pDev);

   pDev->EchoTimeout = FALSE;
   MUTEX_EXIT(&pDev->DevMutex);

}

#ifdef LINUX
/**************************************************************************
* NAME : uiITHandlerDpc_PQ3_0
* DESCRIPTION : deferred routine for a hardware interrupt PQ3 DEV 0
* PARAMETERS :
*    Input   : Index of the device
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void uiITHandlerDpc_PQ3_0(unsigned long Ctxt)
{
   IphWanDevPtr pDev; 

   pDev = (IphWanDevPtr)iph_gMinorMap[Ctxt];

   if ( pDev == 0 )
      return;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[uiITHandlerDpc_PQ3_0] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   drv_guiITHandlerDpc_PQ3((unsigned long)pDev);
}

#if 0
/**************************************************************************
* NAME : uiITHandlerDpc_PQ3_1
* DESCRIPTION : deferred routine for a hardware interrupt from a 653x
* PARAMETERS :
*    Input   : pDev = device context
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void uiITHandlerDpc_PQ3_1(unsigned long Ctxt)
{
   IphWanDevPtr pDev; 

   pDev = (IphWanDevPtr)iph_gMinorMap[Ctxt];

   if ( pDev == 0 )
      return;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[uiITHandlerDpc_PQ3_1] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   drv_guiITHandlerDpc_PQ3((unsigned long)pDev);
}

/**************************************************************************
* NAME : uiITHandlerDpc_PQ3_2
* DESCRIPTION : deferred routine for a hardware interrupt PQ3 DEV 2
* PARAMETERS :
*    Input   : Index of the device
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void uiITHandlerDpc_PQ3_2(unsigned long Ctxt)
{
   IphWanDevPtr pDev; 

   pDev = (IphWanDevPtr)iph_gMinorMap[Ctxt];

   if ( pDev == 0 )
      return;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[uiITHandlerDpc_PQ3_2] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   drv_guiITHandlerDpc_PQ3((unsigned long)pDev);
}

/**************************************************************************
* NAME : uiITHandlerDpc_PQ3_3
* DESCRIPTION : deferred routine for a hardware interrupt PQ3 DEV 3
* PARAMETERS :
*    Input   : Index of the device
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void uiITHandlerDpc_PQ3_3(unsigned long Ctxt)
{
   IphWanDevPtr pDev; 

   pDev = (IphWanDevPtr)iph_gMinorMap[Ctxt];

   if ( pDev == 0 )
      return;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[uiITHandlerDpc_PQ3_3] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   drv_guiITHandlerDpc_PQ3((unsigned long)pDev);
}
#endif

/**************************************************************************
* NAME : uiITHandlerDpc_PQ3_x
* DESCRIPTION : deferred routine for a hardware interrupt PQ3 DEV x
* PARAMETERS :
*    Input   : none
* RETURN : 
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void uiITHandlerDpc_PQ3_x(unsigned long Ctxt)
{
   IphWanDevPtr pDev; 

   pDev = (IphWanDevPtr)ulDpc_ctx;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[uiITHandlerDpc_PQ3_3] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_INTR, pDev->Index,
                pDev->IRQStatus);
#endif

   drv_guiITHandlerDpc_PQ3((unsigned long)pDev);
}

/**************************************************************************
* NAME : drv_guiCleanTasklet
* DESCRIPTION : Kill the tasklet which corresponds to the specified card
* PARAMETERS :
*    Input   : pDev = device context
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_guiCleanTasklet(IphWanDevPtr pDev)
{

   switch (pDev->Index)
   {
      case 0:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 0");
         tasklet_kill(&iphwae_tasklet_0);
         break;

      case 1:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 1");
         tasklet_kill(&iphwae_tasklet_1);
         break;

      case 2:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 2");
         tasklet_kill(&iphwae_tasklet_2);
         break;

      case 3:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 3");
         tasklet_kill(&iphwae_tasklet_3);
         break;

      case 4:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 4");
         tasklet_kill(&iphwae_tasklet_4);
         break;

      case 5:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 5");
         tasklet_kill(&iphwae_tasklet_5);
         break;

      case 6:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 6");
         tasklet_kill(&iphwae_tasklet_6);
         break;

      case 7:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV 7");
         tasklet_kill(&iphwae_tasklet_7);
         break;


      default:
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[guiCleanTasklet] Kill TASKLET  for DEV OTHER");
         tasklet_kill(&iphwae_tasklet);
         break;
   }
}

#endif


