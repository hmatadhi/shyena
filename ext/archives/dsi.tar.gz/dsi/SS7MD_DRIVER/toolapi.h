/****************************************************************************
 * NAME : toolapi.h
 * VERSION : 2.16.1
 * DESCRIPTION : 
 *    Values for the control request from the tools to the base driver
 * REVISIONS :
 *    - Version 1.0 10/19/99 : Creation
 *    - Version 1.1 02/04/00 : Solaris 7 support
 *    - Version 2.0 06/23/00 : Support for 653x
 *    - Version 2.1 01/09/01 : Add new CTL_GET_CONTROL_DBG ioctl
 *    - Version 2.2 06/21/01 : Add default settings for 6535
 *                             Change some default settings for 453x
 *    - Version 2.3 09/07/01 : Add new CTL_CHECK_CARD_STATUS ioctl
 *    - Version 2.4 09/10/01 : Add support for 4532, 4538, and 4539
 *                             Add new port type 'O' for optical
 *    - Version 2.5 01/24/02 : Add of a DRAM size type definition returned by
 *                             CTL_GET_CARD_RSRC ioctl
 *    - Version 2.6 05/16/02 : Add some LINUX specific stucture
 *    - Version 2.7 07/30/02 : PAGE_SIZE is not defined if LINUX
 *    - Version 2.8 03/03/03 : Add of RSRC_PRIMARY_SUBID and RSRC_DEVREV resource
 *                             types
 *    - Version 2.9 17/10/05 : Add the following define 
 *                        CTL_RESET_BOARD             To reset the board with driver function
 *                        CTL_DUMP_CORE_REG           To dump from MPC856X registers area
 *                        CTL_WRITE_CORE_REG          To write into MPC856x register area
 *                        CTL_WRITE_FLASH             To write into  memory flash device area
 *                        CTL_READ_FLASH              TO read from memory flash device area
 *    - Version 2.10 01/17/06: Add support for 3639
 *                             Add CTL_DUMP_HOST, CTL_RESET_HOST_STAT, 
 *                             and CTL_TRACE_CONSOLE_LEVEL commands
 *    - Version 2.11 10/17/06: Add support for 5639
 *    - Version 2.12 12/05/06: Suppress the CARD_5639 define, the 5639 card is part of
 *                             CARD_3639 device category.
 *    - Version 2.13 05/22/07: Add of RSRC_SECONDARY_SUBID resource type
 *    - Version 2.14 09/12/07: Add ioctl codes for i3650 support
 *    - Version 2.15 02/04/08: CTL_GET_ATN_STATUS value change due to conflict
 *                             with CTL_GET_CUSTOM_INFO
 *    - Version 2.16 06/25/08: Add the driver module identifiers (used to select
 *                             driver traces)
 *    - Version 2.16.1 06/30/10: Add the two new ioctl commands:
 *                               - CTL_DUMP_SEEPROM_BYTE
 *                               - CTL_WRITE_SEEPROM_BYTE
 ****************************************************************************/
/* To prevent include of include */
#ifndef TOOLAPI_H
#define TOOLAPI_H
#include "wanapi.h"

/***************************************************************************/
/* Types of request                                                        */
/***************************************************************************/

/* CTL_CLOSE_DEVICE            (FILE_DEVICE_IPHWAN | 1) */
/* CTL_SEND_PRIM               (FILE_DEVICE_IPHWAN | 2) */
/* CTL_GIVE_RX_PRIM            (FILE_DEVICE_IPHWAN | 3) */
/* CTL_GIVE_RX_BUFFER          (FILE_DEVICE_IPHWAN | 4) */
/* CTL_RECV_PRIM               (FILE_DEVICE_IPHWAN | 5) */
/* CTL_MAX_RX_QUEUE            (FILE_DEVICE_IPHWAN | 6) */
/* CTL_NO_OF_DEVICES           (FILE_DEVICE_IPHWAN | 7) */
/* CTL_GET_CARD_ID             (FILE_DEVICE_IPHWAN | 8) */
/* CTL_MAX_RX_CHAIN            (FILE_DEVICE_IPHWAN | 9) */

#define CTL_GET_CONTROL             (FILE_DEVICE_IPHWAN | 10)
#define CTL_FREE_CONTROL            (FILE_DEVICE_IPHWAN | 11)

#define CTL_DUMP_MEM                (FILE_DEVICE_IPHWAN | 12)
#define CTL_WRITE_MEM               (FILE_DEVICE_IPHWAN | 13)
#define CTL_DUMP_PLX_REG            (FILE_DEVICE_IPHWAN | 14)
#define CTL_WRITE_PLX_REG           (FILE_DEVICE_IPHWAN | 15)
#define CTL_DUMP_PCI_CONF           (FILE_DEVICE_IPHWAN | 16)
#define CTL_WRITE_PCI_CONF          (FILE_DEVICE_IPHWAN | 17)

/* CTL_GET_DRV_VER             (FILE_DEVICE_IPHWAN | 18) */

#define CTL_DUMP_CPU_USAGE          (FILE_DEVICE_IPHWAN | 19)
#define CTL_DUMP_POOL               (FILE_DEVICE_IPHWAN | 20)
#define CTL_DUMP_DRV_POOL           (FILE_DEVICE_IPHWAN | 21)

/* CTL_GIVE_RX_DATA_BUFFER     (FILE_DEVICE_IPHWAN | 22) */

#define CTL_DUMP_SEEPROM_BYTE       (FILE_DEVICE_IPHWAN | 23)
#define CTL_WRITE_SEEPROM_BYTE      (FILE_DEVICE_IPHWAN | 24)

#define CTL_MAX_TRANSFER_SIZE       (FILE_DEVICE_IPHWAN | 30)
#define CTL_INIT_PRIM_POOL          (FILE_DEVICE_IPHWAN | 31)
#define CTL_INIT_BUFFER_POOL        (FILE_DEVICE_IPHWAN | 32)
#define CTL_INIT_MAX_APPLI          (FILE_DEVICE_IPHWAN | 33)
#define CTL_INIT_MAX_SESSION        (FILE_DEVICE_IPHWAN | 34)

#define CTL_INIT_DRV_TRACE          (FILE_DEVICE_IPHWAN | 40)

/* CTL_START_DRV_TRACE         (FILE_DEVICE_IPHWAN | 41) */
/* CTL_STOP_DRV_TRACE          (FILE_DEVICE_IPHWAN | 42) */

#define CTL_DUMP_DRV_TRACE          (FILE_DEVICE_IPHWAN | 43)
#define CTL_DUMP_HOST               (FILE_DEVICE_IPHWAN | 44)
#define CTL_RESET_HOST_STAT         (FILE_DEVICE_IPHWAN | 45)
#define CTL_TRACE_CONSOLE_LEVEL     (FILE_DEVICE_IPHWAN | 48)

#define CTL_DUMP_TRACE              (FILE_DEVICE_IPHWAN | 50)
#define CTL_GET_STATUS              (FILE_DEVICE_IPHWAN | 51)

/* CTL_GET_CARD_STATUS         (FILE_DEVICE_IPHWAN | 60) */

#define CTL_SET_CARD_STATUS         (FILE_DEVICE_IPHWAN | 61)
#define CTL_GET_CARD_RSRC           (FILE_DEVICE_IPHWAN | 62)
#define CTL_GET_USING_APPLI         (FILE_DEVICE_IPHWAN | 63)

#define CTL_CHECK_CARD_STATUS       (FILE_DEVICE_IPHWAN | 64)

/* CTL_GET_CUSTOM_INFO         (FILE_DEVICE_IPHWAN | 65) */

#define CTL_SET_ATN_STATUS          (FILE_DEVICE_IPHWAN | 66)
#define CTL_GET_ATN_STATUS          (FILE_DEVICE_IPHWAN | 67)

/* CTL_GET_TIME                (FILE_DEVICE_IPHWAN | 68) */
/* CTL_SET_HOST_TIME_OFFSET    (FILE_DEVICE_IPHWAN | 69) */

#define CTL_GET_CONTROL_DBG         (FILE_DEVICE_IPHWAN | 70)

/* CTL_GET_TEMP_INFO           (FILE_DEVICE_IPHWAN | 71) */

#define CTL_WRITE_FLASH             (FILE_DEVICE_IPHWAN | 80)
#define CTL_READ_FLASH              (FILE_DEVICE_IPHWAN | 81)
#define CTL_WRITE_CORE_REG          (FILE_DEVICE_IPHWAN | 82)
#define CTL_DUMP_CORE_REG           (FILE_DEVICE_IPHWAN | 83)
#define CTL_RESET_BOARD             (FILE_DEVICE_IPHWAN | 84)

/***************************************************************************/
/* Driver module identifiers                                               */
/***************************************************************************/
#define IPHWAN_ID            0x00
#define IPHWAN_OTHER_PRIM_ID 0x01
#define IPHWAN_SVR_PRIM_ID   0x02
#define IPHWAN_REGACC_ID     0x03
#define IPHWAN_DATA_PRIM_ID  0x04


/***************************************************************************/
/* Miscellaneous constant definitions                                      */
/***************************************************************************/
/* Maximum size that the driver can allocate */
#ifndef LINUX
#define PAGE_SIZE             4096
#endif

/* Default maximum size of a DMA data fragment */
#define DEF_MAX_TRANSFER_SIZE 2048

/* Number of buffer pools managed by the driver per adapter */
#define MAX_DRV_POOL          4
 
/***************************************/
/* Default settings for 4534/4535/4537 */
/***************************************/
/* Default number of primitives allocated in the driver per adapter */
/* 06/21/01 change DEF_POOL_PRIM from 1024->8192 */
#define DEF_POOL_PRIM         1024

/* Default number of buffers allocated by the driver in pool 0 */
#define DEF_POOL_0            1024

/* Default buffer size in pool 0 */
#define DEF_BUFFER_SIZE_0     64

/* Default number of buffers allocated by the driver in pool 1 */
/* 06/21/01 change DEF_POOL_1 from 512->4096 */
#define DEF_POOL_1            4096

/* Default buffer size in pool 1 */
#define DEF_BUFFER_SIZE_1     512

/* Default number of buffers allocated by the driver in pool 2 */
#define DEF_POOL_2            128

/* Default buffer size in pool 2 */
#define DEF_BUFFER_SIZE_2     2048

/* Default number of buffers allocated by the driver in pool 3 */
#define DEF_POOL_3            64

/* Default buffer size in pool 3 */
#define DEF_BUFFER_SIZE_3     (PAGE_SIZE - sizeof(dword))

/* Default maximum number of supported applications */
#define DEF_MAX_APPLI         256

/* Default maximum number of MGR session references multiplexed */
/* by the driver for each card */
#define DEF_MAX_MGR_REF       256

/***************************************/
/* 06/21/01 Default settings for 6535  */
/***************************************/
/* Default number of primitives allocated in the driver per adapter */
#define DEF_6535_POOL_PRIM       16384

/* Default number of buffers allocated by the driver in pool 0 */
#define DEF_6535_POOL_0          16384

/* Default buffer size in pool 0 */
#define DEF_6535_BUFFER_SIZE_0   64

/* Default number of buffers allocated by the driver in pool 1 */
#define DEF_6535_POOL_1          8192

/* Default buffer size in pool 1 */
#define DEF_6535_BUFFER_SIZE_1   512

/* Default number of buffers allocated by the driver in pool 2 */
#define DEF_6535_POOL_2          128

/* Default buffer size in pool 2 */
#define DEF_6535_BUFFER_SIZE_2   2048

/* Default number of buffers allocated by the driver in pool 3 */
#define DEF_6535_POOL_3          64

/* Default buffer size in pool 3 */
#define DEF_6535_BUFFER_SIZE_3   (PAGE_SIZE - sizeof(dword))

/* Default maximum number of supported applications */
#define DEF_6535_MAX_APPLI       256

/* Default maximum number of MGR session references multiplexed */
/* by the driver for each card */
#define DEF_6535_MAX_MGR_REF     4096

/***************************************/
/* Default settings for 3639, 5639     */
/***************************************/
/* Default number of primitives allocated in the driver per adapter */
#define DEF_3639_POOL_PRIM       16384
#define DEF_5639_POOL_PRIM       16384

/* Default number of buffers allocated by the driver in pool 0 */
#define DEF_3639_POOL_0          16384
#define DEF_5639_POOL_0          16384
#define DEF_3639_POOL_0_INIT     728
#define DEF_5639_POOL_0_INIT     728

/* Default buffer size in pool 0 */
#define DEF_3639_BUFFER_SIZE_0   64
#define DEF_5639_BUFFER_SIZE_0   64

/* Default number of buffers allocated by the driver in pool 1 */
#define DEF_3639_POOL_1          8192
#define DEF_5639_POOL_1          8192
#define DEF_3639_POOL_1_INIT     256
#define DEF_5639_POOL_1_INIT     256

/* Default buffer size in pool 1 */
#define DEF_3639_BUFFER_SIZE_1   512
#define DEF_5639_BUFFER_SIZE_1   512

/* Default number of buffers allocated by the driver in pool 2 */
#define DEF_3639_POOL_2          128
#define DEF_5639_POOL_2          128
#define DEF_3639_POOL_2_INIT     32
#define DEF_5639_POOL_2_INIT     32

/* Default buffer size in pool 2 */
#define DEF_3639_BUFFER_SIZE_2   2048
#define DEF_5639_BUFFER_SIZE_2   2048

/* Default number of buffers allocated by the driver in pool 3 */
#define DEF_3639_POOL_3          64
#define DEF_5639_POOL_3          64
#define DEF_3639_POOL_3_INIT     8
#define DEF_5639_POOL_3_INIT     8

/* Default buffer size in pool 3 */
#define DEF_3639_BUFFER_SIZE_3   (PAGE_SIZE - 2*sizeof(dword))
#define DEF_5639_BUFFER_SIZE_3   (PAGE_SIZE - 2*sizeof(dword))

/* Types of tracing modes (for CTL_START_TRACE) */
#define LINEAR                0
#define CIRCULAR              1

/* Types of trace function (used in a trace header) */
#define FN_TRACE_NO_PARAM     0
#define FN_TRACE_D1           1
#define FN_TRACE_D2           2
#define FN_TRACE_STRING       3
#define FN_TRACE_STRUCT       4
#define FN_TRACE_PACKET       5

/* Tag value in the trace buffer */
#define TRACE_TAG             "@#@#@#@IphWan Base Driver@#@#@#@"

/* Constant to build the buffer for CTL_GET_CARD_RSRC */
#define RSRC_DEVID            1
#define RSRC_DEVTYPE          2
#define RSRC_PORTYPE          3
#define RSRC_DEVNAME          4
#define RSRC_DRAMSIZE         5
#define RSRC_DEVREV           12
#define RSRC_PRIMARY_SUBID    14
#define RSRC_SECONDARY_SUBID  18

/* Card types */
/* PSPAN and MPC82XX board*/
#define CARD_4535             1
#define CARD_4534             2
#define CARD_6535             3
#define CARD_4532             4     /* v2.4 add support for 4532 */
#define CARD_4538             5     /* v2.4 add support for 4538 */
#define CARD_4539             6     /* v2.4 add support for 4539 */

/* PEX811X and MPC85XX board */ 
#define CARD_3639             20

/* Port types */
#define PORT_PRI              'P'
#define PORT_BRI              'B'
#define PORT_SERIAL           'S'
#define PORT_OC3              'O'   /* v2.4 add support for OC-3 port (4532) */

/***************************************************************************/
/* Structure used for CTL_INIT_PRIM_POOL and CTL_INIT_BUFFER_POOL          */
/***************************************************************************/
typedef struct AllocPool {
   /* Index of the pool to initialize (used only for CTL_INIT_BUFFER_POOL) */
   word Index;

   /* size of elements to allocate */
   word Size;

   /* initial number of elements to allocate */
   word Nb;

   /* maximum number of elements that the driver can allocate for this pool */
   word MaxNb;
} AllocPool_t;

/***************************************************************************/
/* Structure used for CTL_DUMP_DRV_POOL                                        */
/***************************************************************************/
/* Pool to contain primitive headers and data buffers */
typedef struct DrvPool
{
   /* queue of elements currently in use */
   void *UsedQueue[2];

   /* queue of elements not currently in use */
   void *FreeQueue[2];

   /* Pool number */
   dword PoolIndex;

   /* Size of the elements in the pool */
   dword PoolSize;

   /* Initial number of elements */
   dword InitCount;

   /* Maximum number of elements that can be allocated for this pool */
   dword MaxCount;

   /* Current number of elements that have been allocated for this pool */
   dword TotalCount;

   /* Number of elements currently in use */
   dword UsedCount;

   /* Number of elements not currently in use */
   dword FreeCount;

   /* Maximal number of elements that have been simultaneously in use */
   dword MaxUsedCount;
} DrvPool_t;
typedef DrvPool_t *DrvPoolPtr;

/***************************************************************************/
/* Structure used for CTL_INIT_DRV_TRACE                                   */
/***************************************************************************/
typedef struct InitTrace {
   dword Method;              /* LINEAR or CIRCULAR */
   dword Size;                /* size of memory allocated to traces */
} InitTrace_t;

/***************************************************************************/
/* Structure of a trace header                                             */
/***************************************************************************/
typedef struct  TrcMsg
{
   /* Offset of the next trace */
   dword NextPtr;

   /* Identifies the module generating the trace */
   byte ModuleId;

   /* Identifies the trace type EVT/ERR/TRC */
   byte TraceType;

   /* this is the index of the trace format for the module identified */
   /* by ModuleId (index in its template array) */
   word TraceId;

#ifdef LINUX
   struct timeval TimeStamp;
#else
   /* Time at which the trace is made in terms of seconds */
   dword   TimeStamp;
   /* Time at which the trace is made in terms of microseconds*/
   dword UTimeStamp;
#endif
   
   /* Type of the function which generated the trace (one FN_ value) */
   byte FnType;

   /* Length of the following data */
   word Len;

} TrcMsg_t;

/***************************************************************************/
/* Structure of the trace buffer header                                    */
/***************************************************************************/
typedef struct TraceBuffHead
{
   byte Tag[32];
   dword Size;                /* size of the total buffer */
   dword Method;              /* trace mode (LINEAR or CICULAR) */
   dword FirstTrace;          /* offset of the first trace */
   dword LastTrace;           /* offset of the last trace */
} TraceBuffHead_t;

#endif


