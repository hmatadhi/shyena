/****************************************************************************
 * NAME : mgr.h
 * VERSION : 1.3
 * DESCRIPTION :
 *    Constants, types, structures, macros for using the WanOS Link Manager
 * REVISIONS :
 *    - Version 1.0 01/27/97 : Creation
 *    - Version 1.1 04/13/99 : Add constants needed to submit/accept/reject
 *      incoming calls to/by a client
 *    - Version 1.2 07/30/99 : Add following definitions
 *                             MGR_ERR_INVALID_ADAPTER
 *                             MGR_ERR_ADAPTER_INACT
 *                             MGR_DISC_IDENT_REJECT
 *    - Version 1.3 04/24/03 : Reviewed after coherency checkings with the
 *                             iWareAPI document
 ****************************************************************************/

#ifndef MGR_H
#define MGR_H

/***************************************************************************/
/* MGR primitives                                                          */
/***************************************************************************/

/* Type of MGR primitives */

#define  MGR_PRIM                   0x7F00


/* Sub-types of MGR primitives sent by the clients to the Link Manager */

#define  MGR_CLOSE_USER             0x00     /* close a session */
#define  MGR_OPEN_USER              0x01     /* open a session */

#define  MGR_CLOSE_STACK            0x02     /* unselect a profile stack */
#define  MGR_OPEN_STACK             0x03     /* select a profile stack */
#define  MGR_UNLINK_STACK           0x04     /* deactivate a profile stack */
#define  MGR_LINK_STACK             0x05     /* activate a profile stack */

#define  MGR_IDENT_ACCEPT           0x07     /* incoming call accepted */
#define  MGR_IDENT_REJECT           0x08     /* incoming call rejected */

#define  MGR_ADD_PROFILE            0x09     /* define a profile */
#define  MGR_ADD_PROFILE_STACK      0x0A     /* define a profile stack */
#define  MGR_DELETE_NAME            0x0B     /* delete a profile or stack */
#define  MGR_QUERY_NAME_LIST        0x0C     /* query the profile name list*/
#define  MGR_QUERY_NAME             0x0D     /* query a profile definition */

#define  MGR_DIRECT_INFO_REQ        0x18     /* directed message request */

/* Sub-types of MGR primitives sent by the Link Manager to the clients */

#define  MGR_USER_CLOSED            0x00     /* session closed */
#define  MGR_USER_OPENED            0x01     /* session opened */

#define  MGR_STACK_CLOSED           0x02     /* profile stack unselected */
#define  MGR_STACK_OPENED           0x03     /* profile stack selected */
#define  MGR_STACK_UNLINKED         0x04     /* profile stack deactivated */
#define  MGR_STACK_LINKED           0x05     /* stack activation pending */
#define  MGR_STACK_ACTIVE           0x06     /* profile stack active */

#define  MGR_STACK_TRAFFIC_OFF      0x07     /* traffic non established */
#define  MGR_STACK_TRAFFIC_ON       0x08     /* traffic established */

#define  MGR_SUBMIT_IDENT           0x09     /* incoming call identification*/
#define  MGR_IDENT_CANCELED         0x11     /* identification cancelation */

#define  MGR_PROFILE_ADDED          0x0A     /* profile defined */
#define  MGR_PROFILE_STACK_ADDED    0x0B     /* profile stack defined */
#define  MGR_NAME_DELETED           0x0C     /* profile or stack deleted */
#define  MGR_NAME_LIST              0x0D     /* list of profiles and stacks*/
#define  MGR_PROFILE_NAME           0x0E     /* definition of a profile */
#define  MGR_PROFILE_STACK_NAME     0x0F     /* definition of a stack */

#define  MGR_USER_ERR               0x10     /* error primitive */

#define  MGR_DIRECT_INFO_IND        0x18     /* directed message indication */

/* List of error diagnostics returned in a MGR_USER_ERR primitive */

#define  MGR_ERR_UNKNOWN_PRIMID     0x0000   /* unknown primitive */
#define  MGR_ERR_INVALID_SESSION    0x0001   /* invalid session reference */

#define  MGR_ERR_USER_CLOSED        0x0002   /* session closed */
#define  MGR_ERR_USER_OPENED        0x0003   /* session already opened */

#define  MGR_ERR_STACK_CLOSED       0x0004   /* stack not selected */
#define  MGR_ERR_STACK_OPENED       0x0005   /* stack already selected */
#define  MGR_ERR_STACK_UNLINKED     0x0006   /* stack not activated */
#define  MGR_ERR_STACK_LINKED       0x0007   /* stack already activated */
#define  MGR_ERR_STACK_INACT        0x0008   /* stack not active */

#define  MGR_ERR_MEM_ALLOC          0x000A   /* memory allocation error */
#define  MGR_ERR_NO_BUFFER          0x000B   /* buffer missing */
#define  MGR_ERR_BUFFER_LENGTH      0x000C   /* incorrect buffer length */
#define  MGR_ERR_INVALID_NAME       0x000D   /* invalid character in name */
#define  MGR_ERR_UNKNOWN_NAME       0x000E   /* name unknown in the agenda */
#define  MGR_ERR_DUPLICATE_NAME     0x000F   /* name already defined */
#define  MGR_ERR_INVALID_MODULE     0x0010   /* invalid module reference */
#define  MGR_ERR_INVALID_PARAMETER  0x0011   /* invalid profile parameter */
#define  MGR_ERR_SYNTAX             0x0012   /* syntax error in stack */
#define  MGR_ERR_COMPATIBILITY      0x0013   /* incompatible modules */

#define  MGR_ERR_INVALID_ADAPTER    0x0015   /* invalid adapter reference */
#define  MGR_ERR_ADAPTER_INACT      0x0016   /* the adapter is not running */

/* List of diagnostics returned in disconnection or reset primitives */

#define  MGR_DISC_STACK_UNLINKED    0x0000   /* deactivation by the client */
#define  MGR_DISC_NO_LINK           0x0001   /* activation failure */
#define  MGR_DISC_NO_SESSION        0x0002   /* session allocation failure */
#define  MGR_DISC_PROFILE_DENIED    0x0003   /* profile rejected */
#define  MGR_DISC_IDENT_REJECT      0x0004   /* identification denied */
#define  MGR_DISC_SESSION_RESETTING 0x0005   /* reset of one layer */
#define  MGR_DISC_SESSION_CLOSED    0x0006   /* close of one layer */
#define  MGR_DISC_ADAPTER_INACT     0x0007   /* adapter has disactivated */
#define  MGR_DISC_NO_MEMORY         0x0008   /* memory shortage in driver */


/***************************************************************************/
/* Standard data primitives                                                */
/***************************************************************************/

/* Type of standard data primitives */

#define  DATA_PRIM                  0x0000

/* Sub-types of data primitives sent by the clients to the Link Manager */

#define  DATA_REQ                   0x00     /* transmission request */
#define  DATA_ACK                   0x05     /* reception acknowledgment */
#define  RNR_REQ                    0x06     /* reception flow blocking */
#define  RR_REQ                     0x07     /* reception flow unblocking */

/* Sub-types of data primitives sent by the Link Manager to the clients */

#define  DATA_IND                   0x04     /* reception indication */
#define  DATA_CONF                  0x01     /* transmission acknowledgment*/
#define  RNR_IND                    0x02     /* transmission flow blocking */
#define  RR_IND                     0x03     /* transmission flow unblocking*/

/***************************************************************************/
/* Connection modes (stack activation request and profile)                 */
/***************************************************************************/

#define  INCOMING                   0x0001   /* incoming connection */
#define  OUTGOING                   0x0002   /* outgoing connection */
#define  BOTHWAYS                   0x0003   /* both directions connection */
#define  ANYWAY                     0x0007   /* permanent connection */

#define  DIRECT_INFO                0x0100   /* connection may use */
                                             /* directed messages */

#define  IDENTIFICATION             0x0100   /* connection filtering by client */
#define  EXCLUSIVE                  0x0200   /* exclusive filtering */
#define  IDENT_CANCEL_SIGNAL        0x0400   /* filtering cancel indication */

/***************************************************************************/
/* Constants for agenda management                                         */
/***************************************************************************/

#define  MAX_NAME_SIZE              16       /* maximum name size */

/***************************************************************************/
/* Profile header definition                                               */
/***************************************************************************/

#define  MAX_PRF_RESERVED1          6
#define  MAX_PRF_RESERVED2          10

#pragma pack(1)

typedef  struct Profile
{
   byte Name[MAX_NAME_SIZE];                 /* profile name */
   byte Reserved1[MAX_PRF_RESERVED1];        /* first reserved field */
   word ModuleRef;                           /* protocol module reference */
   word Mode;                                /* connection mode */
   byte Reserved2[MAX_PRF_RESERVED2];        /* second reserved field */
} Profile_t;
typedef  Profile_t *ProfilePtr;

#pragma pack()

/***************************************************************************/
/* Macros used to access profile header fields                             */
/***************************************************************************/

/* macro to access the profile name */
#define  ProfileName(PrfPtr)                       \
   (((ProfilePtr)(PrfPtr))->Name)

/* macro to store the protocol module reference */
#define  StoreProfileModuleRef(PrfPtr, Value)      \
   (((ProfilePtr)(PrfPtr))->ModuleRef = NET_SWAP16(Value))

/* macro to get the protocol module reference */
#define  LoadProfileModuleRef(PrfPtr)              \
   (NET_SWAP16(((ProfilePtr)(PrfPtr))->ModuleRef))

/* macro to store the connection mode */
#define  StoreProfileMode(PrfPtr, Value)           \
   (((ProfilePtr)(PrfPtr))->Mode = NET_SWAP16(Value))

/* macro to get the connection mode */
#define  LoadProfileMode(PrfPtr)                   \
   (NET_SWAP16(((ProfilePtr)(PrfPtr))->Mode))

/***************************************************************************/
/* Macros used to access connection mode (MGR_LINK_STACK message)          */
/***************************************************************************/

/* macro to store the connection mode */
#define  StoreConnectionMode(DataPtr, Value)       \
   (*((word *)(DataPtr)) = NET_SWAP16(Value))

/* macro to get the connection mode */
#define  LoadConnectionMode(DataPtr)               \
   (NET_SWAP16(*((word *)(DataPtr))))

/***************************************************************************/
/* Layer reference (used for misc messages including layer and session ref)*/
/***************************************************************************/

#pragma pack(1)

typedef  struct LayerRef
{
   word ModuleRef;                           /* module reference */
   word SessionRef;                          /* session reference */
} LayerRef_t;
typedef  LayerRef_t *LayerRefPtr;

#pragma pack()

/***************************************************************************/
/* Macros used to access layer reference fields                            */
/***************************************************************************/

/* macro to store the protocol module reference */
#define  StoreLayerRefModuleRef(LRefPtr, Value)    \
   (((LayerRefPtr)(LRefPtr))->ModuleRef = NET_SWAP16(Value))

/* macro to get the protocol module reference */
#define  LoadLayerRefModuleRef(LRefPtr)            \
   (NET_SWAP16(((LayerRefPtr)(LRefPtr))->ModuleRef))

/* macro to store the protocol module reference */
#define  StoreLayerRefSessionRef(LRefPtr, Value)   \
   (((LayerRefPtr)(LRefPtr))->SessionRef = NET_SWAP16(Value))

/* macro to get the session reference */
#define  LoadLayerRefSessionRef(LRefPtr)           \
   (NET_SWAP16(((LayerRefPtr)(LRefPtr))->SessionRef))

/***************************************************************************/
/* Info field for MGR_USER_CLOSED/MGR_STACK_UNLINKED/MGR_STACK_TRAFFIC_OFF */
/***************************************************************************/

#pragma pack(1)

typedef  struct UserDisc
{
   word ModuleRef;                           /* module reference */
   word SessionRef;                          /* session reference */
   word Cause;                               /* cause of the disc/reset */
   word Diag;                                /* additionnal diagnostic */
} UserDisc_t;
typedef  UserDisc_t *UserDiscPtr;

#pragma pack()

/***************************************************************************/
/* Macros used to access disconnection/reset messages fields               */
/***************************************************************************/

/* macro to get the module reference */
#define  LoadDiscModuleRef(UDiscPtr)               \
   (NET_SWAP16(((UserDiscPtr)(UDiscPtr))->ModuleRef))

/* macro to get the session reference */
#define  LoadDiscSessionRef(UDiscPtr)              \
   (NET_SWAP16(((UserDiscPtr)(UDiscPtr))->SessionRef))

/* macro to get the cause */
#define  LoadDiscCause(UDiscPtr)                   \
   (NET_SWAP16(((UserDiscPtr)(UDiscPtr))->Cause))

/* macro to get the additionnal diagnostic */
#define  LoadDiscDiag(UDiscPtr)                    \
   (NET_SWAP16(((UserDiscPtr)(UDiscPtr))->Diag))

/***************************************************************************/
/* Content of the Info field for a MGR_USER_ERR message                    */
/***************************************************************************/

#pragma pack(1)

typedef  struct UserErr
{
   word Id;                                  /* Id of the guilty primitive */
   word Cause;                               /* cause of the error */
   word Diag;                                /* additionnal diagnostic */
} UserErr_t;
typedef  UserErr_t *UserErrPtr;

#pragma pack()

/***************************************************************************/
/* Macros used to access error fields                                      */
/***************************************************************************/

/* macro to get the primitive Id */
#define  LoadErrModuleRef(UErrPtr)                 \
   (NET_SWAP16(((UserErrPtr)(UErrPtr))->Id))

/* macro to get the cause */
#define  LoadErrCause(UErrPtr)                     \
   (NET_SWAP16(((UserErrPtr)(UErrPtr))->Cause))

/* macro to get the additionnal diagnostic */
#define  LoadErrDiag(UErrPtr)                      \
   (NET_SWAP16(((UserErrPtr)(UErrPtr))->Diag))

#endif

