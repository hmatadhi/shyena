/****************************************************************************
 * NAME : ppcapi.h
 * VERSION : 3.7
 * DESCRIPTION : 
 *    Constants, types for using the API on the 5535 card
 * REVISIONS :
 *    - Version 1.0 01/27/97 : Creation
 *    - Version 2.0 11/23/98 : Update for DMA master interface
 *    - Version 3.0 06/20/00 : Update for version 3 interface (support of 653x)
 *    - Version 3.1 01/08/01 : Add configuration status when loaded from flash
 *    - Version 3.1 01/16/01 : Define new fields in V3 interface for config
 *                             status
 *    - Version 3.2 03/22/01 : Define new fields in V2 interface for config
 *                             status
 *    - Version 3.3 01/17/06 : Update for version 5 of PCI interface 
 *                             (PQ3-based controllers)
 *    - Version 3.4 02/13/06 : Add SHUTDOWN_PRIM
 *    - Version 3.5 12/19/06 : Change the ExchangeArea_t structure. The Padding0
 *                             field is renameed to WorkingAreaPtr, which is now
 *                             reserved for the Working Area address stocking.
 *    - Version 3.6 01/12/09 : Add the Card time and Host time offset field in
 *                             the V5 interface definition
 *    - Version 3.7 01/19/09 : Add the ddword (unsigned 64-bit) type
 ****************************************************************************/

#ifndef PPCAPI_H
#define PPCAPI_H

/***************************************************************************/
/* Constants                                                               */
/***************************************************************************/

/* maximum number of embedded functions */
#define REF_NUMBER                     16UL

/* maximum number of pools */
#define POOL_NUMBER                    8UL

/* number of bytes in the immediate data for a primitive */
#define MAX_PRIM_INFO                  8

/* maximum number of transfer descriptors (version 2) */
#define TRANSFER_NUMBER                64UL

/* number of DMA descriptors per transfer descriptor */
#define DMADESC_NUMBER                 31UL

/* maximum number of transfer descriptors (version 3) */
#define V3_TRANSFER_NUMBER             512UL

/* maximum number of DMA descriptors (version 3) */
#define V3_DMADESC_NUMBER              512UL

/* maximum number of inbound transfer descriptors (version 5) */
#define V5_INB_CTRL_MAX                512UL

/* maximum number of inbound data descriptors (version 5) */
#define V5_INB_DATA_MAX                512UL

/* maximum number of outbound transfer descriptors (version 5) */
#define V5_OUTB_CTRL_MAX               512UL

/* maximum number of outbound data descriptors (version 5) */
#define V5_OUTB_DATA_MAX               4096UL

/* maximum number of outbound host pools (version 5) */
#define V5_OUTB_POOL_MAX               4

/* Card's parameter area definition */
#define START_CODE_PTR_INDX            0x0000UL
#define EXCH_AREA_ADDR_INDX            0x0004UL

#define EXCH_AREA_INDX                 0x2100UL

/* Offset from the beginning of the Exchange Area */
#define INTF_SIGN_INDX                 0x0000UL
#define INTF_VER_INDX                  0x0004UL
#define CODE_READY_INDX                0x0008UL
#define TRACE_BUFFER_PTR_INDX          0x000CUL
#define TRACE_BUFFER_SIZE_INDX         0x0010UL
#define TRACE_BUFFER_START_INDX        0x0014UL
#define TRACE_BUFFER_END_INDX          0x0018UL
#define HEAP_START_PTR_INDX            0x001CUL
#define HEAP_END_PTR_INDX              0x0020UL
#define PADDING0_INDX                  0x0024UL
#define SYSBUFF_CHECK_LEVEL_INDX       0x0028UL
#define NB_SYSBUFF_POOL_INDX           0x002CUL
#define SYSBUFF_POOL_INDX              0x0030UL
#define PADDING1_INDX                  0x0230UL
#define CFG_STATUS_INDX                0x0234UL
#define CFG_ERRCODE_INDX               0x0238UL
#define NB_FUNCTION_INDX               0x023CUL
#define REF_FUNCTION_INDX              0x0240UL
#define P2L_TRANSFER_TAB_INDX          0x0280UL
#define L2P_TRANSFER_TAB_INDX          0x8280UL

/* value of the CodeReady variable when the card has successfully booted */
#define  CODE_RDY                      0x52445921  /* RDY! */

/* value of the InterfaceSignature variable */
#define  INTF_SIGNATURE                0x494E5048  /* INPH */

/* current interface major version number */
#define  MAJOR_VER                     0x0002

/* current interface minor version number */
#define  MINOR_VER                     0x0000

/* V3 interface major version number */
#define  V3_MAJOR_VER                  0x0003

/* V3 interface minor version number */
#define  V3_MINOR_VER                  0x0001

/* V5 interface major version number */
#define  V5_MAJOR_VER                  0x0005

/* V5 interface minor version number */
#define  V5_MINOR_VER                  0x0000

/* Values for the Status field in the Transfer_t structure */
#define TRANSFER_IDLE         0
#define TRANSFER_PENDING      1
#define TRANSFER_DMA          2
#define TRANSFER_DONE         3

/* New Value for the Status field in the Transfer_t structure (version 3&5) */
#define TRANSFER_READY        0x80

/* Primitives sent to the card-to-PC interface module on the card */
#define OPEN_PRIM             0x4001         /* initialize the dialog */
#define CLOSE_PRIM            0x4002         /* end the dialog */

/* Primitives recived from the card-to-PC interface module on the card */
#define SHUTDOWN_PRIM         0x4004         /* end the dialog */

/* v3.1 status of the embedded configuration when flashed in EEPROM */
#define CFG_OK                0x21434647     /* !CFG */
#define CFG_LOADING           0x214C4447     /* !LDG */
#define CFG_ERROR             0x21455252     /* !ERR */

/***************************************************************************/
/* Structures                                                              */
/***************************************************************************/

#ifndef BYTE_WORD_DWORD
#define BYTE_WORD_DWORD
typedef  unsigned char  byte;
typedef  unsigned short word;
typedef  uint32_t  dword;
typedef  uint64_t  ddword;
#endif


/* Adapter Pool */
typedef struct AdapterPool
{
   dword UsedQueue[2];              /* used element queue */
   dword FreeQueue[2];              /* free element queue */
   dword PoolSize;                  /* size of each element */
   dword TotalCount;                /* total number of elements */
   dword UsedCount;                 /* number of used elements */
   dword FreeCount;                 /* number of free elements */
   dword ClaimedCount;              /* number of claimed elements */
   dword UnclaimedCount;            /* number of unclaimed elements */
   dword MaxUsedCount;              /* maximal number of used elements*/
   dword MaxClaimedCount;           /* maximal number of claimed elements */
   dword ErrorGetCount;             /* number of failing allocation */
   dword DirtyGetCount;             /* number of allocation for unclaimed */
   dword ErrorClaimCount;           /* number of failing claim operation */
   dword Padding;                   /* padding for structure alignment */
} AdapterPool_t;
typedef AdapterPool_t *AdapterPoolPtr;

/* Queue elements */
typedef  struct QueueItem
{
   struct QueueItem *NextPtr;       /* pointer to next element */
   struct QueueItem *PrevPtr;       /* pointer to previous element */
} QueueItem_t;
typedef  QueueItem_t *QueueItemPtr;


/* Queue */
typedef  struct Queue
{
   QueueItemPtr   FirstPtr;         /* pointer to 1st element */
   QueueItemPtr   LastPtr;          /* pointer to last element */
} Queue_t;
typedef  Queue_t *QueuePtr;


/* Adapter Buffer */
typedef  struct AdapterBuffer
{
   dword QueueItem[2];              /* pointers on previous and next buffer */
   dword PoolNum;                   /* index number of the original pool */
   dword Status;                    /* 'FREE' or 'USED' status of the buffer*/
   dword Tag[4];                    /* reserved */
   byte  Data[1];                   /* beginning of data */
} AdapterBuffer_t;
typedef AdapterBuffer_t *AdapterBufferPtr;

/* DMA block transfer descriptor */
typedef  struct DMADesc
{
   dword PCIAddress;                /* physical address in PCI memory */
   dword LocalAddress;              /* physical address in local memory */
   dword TransferSize;              /* amount of data to transfer */
   dword NextDMADesc;               /* next descriptor characteristics */
} DMADesc_t;
typedef DMADesc_t *DMADescPtr;

/* Transfer descriptor */
typedef  struct Transfer
{
   byte      Status;                /* transfer status */
   byte      Reserved;              /* reserved */
   word      RefIndx;               /* target function index in RefFunction */
   word      PrimitiveId;           /* primitive identificator */
   word      PrimitiveRef;          /* primitive reference */
   byte      PrimitiveInfo[MAX_PRIM_INFO];  /* primitive immediate data */
   DMADesc_t DMADesc[DMADESC_NUMBER];  /* DMA block transfer descriptors */
} Transfer_t;
typedef  Transfer_t *TransferPtr;

/* Exchange Area in the local memory */
typedef  struct ExchangeArea
{
   dword IntfSign;                  /* Interface signature */
   dword IntfVer;                   /* Interface version */
   dword CodeReady;                 /* activity status */
   dword TraceBufferPtr;            /* offset of the trace buffer */
   dword TraceBufferSize;           /* size of the trace buffer */
   dword TraceBufferStart;          /* offset of the first trace */
   dword TraceBufferEnd;            /* offset of the last trace */
   dword HeapStartPtr;              /* offset of the beginning of the heap */
   dword HeapEndPtr;                /* offset of the end of the heap */
   dword WorkingAreaPtr;            /* offset of the local Working area */
   dword SysBuffCheckLevel;         /* check level for the buffers */
   dword NbSysBuffPool;             /* number of buffer pools */
   AdapterPool_t SysBuffPool[POOL_NUMBER];
   dword Padding1[1];
   dword ConfigStatus;              /* configuration status (v3.2) */
   dword ConfigErrCode;             /* error code of autoconfiguration (v3.2) */
   dword NbFunction;                /* number of embedded functions */
   dword RefFunction[REF_NUMBER];
   Transfer_t P2LTransferTab[TRANSFER_NUMBER];
   Transfer_t L2PTransferTab[TRANSFER_NUMBER];
} ExchangeArea_t;
typedef ExchangeArea_t *ExchangeAreaPtr;

/* DMA block transfer descriptor (version 3) */
typedef  struct V3_DMADesc
{
   dword Reserved0;
   dword SrcAddress;                /* physical source address */
   dword Reserved1;
   dword DestAddress;               /* physical destination address */
   dword Reserved2;
   dword Tcr;                       /* transfer control register */
   dword Reserved3;
   dword Cpp;                       /* command packet pointer */
} V3_DMADesc_t;
typedef V3_DMADesc_t *V3_DMADescPtr;

/* Transfer descriptor (version 3) */
typedef  struct V3_Transfer
{
   byte      Status;                /* transfer status */
   byte      DMACount;              /* number of DMA descriptor */
   word      RefIndx;               /* target function index in RefFunction */
   word      PrimitiveId;           /* primitive identificator */
   word      PrimitiveRef;          /* primitive reference */
   byte      PrimitiveInfo[MAX_PRIM_INFO];  /* primitive immediate data */
} V3_Transfer_t;
typedef  V3_Transfer_t *V3_TransferPtr;

/* Exchange Area in the local memory (version 3) */
typedef  struct V3_ExchangeArea
{
   dword IntfSign;                  /* Interface signature */
   dword IntfVer;                   /* Interface version */
   dword CodeReady;                 /* activity status */
   dword TraceBufferPtr;            /* offset of the trace buffer */
   dword TraceBufferSize;           /* size of the trace buffer */
   dword TraceBufferStart;          /* offset of the first trace */
   dword TraceBufferEnd;            /* offset of the last trace */
   dword HeapStartPtr;              /* offset of the beginning of the heap */
   dword HeapEndPtr;                /* offset of the end of the heap */
   dword Padding0[1];
   dword SysBuffCheckLevel;         /* check level for the buffers */
   dword NbSysBuffPool;             /* number of buffer pools */
   AdapterPool_t SysBuffPool[POOL_NUMBER];
   dword Padding1[1];
   dword ConfigStatus;              /* configuration status (v3.1) */
   dword ConfigErrCode;             /* error code of autoconfiguration (v3.1) */
   dword NbFunction;                /* number of embedded functions */
   dword RefFunction[REF_NUMBER];
   V3_Transfer_t P2LTransferTab[V3_TRANSFER_NUMBER];
   V3_DMADesc_t P2LDMATab[V3_DMADESC_NUMBER];
   V3_Transfer_t L2PTransferTab[V3_TRANSFER_NUMBER];
   V3_DMADesc_t L2PDMATab[V3_DMADESC_NUMBER];
} V3_ExchangeArea_t;
typedef V3_ExchangeArea_t *V3_ExchangeAreaPtr;

/* Transfer control descriptor (version 5) */
typedef struct V5_TransferCtrl
{
   word PrimitiveId;                /* primitive identificator */
   word PrimitiveRef;               /* primitive reference */
   byte PrimitiveInfo[MAX_PRIM_INFO];  /* primitive immediate data */
   word RefIndx;                    /* target function index in RefFunction */
   byte DataCount;                  /* number of Data descriptors */
   byte Status;                     /* transfer status */
} V5_TransferCtrl_t;
typedef V5_TransferCtrl_t *V5_TransferCtrlPtr;

/* Transfer status descriptor (version 5) */
typedef struct V5_TransferStatus
{
   byte Status;                     /* transfer status */
} V5_TransferStatus_t;
typedef V5_TransferStatus_t *V5_TransferStatusPtr;

/* Data address structure (version 5) */
typedef struct V5_DataAddr
{
   dword BufferOffset;              /* buffer offset */
} V5_DataAddr_t;
typedef V5_DataAddr_t *V5_DataAddrPtr;

/* Inbound send entry (version 5) */
typedef struct V5_InboundSend
{
   word ByteCount;                  /* byte count */
} V5_InboundSend_t;
typedef V5_InboundSend_t *V5_InboundSendPtr;

/* Outbound send entry (version 5) */
typedef struct V5_OutboundSend
{
   word DataIndex;                  /* outbound data descriptor index */
   word ByteCount;                  /* byte count */
} V5_OutboundSend_t;
typedef V5_OutboundSend_t *V5_OutboundSendPtr;

/* Outbound pool entry (version 5) */
typedef struct V5_OutboundPool
{
   word DataIndex;                  /* outbound data descriptor index */
} V5_OutboundPool_t;
typedef V5_OutboundPool_t *V5_OutboundPoolPtr;

/* Interface statistics (version 5) */
typedef struct V5_IntfStat
{
   dword InbPrims;                  /* number of inb primitives      */
   dword InbChains;                 /* number of inb buffer chains   */
   dword InbBufs;                   /* number of inb buffers         */
   dword InbBytes;                  /* number of inb bytes           */
   dword InbMaxDMAChains;           /* max number of inb DMA chains  */
   dword InbMaxDMABufs;             /* max number of inb DMA buffers */
   dword InbBusy;                   /* number of inb busy conditions */
   dword InbDMAErrors;              /* number of inb DMA errors      */
                                          
   dword OutbPrims;                 /* number of outb primitives     */
   dword OutbChains;                /* number of outb buffer chains  */
   dword OutbBufs;                  /* number of outb buffers        */
   dword OutbBytes;                 /* number of outb bytes          */
   dword OutbMaxDMAChains;          /* max number of outb DMA chains */
   dword OutbMaxDMABufs;            /* max number of outb DMA buffers*/
   dword OutbBusy;                  /* number of outb busy conditions*/
   dword OutbDMAErrors;             /* number of outb DMA errors     */

   dword SignalTimeouts;            /* signalization timeouts        */

} V5_IntfStat_t;
typedef V5_IntfStat_t *V5_IntfStatPtr;

/* Card control area in the local memory (version 5) */
typedef struct V5_CardCtrlArea
{
   /* Interface signature */
   dword IntfSign;

   /* Interface version */
   dword IntfVer;

   /* activity status */
   dword CodeReady;

   /* offset of the trace buffer */
   dword TraceBufferPtr;

   /* size of the trace buffer */
   dword TraceBufferSize;

   /* offset of the first trace */
   dword TraceBufferStart;

   /* offset of the last trace */
   dword TraceBufferEnd;

   /* offset of the beginning of the heap */
   dword HeapStartPtr;

   /* offset of the end of the heap */
   dword HeapEndPtr;

   /* reserved */
   dword Padding0[1];

   /* check level for the buffers */
   dword SysBuffCheckLevel;

   /* number of buffer pools */
   dword NbSysBuffPool;

   /* buffer pools */
   AdapterPool_t SysBuffPool[POOL_NUMBER];

   /* reserved */
   dword Padding1[1];

   /* configuration status */
   dword ConfigStatus;

   /* error code of autoconfiguration */
   dword ConfigErrCode;

   /* number of embedded functions */
   dword NbFunction;

   /* embedded functions */
   dword RefFunction[REF_NUMBER];

   /* primitive special pool */
   AdapterPool_t PrimBuffPool;

   /* buffer descriptor pool */
   AdapterPool_t DescrBuffPool;

   /* maximum number of inbound control descriptors */
   dword InbCtrlMax;

   /* number of inbound control descriptors used by the host */
   dword InbCtrlNumber;

   /* offset of the inbound control queue */
   /* (this queue is a table of InbCtrlMax transfer control descriptors) */
   dword InbCtrlOffset;

   /* offset of the inbound status queue */
   /* (this queue is a table of InbCtrlMax transfer status descriptors) */
   dword InbStatusOffset;

   /* maximum number of inbound data descriptors */
   dword InbDataMax;

   /* number of inbound data descriptors used by the host */
   dword InbDataNumber;

   /* offset of the inbound buffer address table */
   /* (in this table, the host gives the offset of its inbound buffers) */
   dword InbAddrOffset;

   /* offset of the inbound send queue */
   /* (in this table, the host gives the size of data to transfer */
   /*  for each buffer) */
   dword InbSendOffset;

   /* reserved */
   dword InbSpare[8];

   /* maximum number of outbound control descriptors */
   dword OutbCtrlMax;

   /* number of outbound control descriptors used by the host */
   dword OutbCtrlNumber;

   /* offset of the outbound control queue (in the host control area) */
   dword OutbCtrlOffset;

   /* offset of the outbound status queue */
   /* (in this table, the host notifies an end of use of outbound transfer */
   /*  control descriptors) */
   dword OutbStatusOffset;

   /* maximum number of outbound data descriptors */
   dword OutbDataMax;

   /* number of outbound data descriptors used by the host */
   dword OutbDataNumber;

   /* offset of the outbound buffer address table */
   /* (in this table, the host gives the offset of its outbound buffers) */
   dword OutbAddrOffset;

   /* offset of the outbound send queue (in the host control area) */
   dword OutbSendOffset;

   /* size of buffers in the outbound pools */
   dword OutbPoolSize[V5_OUTB_POOL_MAX];

   /* offsets of the outbound pools */
   /* (each pool includes V5_OUTB_DATA_MAX entries, */
   /*  an entry is a V5_OutboundPool_t) */
   dword OutbPoolOffset[V5_OUTB_POOL_MAX]; 

   /* reserved */
   dword OutbSpare[16];

   /* host to card signal counter */
   /* (the host updates this counter, the card duplicates this value */
   /*  in the host control area) */
   dword HostToCardSigCount;

   /* card to host echo counter */
   /* (the card updates the CardToHostSigCount counter in the host control */
   /*  area, the host duplicates this value in this counter) */
   dword CardToHostEchoCount;

   /* host control area offset */
   dword HostAreaOffset;

   /* interface statistics offset */
   dword IntfStatOffset;

   byte CardTime[8];
   byte HostTimeOffset[8];

   /* reserved */
   dword V5Spare[8]; 

   /* start of inbound and outbound descriptors */
   byte InbOutbTables[1];

} V5_CardCtrlArea_t;
typedef V5_CardCtrlArea_t *V5_CardCtrlAreaPtr;

/* Host control area (version 5) */
typedef struct V5_HostCtrlArea
{
   /* card to host signal counter */
   /* (the card updates this counter, the host duplicates this value */
   /*  in the card control area) */
   dword CardToHostSigCount;

   /* host to card echo counter */
   /* (the host updates the HostToCardSigCount counter in the card control */
   /*  area, the card duplicates this value in this counter) */
   dword HostToCardEchoCount;

   /* reserved */
   dword V5Spare[2];

   /* start of inbound and outbound descriptors */
   byte InbOutbTables[1];

} V5_HostCtrlArea_t;
typedef V5_HostCtrlArea_t *V5_HostCtrlAreaPtr;
#endif

