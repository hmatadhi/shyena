/****************************************************************************
 * NAME : iphmain.h
 * VERSION : 1.2
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the iphmain module of the base driver
 * REVISIONS :
 *    - Version 1.0 12/15/05 : Creation
 *    - Version 1.1 06/26/06 : Change global prefix into iphwae
 *    - Version 1.2 07/13/06 : gdwResetBoard becomes public
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHMAIN_H
#define IPHMAIN_H

#ifdef IPHMAIN_C
static dword drv_gdwResetBoard(IphWanDevPtr pDev);
static dword drv_kernel_open(dword serial, void (*wakeup_ptr)(void *, word),
                             void (*free_ptr)(void *, word, byte, void *),
                             void *backref_ptr, word *app_id_ptr);
static dword drv_kernel_close(word app_id);
static dword drv_kernel_ioctl(word app_id, dword cmd_type, void *arg);

#define ExportGlobalMain(PRFX)\
IphWanDevPtr iph##PRFX##_gMinorMap[MAX_CARD];\
byte iph##PRFX##_gbAttachedCard;\
dword iph##PRFX##_gdwResetBoard(IphWanDevPtr pDev)\
{\
   return(drv_gdwResetBoard(pDev));\
}\
dword iph##PRFX##_kernel_open(dword serial, void (*wakeup_ptr)(void *, word),\
                              void (*free_ptr)(void *, word, byte, void *),\
                              void *backref_ptr, word *app_id_ptr)\
{\
   return(drv_kernel_open(serial, wakeup_ptr, free_ptr,\
                          backref_ptr, app_id_ptr));\
}\
dword iph##PRFX##_kernel_close(word app_id)\
{\
   return(drv_kernel_close(app_id));\
}\
dword iph##PRFX##_kernel_ioctl(word app_id, dword cmd_type, void *arg)\
{\
   return(drv_kernel_ioctl(app_id, cmd_type, arg));\
}

ExportGlobalMain(wae)

#ifdef LINUX_2_6
EXPORT_SYMBOL(iphwae_kernel_open);
EXPORT_SYMBOL(iphwae_kernel_close);
EXPORT_SYMBOL(iphwae_kernel_ioctl);
#endif

#else /* IPHTRACE_C */

#define ExportExtMain(PRFX) \
extern IphWanDevPtr iph##PRFX##_gMinorMap[MAX_CARD];\
extern byte iph##PRFX##_gbAttachedCard;\
dword iph##PRFX##_gdwResetBoard(IphWanDevPtr pDev);\
dword iph##PRFX##_kernel_open(dword serial, void (*wakeup_ptr)(void *, word),\
                              void (*free_ptr)(void *, word, byte, void *),\
                              void *backref_ptr, word *app_id_ptr);\
dword iph##PRFX##_kernel_close(word app_id);\
dword iph##PRFX##_kernel_ioctl(word app_id, dword cmd_type, void *arg);

ExportExtMain(wae)

#endif

#define iph_gbAttachedCard iphwae_gbAttachedCard
#define iph_gMinorMap iphwae_gMinorMap
#define iph_gdwResetBoard iphwae_gdwResetBoard
#define iph_kernel_open iphwae_kernel_open
#define iph_kernel_close iphwae_kernel_close
#define iph_kernel_ioctl iphwae_kernel_ioctl

#endif
