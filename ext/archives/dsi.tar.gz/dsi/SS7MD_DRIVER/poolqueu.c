/****************************************************************************
 *  (C) Copyright Interphase Corp 2005.
 *
 * NAME : poolqueu.c
 * VERSION : 1.01
 *
 * DESCRIPTION : 
 *    Functions to manage pools and queues 
 * REVISIONS :
 *    - Version 1.00 09/27/05 : Creation
 *    - Version 1.01 07/12/06 : - Use MUTEX_xx and CV_xx macros
 * FUNCTIONS LIST :
 *    Local functions :
 *       dwNewDataPool
 *
 *    Public functions :
 *       drv_gvInitDrvPool
 *       drv_gvInitQueue
 *       drv_gpGetPool
 *       drv_gvPutPool
 *       drv_gpGetQueue
 *       drv_gvExtractQueue
 *       drv_gvPutQueue
 *       drv_gdwNewPrimPool
 *       drv_gpGetPrimPool
 *       drv_gvPutPrimPool
 *       drv_gdwNewDataDescPool
 *       drv_gpGetDataDescPool
 *       drv_gvPutDataDescPool
 *       drv_gvExtractCorrHash
 *       drv_gvPutCorrHash
 *       drv_gpGetPoolUser
 *       drv_gvPutPoolUser
 *    
 ****************************************************************************/
#define POOLQUEU_C
#include "iphwan.h"
#include "poolqueu.h"
#include "iphwantr.h"
#include "iphtrace.h"
#include "iphmsys.h"


/* #define TRACE_POOL */

/**************************************************************************
* NAME : drv_gvInitDrvPool
* DESCRIPTION : initialize a private pool of the driver
* PARAMETERS :
*    Input   : pPool = address of the pool
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvInitDrvPool(DrvPoolPtr pPool)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvInitDrvPool] entry");
#endif

   pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
   pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
   pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
   pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
   pPool->PoolSize = 0;
   pPool->InitCount = 0;
   pPool->MaxCount = 0;
   pPool->TotalCount = 0;
   pPool->UsedCount = 0;
   pPool->FreeCount = 0;
   pPool->MaxUsedCount = 0;
}

/**************************************************************************
* NAME : drv_gvInitQueue
* DESCRIPTION : initialize a queue
* PARAMETERS :
*    Input   : pQueue = address of the queue
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvInitQueue(QueuePtr pQueue)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvInitQueue] entry");
#endif

   pQueue->FirstPtr = (QueueItemPtr)pQueue;
   pQueue->LastPtr = (QueueItemPtr)pQueue;
}

/**************************************************************************
* NAME : drv_gpGetPool
* DESCRIPTION : extract an item from a private pool of the driver
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static PoolItemPtr drv_gpGetPool(kmutex_t *pLock, PoolPtr pPool)
{
   PoolItemPtr pPoolItem;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)(byte *)"[gpGetPool] entry");
#endif
   IPH_LOCK(pLock);

   /* initialize the value to return */
   pPoolItem = (PoolItemPtr)0;

   /* if the pool is not empty */
   if (pPool->PoolCount > 0)
   {
      /* get the address of the first item */
      pPoolItem = pPool->NextPtr;

      /* change the address of the new first item */
      pPool->NextPtr = pPoolItem->NextPtr;

      /* reinitialize the allocated structure */
      pPoolItem->NextPtr = (PoolItemPtr)0;

      /* decrement the counter of available items in the pool */
      pPool->PoolCount--;
   }
   else
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetPool] no item is available in this pool");
#endif
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)(byte *)"[gpGetPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, (dword)pPoolItem);
#endif

   return(pPoolItem);
}

/**************************************************************************
* NAME : drv_gvPutPool
* DESCRIPTION : add an item to a private pool of the driver
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : pPoolItem = address of the item to add
* RETURN : 0 or
*          ENOSPC if the pool is already full
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static dword drv_gvPutPool(kmutex_t *pLock, PoolPtr pPool, 
                           PoolItemPtr pPoolItem)
{
   dword dwError = 0;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutPool] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)pPoolItem);
#endif

   IPH_LOCK(pLock);

   if (pPool->PoolCount == 0xFFFF)
   {
      /* The Pool is already full */
      dwError = -ENOSPC;
   }
   else
   {
      /* change the pointer to the next structure for the new item */
      pPoolItem->NextPtr = pPool->NextPtr;

      /* change the pointer in the pool to the first item */
      pPool->NextPtr = pPoolItem;

      /* increment the counter of available items in the pool */
      pPool->PoolCount++;
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutPool] return");
#endif

   return(dwError);
}

/**************************************************************************
* NAME : drv_gpGetQueue
* DESCRIPTION : extract the first item of a private queue
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pQueue = address of the queue
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static QueueItemPtr drv_gpGetQueue(kmutex_t *pLock, QueuePtr pQueue)
{
   QueueItemPtr pQueueItem;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetQueue] entry");
#endif

   IPH_LOCK(pLock);

   /* initialize the value to return */
   pQueueItem = (QueueItemPtr)0;

   /* if the queue is not empty */
   if (pQueue->FirstPtr != (QueueItemPtr)pQueue)
   {
      /* get the address of the first item */
      pQueueItem = pQueue->FirstPtr;

      /* change the address of the new first item */
      pQueue->FirstPtr = pQueueItem->NextPtr;

      /* change the address of the previous item for the new first item */
      pQueue->FirstPtr->PrevPtr = (QueueItemPtr)pQueue;

      /* reinitialize the extracted structure */
      pQueueItem->NextPtr = (QueueItemPtr)0;
      pQueueItem->PrevPtr = (QueueItemPtr)0;
   }
   else
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetQueue] no item is available in this queue");
#endif
      pQueueItem = (QueueItemPtr)0;
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetQueue] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, (dword)pQueueItem);
#endif

   /* return the pointer value */
   return(pQueueItem);
}

/**************************************************************************
* NAME : drv_gvExtractQueue
* DESCRIPTION : extract an item from a private queue
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pQueue = address of the queue
*    Input   : pQueueItem = address of the item to extract
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvExtractQueue(kmutex_t *pLock, QueuePtr pQueue,
                               QueueItemPtr pQueueItem)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvExtractQueue] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)pQueueItem);
#endif

   IPH_LOCK(pLock);

   /* change the pointer to the next item for the previous one */
   pQueueItem->PrevPtr->NextPtr = pQueueItem->NextPtr;

   /* change the pointer to the previous item for the next one */
   pQueueItem->NextPtr->PrevPtr = pQueueItem->PrevPtr;

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvExtractQueue] return");
#endif
}

/**************************************************************************
* NAME : drv_gvPutQueue
* DESCRIPTION : add an item to a private queue
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pQueue = address of the queue
*    Input   : pQueueItem = address of the item to add
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvPutQueue(kmutex_t *pLock, QueuePtr pQueue, 
                           QueueItemPtr pQueueItem)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutQueue] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)pQueueItem);
#endif

   IPH_LOCK(pLock);

   /* change the pointer to the next structure for the new item */
   pQueueItem->NextPtr = (QueueItemPtr)pQueue;

   /* change the pointer to the previous structure for the new item */
   pQueueItem->PrevPtr = pQueue->LastPtr;

   /* change the pointer to the next structure for the current last item */
   /* of the queue */
   /* note that when the queue is empty, the pointer to the first item */
   /* is automatically set by the following operation */
   pQueue->LastPtr->NextPtr = pQueueItem;

   /* change the pointer to the new last item of the queue */
   pQueue->LastPtr = pQueueItem;

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutQueue] return");
#endif

}

/**************************************************************************
* NAME : ADD_NEW_DRV_DESC_POOL
* DESCRIPTION : add a driver structure to the pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : wCount = number of structures to add
*    Input   : stype = structure type
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 11/17/99 Creation
**************************************************************************/
#define ADD_NEW_DRV_DESC_POOL(pLock, pPool, pDrvStruct, stype)          \
{                                                                       \
   if (pDrvStruct != NULL)                                              \
   {                                                                    \
      IPH_LOCK(pLock);                                                  \
      pPool->TotalCount++;                                              \
      pDrvStruct->NextItemPtr = (stype *)pPool->FreeQueue;              \
      pDrvStruct->PrevItemPtr = (stype *)pPool->FreeQueue[1];           \
      if (pPool->FreeQueue[0] == (void *)pPool->FreeQueue)              \
         pPool->FreeQueue[0] = (void *)pDrvStruct;                      \
      else                                                              \
      {                                                                 \
         ((stype *)(pPool->FreeQueue[1]))->NextItemPtr = pDrvStruct;    \
      }                                                                 \
      pPool->FreeQueue[1] = (void *)pDrvStruct;                         \
      pPool->FreeCount++;                                               \
      IPH_UNLOCK(pLock);                                                \
   }                                                                    \
}

/**************************************************************************
* NAME : NEW_DRV_DESC_POOL
* DESCRIPTION : allocate new driver structure and add them to the pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : wCount = number of structures to add
*    Input   : stype = structure type
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 11/17/99 Creation
**************************************************************************/
#define NEW_DRV_DESC_POOL(pLock, pPool, wCount, stype, pError)          \
{                                                                       \
   stype *pDrvStruct = NULL;                                            \
   PoolItemPtr pItem;                                                   \
   PoolItemPtr pNextItem;                                               \
   dword dwErr = 0;                                                     \
   if (wCount != 0)                                                     \
   {                                                                    \
      pItem = (PoolItemPtr)iph_gpMemAlloc(sizeof(stype), wCount,        \
                                          ALLOC_KERNEL, 1);             \
      if (pItem != (PoolItemPtr)0)                                      \
      {                                                                 \
         IPH_LOCK(pLock);                                               \
         while (pItem != (PoolItemPtr)0)                                \
         {                                                              \
            pNextItem = pItem->NextPtr;                                 \
            pDrvStruct = (stype *)pItem;                                \
            ADD_NEW_DRV_DESC_POOL(NULL, pPool, pDrvStruct, stype);      \
            pItem = pNextItem;                                          \
         }                                                              \
         IPH_UNLOCK(pLock);                                             \
      }                                                                 \
      else                                                              \
      {                                                                 \
         dwErr = ENOMEM;                                                \
      }                                                                 \
   }                                                                    \
   if (pError != NULL)                                                  \
   {                                                                    \
      *pError = dwErr;                                                  \
   }                                                                    \
}

/**************************************************************************
* NAME : drv_gdwNewPrimPool
* DESCRIPTION : allocate new primitives and add them to the pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : wCount = number of primitives to add
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static dword drv_gdwNewPrimPool(kmutex_t *pLock, DrvPoolPtr pPool, word wCount)
{
   dword dwError = 0;
   NEW_DRV_DESC_POOL(pLock, pPool, wCount, DrvPrimDesc_t, &dwError);
#ifdef TRACE_POOL
   if (dwError == ENOMEM)
   {
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwNewPrimPool] no new item can be allocated for this pool");
      iph_gvDumpDrvPool(pPool);
   }
#endif
   return(dwError);
}

/**************************************************************************
* NAME : GET_DRV_DESC_POOL
* DESCRIPTION : extract a driver structure from a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : stype = structure type
*    Input   : pDrvStruct = where to return the extracted structure
*    Input   : dynAlloc = flag set if dynamic allocation of nex structure
*                         is allowed
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 11/17/99 Creation
**************************************************************************/
#define GET_DRV_DESC_POOL(pLock, pPool, stype, pDrvStruct, dynAlloc)    \
{                                                                       \
   dword dwE;                                                           \
   IPH_LOCK(pLock);                                                     \
   pDrvStruct = NULL;                                                   \
   if (pPool->FreeCount == 0 && pPool->TotalCount < pPool->MaxCount &&  \
       (dynAlloc) != 0)                                                 \
   {                                                                    \
      NEW_DRV_DESC_POOL(NULL, pPool, 1, stype, &dwE);                   \
   }                                                                    \
   if (pPool->FreeCount > 0)                                            \
   {                                                                    \
      pDrvStruct = (stype *)pPool->FreeQueue[0];                        \
      pPool->FreeQueue[0] = (void *)pDrvStruct->NextItemPtr;            \
      if (pPool->FreeQueue[1] == (void *)pDrvStruct)                    \
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;                \
      else                                                              \
         ((stype *)(pPool->FreeQueue[0]))->PrevItemPtr =                \
            (stype *)pPool->FreeQueue;                                  \
      pPool->FreeCount--;                                               \
      pDrvStruct->NextItemPtr = (stype *)pPool->UsedQueue;              \
      pDrvStruct->PrevItemPtr = (stype *)pPool->UsedQueue[1];           \
      if (pPool->UsedQueue[0] == (void *)pPool->UsedQueue)              \
         pPool->UsedQueue[0] = (void *)pDrvStruct;                      \
      else                                                              \
         ((stype *)(pPool->UsedQueue[1]))->NextItemPtr = pDrvStruct;    \
      pPool->UsedQueue[1] = (void *)pDrvStruct;                         \
      pPool->UsedCount++;                                               \
      if (pPool->UsedCount > pPool->MaxUsedCount)                       \
         pPool->MaxUsedCount = pPool->UsedCount;                        \
      IPH_SET_DRV_STRUCT_STATUS(pDrvStruct);                            \
   }                                                                    \
   IPH_UNLOCK(pLock);                                                   \
}

/**************************************************************************
* NAME : drv_gpGetPrimPool
* DESCRIPTION : extract a primitive from a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static PrimDescPtr drv_gpGetPrimPool(kmutex_t *pLock, DrvPoolPtr pPool)
{
   DrvPrimDescPtr pDrvPrim;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[GetPrimPool]");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)pPool);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->FreeQueue[0], (dword)pPool->FreeQueue[1]);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->UsedQueue[0], (dword)pPool->UsedQueue[1]);
#endif
   GET_DRV_DESC_POOL(pLock, pPool, DrvPrimDesc_t, pDrvPrim, 1);
   if (pDrvPrim != NULL)
   {
      /* reset the primitive */
      pDrvPrim->Prim.NextPtr = NULL;
      pDrvPrim->Prim.PrevPtr = NULL;
      pDrvPrim->Prim.DataDescPtr = NULL;
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[GetPrimPool] got");
      iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)pDrvPrim);
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   (dword)pPool->FreeQueue[0], (dword)pPool->FreeQueue[1]);
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   (dword)pPool->UsedQueue[0], (dword)pPool->UsedQueue[1]);
#endif
   }
#ifdef TRACE_POOL
   else
   {
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetPrimPool] no item is available in this pool");
      iph_gvDumpDrvPool(pPool);
   }
#endif
   return((PrimDescPtr)pDrvPrim);
}

/**************************************************************************
* NAME : PUT_DRV_DESC_POOL
* DESCRIPTION : add a driver structure to a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : stype = structure type
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 11/17/99 Creation
**************************************************************************/
#define PUT_DRV_DESC_POOL(pLock, pPool, stype, pDrvStruct)              \
{                                                                       \
   IPH_LOCK(pLock);                                                     \
   if (pDrvStruct->PrevItemPtr == (stype *)pPool->UsedQueue)            \
      pPool->UsedQueue[0] = (void *)pDrvStruct->NextItemPtr;            \
   else                                                                 \
      pDrvStruct->PrevItemPtr->NextItemPtr = pDrvStruct->NextItemPtr;   \
   if (pDrvStruct->NextItemPtr == (stype *)pPool->UsedQueue)            \
      pPool->UsedQueue[1] = (void *)pDrvStruct->PrevItemPtr;            \
   else                                                                 \
      pDrvStruct->NextItemPtr->PrevItemPtr = pDrvStruct->PrevItemPtr;   \
   pPool->UsedCount--;                                                  \
   pDrvStruct->NextItemPtr = (stype *)pPool->FreeQueue;                 \
   pDrvStruct->PrevItemPtr = (stype *)pPool->FreeQueue[1];              \
   if (pPool->FreeQueue[0] == (void *)pPool->FreeQueue)                 \
      pPool->FreeQueue[0] = (void *)pDrvStruct;                         \
   else                                                                 \
   {                                                                    \
      ((stype *)(pPool->FreeQueue[1]))->NextItemPtr = pDrvStruct;       \
   }                                                                    \
   pPool->FreeQueue[1] = (void *)pDrvStruct;                            \
   pPool->FreeCount++;                                                  \
   pDrvStruct->Status = (dword)0;                                       \
   IPH_UNLOCK(pLock);                                                   \
}

/**************************************************************************
* NAME : drv_gvPutPrimPool
* DESCRIPTION : add a primitive to a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : pDrvPrim = address of the primitive to release
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvPutPrimPool(kmutex_t *pLock, DrvPoolPtr pPool,
                              DrvPrimDescPtr pDrvPrim)
{
#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[PutPrimPool] pool-prim");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, (dword)pPool, (dword)pDrvPrim);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->FreeQueue[0], (dword)pPool->FreeQueue[1]);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->UsedQueue[0], (dword)pPool->UsedQueue[1]);
#endif
   PUT_DRV_DESC_POOL(pLock, pPool, DrvPrimDesc_t, pDrvPrim);
#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[PutPrimPool] after");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->FreeQueue[0], (dword)pPool->FreeQueue[1]);
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                (dword)pPool->UsedQueue[0], (dword)pPool->UsedQueue[1]);
#endif
}

/**************************************************************************
* NAME : drv_gdwNewDataDescPool
* DESCRIPTION : allocate new data descriptors and add them to the pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : wCount = number of dexcriptors to add
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static dword drv_gdwNewDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool, 
                                    word wCount)
{
   dword dwError = 0;
   NEW_DRV_DESC_POOL(pLock, pPool, wCount, DrvDataDesc_t, &dwError);
#ifdef TRACE_POOL
   if (dwError == ENOMEM)
   {
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwNewDataDescPool] no new item can be allocated for this pool");
      iph_gvDumpDrvPool(pPool);
   }
#endif
   return(dwError);
}

/**************************************************************************
* NAME : drv_gpGetDataDescPool
* DESCRIPTION : extract a data descriptor from a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static DataDescPtr drv_gpGetDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool)
{
   DrvDataDescPtr pDrvData;

   GET_DRV_DESC_POOL(pLock, pPool, DrvDataDesc_t, pDrvData, 1);
   if (pDrvData != NULL)
   {
      /* reset the descriptor */
      pDrvData->Data.NextPtr = NULL;
   }
#ifdef TRACE_POOL
   else
   {
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetDataPool] no item is available in this pool");
      iph_gvDumpDrvPool(pPool);
   }
#endif
   return((DataDescPtr)pDrvData);
}

/**************************************************************************
* NAME : drv_gvPutDataDescPool
* DESCRIPTION : add a data descriptor to a private driver pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : pDrvData = address of the data descriptor to release
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvPutDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool,
                                  DrvDataDescPtr pDrvData)
{
   PUT_DRV_DESC_POOL(pLock, pPool, DrvDataDesc_t, pDrvData);
}

/**************************************************************************
* NAME : dwNewDataPool
* DESCRIPTION : allocate new data descriptors with their buffer and add them 
*               to the pool
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
*    Input   : wCount = number of dexcriptors to add
* RETURN : 0 if all is OK
*          ENOMEM if memory allocation failed
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static dword dwNewDataPool(kmutex_t *pLock, DrvPoolPtr pPool, word wCount)
{
   DrvDataDescPtr pDrvData;
   PoolItemPtr pDescItem;
   PoolItemPtr pNextDescItem;
   PoolItemPtr pBuffItem;
   PoolItemPtr pNextBuffItem;
   dword dwError;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwNewDataPool] entry");
#endif

   dwError = 0;

   /* if no structure to allocate, return OK */
   if (wCount == 0)
      return(dwError);

   pDescItem = (PoolItemPtr)iph_gpMemAlloc(sizeof(DrvDataDesc_t), wCount,
                                           ALLOC_KERNEL, 1);
   if (pDescItem != (PoolItemPtr)0)
   {
      pBuffItem = (PoolItemPtr)iph_gpMemAlloc(pPool->PoolSize, wCount,
                                              ALLOC_KERNEL, 1);

      if (pBuffItem == (PoolItemPtr)0)
      {
#ifdef TRACE_POOL
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[dwNewDataPool] failed to allocate new buffers");
#endif
         /* release all the newly allocated descriptors */
         while (pDescItem != (PoolItemPtr)0)
         {
            pNextDescItem = pDescItem->NextPtr;
            iph_gvMemFree((void *)pDescItem);
            pDescItem = pNextDescItem;
         }
         pDescItem = (PoolItemPtr)0;
      }

      IPH_LOCK(pLock);

      while (pDescItem != (PoolItemPtr)0)
      {
         /* save the next allocated structure */
         pNextDescItem = pDescItem->NextPtr;
         pNextBuffItem = pBuffItem->NextPtr;

         pDrvData = (DrvDataDescPtr)pDescItem;
         pDrvData->Data.MaxSize = (word)pPool->PoolSize;
         pDrvData->Data.Reserved = (word)pPool->PoolIndex | DRV_BUFFER;
         pDrvData->Data.DataPtr = (byte *)pBuffItem;

         /* add descriptor in the pool */
         ADD_NEW_DRV_DESC_POOL(NULL, pPool, pDrvData, DrvDataDesc_t);

         /* try next structure */
         pDescItem = pNextDescItem;
         pBuffItem = pNextBuffItem;
      }

      IPH_UNLOCK(pLock);
   }
   else
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[dwNewDataPool] no new item can be allocated for this pool");
      iph_gvDumpDrvPool(pPool);
#endif
      dwError = ENOMEM;
   }

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[dwNewDataPool] return");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_RETCODE, dwError);
#endif

   return(dwError);
}

/**************************************************************************
* NAME : drv_gpGetDataPool
* DESCRIPTION : extract a data descriptor from a private driver pool
*               if none is available, allocate buffer and descriptor
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pPool = address of the pool
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static DataDescPtr drv_gpGetDataPool(kmutex_t *pLock, DrvPoolPtr pPool)
{
   DrvDataDescPtr pDrvData;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetDataPool] entry");
#endif

   IPH_LOCK(pLock);

   pDrvData = NULL;

   /* if the pool is empty, try to allocate a new structure */
   if (pPool->FreeCount == 0 && pPool->TotalCount < pPool->MaxCount)
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetDataPool] memory shortage >> extra allocation");
#endif
      /* NOTE: if it costs less to allocate more structures, change the */
      /* following... */
      dwNewDataPool(NULL, pPool, 1);
   }

   /* if the pool is not empty */
   if (pPool->FreeCount > 0)
   {
      /* extract an item from FreeQueue */
      pDrvData = (DrvDataDescPtr)drv_gpGetDataDescPool(NULL, pPool);
   }
   else
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetDataPool] no item is available in this pool");
      iph_gvDumpDrvPool(pPool);
#endif
   }

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetDataPool] return");
#endif

   if (pDrvData != (DrvDataDescPtr)0)
      return(&(pDrvData->Data));
   else
      return(NULL);
}

/**************************************************************************
* NAME : drv_gvExtractCorrHash
* DESCRIPTION : extract a correlator from a hash queue
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pQueue = address of the queue
*    Input   : pHashItem = address of the item to extract
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvExtractCorrHash(kmutex_t *pLock, QueuePtr pQueue,
                                  MGRSessionCorrPtr pHashItem)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvExtractCorrHash] entry");
#endif

   IPH_LOCK(pLock);

   /* change the pointer to the next item for the previous one */
   if (pHashItem->HashPrevPtr != (MGRSessionCorrPtr)pQueue)
      pHashItem->HashPrevPtr->HashNextPtr = pHashItem->HashNextPtr;
   else
      pQueue->FirstPtr = (QueueItemPtr)pHashItem->HashNextPtr;

   /* change the pointer to the previous item for the next one */
   if (pHashItem->HashNextPtr != (MGRSessionCorrPtr)pQueue)
      pHashItem->HashNextPtr->HashPrevPtr = pHashItem->HashPrevPtr;
   else
      pQueue->LastPtr = (QueueItemPtr)pHashItem->HashPrevPtr;

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvExtractCorrHash] return");
#endif

}

/**************************************************************************
* NAME : drv_gvPutCorrHash
* DESCRIPTION : add a correlator to a hash queue
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pQueue = address of the queue
*    Input   : pHashItem = address of the item to add
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static void drv_gvPutCorrHash(kmutex_t *pLock, QueuePtr pQueue,
                              MGRSessionCorrPtr pHashItem)
{

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutCorrHash] entry");
#endif

   IPH_LOCK(pLock);

   /* change the pointer to the next structure for the new item */
   pHashItem->HashNextPtr = (MGRSessionCorrPtr)pQueue;

   /* change the pointer to the previous structure for the new item */
   pHashItem->HashPrevPtr = (MGRSessionCorrPtr)pQueue->LastPtr;

   /* change the pointer to the next structure for the current last item */
   /* of the queue */
   if (pQueue->FirstPtr != (QueueItemPtr)pQueue)
      ((MGRSessionCorrPtr)(pQueue->LastPtr))->HashNextPtr = 
         (MGRSessionCorrPtr)pHashItem;
   else
      pQueue->FirstPtr = (QueueItemPtr)pHashItem;

   /* change the pointer to the new last item of the queue */
   pQueue->LastPtr = (QueueItemPtr)pHashItem;

   IPH_UNLOCK(pLock);

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutCorrHash] return");
#endif

}

/**************************************************************************
* NAME : drv_gpGetPoolUser
* DESCRIPTION : extract an item from a private pool of the driver with items
*               from user application
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pCondVar = conditional variable used to protect access to the 
*                         pool
*    Input   : pInUse = flag set when the pool is currently in use
*    Input   : pPool = address of the pool
*    Input   : iFlags = flags for copy
* RETURN : address of the extracted item if all is OK, NULL if not
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static PoolItemPtr drv_gpGetPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,
                                     byte *pInUse, PoolPtr pPool, int iFlags)
{
   PoolItemPtr pPoolItem;
   PoolItemPtr AnAddr;
   dword dwError;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetPoolUser] entry");
#endif
   if (pLock != NULL)
   {
      MUTEX_ENTER(pLock);
#if defined(APPLI_POOL_USER_CONDVAR) || defined(SOLARIS)
      while (*pInUse == TRUE)
      {
         CV_WAIT_SIG(pCondVar, pLock);
      }
      *pInUse = TRUE;
      MUTEX_EXIT(pLock);
#else
      *pInUse = TRUE;
#endif
   }

   /* initialize the value to return */
   pPoolItem = (PoolItemPtr)0;

   /* if the pool is not empty */
   if (pPool->PoolCount > 0)
   {
      /* get the address of the first item */
      pPoolItem = pPool->NextPtr;

      /* change the address of the new first item */
      GET_POOL_ITEM_NEXTPTR(pPoolItem, &pPool->NextPtr, iFlags, &dwError);

      /* reset the linkage for the extracted item */
      AnAddr = NULL;
      PUT_POOL_ITEM_NEXTPTR(pPoolItem, &AnAddr, iFlags, &dwError);

      /* decrement the counter of available items in the pool */
      pPool->PoolCount--;
   }
   else
   {
#ifdef TRACE_POOL
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gpGetPoolUser] no item is available in this pool");
#endif
   }

   if (pLock != NULL)
   {
#if defined(APPLI_POOL_USER_CONDVAR) || defined(SOLARIS)
      MUTEX_ENTER(pLock);
      *pInUse = FALSE;
      CV_SIGNAL(pCondVar);
#else
      *pInUse = FALSE;
#endif
      MUTEX_EXIT(pLock);
   }

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gpGetPoolUser] return");
#endif

   return(pPoolItem);
}

/**************************************************************************
* NAME : drv_gvPutPoolUser
* DESCRIPTION : add an item to a private pool of the driver with items
*               from user application
* PARAMETERS :
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pLock = address of a semaphore that provides protection
*                      if NULL, the operation is not protected
*    Input   : pCondVar = conditional variable used to protect access to the 
*                         pool
*    Input   : pInUse = flag set when the pool is currently in use
*    Input   : pPool = address of the pool
*    Input   : pPoolItem = address of the item to add
*    Input   : iFlags = flags for copy
* RETURN :
*          ENOSPC if the pool is already full
* REVISION :
*    - Version 1.0 : 10/18/05 Creation
**************************************************************************/
static dword drv_gvPutPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,
                               byte *pInUse, PoolPtr pPool, 
                               PoolItemPtr pPoolItem, int iFlags)
{
   dword dwError = 0;

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutPoolUser] entry");
#endif

   if (pLock != NULL)
   {
      MUTEX_ENTER(pLock);
#if defined(APPLI_POOL_USER_CONDVAR) || defined(SOLARIS)
      while (*pInUse == TRUE)
      {
         CV_WAIT_SIG(pCondVar, pLock);
      }
      *pInUse = TRUE;
      MUTEX_EXIT(pLock);
#else
      *pInUse = TRUE;
#endif
   }

   if (pPool->PoolCount == 0xFFFF)
   {
      /* The Pool is already full */
      dwError = -ENOSPC;
   }
   else
   {
      /* set the NextPtr of the New Item to Address of the NexPtr of the pool */
      PUT_POOL_ITEM_NEXTPTR(pPoolItem, &pPool->NextPtr, iFlags, &dwError);

      /* change the pointer in the pool to the first item */
      pPool->NextPtr = pPoolItem;

      /* increment the counter of available items in the pool */
      pPool->PoolCount++;
   }

   if (pLock != NULL)
   {
#if defined(APPLI_POOL_USER_CONDVAR) || defined(SOLARIS)
      MUTEX_ENTER(pLock);
      *pInUse = FALSE;
      CV_SIGNAL(pCondVar);
#else
      *pInUse = FALSE;
#endif
      MUTEX_EXIT(pLock);
   }

#ifdef TRACE_POOL
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPutPoolUser] return");
#endif

   return(dwError);
}

