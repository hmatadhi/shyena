/****************************************************************************
 * * (C) Copyright Interphase Corp 2005-2009.
 * NAME : iphmsys.c
 * VERSION : 1.10.3
 * DESCRIPTION : 
 *    Linux/Solaris driver general utility routines
 * 
 * REVISIONS :
 *    - Version 1.00 10/04/2005 : Creation
 *    - Version 1.01 03/21/2006 : - Fix a bug in echo timer management 
 *                                  on shutdown
 *                                - Remove drv_gvMemFreeSize
 *                                - Add drv_gdwAllocDmaMem/drv_gdwFreeDmaMem
 *                                - Fix a bug with lock in gvCloseAppliSession
 *                                - Reset BuffInPool field in primitive sent 
 *                                  in drv_gvCloseAppliSession
 *    - Version 1.02 05/03/2006 : - Fix a bug in poll timer management 
 *                                  in drv_gvShutdownAdapter
 *    - Version 1.03 05/23/2006 :
 *       - Add mutex protection for access to MEM_REGION to avoid unexpected
 *         window translation
 *    - Version 1.04 06/29/2006 : 
 *       - in drv_gdwAllocDmaMem for SOLARIS, fix management for buffer 
 *         size > PAGESIZE
 *    - Version 1.05 07/12/2006 : - Use MUTEX_xx and CV_xx macros
 *                                - ShutdownAdapter checks whether the device
 *                                  is initialized
 *    - Version 1.06 09/05/2006 : 
 *       - In drv_gvPurgeAppliSession, swap the received session with uses 
 *         host format while primitives stored in the reception queue uses 
 *         Big Endian. In addition, it does not free any MGR_USER_CLOSED.
 *       - In drv_gvPurgeAppliSession, extract all the relevant primitives 
 *         under protection of the application mutex before releasing them 
 *         (under protection of the device mutex)
 *    - Version 1.07 12/21/2006 : 
 *       - Suppress some Linux compilation warnings
 *    - Version 1.08 01/11/2007 : 
 *       - In drv_gdwAllocDmaMem function, assure that the physical addresess
 *         of the DMA receive Pools are multiple of 8 (64-bits addressing).
 *    - Version 1.09 09/15/2008 : 
 *       - In drv_gvShutdownAdapter, awake any sending process waiting for a 
 *         descriptor and reset the SendPending variable
 *    - Version 1.10 11/20/08 :
 *       - In gvSendPrimToAppli, do not extract correlator from application 
 *         context (done in gvReleaseCorr or vEndAppli)
 *    - Version 1.10.1 02/27/09 :
 *       - Remove unused variables
 *    - Version 1.10.2 04/03/09 :
 *       - In drv_gvShutdownAdapter, when closing a session, use ReleaseCorr
 *         to properly reset all the references
 *       - In drv_gvCloseAppliSession, try to close the session on the card
 *         only if the card is running
 *       - update AppliReady in correlator on session close
 *    - Version 1.10.3 05/19/09 :
 *       - ShutdownAdapter: Do not restart PollTimer if card status is 
 *         CARD_UNAVAILABLE
 *
 * FUNCTIONS LIST :
 *    Local functions :
 *
 *    Public functions :
 *       drv_gvShutdownAdapter
 *       drv_gpMemAlloc
 *       drv_gvMemFree
 *       drv_gdwAllocDmaMem
 *       drv_gdwFreeDmaMem
 *       drv_gvReleaseDrvPrim
 *       drv_gvPurgeAppliSession
 *       drv_gvSendPrimToAppli
 *       drv_gvCloseAppliSession
 *       
 ****************************************************************************/
#define IPHMSYS_C
#include "iphwan.h"
#include "wanapi.h"
#include "iphuser.h"
#include "iphwantr.h"
#include "poolqueu.h"
#include "ithandle.h"
#include "sendprim.h"
#include "ppcperf.h"
#include "iphtrace.h"
#include "iphmsys.h"

/**************************************************************************
* NAME : drv_gvShutdownAdapter
* DESCRIPTION : close all the pending sessions on this adapter
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pWanDev = adapter context
*    Input   : Reason = reason of the reset
* RETURN : none
* NOTE: if pLock != NULL, it must the device mutex
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void drv_gvShutdownAdapter(kmutex_t *pLock, IphWanDevPtr pWanDev, 
                                  int Reason)
{
   MGRSessionCorrPtr pCorr;
   ApplCtxtPtr pAppli;
   PrimDescPtr pPrim;
   word wLogicalSession;
   word wTransf;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvShutdownAdapter] entry (Index - reason)");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pWanDev->Index);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, Reason);
#endif

   if (pWanDev->HostArea == NULL)
      return;

   IPH_LOCK(pLock);

   pWanDev->Status = Reason;

   if (pWanDev->SendPending != 0)
   {
      CV_SIGNAL(&pWanDev->CondVar);
   }
   /* check whether there were pending transmissions to release */
   /* the structures */
   wTransf = 0;
   while (wTransf < pWanDev->OutbCtrlNb)
   {
      pPrim = pWanDev->SendingPrim[wTransf];
      pWanDev->SendingPrim[wTransf] = NULL;
      wTransf++;

      /* release the data buffers */
      if (pPrim != NULL)
      {
         pAppli = iph_gpFindCtxtWithMGRSession(NULL, pWanDev,
                                               pPrim->PrimRef,
                                               &wLogicalSession, &pCorr);
         if (pAppli != NULL && pAppli->Type == TYPE_KERNEL)
         {
            pPrim->PrimInPool |= SENT_PRIM;
         }
         /* release the primitive structure and its attached buffers */
         iph_gvReleaseDrvPrim(NULL, pAppli, pWanDev, pPrim);
         if (pAppli != NULL && pAppli->Status == WAIT_SEND_END)
         {
            MUTEX_EXIT(&pWanDev->DevMutex);

            MUTEX_ENTER(&pAppli->AppliMutex);
            CV_SIGNAL(&pAppli->CondVar);
            MUTEX_EXIT(&pAppli->AppliMutex);

            MUTEX_ENTER(&pWanDev->DevMutex);

         }
      }
   }

   /* NOTE: at this point we are protected against interrupts */

   IPH_UNLOCK(pLock);

   /* close all the pending sessions */
   /* call ReleaseCorr to Properly release the correloator */
   /*pCorr = (MGRSessionCorrPtr)iph_gpGetQueue(pLock,
                                             &pWanDev->UsedMGRSessionCorrQueue);
   while (pCorr != (MGRSessionCorrPtr)0)*/
   pCorr = (MGRSessionCorrPtr)pWanDev->UsedMGRSessionCorrQueue.FirstPtr;
   while (pCorr != (MGRSessionCorrPtr)&pWanDev->UsedMGRSessionCorrQueue)
   {
      iph_gvCloseAppliSession(pLock, pWanDev, pCorr, MGR_DISC_ADAPTER_INACT);

      iph_gvReleaseCorr(pLock, pWanDev, pCorr);

      /*pCorr->Status = SESS_CLOSED;*/

      /*iph_gvPutQueue(pLock,
                     &pWanDev->FreeMGRSessionCorrQueue,(QueueItemPtr)pCorr);*/

      /* next session correlator */
      /*pCorr = (MGRSessionCorrPtr)iph_gpGetQueue(pLock,
                                                &pWanDev->UsedMGRSessionCorrQueue);*/
      pCorr = (MGRSessionCorrPtr)pWanDev->UsedMGRSessionCorrQueue.FirstPtr;
   }


   IPH_LOCK(pLock);
   /* miscellaneous initializations */
   pWanDev->SoftITNeeded = FALSE;
   pWanDev->SoftITRunning = FALSE;
   pWanDev->OpenPrimToDo = FALSE;
   pWanDev->OpenPrimDone = FALSE;
   pWanDev->IRQStatus = 0;
   pWanDev->SendPending = 0;

   IPH_UNLOCK(pLock);

   /* This routine can be called with a NULL pLock pointer BUT the timeout */
   /* delete must be called with no mutex hold or there may be a deadlock */
   /* because the timeout handler needs the mutex */

   if (pLock == NULL)
   {
      MUTEX_EXIT(&pWanDev->DevMutex);
   }


   /* del timer watchdog timer if armed and not expired*/
   if ((pWanDev->WatchdogTimeout == FALSE) &&
       (pWanDev->WatchdogTimer == TRUE))
   {
      pWanDev->WatchdogTimer = FALSE;
      IPH_DEL_TIMER(&pWanDev->Watchdog);
   }

   /* remove the poll status timer if active */
   if (pWanDev->PollTimeout == FALSE && pWanDev->PollTimer == TRUE)
   {
      pWanDev->PollTimer = FALSE;
      IPH_DEL_TIMER(&pWanDev->StatusPoll);
   }

   /* remove the echo timer if active */
   if (pWanDev->EchoTimeout == FALSE && pWanDev->EchoTimer == TRUE)
   {
      pWanDev->EchoTimer = FALSE;
      IPH_DEL_TIMER(&pWanDev->EchoPoll);
   }

   /* acquire the device mutex again if pLock is NULL */
   if (pLock == NULL)
   {
      MUTEX_ENTER(&pWanDev->DevMutex);
   }

   /* restart PollStatus timer if necessary */
   if (pWanDev->Rsrc->CheckCardStatus != NULL && 
       pWanDev->PollTimer == FALSE &&
       Reason != CARD_UNAVAILABLE)
   {
      IPH_START_TIMER(&pWanDev->StatusPoll, iph_gvITPollStatus, pWanDev, 
                      10*POLL_STATUS_TIMEOUT);
      pWanDev->PollTimeout = FALSE;
      pWanDev->PollTimer = TRUE;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvShutdownAdapter] return");
#endif
}

/**************************************************************************
* NAME : drv_gpMemAlloc
* DESCRIPTION : memory allocation
* PARAMETERS :
*    Input   : wSize = size of elements to allocate
*    Input   : wNb = number of elements to allocate
*    Input   : iFlags = flags for allocation
*    Input   : addSize = flags set if extra allocation needed to store size
* RETURN : - address of the first allocated element; the first dword in the
*          area contains the pointer of the next allocated element and so on
*          the other bytes are zeroed.
*          - if allocation fails, the routine returns NULL
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void *drv_gpMemAlloc(dword dwSize, word wNb, int iFlags, int addSize)
{
   byte *pBuf;
   dword dwRealSize;
   MemAllocPtr pFirstMem;
   MemAllocPtr pNextMem;
   MemAllocPtr pTmpMem;
   word wCount;
   MemAlloc_t ToGetSize;
   PoolItemPtr pFirst;
   PoolItemPtr pNext;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gpMemAlloc] entry: size and nb are");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, dwSize);
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, wNb);
#endif

   if (dwSize == 0 || wNb == 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, 
                       (byte *)"[gpMemAlloc] invalid NULL arguement");
#endif
      return(NULL);
   }

   /* estimate the real size to allocate */
   /* the buffers must be 64-bit aligned */
   dwRealSize = (dwSize /sizeof(long)) * sizeof(long);
   if (dwSize % sizeof(long) !=0)
      dwRealSize +=sizeof(long);

   if (addSize != 0)
   {
      dwRealSize +=(dword)((byte *)&ToGetSize.NextPtr - (byte *)&ToGetSize);
   }

   pFirstMem = NULL;
   pNextMem = NULL;
   pFirst = NULL;
   pNext = NULL;

   for (wCount = 0; wCount < wNb; wCount++)
   {
#ifdef LINUX
      pTmpMem = (MemAllocPtr)kmalloc(dwRealSize, iFlags);
#endif
#ifdef SOLARIS
      pTmpMem = (MemAllocPtr)kmem_zalloc(dwRealSize, iFlags);
#endif

      if (pTmpMem == (MemAllocPtr)NULL)
      {
         while (pFirstMem != NULL)
         {
            if (addSize != 0)
            {
               pNextMem = pFirstMem->NextPtr;
               pBuf = (byte *)pFirstMem;
               pBuf -= ((byte *)&ToGetSize.NextPtr - (byte *)&ToGetSize);
               pFirstMem = pNextMem;        
            }
            else
            {
               pNext = pFirst->NextPtr;
               pBuf = (byte *)pFirst;
               pFirst = pNext;
            }
#ifdef LINUX
            kfree((void *)pBuf);
#endif
#ifdef SOLARIS
            kmem_free((void *)pBuf, dwRealSize);
#endif
         }
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gpMemAlloc] ALLOCATION FAILED");
#endif
         return(NULL);
      }
      else
      {
#ifdef LINUX
         memset(pTmpMem, 0, dwRealSize);
#endif
         if (addSize != 0)
         {
            if (pFirstMem == NULL)
            {
               pFirstMem = pTmpMem;
               pFirstMem->Size = dwRealSize;
               pFirstMem->Reserved = iFlags;
               pNextMem = pFirstMem;
            }
            else
            {
               pNextMem->NextPtr = (MemAllocPtr)&pTmpMem->NextPtr;
               pNextMem->Size    = dwRealSize;
               pNextMem->Reserved = iFlags;
               pNextMem = pTmpMem;
            }
         }
         else
         {
            if (pFirst == NULL)
            {
               pFirst = (PoolItemPtr)pTmpMem;
               pNext = pFirst;
            }
            else
            {
               pNext->NextPtr = (PoolItemPtr)pTmpMem;
               pNext = (PoolItemPtr)pTmpMem;
            }
         }
      }
   }

   /* set the NextPtr field for the last memory to NULL */
   if (addSize != 0)
   {
      pNextMem->NextPtr = (MemAllocPtr)NULL;
      pBuf = (byte *)&pFirstMem->NextPtr;
   }
   else
   {
      pNext->NextPtr = (PoolItemPtr)NULL;
      pBuf = (byte *)pFirst;
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gpMemAlloc] return OK");
#endif

   return((void *)pBuf);
}

/**************************************************************************
* NAME : drv_gvMemFree
* DESCRIPTION : memory free
* PARAMETERS :
*    Input   : pMem = memory to free
* RETURN : NONE
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
*      NOTE: the dword before vMem contains the size to free; if this size
*            is null, no memory is freed
**************************************************************************/
static void drv_gvMemFree(void *pMem)
{
   MemAlloc_t ToGetSize;
   MemAllocPtr pTmpMem;
   byte *pBuf;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gvMemFree] entry");
   iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, (dword)(unsigned long)pMem);
#endif

   /* For 64-bit support, check the alignment using the sizeof(long) */
   if (pMem == NULL || ((long)pMem & 0x00000007) != 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, 
                       (byte *)"[gvMemFree] NULL address or not aligned!!");
#endif
      return;
   }

   pBuf = (byte *)pMem;

   /* points to the size field for the allocated memory */
   pBuf -= ((byte *)&ToGetSize.NextPtr - (byte *)&ToGetSize);
   pTmpMem = (MemAllocPtr)pBuf;

   if (pTmpMem->Size != 0)
   {
#ifdef LINUX
      kfree((void *)pBuf);
#endif
#ifdef SOLARIS
      kmem_free((void *)pBuf, pTmpMem->Size);
#endif
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0, 
                    (byte *)"[gvMemFree] return");
#endif
}

#ifdef LINUX
/**************************************************************************
* NAME : drv_gdwAllocDmaMem
* DESCRIPTION : allocate memory for DMA exchanges
* PARAMETERS :
*    Input  : pLock = protection against interrupts from this device
*    Input  : pDev = pointer to the device context
* RETURN : 0 if all is OK
*          ENOMEM if allocation failed
* REVISION :
*    - Version 1.0 : 04/05/06 Creation
**************************************************************************/
static dword drv_gdwAllocDmaMem(kmutex_t *pLock, IphWanDevPtr pDev)
{
   dword dwError;
   int real_len, cpt;
   int wPool;
   DrvPool_t *pPool;
   DataDesc_t *pDataDesc;
   DrvDataDesc_t *pDrvData;
   int wDataNb;

   dwError = 0;

   IPH_UNLOCK(pLock);
   pDev->SendDmaDesc = 
      (DmaBuffDesc_t *)iph_gpMemAlloc(sizeof(DmaBuffDesc_t) * pDev->InbDataNb,
                                      1,ALLOC_KERNEL, 1);
   pDev->RecvDmaDesc = 
      (DmaBuffDesc_t *)iph_gpMemAlloc(sizeof(DmaBuffDesc_t) * pDev->OutbDataNb,
                                      1,ALLOC_KERNEL, 1);
   IPH_LOCK(pLock);
   if (pDev->SendDmaDesc == NULL || pDev->RecvDmaDesc == NULL)
   {
      if (pDev->SendDmaDesc != NULL)
      {
         iph_gvMemFree(pDev->SendDmaDesc);
         pDev->SendDmaDesc = NULL;
      }
      if (pDev->RecvDmaDesc != NULL)
      {
         iph_gvMemFree(pDev->RecvDmaDesc);
         pDev->RecvDmaDesc = NULL;
      }
      return(ENOMEM);
   }
   else
   {
      /* allocate DMA buffers for host-to-card transfer */
      for (cpt = 0; cpt < pDev->InbDataNb && dwError == 0; cpt++)
      {
         pDev->SendDmaDesc[cpt].Index = cpt;
      }
   }

   /* allocate DMA buffers for host-to-card transfer */
   for (cpt = 0; cpt < pDev->InbDataNb && dwError == 0; cpt++)
   {
      DMA_ALLOC_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
      if (pDev->SendDmaDesc[cpt].PhysAddr != 0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] failed to allocate DMA handle");
#endif
         pDev->SendDmaDesc[cpt].VirtAddr = NULL;
         dwError = ENOMEM;
         break;
      }
      IPH_UNLOCK(pLock);
      DMA_ALLOC_MEM(pDev, &pDev->SendDmaDesc[cpt], pDev->MaxTransferSize, &real_len);
      IPH_LOCK(pLock);
      if (pDev->SendDmaDesc[cpt].VirtAddr == NULL)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] failed to allocate DMA buffer");
#endif
         DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         dwError = ENOMEM;
         break;
      }
      DMA_BIND_SEND_HANDLE(pDev, &pDev->SendDmaDesc[cpt], 
                           pDev->SendDmaDesc[cpt].VirtAddr, 
                           real_len);
      if (pDev->SendDmaDesc[cpt].PhysAddr == 0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] failed to bind DMA buffer");
#endif
         DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_MEM(pDev, &pDev->SendDmaDesc[cpt]);
         dwError = ENOMEM;
         break;
      }
      else
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] Send DMA buffer - cpt/real_len/VirtAddr/PhysAddr");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                      cpt, real_len);
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                      (dword)(unsigned long)pDev->SendDmaDesc[cpt].VirtAddr,
                      (dword)(unsigned long)pDev->SendDmaDesc[cpt].PhysAddr);
#endif

         /* check 192 window constraint */
         if (pDev->FirstDmaDesc != NULL &&
             ((pDev->SendDmaDesc[cpt].PhysAddr < 
               pDev->FirstDmaDesc->PhysAddr &&
               (pDev->LastDmaDesc->PhysAddr - 
                pDev->SendDmaDesc[cpt].PhysAddr) > 0xC000000) ||
              (pDev->SendDmaDesc[cpt].PhysAddr > 
               pDev->LastDmaDesc->PhysAddr &&
               (pDev->SendDmaDesc[cpt].PhysAddr - 
                pDev->FirstDmaDesc->PhysAddr) > 0xC000000)))
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwAllocDmaMem] DMA buffer out of range");
#endif
            DMA_UNBIND_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
            DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
            DMA_FREE_MEM(pDev, &pDev->SendDmaDesc[cpt]);
            dwError = ENOMEM;
            break;
         }
         else
         {
            if (pDev->FirstDmaDesc == NULL ||
                pDev->SendDmaDesc[cpt].PhysAddr < 
                pDev->FirstDmaDesc->PhysAddr)
            {
               pDev->FirstDmaDesc = &pDev->SendDmaDesc[cpt];
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwAllocDmaMem] update FirstDmaDesc @ - PhysAddr");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                            (dword)(unsigned long)pDev->FirstDmaDesc, 
                            (dword)(unsigned long)pDev->FirstDmaDesc->PhysAddr);
#endif
            }
            if (pDev->LastDmaDesc == NULL ||
                pDev->SendDmaDesc[cpt].PhysAddr > 
                pDev->LastDmaDesc->PhysAddr)
            {
               pDev->LastDmaDesc = &pDev->SendDmaDesc[cpt];
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwAllocDmaMem] update LastDmaDesc @ - PhysAddr");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                            (dword)(unsigned long)pDev->LastDmaDesc, 
                            (dword)(unsigned long)pDev->LastDmaDesc->PhysAddr);
#endif
            }
         }
      }
   }

   if (dwError != 0 && cpt < pDev->InbDataNb)
   {
      cpt--;
      for (; cpt >= 0; cpt--)
      {
         DMA_UNBIND_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_MEM(pDev, &pDev->SendDmaDesc[cpt]);
      }
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
      return(dwError);
   }

   /* allocate DMA handles for card-to-host transfer */
   for (cpt = 0; cpt < pDev->OutbDataNb && dwError == 0; cpt++)
   {
      DMA_ALLOC_HANDLE(pDev, &pDev->RecvDmaDesc[cpt]);
      if (pDev->RecvDmaDesc[cpt].PhysAddr != 0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] failed to allocate DMA handle");
#endif
         dwError = ENOMEM;
      }
   }

   wDataNb = 0;
   for (wPool = 0; 
        wPool < MAX_DRV_POOL && dwError == 0 && 
        wDataNb < pDev->OutbDataNb; 
        wPool++)
   {
      pPool = &pDev->FreeDataPools[wPool];
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwAllocDmaMem] fill data pool - index/size");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   wPool, pPool->PoolSize);
#endif
      if (wDataNb + pPool->InitCount > pDev->OutbDataNb)
      {
         pPool->InitCount = pDev->OutbDataNb - wDataNb;
      }
      /* allocate descriptors to keep track of reception buffers */
      dwError = iph_gdwNewDataDescPool(NULL,
                                       pPool,
                                       pPool->InitCount);
      wDataNb+= pPool->InitCount;
   }
   if (dwError != 0 && wPool > 0)
   {
      wPool--;
      for (;wPool >= 0; wPool--)
      {
         pPool = &pDev->FreeDataPools[wPool];
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
         {
            pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         }
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
         {
            pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         }
         pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
         pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
         pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
         pPool->TotalCount = 0;
         pPool->UsedCount = 0;
         pPool->FreeCount = 0;
         pPool->MaxUsedCount = 0;
      }
      return(dwError);
   }
   wDataNb = 0;
   for (wPool = 0; 
        wPool < MAX_DRV_POOL && dwError == 0 && 
        wDataNb < pDev->OutbDataNb; 
        wPool++)
   {
      pPool = &pDev->FreeDataPools[wPool];
      for (cpt = 0; cpt < pPool->InitCount && dwError == 0; cpt++)
      {
         pDataDesc = iph_gpGetDataDescPool(NULL, pPool);
         /* following allocation may need to be done */
         /* in a different way to get contiguous */
         /* DMA buffers */
         IPH_UNLOCK(pLock);
         DMA_ALLOC_MEM(pDev, &pDev->RecvDmaDesc[wDataNb+cpt], pPool->PoolSize, &real_len);
         IPH_LOCK(pLock);
         if (pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr == NULL)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwAllocDmaMem] failed to allocate DMA buffer");
#endif
            dwError = ENOMEM;
            break;
         }
         else
         {
            DMA_BIND_RECEIVE_HANDLE(pDev, &pDev->RecvDmaDesc[wDataNb+cpt], 
                                    pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr, 
                                    real_len);
            if (pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr == 0)
            {
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                (byte *)"[gdwAllocDmaMem] failed to bind DMA buffer");
#endif
               DMA_FREE_MEM(pDev, &pDev->RecvDmaDesc[wDataNb+cpt]);
               pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr = NULL;
               dwError = ENOMEM;
            }
            else
            {
               /* check 192MB window constraint */
               if (pDev->FirstDmaDesc != NULL &&
                   ((pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr < 
                     pDev->FirstDmaDesc->PhysAddr &&
                     (pDev->LastDmaDesc->PhysAddr - 
                      pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr) > 0xC000000) ||
                    (pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr > 
                     pDev->LastDmaDesc->PhysAddr &&
                     (pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr - 
                      pDev->FirstDmaDesc->PhysAddr) > 0xC000000)))
               {
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwAllocDmaMem] DMA buffer out of range");
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwAllocDmaMem] Recv DMA buffer - cpt/real_len/VirtAddr/PhysAddr");
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                               wDataNb+cpt, real_len);
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                               (dword)(unsigned long)pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr,
                               (dword)(unsigned long)pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr);
#endif
                  DMA_UNBIND_HANDLE(pDev, &pDev->RecvDmaDesc[wDataNb+cpt]);
                  DMA_FREE_MEM(pDev, &pDev->RecvDmaDesc[wDataNb+cpt]);
                  pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr = NULL;
                  pDataDesc->DataPtr = NULL;
                  dwError = ENOMEM;
               }
               else
               {
                  if (pDev->FirstDmaDesc == NULL ||
                      pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr < 
                      pDev->FirstDmaDesc->PhysAddr)
                  {
                     pDev->FirstDmaDesc = &pDev->RecvDmaDesc[wDataNb+cpt];
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwAllocDmaMem] update FirstDmaDesc @ - PhysAddr");
                     iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                                  (dword)(unsigned long)pDev->FirstDmaDesc, 
                                  (dword)(unsigned long)pDev->FirstDmaDesc->PhysAddr);
#endif
                  }
                  if (pDev->LastDmaDesc == NULL ||
                      pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr > 
                      pDev->LastDmaDesc->PhysAddr)
                  {
                     pDev->LastDmaDesc = &pDev->RecvDmaDesc[wDataNb+cpt];
#ifdef TRACE
                     iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                      (byte *)"[gdwAllocDmaMem] update LastDmaDesc @ - PhysAddr");
                     iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                                  (dword)(unsigned long)pDev->LastDmaDesc, 
                                  (dword)(unsigned long)pDev->LastDmaDesc->PhysAddr);
#endif
                  }
                  pDev->RecvDmaDesc[wDataNb+cpt].Index = wDataNb+cpt;
                  pDev->RecvDmaDesc[wDataNb+cpt].PoolIndex = wPool;
                  pDev->RecvDmaDesc[wDataNb+cpt].pDataDesc = pDataDesc;
                  pDev->RecvDmaDesc[wDataNb+cpt].PoolIndex = pPool->PoolIndex;
                  ((DrvDataDesc_t *)pDataDesc)->iFlags = wDataNb+cpt;
                  pDataDesc->DataPtr = pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr;
                  pDataDesc->Reserved |= DMA_BUFFER;
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwAllocDmaMem] Recv DMA buffer - cpt/VirtAddr/PhysAddr");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, 
                               wDataNb+cpt);
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                               (dword)(unsigned long)pDev->RecvDmaDesc[wDataNb+cpt].VirtAddr,
                               (dword)(unsigned long)pDev->RecvDmaDesc[wDataNb+cpt].PhysAddr);
#endif
               }
            }
         }
      }
      wDataNb+=cpt;
   }
   if (dwError != 0 && wDataNb < pDev->OutbDataNb)
   {
      wDataNb--;
      for (; wDataNb >= 0; wDataNb--)
      {
         DMA_UNBIND_HANDLE(pDev, &pDev->RecvDmaDesc[wDataNb]);
      }
      for (cpt = 0; cpt < pDev->OutbDataNb; cpt++)
      {
         DMA_FREE_MEM(pDev, &pDev->RecvDmaDesc[cpt]);
         DMA_FREE_HANDLE(pDev, &pDev->RecvDmaDesc[cpt]);
      }
      for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
      {
         pPool = &pDev->FreeDataPools[wPool];
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
         {
            pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
            if (pDrvData->Data.DataPtr != NULL)
            {
               if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
                  iph_gvMemFree(pDrvData->Data.DataPtr);
            }
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         }
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
         {
            pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
            if (pDrvData->Data.DataPtr != NULL)
            {
               if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
                  iph_gvMemFree(pDrvData->Data.DataPtr);
            }
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         }
         pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
         pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
         pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
         pPool->TotalCount = 0;
         pPool->UsedCount = 0;
         pPool->FreeCount = 0;
         pPool->MaxUsedCount = 0;
      }
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
      for (cpt = 0; cpt < pDev->InbDataNb; cpt++)
      {
         DMA_UNBIND_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_MEM(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
      }
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
   }
   return(dwError);
}

/**************************************************************************
* NAME : drv_gdwFreeDmaMem
* DESCRIPTION : free memory for DMA exchanges
* PARAMETERS :
*    Input  : pDev = pointer to the device context
* RETURN : 0 if all is OK
* REVISION :
*    - Version 1.0 : 04/05/06 Creation
**************************************************************************/
static dword drv_gdwFreeDmaMem(IphWanDevPtr pDev)
{
   dword cpt, dwError;
   word wPool;
   DrvPool_t *pPool;
   DrvDataDesc_t *pDrvData;

   dwError = 0;

   /* free everything was dynamically allocated */
   if (pDev->SendDmaDesc != NULL)
   {
      for (cpt = 0; cpt < pDev->InbDataNb; cpt++)
      {
         DMA_UNBIND_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_MEM(pDev, &pDev->SendDmaDesc[cpt]);
         DMA_FREE_HANDLE(pDev, &pDev->SendDmaDesc[cpt]);
      }
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
   }

   if (pDev->RecvDmaDesc != NULL)
   {
      for (cpt = 0; cpt < pDev->OutbDataNb; cpt++)
      {
         DMA_UNBIND_HANDLE(pDev, &pDev->RecvDmaDesc[cpt]);
         DMA_FREE_MEM(pDev, &pDev->RecvDmaDesc[cpt]);
         DMA_FREE_HANDLE(pDev, &pDev->RecvDmaDesc[cpt]);
      }
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
   }

   pDev->FirstDmaDesc = pDev->LastDmaDesc = NULL;

   for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
   {
      pPool = &pDev->FreeDataPools[wPool];
      pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
      while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
      {
         pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
         if (pDrvData->Data.DataPtr != NULL)
         {
            if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
            {
               iph_gvMemFree(pDrvData->Data.DataPtr);
            }
         }
         iph_gvMemFree(pDrvData);
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
      }
      pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
      while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
      {
         pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
         if (pDrvData->Data.DataPtr != NULL)
         {
            if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
            {
               iph_gvMemFree(pDrvData->Data.DataPtr);
            }
         }
         iph_gvMemFree(pDrvData);
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
      }
      pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
      pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
      pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
      pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
      pPool->TotalCount = 0;
      pPool->UsedCount = 0;
      pPool->FreeCount = 0;
      pPool->MaxUsedCount = 0;
   }
   return(0);
}
#endif

#ifdef SOLARIS
/**************************************************************************
* NAME : drv_gdwAllocDmaMem
* DESCRIPTION : allocate memory for DMA exchanges
* PARAMETERS :
*    Input  : pLock = protection against interrupts from this device
*    Input  : pDev = pointer to the device context
* RETURN : 0 if all is OK
*          ENOMEM if allocation failed
* REVISION :
*    - Version 1.0 : 04/05/06 Creation
*    - Version 1.1 : 06/06/29 Fix management for buffer size > PAGESIZE
**************************************************************************/
static dword drv_gdwAllocDmaMem(kmutex_t *pLock, IphWanDevPtr pDev)
{
   int iPool;
   size_t total, left, lost, real_len;
   dword AllocRecv[MAX_DRV_POOL];
   dword AllocSend = 0;
   dword SzRecv[MAX_DRV_POOL];
   dword SzSend, tSize;
   int toAlloc = pDev->InbDataNb + pDev->OutbDataNb;
   dword addr;
   DataDesc_t *pDataDesc;
   DrvDataDesc_t *pDrvData;
   int RecvNb;
   int wDataNb;
   int wPool;
   dword dwError;
   DrvPool_t *pPool;
   int cpt;

   IPH_UNLOCK(pLock);
   pDev->SendDmaDesc = 
      (DmaBuffDesc_t *)iph_gpMemAlloc(sizeof(DmaBuffDesc_t) * pDev->InbDataNb,
                                      1,ALLOC_KERNEL, 1);
   pDev->RecvDmaDesc = 
      (DmaBuffDesc_t *)iph_gpMemAlloc(sizeof(DmaBuffDesc_t) * pDev->OutbDataNb,
                                      1,ALLOC_KERNEL, 1);
   IPH_LOCK(pLock);

   if (pDev->SendDmaDesc == NULL || pDev->RecvDmaDesc == NULL)
   {
      if (pDev->SendDmaDesc != NULL)
      {
         iph_gvMemFree(pDev->SendDmaDesc);
         pDev->SendDmaDesc = NULL;
      }
      if (pDev->RecvDmaDesc != NULL)
      {
         iph_gvMemFree(pDev->RecvDmaDesc);
         pDev->RecvDmaDesc = NULL;
      }
      return(ENOMEM);
   }
   else
   {
      /* allocate DMA buffers for host-to-card transfer */
      for (cpt = 0; cpt < pDev->InbDataNb && dwError == 0; cpt++)
      {
         pDev->SendDmaDesc[cpt].Index = cpt;
      }
   }

   wDataNb = 0;
   for (wPool = 0; 
        wPool < MAX_DRV_POOL && dwError == 0 && 
        wDataNb < pDev->OutbDataNb; 
        wPool++)
   {
      pPool = &pDev->FreeDataPools[wPool];
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwAllocDmaMem] fill data pool - index/size");
      iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                   wPool, pPool->PoolSize);
#endif
      if (wDataNb + pPool->InitCount > pDev->OutbDataNb)
      {
         pPool->InitCount = pDev->OutbDataNb - wDataNb;
      }
      /* allocate descriptors to keep track of reception buffers */
      dwError = iph_gdwNewDataDescPool(NULL,
                                       pPool,
                                       pPool->InitCount);
      wDataNb += pPool->InitCount;
   }
   if (dwError != 0 && wPool > 0)
   {
      wPool--;
      for (;wPool >= 0; wPool--)
      {
         pPool = &pDev->FreeDataPools[wPool];
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
         {
            pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         }
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
         {
            pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         }
         pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
         pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
         pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
         pPool->TotalCount = 0;
         pPool->UsedCount = 0;
         pPool->FreeCount = 0;
         pPool->MaxUsedCount = 0;
      }
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
      return(dwError);
   }

   if ((pDev->MaxTransferSize & 0x80))
      SzSend = (pDev->MaxTransferSize & 0xffffff80) + 0x40;
   else
      SzSend = pDev->MaxTransferSize;
   for (iPool = 0; iPool < MAX_DRV_POOL; iPool++)
   {
      AllocRecv[iPool] = 0;
      if ((pDev->FreeDataPools[iPool].PoolSize & 0x80))
         SzRecv[iPool] = (pDev->FreeDataPools[iPool].PoolSize & 0xffffff80) + 0x40;
      else
         SzRecv[iPool] = pDev->FreeDataPools[iPool].PoolSize;

      /* to make SzRecv a multiple of  8 */
      tSize = SzRecv[iPool] % 8;
      if( tSize > 0 ) {
         SzRecv[iPool] += (8 - tSize);
      }
   }
   total = left = lost = 0;
   while (toAlloc > 0)
   {
      if (left >= SzSend && AllocSend < pDev->InbDataNb)
      {
         left -= SzSend;
         AllocSend++;
         toAlloc--;
         continue;
      }
      for (iPool = MAX_DRV_POOL - 1; iPool >= 0;)
      {
         if (left >= SzRecv[iPool] && 
             AllocRecv[iPool] < pDev->FreeDataPools[iPool].InitCount)
         {
            left -= SzRecv[iPool];
            AllocRecv[iPool]++;
            toAlloc--;
         }
         else
         {
            iPool--;
         }
      }
      if (iPool < 0 && toAlloc > 0)
      {
         if (left >= PAGESIZE)
         {
            total += PAGESIZE;
            left += PAGESIZE;
         }
         else
         {
            lost+=left;
            total += PAGESIZE;
            left = PAGESIZE;
         }
      }
   }
   lost+=left;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwAllocDmaMem] total/lost");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, total, lost);
#endif

   DMA_ALLOC_HANDLE(pDev, &pDev->DmaAreaDesc);
   if (pDev->DmaAreaDesc.PhysAddr != 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwAllocDmaMem] failed to allocate DMA handle");
#endif
      pDev->DmaAreaDesc.VirtAddr = NULL;
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
      for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
      {
         pPool = &pDev->FreeDataPools[wPool];
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
         {
            pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         }
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
         {
            pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         }
         pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
         pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
         pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
         pPool->TotalCount = 0;
         pPool->UsedCount = 0;
         pPool->FreeCount = 0;
         pPool->MaxUsedCount = 0;
      }
      return(ENOMEM);
   }
   DMA_ALLOC_MEM(pDev, &pDev->DmaAreaDesc, total, &real_len);
   if (real_len == 0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gdwAllocDmaMem] failed to allocate big DMA buffer");
#endif
      DMA_FREE_HANDLE(pDev, &pDev->DmaAreaDesc);
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
      for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
      {
         pPool = &pDev->FreeDataPools[wPool];
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
         {
            pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
         }
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
         {
            pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
            iph_gvMemFree(pDrvData);
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
         }
         pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
         pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
         pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
         pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
         pPool->TotalCount = 0;
         pPool->UsedCount = 0;
         pPool->FreeCount = 0;
         pPool->MaxUsedCount = 0;
      }
      return(ENOMEM);
   }
   else
   {
      DMA_BIND_SEND_HANDLE(pDev, &pDev->DmaAreaDesc, 
                           pDev->DmaAreaDesc.VirtAddr, 
                           real_len);
      if (pDev->DmaAreaDesc.PhysAddr == 0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwAllocDmaMem] failed to bind big DMA buffer");
#endif
         DMA_FREE_MEM(pDev, &pDev->DmaAreaDesc);
         DMA_FREE_HANDLE(pDev, &pDev->DmaAreaDesc);
         iph_gvMemFree(pDev->SendDmaDesc);
         pDev->SendDmaDesc = NULL;
         iph_gvMemFree(pDev->RecvDmaDesc);
         pDev->RecvDmaDesc = NULL;
         for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
         {
            pPool = &pDev->FreeDataPools[wPool];
            pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
            while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
            {
               pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
               iph_gvMemFree(pDrvData);
               pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
            }
            pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
            while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
            {
               pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
               iph_gvMemFree(pDrvData);
               pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
            }
            pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
            pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
            pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
            pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
            pPool->TotalCount = 0;
            pPool->UsedCount = 0;
            pPool->FreeCount = 0;
            pPool->MaxUsedCount = 0;
         }
         return(ENOMEM);
      }
      else
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                    (byte *)"[gdwAllocDmaMem] Send DMA buffer - total/real_len/VirtAddr/PhysAddr");
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, total, real_len);
         iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, 
                      (dword)pDev->DmaAreaDesc.VirtAddr,
                      (dword)pDev->DmaAreaDesc.PhysAddr);
#endif
         memset(pDev->DmaAreaDesc.VirtAddr, 0xfa, real_len);
         pDev->DmaAreaDesc.Size = real_len;
         toAlloc = pDev->InbDataNb + pDev->OutbDataNb;
         AllocSend = 0;
         for (iPool = 0; iPool < MAX_DRV_POOL; iPool++)
         {
            AllocRecv[iPool] = 0;
         }
         addr = pDev->DmaAreaDesc.PhysAddr;
         left = 0;
         RecvNb = 0;
         while (toAlloc > 0)
         {
            if (left >= SzSend && AllocSend < pDev->InbDataNb)
            {
               pDev->SendDmaDesc[AllocSend].PhysAddr = addr;
               pDev->SendDmaDesc[AllocSend].VirtAddr = pDev->DmaAreaDesc.VirtAddr + addr - pDev->DmaAreaDesc.PhysAddr;
#ifdef TRACE
               iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gdwAllocDmaMem] Send DMA buffer - indx/size/virt/phys");
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, AllocSend, SzSend);
               iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, (dword)pDev->SendDmaDesc[AllocSend].VirtAddr, addr);
#endif
               left -= SzSend;
               AllocSend++;
               toAlloc--;
               addr += SzSend;
               continue;
            }
            for (iPool = MAX_DRV_POOL - 1; iPool >= 0;)
            {
               if (left >= SzRecv[iPool] && 
                   AllocRecv[iPool] < pDev->FreeDataPools[iPool].InitCount)
               {
                  pDataDesc = iph_gpGetDataDescPool(NULL, 
                                                    &pDev->FreeDataPools[iPool]);
                  pDev->RecvDmaDesc[RecvNb].Index = RecvNb;
                  pDev->RecvDmaDesc[RecvNb].PoolIndex = iPool;
                  pDev->RecvDmaDesc[RecvNb].PhysAddr = addr;
                  pDev->RecvDmaDesc[RecvNb].VirtAddr = pDev->DmaAreaDesc.VirtAddr + addr - pDev->DmaAreaDesc.PhysAddr;
                  pDev->RecvDmaDesc[RecvNb].pDataDesc = pDataDesc;
                  pDataDesc->DataPtr = (byte *)pDev->RecvDmaDesc[RecvNb].VirtAddr;
                  ((DrvDataDesc_t *)pDataDesc)->iFlags = RecvNb;
                  pDataDesc->Reserved |= DMA_BUFFER;
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gdwAllocDmaMem] Recv DMA buffer - pool/size/indx/rindx/virt/phys");
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, iPool, SzRecv[iPool]);
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, AllocRecv[iPool], RecvNb);
                  iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2, (dword)pDev->RecvDmaDesc[RecvNb].VirtAddr, addr);
#endif
                  RecvNb++;
                  left -= SzRecv[iPool];
                  AllocRecv[iPool]++;
                  toAlloc--;
                  addr += SzRecv[iPool];
               }
               else
               {
                  iPool--;
               }
            }
            if (iPool < 0)
            {
               if (left >= PAGESIZE)
               {
                  total += PAGESIZE;
                  left += PAGESIZE;
               }
               else
               {
                  lost+=left;
#ifdef TRACE
                  iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                                   (byte *)"[gdwAllocDmaMem] new page - lost");
                  iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, left);
#endif
                  total += PAGESIZE;
                  left = PAGESIZE;
               }
            }
         }
         pDev->FirstDmaDesc = pDev->LastDmaDesc = &pDev->DmaAreaDesc;
      }
   }
   return(0);
}

/**************************************************************************
* NAME : drv_gdwFreeDmaMem
* DESCRIPTION : free memory for DMA exchanges
* PARAMETERS :
*    Input  : pDev = pointer to the device context
* RETURN : 0 if all is OK
* REVISION :
*    - Version 1.0 : 04/05/06 Creation
**************************************************************************/
static dword drv_gdwFreeDmaMem(IphWanDevPtr pDev)
{
   dword cpt, dwError;
   int real_len;
   word wPool, wDataNb;
   DrvPool_t *pPool;
   DrvDataDesc_t *pDrvData;

   dwError = 0;

   if (pDev->DmaAreaDesc.VirtAddr != NULL)
   {
      DMA_UNBIND_HANDLE(pDev, &pDev->DmaAreaDesc);
      DMA_FREE_MEM(pDev, &pDev->DmaAreaDesc);
      DMA_FREE_HANDLE(pDev, &pDev->DmaAreaDesc);
   }
   /* free everything was dynamically allocated */
   if (pDev->SendDmaDesc != NULL)
   {
      iph_gvMemFree(pDev->SendDmaDesc);
      pDev->SendDmaDesc = NULL;
   }

   if (pDev->RecvDmaDesc != NULL)
   {
      iph_gvMemFree(pDev->RecvDmaDesc);
      pDev->RecvDmaDesc = NULL;
   }

   pDev->FirstDmaDesc = pDev->LastDmaDesc = NULL;

   for (wPool = 0; wPool < MAX_DRV_POOL; wPool++)
   {
      pPool = &pDev->FreeDataPools[wPool];
      pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
      while (pDrvData != (DrvDataDesc_t *)pPool->UsedQueue)
      {
         pPool->UsedQueue[0] = (void *)pDrvData->NextItemPtr;
         if (pDrvData->Data.DataPtr != NULL)
         {
            if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
               iph_gvMemFree(pDrvData->Data.DataPtr);
         }
         iph_gvMemFree(pDrvData);
         pDrvData = (DrvDataDesc_t *)pPool->UsedQueue[0];
      }
      pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
      while (pDrvData != (DrvDataDesc_t *)pPool->FreeQueue)
      {
         pPool->FreeQueue[0] = (void *)pDrvData->NextItemPtr;
         if (pDrvData->Data.DataPtr != NULL)
         {
            if ((pDrvData->Data.Reserved & DMA_BUFFER) == 0)
               iph_gvMemFree(pDrvData->Data.DataPtr);
         }
         iph_gvMemFree(pDrvData);
         pDrvData = (DrvDataDesc_t *)pPool->FreeQueue[0];
      }
      pPool->UsedQueue[0] = (void *)pPool->UsedQueue;
      pPool->UsedQueue[1] = (void *)pPool->UsedQueue;
      pPool->FreeQueue[0] = (void *)pPool->FreeQueue;
      pPool->FreeQueue[1] = (void *)pPool->FreeQueue;
      pPool->TotalCount = 0;
      pPool->UsedCount = 0;
      pPool->FreeCount = 0;
      pPool->MaxUsedCount = 0;
   }
   return(0);
}
#endif

/**************************************************************************
* NAME : drv_gvReleaseDrvPrim
* DESCRIPTION : release a driver primitive
* PARAMETERS :
*    Input   : pLock = protection against interrupts for this device
*    Input   : pAppli = application context
*    Input   : pDev = device context
*    Input   : pPrim = primitive
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void drv_gvReleaseDrvPrim(kmutex_t *pLock, ApplCtxtPtr pAppli, 
                                 IphWanDevPtr pDev, PrimDesc_t *pPrim)
{
   DataDesc_t *pDesc;
   DataDesc_t *pNextDesc;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvReleaseDrvPrim] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF, 
                pPrim->PrimId, pPrim->PrimRef); 
#endif

   if (pAppli != NULL && pAppli->Type == TYPE_KERNEL)
   {
      if ((pPrim->PrimInPool & 0xFF) == SENT_PRIM)
      {
         pPrim->PrimInPool = 0;
         pAppli->kd_free(pAppli->Backref, pAppli->Minor, SENT_PRIM,
                         (void *)pPrim);
         return;
      }
   }

   pDesc = pPrim->DataDescPtr;
   while (pDesc != NULL)
   {
      pNextDesc = pDesc->NextPtr;

      /* if the buffer must be given back to the controller */
      if ((pDesc->Reserved & DMA_BUFFER) != 0)
      {
         IPH_LOCK(pLock);
         /* add buffer in the card pool */
         GIVE_BUFF_TO_CARD(pDev, 
                           &pDev->RecvDmaDesc[((DrvDataDesc_t *)pDesc)->iFlags]);
         IPH_UNLOCK(pLock);
      }
      else if ((pDesc->Reserved & USER_BUFFER) != 0)
      {
         pDesc->DataPtr = NULL;
         iph_gvPutDataDescPool(pLock,
                               &pDev->FreeDataDescPool,
                               (DrvDataDescPtr)pDesc);
      }
      else if ((pDesc->Reserved & KERN_BUFFER) != 0 && pAppli != NULL)
      {
         iph_gvPutPool(NULL, 
                       &pAppli->FreeDataPools[pDesc->Reserved & 0xFF],
                       (PoolItemPtr)pDesc);
      }
      else
      {
         iph_gvPutDataDescPool(pLock,
                               &pDev->FreeDataPools[pDesc->Reserved & 0xFF],
                               (DrvDataDescPtr)pDesc);
      }

      pDesc = pNextDesc;
   }

   /* release the primitive header */
   if (pAppli != NULL && pAppli->Type == TYPE_KERNEL &&
       (pPrim->PrimInPool & 0xFF) == KERN_BUFFER)
   {
      iph_gvPutPool(NULL, 
                    &pAppli->FreePrimHeadPool,
                    (PoolItemPtr)pPrim);
   }
   else
   {
      iph_gvPutPrimPool(pLock,
                        &pDev->FreePrimHeadPool,
                        (DrvPrimDescPtr)pPrim);
   }


#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvReleaseDrvPrim] return");
#endif
}

/**************************************************************************
* NAME : drv_gvPurgeAppliSession
* DESCRIPTION : free all pending primitives for a session
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pAppli = application context
*    Input   : wSession = session number (logical number)
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
*    - Version 1.1 : 09/05/06 Creation
*       - Swap the received session with uses host format while primitives 
*         stored in the reception queue uses Big Endian. 
*         In addition, it does not free any MGR_USER_CLOSED.
*       - extract all the relevant primitives under protection of the 
*         application mutex before releasing them (under protection of the 
*         device mutex)
**************************************************************************/
static void drv_gvPurgeAppliSession(kmutex_t *pLock, ApplCtxtPtr pAppli, 
                                    word wSession)
{
   PrimDesc_t        *pPrim;
   PrimDesc_t        *pNextPrim;
   IphWanDevPtr      pWanDev;
   word wRealSession = HOST_CARD16(wSession);
   word wRealPrimId  = HOST_CARD16((MGR_PRIM + MGR_USER_CLOSED));
   PrimDesc_t        *pFirstPrim = NULL;
   PrimDesc_t        *pLastPrim = NULL;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPurgeAppliSession] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_APPLI_SESSION,
                pAppli->Minor, (wSession));
#endif

   MUTEX_ENTER(&pAppli->AppliMutex);

   pWanDev = pAppli->WanDevPtr;
   pPrim = (PrimDesc_t *)pAppli->RecvQueue.FirstPtr;
   while (pPrim != NULL && pPrim != (PrimDesc_t *)&pAppli->RecvQueue)
   {
      pNextPrim = pPrim->NextPtr;

      if (pPrim->PrimRef == wRealSession && pPrim->PrimId != wRealPrimId) 
      {
         iph_gvExtractQueue(NULL, &pAppli->RecvQueue,
                            (QueueItemPtr)pPrim);
         pAppli->RecvNb--;

         pPrim->NextPtr = NULL;
         if (pFirstPrim == NULL)
         {
            pFirstPrim = pPrim;
         }
         else
         {
            pLastPrim->NextPtr = pPrim;
         }
         pLastPrim = pPrim;
      }
      pPrim = pNextPrim;
   }
   MUTEX_EXIT(&pAppli->AppliMutex);

   while (pFirstPrim != NULL)
   {
      pPrim = pFirstPrim;
      pFirstPrim = pFirstPrim->NextPtr;
      iph_gvReleaseDrvPrim(pLock, pAppli, pWanDev, pPrim);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvPurgeAppliSession] return");
#endif
}

/**************************************************************************
* NAME : drv_gvSendPrimToAppli
* DESCRIPTION : send a primitive to an application and notify it
* PARAMETERS :
*    Input   : pAppli = application context
*    Input   : pPrim = primitive to send
*    Input   : pCorr = session correlator involved
* RETURN : none
* NOTE : this function is always called without any mutex hold
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void drv_gvSendPrimToAppli(ApplCtxtPtr pAppli, PrimDescPtr pPrim, 
                                  MGRSessionCorrPtr pCorr)
{
   UserErrPtr pErr;
   word wErrId = 0;
   IphWanDevPtr pDev = pAppli->WanDevPtr;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvSendPrimToAppli] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                pAppli->WanDevPtr->Index, pAppli->Minor);
#endif

   if (pPrim->PrimId == (MGR_PRIM|MGR_USER_ERR))
   {
      pErr = (UserErrPtr)pPrim->PrimInfo;
      wErrId = pErr->Id;
      wErrId = HOST_CARD16(wErrId);
   }

   /* if the session is closed, update the correlator hash table */
   /* Check also received MGR_USER_ERR in response to MGR_OPEN_USER */
   if (((pPrim->PrimId) == (MGR_PRIM + MGR_USER_CLOSED)) ||
       ((pPrim->PrimId) == (MGR_PRIM|MGR_USER_ERR) &&
        (wErrId == (MGR_PRIM | MGR_OPEN_USER))))
   {
      /* for a KERNEL application we must ensure that the corresponding */
      /* sent MGR_CLOSE_USER primitive has been given back to the application */
      pDev->Rsrc->ReleaseP2LTransfer(&pDev->DevMutex, pDev);

   }

   MUTEX_ENTER(&pAppli->AppliMutex);
   /* restore Big Endian values */
   pPrim->PrimId = HOST_CARD16(pPrim->PrimId);
   pPrim->PrimRef = HOST_CARD16(pPrim->PrimRef);

   iph_gvPutQueue(NULL, &pAppli->RecvQueue, (QueueItemPtr)pPrim);
   pAppli->RecvNb++;
   MUTEX_EXIT(&pAppli->AppliMutex);

   /* wakeup the application */
   if (pAppli->Type == TYPE_USER)
   {
#ifdef LINUX
      wake_up_interruptible(&pAppli->Pollhead);
#endif
#ifdef SOLARIS
      pollwakeup(&pAppli->Pollhead, POLLRDBAND);
#endif
   }
   else
   {
      pAppli->kd_wakeup(pAppli->Backref, pAppli->Minor);
   }

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvSendPrimToAppli] return");
#endif
}

/**************************************************************************
* NAME : drv_gvCloseAppliSession
* DESCRIPTION : close a session on this adapter and notify the application
* PARAMETERS :
*    Input   : pLock = protection against interrupts from this device
*    Input   : pWanDev = adapter context
*    Input   : pCorr = session correlator
*    Input   : wDiag = diagnostic to send to the application
* RETURN : none
* REVISION :
*    - Version 1.0 : 10/20/05 Creation
**************************************************************************/
static void drv_gvCloseAppliSession(kmutex_t *pLock, IphWanDevPtr pWanDev, 
                                    MGRSessionCorrPtr pCorr, word wDiag)
{
   PrimDescPtr pPrim;

#ifdef TRACE
   iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,
                    (byte *)"[gvCloseAppliSession] entry");
   iph_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_SESSION, pWanDev->Index,
                SWAP16(pCorr->CardMGRSession));
#endif

   /* send session closure to the application */
   IPH_LOCK(pLock);
   if (pCorr->AppliPtr != (ApplCtxtPtr)0 && pCorr->OpenPrim != (PrimDescPtr)0)
   {
#ifdef TRACE
      iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                       (byte *)"[gvCloseAppliSession] force application session closure");
#endif
      pPrim = pCorr->OpenPrim;
      pCorr->OpenPrim = (PrimDescPtr)0;
      pCorr->AppliReady = 0;
      IPH_UNLOCK(pLock);
      pPrim->PrimId = MGR_PRIM + MGR_USER_CLOSED;
      pPrim->PrimRef = pCorr->LogicalMGRSession;
      *(word *)&pPrim->PrimInfo[4] = NET_SWAP16(wDiag);
      pPrim->DataDescPtr = (DataDesc_t *)0;
      if (pLock == NULL)
         MUTEX_EXIT(&pWanDev->DevMutex);
      iph_gvSendPrimToAppli(pCorr->AppliPtr, pPrim, pCorr);
      if (pLock == NULL)
         MUTEX_ENTER(&pWanDev->DevMutex);
   }
   else
   {
      IPH_UNLOCK(pLock);
   }

   /*if (pCorr->Status != SESS_CLOSED &&
       pCorr->Status != SESS_CLOSING)*/
   if ((pCorr->Status != SESS_CLOSED && pCorr->Status != SESS_CLOSING) &&
       (pWanDev->Status == CARD_LOADED || pWanDev->Status == CARD_RUNNING))
   {
      pPrim = iph_gpGetPrimPool(pLock,
                                &pWanDev->FreePrimHeadPool);
      if (pPrim == (PrimDescPtr)0)
      {
#ifdef TRACE
         iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"[gvCloseAppliSession] not enough memory to close session");
#endif
         /* display error on console */
         iph_TRACEK(TRCLVL_0,
                    DRIVER_NAME" device %d - NO AVAILABLE PRIM to abort session",
                    pWanDev->Index);
         iph_TRACEK(TRCLVL_0,
                    DRIVER_NAME" => check pool size %d",
                    pWanDev->FreePrimHeadPool.MaxCount);
      }
      else
      {
         pPrim->PrimId = MGR_PRIM + MGR_CLOSE_USER;
         pPrim->PrimRef = pCorr->CardMGRSession;
         memset(pPrim->PrimInfo, 0,MAX_PRIM_INFO);
         pPrim->DataDescPtr = (DataDesc_t *)0;
         pPrim->BuffInPool = 0;
         if (pWanDev->Rsrc->CardSendPrim(pLock, pWanDev, NULL, pPrim) != 0)
         {
#ifdef TRACE
            iph_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"[gvCloseAppliSession] failed to close session");
            iph_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_ARGVAL, pWanDev->SendPending);
#endif
            /*iph_TRACEK(TRCLVL_0,
                       DRIVER_NAME" Failed to close session %d (SendPending %d)",
                       pCorr->CardMGRSession, pWanDev->SendPending);*/
            /* release the primitive structure and its attached buffers */
            iph_gvReleaseDrvPrim(pLock, NULL, pWanDev, pPrim);
         }
      }
   }
}

