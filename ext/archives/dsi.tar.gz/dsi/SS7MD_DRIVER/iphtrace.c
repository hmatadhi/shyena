/****************************************************************************
 * (C) Copyright Interphase Corp 2005-2010.
 *
 * NAME : iphtrace.c
 * VERSION : 1.08.2
 * DESCRIPTION : 
 *    Tracing routines
 * REVISIONS :
 *    - Version 1.00 10/09/05 : Creation
 *    - Version 1.01 02/14/06 : Add display for CTL_RESET_BOARD
 *    - Version 1.02 04/24/06 
 *         - Add the IPHWAN_SVRDATA_ID module id management to isolate SVR 
 *           traffic display from normal traffic display in iph_gvDumpPrim
 *    - Version 1.03 06/22/06 : Fix filter on IPHWAN_SVRDATA_ID traces
 *    - Version 1.04 06/29/06 : SVR primitives are dumped only if 
 *                              IPHWAN_SVRDATA_ID mask is active
 *                              Other primitives are dumped with IPHWAN_DATA_ID
 *    - Version 1.05 07/12/2006 : - Use MUTEX_xx and CV_xx macros
 *    - Version 1.06 04/12/2007 : Add the CTL_GIVE_RX_DATA_BUFFER debug trace
 *                                Add the CTL_WRITE_CORE_REG debug trace
 *                                Add the CTL_DUMP_CORE_REG debug trace
 *    - Version 1.07 06/25/08 : Add the IPHWAN_DATA_PRIM_ID module id
 *                              Rename IPHWAN_DATA_ID into IPHWAN_OTHER_PRIM_ID
 *                              Rename IPHWAN_SVRDATA_ID into IPHWAN_SVR_PRIM_ID
 *    - Version 1.08 01/29/09 : Add ioctl cmd decoding for :
 *                                 - CTL_GET_CUSTOM_INFO
 *                                 - CTL_GET_TIME
 *                                 - CTL_SET_HOST_TIME_OFFSET
 *    - Version 1.08.1 05/25/09 : Add ioctl cmd decoding for :
 *                                 - CTL_GET_TEMP_INFO
 *    - Version 1.08.2 07/05/10 : Add ioctl cmd decoding for :
 *                                 - CTL_DUMP_SEEPROM_BYTE
 *                                 - CTL_WRITE_SEEPROM_BYTE
 * FUNCTIONS LIST :
 *    Local functions :
 *       bPrepareTrace
 *    Public functions :
 *       drv_TRACE_NO_PARAM
 *       drv_TRACE_D1
 *       drv_TRACE_D2
 *       drv_TRACE_STRING
 *       drv_TRACE_STRUCT
 *       drv_TRACE_PACKET
 *       drv_gvDumpDrvPool
 *       drv_gvDumpIoctlCmd
 *       drv_gvDumpPrim
 *    
 ****************************************************************************/
#define IPHTRACE_C
#include "iphwan.h"
#include "wanapi.h"
#include "iphwantr.h"
#include "iphtrace.h"

#ifdef DEBUG_INIT
/*#define DEBUG_START 1*/
#endif

/**************************************************************************
* NAME : bPrepareTrace
* DESCRIPTION : prepare the trace buffer to receive a new trace
* PARAMETERS :
*    Input   : wLen = length of the trace data
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static byte bPrepareTrace(word wLen)
{
   TraceBuffHead_t *pTraceHead;
   TrcMsg_t *pFirst;
   TrcMsg_t *pLast;
   byte *pucLastTrace;       /* pointer to the last trace structure */

   pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;
   pucLastTrace = &iph_gpucTrace[pTraceHead->LastTrace];

   /* ATTENTION: the structures must be aligned */
   if ((wLen & (sizeof(dword) - 1)) != 0)
   {
      wLen = (wLen & ~(sizeof(dword) - 1)) + sizeof(dword);
   }

   /* checks the new trace length */
   if (wLen + sizeof(TrcMsg_t) + sizeof(TraceBuffHead_t) + 32 > 
       pTraceHead->Size)
   {
      return(FALSE);
   }

   /* get pointer to the last trace structure */
   pLast = (TrcMsg_t *)pucLastTrace;

   /* if there is no trace in the buffer, return TRUE right now */
   if (pTraceHead->FirstTrace == pTraceHead->LastTrace &&
       pLast->TraceType == NO_TRC)
   {
      pTraceHead->FirstTrace = sizeof(TraceBuffHead_t);
      pTraceHead->LastTrace = sizeof(TraceBuffHead_t);
      pLast = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pLast->NextPtr = pTraceHead->LastTrace;
      pLast->TraceType = NO_TRC;
      return(TRUE);
   }

   if (pTraceHead->FirstTrace <= pTraceHead->LastTrace)
   {
      /* case 1: FirstTrace < LastTrace */
      /*       & new trace can be added at the end of the buffer */
      if ((pTraceHead->LastTrace + 2 * sizeof(TrcMsg_t) + pLast->Len + wLen) < 
          (pTraceHead->Size - 32))
      {
         pLast->NextPtr = 
            pTraceHead->LastTrace + sizeof(TrcMsg_t) + pLast->Len;
         /* ATTENTION: the structures must be aligned */
         if ((pLast->NextPtr & (sizeof(dword) - 1)) != 0)
         {
            pLast->NextPtr = (pLast->NextPtr & ~(sizeof(dword) - 1)) + sizeof(dword);
         }
         return(TRUE);
      }
      else
      {
         /* case 2: FirstTrace < LastTrace */
         /*       & there is no place for the trace at the end of the buffer*/
         /*       & there is space enough to put it at the beginning of the */
         /*         buffer*/
         if (pTraceHead->FirstTrace - sizeof(TraceBuffHead_t) > sizeof(TrcMsg_t) + wLen)
         {
            /* Next trace will be stored at the beginning of the buffer */
            pLast->NextPtr = sizeof(TraceBuffHead_t);
            return(TRUE);
         }
         else
         {
            /* case 3: FirstTrace < LastTrace */
            /*       & there is no place for the trace at the end of the */
            /*         buffer */
            /*       & there is no space enough at the beginning of the */
            /*         buffer*/

            /* if the buffer is CIRCULAR we must delete some trace */
            if (pTraceHead->Method == CIRCULAR)
            {
               /* case 4: adding this new trace results in deleting all the */
               /* existing traces => reset FirstTrace and LastTrace */
               /* ATTENTION: the calling routine must check this case */
               /* not to update LastTrace */
               if (sizeof(TrcMsg_t) + wLen > pTraceHead->LastTrace)
               {
                  pTraceHead->FirstTrace = sizeof(TraceBuffHead_t);
                  pTraceHead->LastTrace = sizeof(TraceBuffHead_t);
                  pFirst = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->FirstTrace];
                  pFirst->TraceType = NO_TRC;
                  pFirst->NextPtr = pTraceHead->LastTrace;
                  return(TRUE);
               }

               while (pTraceHead->FirstTrace - sizeof(TraceBuffHead_t) <= wLen + sizeof(TrcMsg_t))
               {
                  pFirst = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->FirstTrace];
                  pFirst->TraceType = NO_TRC;
                  pTraceHead->FirstTrace = pFirst->NextPtr;
               }
               pLast->NextPtr = sizeof(TraceBuffHead_t);
               return(TRUE);
            }
            else
            {
               /* we can't store the new trace */
               return(FALSE);
            }
         }
      }
   }
   else
   {
      /* case 5: FirstTrace > LastTrace */
      /*       & there is space enough to put it after the last trace */
      if (pTraceHead->FirstTrace > 
          pTraceHead->LastTrace + 2 * sizeof(TrcMsg_t) + pLast->Len + wLen)
      {
         pLast->NextPtr = 
            pTraceHead->LastTrace + sizeof(TrcMsg_t) + pLast->Len;
         /* ATTENTION: the structures must be aligned */
         if ((pLast->NextPtr & (sizeof(dword) - 1)) != 0)
         {
            pLast->NextPtr = (pLast->NextPtr & ~(sizeof(dword) - 1)) + sizeof(dword);
         }
         return(TRUE);
      }
      else
      {
         /* case 6: FirstTrace > LastTrace */
         /*       & there is no space enough to put it after the last trace */
         /*       & there is space between the last trace and the end of */
         /*         buffer*/
         if (pTraceHead->Size -32 >
             pTraceHead->LastTrace + 2* sizeof(TrcMsg_t) + pLast->Len + wLen)
         {
            /* if the buffer is CIRCULAR we must delete some trace */
            if (pTraceHead->Method == CIRCULAR)
            {
               while (pTraceHead->FirstTrace > sizeof(TraceBuffHead_t) &&
                      pTraceHead->FirstTrace <
                      (pTraceHead->LastTrace + 2 * sizeof(TrcMsg_t) + 
                       pLast->Len + wLen))
               {
                  pFirst = 
                     (TrcMsg_t *)&iph_gpucTrace[pTraceHead->FirstTrace];
                  pFirst->TraceType = NO_TRC;
                  pTraceHead->FirstTrace = pFirst->NextPtr;
               }
               pLast->NextPtr = 
                  pTraceHead->LastTrace + sizeof(TrcMsg_t) + pLast->Len;
               /* ATTENTION: the structures must be aligned */
               if ((pLast->NextPtr & (sizeof(dword) - 1)) != 0)
               {
                  pLast->NextPtr = (pLast->NextPtr & ~(sizeof(dword) - 1)) + sizeof(dword);
               }
               return(TRUE);
            }
            else
            {
               /* we can't store the new trace */
               return(FALSE);
            }
         }
         else
         {
            /* case 7: FirstTrace > LastTrace */
            /*       & there is no space enough to put it after the last */
            /*         trace */
            /*       & there is no space between the last trace and the end */
            /*         of the buffer*/

            /* if the buffer is CIRCULAR we must delete some trace */
            if (pTraceHead->Method == CIRCULAR)
            {
               /* case 8: adding this new trace results in deleting all the */
               /* existing traces => reset the FirstTrace and LastTrace */
               /* fields*/
               /* ATTENTION: the calling routine must check this case */
               /* not to update LastTrace */
               if (sizeof(TrcMsg_t) + wLen > pTraceHead->LastTrace)
               {
                  pTraceHead->FirstTrace = sizeof(TraceBuffHead_t);
                  pTraceHead->LastTrace = sizeof(TraceBuffHead_t);
                  pFirst = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->FirstTrace];
                  pFirst->TraceType = NO_TRC;
                  pFirst->NextPtr = pTraceHead->LastTrace;
                  return(TRUE);
               }

               /* FirstTrace must be updated until there is space enough */
               /* at the beginning of the buffer */
               /* first we jump directly to the beginning of the buffer */
               pTraceHead->FirstTrace = sizeof(TraceBuffHead_t);
               while (pTraceHead->FirstTrace - sizeof(TraceBuffHead_t) <= 
                      sizeof(TrcMsg_t) + wLen)
               {
                  pFirst = 
                     (TrcMsg_t *)&iph_gpucTrace[pTraceHead->FirstTrace];
                  pFirst->TraceType = NO_TRC;
                  pTraceHead->FirstTrace = pFirst->NextPtr;
               }
               /* the next trace will be stored at the beginning of the */
               /* buffer */
               pLast->NextPtr = sizeof(TraceBuffHead_t);
               return(TRUE);
            }
            else
            {
               /* we can't store the new trace */
               return(FALSE);
            }
         }
      }
   }
}

/**************************************************************************
* NAME : drv_TRACE_NO_PARAM
* DESCRIPTION : add a new trace with no extra parameter
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_NO_PARAM(byte module_id, byte trace_type, word trace_id)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_NO(%d-%d)", module_id, trace_id);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_NO(%d-%d)", module_id, trace_id);
#endif
   }

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (bPrepareTrace(0) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_NO_PARAM;
      pTrc->Len = 0;

      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_TRACE_D1
* DESCRIPTION : add a new trace with one integer to dump
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
*    Input   : data = integer to dump
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_D1(byte module_id, byte trace_type, word trace_id, 
                          dword data)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_D1(%d-%d): 0x%lx", module_id, trace_id, data);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_D1(%d-%d): 0x%lx", module_id, trace_id, data);
#endif
   }

   pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (bPrepareTrace(sizeof(dword)) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_D1;
      pTrc->Len = sizeof(dword);
      bcopy(&data, &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t)],
            sizeof(dword));
      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_TRACE_D2
* DESCRIPTION : add a new trace with two integers to dump
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
*    Input   : data1 = first integer to dump
*    Input   : data2 = second integer to dump
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_D2(byte module_id, byte trace_type, word trace_id,
                          dword data1, dword data2)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_D2(%d-%d): 0x%lx 0x%lx", module_id, trace_id,
                 data1, data2);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_D2(%d-%d): 0x%lx 0x%lx", module_id, trace_id,
                 data1, data2);
#endif
   }

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (bPrepareTrace(2 * sizeof(dword)) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_D2;
      pTrc->Len = 2 * sizeof(dword);
      bcopy(&data1, &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t)],
            sizeof(dword));
      bcopy(&data2,
            &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t) + sizeof(dword)],
            sizeof(dword));
      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_TRACE_STRING
* DESCRIPTION : add a new trace with a string to dump
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
*    Input   : len = length of data to dump (if len = 0, we take strlen(data))
*    Input   : data = data to dump
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_STRING(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_STR(%d-%d): %s", module_id, trace_id, buf);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_STR(%d-%d): %s", module_id, trace_id, buf);
#endif
   }

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (len == 0)
      len = strlen((char *)buf) + 1;

   if (bPrepareTrace(len) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_STRING;
      pTrc->Len = len;
      bcopy(buf, &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t)], len);
      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_TRACE_STRUCT
* DESCRIPTION : add a new trace with a structure to dump
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
*    Input   : len = length of data to dump
*    Input   : data = data to dump
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_STRUCT(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_STRUCT(%d-%d): len %d", module_id, trace_id,
                 len);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_STRUCT(%d-%d): len %d", module_id, trace_id,
                 len);
#endif
   }

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (bPrepareTrace(len) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_STRUCT;
      pTrc->Len = len;
      bcopy(buf, &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t)], len);
      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_TRACE_PACKET
* DESCRIPTION : add a new trace with a packet to dump
* PARAMETERS :
*    Input   : module_id = module that generates the message
*    Input   : trace_type = EVT, TRC, or ERR
*    Input   : trace_id = trace identifier
*    Input   : len = length of data to dump
*    Input   : data = data to dump
* RETURN : 0 if the trace could be added, 1 else
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static dword drv_TRACE_PACKET(byte module_id, byte trace_type, word trace_id,
                              word len, byte *buf)
{
   TrcMsg_t *pTrc;
   dword dwError;
   TraceBuffHead_t *pTraceHead;

   /* check whether the traces are active */
   if (iph_gpucTrace == (byte *)0)
   {
#ifdef DEBUG_START
      iph_TRACEK(TRCLVL_2, "BD_PKT(%d-%d): len %d", module_id, trace_id,
                 len);
#endif
      return(1);
   }
   else
   {
#ifdef DEBUG_CONSOLE
      iph_TRACEK(TRCLVL_2, "BD_PKT(%d-%d): len %d", module_id, trace_id,
                 len);
#endif
   }

   /* enter in critical section */
   MUTEX_ENTER(&iph_gTraceMutex);

   if (bPrepareTrace(len) == TRUE)
   {
      pTraceHead = (TraceBuffHead_t *)iph_gpucTrace;

      /* the current last trace points to the location where to store the */
      /* trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];

      /* update the pointer to the last trace */
      pTraceHead->LastTrace = pTrc->NextPtr;

      /* store the trace */
      pTrc = (TrcMsg_t *)&iph_gpucTrace[pTraceHead->LastTrace];
      pTrc->NextPtr = 0;
      pTrc->ModuleId = module_id;
      pTrc->TraceType = trace_type;
      pTrc->TraceId = trace_id;
      IPH_GET_TIME(&pTrc->TimeStamp);
#ifdef SOLARIS
      IPH_GET_UTIME(&pTrc->UTimeStamp);
#endif
      pTrc->FnType = FN_TRACE_PACKET;
      pTrc->Len = len;
      bcopy(buf, &iph_gpucTrace[pTraceHead->LastTrace + sizeof(TrcMsg_t)], len);
      dwError = 0;
   }
   else
   {
      dwError = 1;
   }

   MUTEX_EXIT(&iph_gTraceMutex);

   return(dwError);
}

/**************************************************************************
* NAME : drv_gvDumpDrvPool
* DESCRIPTION : dump the status of a driver pool
* PARAMETERS :
*    Input   : pPool = address of the driver pool
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvDumpDrvPool(DrvPoolPtr pPool)
{
#ifdef TRACE
   drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0, (byte *)"DUMP OF POOL");
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_POOL_SIZE, pPool->PoolSize);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_INIT_COUNT, pPool->InitCount);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_MAX_COUNT, pPool->MaxCount);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_TOTAL_COUNT, pPool->TotalCount);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_USED_COUNT, pPool->UsedCount);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_FREE_COUNT, pPool->FreeCount);
   drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_MAX_USED_COUNT, pPool->MaxUsedCount);
#endif
}

/**************************************************************************
* NAME : drv_gvDumpIoctlCmd
* DESCRIPTION : dump the type of ioctl
* PARAMETERS :
*    Input   : dwCmd = type of command
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
**************************************************************************/
static void drv_gvDumpIoctlCmd(dword dwCmd)
{
#ifdef TRACE
   switch (dwCmd)
   {
      case CTL_CLOSE_DEVICE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_CLOSE_DEVICE");
         break;

      case CTL_SEND_PRIM:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_SEND_PRIM");
         break;

      case CTL_GIVE_RX_PRIM:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GIVE_RX_PRIM");
         break;

      case CTL_GIVE_RX_BUFFER:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GIVE_RX_BUFFER");
         break;

      case CTL_GIVE_RX_DATA_BUFFER:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GIVE_RX_DATA_BUFFER");
         break;

      case CTL_RECV_PRIM:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_RECV_PRIM");
         break;

      case CTL_MAX_RX_QUEUE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_MAX_RX_QUEUE");
         break;

      case CTL_MAX_RX_CHAIN:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_MAX_RX_CHAIN");
         break;

      case CTL_NO_OF_DEVICES:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_NO_OF_DEVICES");
         break;

      case CTL_GET_CARD_ID:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CARD_ID");
         break;

      case CTL_GET_CONTROL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CONTROL");
         break;

      case CTL_GET_CONTROL_DBG:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CONTROL_DBG");
         break;

      case CTL_FREE_CONTROL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_FREE_CONTROL");
         break;

      case CTL_DUMP_MEM:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_MEM");
         break;

      case CTL_WRITE_MEM:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_MEM");
         break;

      case CTL_DUMP_PLX_REG:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_PLX_REG");
         break;

      case CTL_WRITE_PLX_REG:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_PLX_REG");
         break;

      case CTL_DUMP_PCI_CONF:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_PCI_CONF");
         break;

      case CTL_WRITE_PCI_CONF:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_PCI_CONF");
         break;

      case CTL_GET_DRV_VER:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_DRV_VER");
         break;

      case CTL_DUMP_CPU_USAGE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_CPU_USAGE");
         break;

      case CTL_DUMP_POOL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_POOL");
         break;

      case CTL_DUMP_DRV_POOL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_DRV_POOL");
         break;

      case CTL_DUMP_SEEPROM_BYTE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_SEEPROM_BYTE");
         break;

      case CTL_WRITE_SEEPROM_BYTE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_SEEPROM_BYTE");
         break;

      case CTL_MAX_TRANSFER_SIZE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_MAX_TRANSFER_SIZE");
         break;

      case CTL_INIT_PRIM_POOL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_INIT_PRIM_POOL");
         break;

      case CTL_INIT_BUFFER_POOL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_INIT_BUFFER_POOL");
         break;

      case CTL_INIT_MAX_APPLI:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_MAX_APPLI");
         break;

      case CTL_INIT_MAX_SESSION:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_MAX_SESSION");
         break;

      case CTL_INIT_DRV_TRACE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_INIT_DRV_TRACE");
         break;

      case CTL_START_DRV_TRACE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_START_DRV_TRACE");
         break;

      case CTL_STOP_DRV_TRACE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_STOP_DRV_TRACE");
         break;

      case CTL_DUMP_DRV_TRACE:
           /* drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                               (byte *)"CTL_DUMP_DRV_TRACE");*/
           break;

      case CTL_DUMP_TRACE:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_TRACE");
         break;

      case CTL_GET_STATUS:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_STATUS");
         break;

      case CTL_GET_CARD_STATUS:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CARD_STATUS");
         break;

      case CTL_SET_CARD_STATUS:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_SET_CARD_STATUS");
         break;

      case CTL_GET_CARD_RSRC:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CARD_RSRC");
         break;

      case CTL_GET_USING_APPLI:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_USING_APPLI");
         break;

      case CTL_CHECK_CARD_STATUS:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_CHECK_CARD_STATUS");
         break;

      case CTL_READ_FLASH:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_READ_FLASH");
         break;

      case CTL_WRITE_FLASH:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_FLASH");
         break;

      case CTL_WRITE_CORE_REG:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_WRITE_CORE_REG");
         break;

      case CTL_DUMP_CORE_REG:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_CORE_REG");
         break;

      case CTL_RESET_BOARD:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_RESET_BOARD");
         break;

      case CTL_DUMP_HOST:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_DUMP_HOST");
         break;

      case CTL_RESET_HOST_STAT:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_RESET_HOST_STAT");
         break;

      case CTL_TRACE_CONSOLE_LEVEL:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_TRACE_CONSOLE_LEVEL");
         break;

      case CTL_GET_CUSTOM_INFO:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_CUSTOM_INFO");
         break;

      case CTL_GET_TIME:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_TIME");
         break;

      case CTL_SET_HOST_TIME_OFFSET:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_SET_HOST_TIME_OFFSET");
         break;

      case CTL_GET_TEMP_INFO:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"CTL_GET_TEMP_INFO");
         break;

      default:
         drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                          (byte *)"unknown command");
         break;
   }
#endif
}

/**************************************************************************
* NAME : drv_gvDumpPrim
* DESCRIPTION : dump a primitive content
* PARAMETERS :
*    Input   : pPrim = primitive to dump
*    Input   : pDev = device involved
*    Input   : pAppli = application involved
*    Input   : bSent = flag set to TRUE when the primitive is sent
* RETURN : none
* REVISION :
*    - Version 1.0 : 12/01/05 Creation
*    - Version 1.01: 04/24/06 
*         - Add the IPHWAN_SVRDATA_ID module id management to isolate SVR 
*           traffic display from normal traffic display in iph_gvDumpPrim
*    - Version 1.02 06/29/06 : 
*         - SVR primitives are dumped only if IPHWAN_SVRDATA_ID mask is active
*         - Other primitives are dumped with IPHWAN_DATA_ID
**************************************************************************/
static void drv_gvDumpPrim(PrimDescPtr pPrim, IphWanDevPtr pDev, 
                           ApplCtxtPtr pAppli, byte bSent)
{
   dword dwTotalLength;
   DataDescPtr pDesc;
   dword dwDevIndex;
   dword dwMinor;
   byte *pData;
   byte pucBuff[100];
   word wSize;
   dword dwError;
   byte  ModuleId=IPHWAN_ID;

#ifdef TRACE
   switch ( pPrim->PrimId & 0xFF00 )
   {
      case DATA_PRIM:
         if ( iph_gpucTraceMask[IPHWAN_DATA_PRIM_ID] == TRUE )
            ModuleId = IPHWAN_DATA_PRIM_ID;
         break;
      case SVR_PRIM:
         if ( iph_gpucTraceMask[IPHWAN_SVR_PRIM_ID] == TRUE )
            ModuleId = IPHWAN_SVR_PRIM_ID;
         break;
      default:
         if ( iph_gpucTraceMask[IPHWAN_OTHER_PRIM_ID] == TRUE )
            ModuleId = IPHWAN_OTHER_PRIM_ID;
         break;
   }

   if ( ModuleId == IPHWAN_ID )
   {
      if ( iph_gpucTraceMask[IPHWAN_ID] == TRUE )
      {
         if (bSent == TRUE)
            drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)">>>>> SEND PRIMITIVE >>>>>");
         else
            drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"<<<<< RECV PRIMITIVE <<<<<");
         if (pAppli != NULL)
            drv_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_DEV_MINOR, 
                         pAppli->WanDevPtr->Index, pAppli->Minor);
         else
         {
            if (pDev != NULL)
               drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_DEV, pDev->Index);
            drv_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,
                             (byte *)"Primitive initialized by the driver");
         }
         drv_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_PRIM_ID_REF,
                      pPrim->PrimId, pPrim->PrimRef);
         drv_TRACE_PACKET(IPHWAN_ID, TRC, IPHWAN_PRIM_INFO,
                          MAX_PRIM_INFO, pPrim->PrimInfo);
         dwTotalLength = 0;
         pDesc = pPrim->DataDescPtr;
         while (pDesc != NULL)
         {
            dwTotalLength+=pDesc->Size;
            pDesc = pDesc->NextPtr;
         }
         drv_TRACE_D1(IPHWAN_ID, TRC, IPHWAN_SIZE, dwTotalLength);

         if (pPrim->DataDescPtr != NULL)
         {
            pDesc = pPrim->DataDescPtr;
   
            wSize = pDesc->Size;
            if (pDesc->Size >= 16)
               wSize = 16;
            if ((pDesc->Reserved & USER_BUFFER) != 0)
            {
               GET_DATA_USER(&pDesc->DataPtr[pDesc->Offset],
                             pucBuff,
                             wSize,
                             ((DrvDataDescPtr)pDesc)->iFlags,
                             &dwError);
               pData = pucBuff;
            }
            else
            {
               pData = &pDesc->DataPtr[pDesc->Offset];
            }
            drv_TRACE_PACKET(IPHWAN_ID, TRC, IPHWAN_PRIM_DATA,
                             wSize, pData);
         }
      }
   }
   else
   {
      if (bSent == TRUE)
         drv_TRACE_STRING(ModuleId, TRC, IPHWAN_DATA_STR, 0,
                          (byte *)">>>>> SEND PRIMITIVE >>>>>");
      else
         drv_TRACE_STRING(ModuleId, TRC, IPHWAN_DATA_STR, 0,
                          (byte *)"<<<<< RECV PRIMITIVE <<<<<");
      dwDevIndex = 0xFF;
      if (pDev != NULL)
         dwDevIndex = pDev->Index;
      else if (pAppli != NULL && pAppli->WanDevPtr != NULL)
         dwDevIndex = pAppli->WanDevPtr->Index;
      dwMinor = 0xFFFF;
      if (pAppli != NULL)
         dwMinor = pAppli->Minor;
      drv_TRACE_D2(ModuleId, TRC, IPHWAN_DATA_DEV_MINOR, 
                   dwDevIndex, dwMinor);
      drv_TRACE_D2(ModuleId, TRC, IPHWAN_DATA_PRIM_ID_REF,
                   pPrim->PrimId, pPrim->PrimRef);
      drv_TRACE_PACKET(ModuleId, TRC, IPHWAN_DATA_PRIM_INFO,
                       MAX_PRIM_INFO, pPrim->PrimInfo);
      dwTotalLength = 0;
      pDesc = pPrim->DataDescPtr;
      while (pDesc != NULL)
      {
         dwTotalLength+=pDesc->Size;
         pDesc = pDesc->NextPtr;
      }
      drv_TRACE_D1(ModuleId, TRC, IPHWAN_DATA_SIZE, dwTotalLength);
      pDesc = pPrim->DataDescPtr;
      if (pDesc != NULL)
      {
         wSize = pDesc->Size;
         if (pDesc->Size >= 100)
            wSize = 100;
         if ((pDesc->Reserved & USER_BUFFER) != 0)
         {
            GET_DATA_USER(&pDesc->DataPtr[pDesc->Offset],
                          pucBuff,
                          wSize,
                          ((DrvDataDescPtr)pDesc)->iFlags,
                          &dwError);
            pData = pucBuff;
         }
         else
         {
            pData = &pDesc->DataPtr[pDesc->Offset];
         }
         drv_TRACE_PACKET(ModuleId, TRC, IPHWAN_DATA_PRIM_DATA,
                          wSize, pData);
      }
#if 0
      while (pDesc != NULL)
      {
         wSize = pDesc->Size;
         if (pDesc->Size >= 100)
            wSize = 100;
         if ((pDesc->Reserved & USER_BUFFER) != 0)
         {
            GET_DATA_USER(&pDesc->DataPtr[pDesc->Offset],
                          pucBuff,
                          wSize,
                          ((DrvDataDescPtr)pDesc)->iFlags,
                          &dwError);
            pData = pucBuff;
         }
         else
         {
            pData = &pDesc->DataPtr[pDesc->Offset];
         }
         drv_TRACE_PACKET(ModuleId, TRC, IPHWAN_DATA_PRIM_DATA,
                          wSize, pData);
         pDesc = pDesc->NextPtr;
      }
#endif
   }
#endif
}

