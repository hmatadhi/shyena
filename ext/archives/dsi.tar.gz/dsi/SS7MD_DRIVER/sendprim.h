/****************************************************************************
 * NAME : sendprim.h
 * VERSION : 1.1
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the sendprim module of the base driver
 * REVISIONS :
 *    - Version 1.0 07/06/06 : Creation
 *    - Version 1.1 06/26/06 : Change global prefix into iphwae
 ****************************************************************************/
/* To prevent include of include */
#ifndef SENDPRIM_H
#define SENDPRIM_H

#ifdef SENDPRIM_C
static dword drv_gdwCardSendPrim_PQ3(kmutex_t *pLock, IphWanDevPtr pDev,
                                     ApplCtxtPtr pApplCtxt,
                                     PrimDesc_t *pPrim);
static void drv_gvInitDialogWithCard(kmutex_t *pLock, IphWanDevPtr pDev);

#define ExportGlobalSend(PRFX)\
dword iph##PRFX##_gdwCardSendPrim_PQ3(kmutex_t *pLock, IphWanDevPtr pDev,\
                                      ApplCtxtPtr pApplCtxt,\
                                      PrimDesc_t *pPrim)\
{\
   return(drv_gdwCardSendPrim_PQ3(pLock, pDev, pApplCtxt, pPrim));\
}\
void iph##PRFX##_gvInitDialogWithCard(kmutex_t *pLock, IphWanDevPtr pDev)\
{\
   drv_gvInitDialogWithCard(pLock, pDev);\
}

ExportGlobalSend(wae)

#else

#define ExportExtSend(PRFX)\
dword iph##PRFX##_gdwCardSendPrim_PQ3(kmutex_t *pLock, IphWanDevPtr pDev,\
                                      ApplCtxtPtr pApplCtxt,\
                                      PrimDesc_t *pPrim);\
void iph##PRFX##_gvInitDialogWithCard(kmutex_t *pLock, IphWanDevPtr pDev);

ExportExtSend(wae)

#endif

#define iph_gdwCardSendPrim_PQ3 iphwae_gdwCardSendPrim_PQ3
#define iph_gvInitDialogWithCard iphwae_gvInitDialogWithCard

#endif
