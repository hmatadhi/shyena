/****************************************************************************
 * NAME : poolqueu.h
 * VERSION : 1.01
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the poolqueu module of the base driver
 * REVISIONS :
 *    - Version 1.00 09/27/05 : Creation
 *    - Version 1.01 06/26/06 : Change global prefix into iphwae
 ****************************************************************************/
/* To prevent include of include */
#ifndef POOLQUEU_H
#define POOLQUEU_H

#ifdef POOLQUEU_C
static void drv_gvInitDrvPool(DrvPoolPtr pPool);
static void drv_gvInitQueue(QueuePtr pQueue);
static PoolItemPtr drv_gpGetPool(kmutex_t *pLock, PoolPtr pPool);
static dword drv_gvPutPool(kmutex_t *pLock, PoolPtr pPool, 
                           PoolItemPtr pPoolItem);
static QueueItemPtr drv_gpGetQueue(kmutex_t *pLock, QueuePtr pQueue);
static void drv_gvExtractQueue(kmutex_t *pLock, QueuePtr pQueue,
                               QueueItemPtr pQueueItem);
static void drv_gvPutQueue(kmutex_t *pLock, QueuePtr pQueue, 
                           QueueItemPtr pQueueItem);
static dword drv_gdwNewPrimPool(kmutex_t *pLock, DrvPoolPtr pPool, word wCount);
static PrimDescPtr drv_gpGetPrimPool(kmutex_t *pLock, DrvPoolPtr pPool);
static void drv_gvPutPrimPool(kmutex_t *pLock, DrvPoolPtr pPool,
                              DrvPrimDescPtr pDrvPrim);
static dword drv_gdwNewDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool, 
                                    word wCount);
static DataDescPtr drv_gpGetDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool);
static void drv_gvPutDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool,
                                  DrvDataDescPtr pDrvData);
static DataDescPtr drv_gpGetDataPool(kmutex_t *pLock, DrvPoolPtr pPool);
static void drv_gvExtractCorrHash(kmutex_t *pLock, QueuePtr pQueue,
                                  MGRSessionCorrPtr pHashItem);
static void drv_gvPutCorrHash(kmutex_t *pLock, QueuePtr pQueue,
                              MGRSessionCorrPtr pHashItem);
static PoolItemPtr drv_gpGetPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,
                                     byte *pInUse, PoolPtr pPool, int iFlags);
static dword drv_gvPutPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,
                               byte *pInUse, PoolPtr pPool, 
                               PoolItemPtr pPoolItem, int iFlags);

#define ExportGlobalPoolqueu(PRFX)\
void iph##PRFX##_gvInitDrvPool(DrvPoolPtr pPool)\
{\
   drv_gvInitDrvPool(pPool);\
}\
void iph##PRFX##_gvInitQueue(QueuePtr pQueue)\
{\
   drv_gvInitQueue(pQueue);\
}\
PoolItemPtr iph##PRFX##_gpGetPool(kmutex_t *pLock, PoolPtr pPool)\
{\
   return(drv_gpGetPool(pLock, pPool));\
}\
dword iph##PRFX##_gvPutPool(kmutex_t *pLock, PoolPtr pPool, \
                            PoolItemPtr pPoolItem)\
{\
   return(drv_gvPutPool(pLock, pPool, pPoolItem));\
}\
QueueItemPtr iph##PRFX##_gpGetQueue(kmutex_t *pLock, QueuePtr pQueue)\
{\
   return(drv_gpGetQueue(pLock, pQueue));\
}\
void iph##PRFX##_gvExtractQueue(kmutex_t *pLock, QueuePtr pQueue,\
                                QueueItemPtr pQueueItem)\
{\
   drv_gvExtractQueue(pLock, pQueue, pQueueItem);\
}\
void iph##PRFX##_gvPutQueue(kmutex_t *pLock, QueuePtr pQueue, \
                            QueueItemPtr pQueueItem)\
{\
   drv_gvPutQueue(pLock, pQueue, pQueueItem);\
}\
dword iph##PRFX##_gdwNewPrimPool(kmutex_t *pLock, DrvPoolPtr pPool, \
                                 word wCount)\
{\
   return(drv_gdwNewPrimPool(pLock, pPool, wCount));\
}\
PrimDescPtr iph##PRFX##_gpGetPrimPool(kmutex_t *pLock, DrvPoolPtr pPool)\
{\
   return(drv_gpGetPrimPool(pLock, pPool));\
}\
void iph##PRFX##_gvPutPrimPool(kmutex_t *pLock, DrvPoolPtr pPool,\
                               DrvPrimDescPtr pDrvPrim)\
{\
   drv_gvPutPrimPool(pLock, pPool, pDrvPrim);\
}\
dword iph##PRFX##_gdwNewDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool, \
                                     word wCount)\
{\
   return(drv_gdwNewDataDescPool(pLock, pPool, wCount));\
}\
DataDescPtr iph##PRFX##_gpGetDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool)\
{\
   return(drv_gpGetDataDescPool(pLock, pPool));\
}\
void iph##PRFX##_gvPutDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool,\
                                   DrvDataDescPtr pDrvData)\
{\
   drv_gvPutDataDescPool(pLock, pPool, pDrvData);\
}\
DataDescPtr iph##PRFX##_gpGetDataPool(kmutex_t *pLock, DrvPoolPtr pPool)\
{\
   return(drv_gpGetDataPool(pLock, pPool));\
}\
void iph##PRFX##_gvExtractCorrHash(kmutex_t *pLock, QueuePtr pQueue,\
                                   MGRSessionCorrPtr pHashItem)\
{\
   drv_gvExtractCorrHash(pLock, pQueue, pHashItem);\
}\
void iph##PRFX##_gvPutCorrHash(kmutex_t *pLock, QueuePtr pQueue,\
                               MGRSessionCorrPtr pHashItem)\
{\
   drv_gvPutCorrHash(pLock, pQueue, pHashItem);\
}\
PoolItemPtr iph##PRFX##_gpGetPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,\
                                      byte *pInUse, PoolPtr pPool, int iFlags)\
{\
   return(drv_gpGetPoolUser(pLock, pCondVar, pInUse, pPool, iFlags));\
}\
dword iph##PRFX##_gvPutPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,\
                                byte *pInUse, PoolPtr pPool, \
                                PoolItemPtr pPoolItem, int iFlags)\
{\
   return(drv_gvPutPoolUser(pLock, pCondVar, pInUse, pPool, pPoolItem, \
                            iFlags));\
}

ExportGlobalPoolqueu(wae)

#else /* !POOLQUEU_C */

#define ExportExtPoolqueu(PRFX)\
void iph##PRFX##_gvInitDrvPool(DrvPoolPtr pPool);\
void iph##PRFX##_gvInitQueue(QueuePtr pQueue);\
PoolItemPtr iph##PRFX##_gpGetPool(kmutex_t *pLock, PoolPtr pPool);\
dword iph##PRFX##_gvPutPool(kmutex_t *pLock, PoolPtr pPool, \
                            PoolItemPtr pPoolItem);\
QueueItemPtr iph##PRFX##_gpGetQueue(kmutex_t *pLock, QueuePtr pQueue);\
void iph##PRFX##_gvExtractQueue(kmutex_t *pLock, QueuePtr pQueue,\
                                QueueItemPtr pQueueItem);\
void iph##PRFX##_gvPutQueue(kmutex_t *pLock, QueuePtr pQueue, \
                            QueueItemPtr pQueueItem);\
dword iph##PRFX##_gdwNewPrimPool(kmutex_t *pLock, DrvPoolPtr pPool, \
                                 word wCount);\
PrimDescPtr iph##PRFX##_gpGetPrimPool(kmutex_t *pLock, DrvPoolPtr pPool);\
void iph##PRFX##_gvPutPrimPool(kmutex_t *pLock, DrvPoolPtr pPool,\
                               DrvPrimDescPtr pDrvPrim);\
dword iph##PRFX##_gdwNewDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool, \
                                     word wCount);\
DataDescPtr iph##PRFX##_gpGetDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool);\
void iph##PRFX##_gvPutDataDescPool(kmutex_t *pLock, DrvPoolPtr pPool,\
                                   DrvDataDescPtr pDrvData);\
DataDescPtr iph##PRFX##_gpGetDataPool(kmutex_t *pLock, DrvPoolPtr pPool);\
void iph##PRFX##_gvExtractCorrHash(kmutex_t *pLock, QueuePtr pQueue,\
                                   MGRSessionCorrPtr pHashItem);\
void iph##PRFX##_gvPutCorrHash(kmutex_t *pLock, QueuePtr pQueue,\
                               MGRSessionCorrPtr pHashItem);\
PoolItemPtr iph##PRFX##_gpGetPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,\
                                      byte *pInUse, PoolPtr pPool, int iFlags);\
dword iph##PRFX##_gvPutPoolUser(kmutex_t *pLock, kcondvar_t *pCondVar,\
                                byte *pInUse, PoolPtr pPool, \
                                PoolItemPtr pPoolItem, int iFlags);\

ExportExtPoolqueu(wae)
#endif

#define iph_gvInitDrvPool iphwae_gvInitDrvPool
#define iph_gvInitQueue iphwae_gvInitQueue
#define iph_gpGetPool iphwae_gpGetPool
#define iph_gvPutPool iphwae_gvPutPool
#define iph_gpGetQueue iphwae_gpGetQueue
#define iph_gvExtractQueue iphwae_gvExtractQueue
#define iph_gvPutQueue iphwae_gvPutQueue
#define iph_gdwNewPrimPool iphwae_gdwNewPrimPool
#define iph_gpGetPrimPool iphwae_gpGetPrimPool
#define iph_gvPutPrimPool iphwae_gvPutPrimPool
#define iph_gdwNewDataDescPool iphwae_gdwNewDataDescPool
#define iph_gpGetDataDescPool iphwae_gpGetDataDescPool
#define iph_gvPutDataDescPool iphwae_gvPutDataDescPool
#define iph_gpGetDataPool iphwae_gpGetDataPool
#define iph_gvExtractCorrHash iphwae_gvExtractCorrHash
#define iph_gvPutCorrHash iphwae_gvPutCorrHash
#define iph_gpGetPoolUser iphwae_gpGetPoolUser
#define iph_gvPutPoolUser iphwae_gvPutPoolUser

#endif
