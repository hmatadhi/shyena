/****************************************************************************
 * NAME : iphwan.h
 * VERSION : 1.21.2.2
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the LINUX/SOLARIS base driver for Interphase PQIII-based controller.
 * REVISIONS :
 *    - Version 1.00 10/06/05 : Creation
 *    - Version 1.01 04/12/06 : Update for Solaris
 *    - Version 1.02 05/23/06 : Fix region id in some macros
 *    - Version 1.03 06/26/06 : Rename driver into iphwae and device node 
 *                              into iph_wae_
 *    - Version 1.04 07/12/06 : Add MUTEX_ and CV_ macros
 *                              Change ALLOC_DMA for Linux to avoid sleep
 *    - Version 1.05 09/21/06 : Add support for 5639
 *    - Version 1.06 12/20/06 : Add the READ_EXCH_WORKING_AREA_PTR macro
 *                              Add (unsigned long) before (dword) casting
 *                              to avoid Linux 64 bits compilation warnings
 *    - Version 1.07 01/26/07 : Add the IPH_DELAY macro
 *                              Add the POLL_STATUS_DEL_DELAY constant
 *    - Version 1.08 02/20/07 : Include <linux/autoconf.h> file instead of 
 *                              <linux/config.h> file.
 *    - Version 1.09 04/03/07 : Add the DATA_IND dedicated circular pool 
 *                              support in the application context
 *                              MDELAY macro does not freeze anymore the CPU 
 *                              (Linux only)
 *    - Version 1.10 07/12/07 : Add the secondary rsrc id support
 *    - Version 1.11 07/19/07 : Add the customer information support
 *                              Change the AdapterSerialNum prototype
 *    - Version 1.12 10/09/07 : In macros that copy data to/from user applis,
 *                              add support for 32-bit applis on 64-bit 
 *                              systems (Linux 2.6 only)
 *                              Add the 5639E support
 *    - Version 1.13 01/07/08 : Eliminate compilation warnings on 64-bit in 
 *                              macro GET_DATA_DESC_PTRFIELD and
 *                              GET_PRIM_DESC_PTRFIELD.
 *    - Version 1.14 07/29/08 : Add the 5639L support
 *    - Version 1.15 08/11/08 : Add the custom info offset and size in the
 *                              resource structure
 *                              Change the 5639L Device Id (90E5 instead of 90E4)
 *    - Version 1.16 10/15/08 : - Correct GET_PRIM_DESC_PTRFIELD macro for 
 *                              Solaris (add CastType field)
 *                              - Add the support for Solaris 9 (SOL_9 option)
 *    - Version 1.17 11/06/08 : Add the support of PEX device 0x8112
 *    - Version 1.18 11/24/08 : - change the MDELAY macro for Solaris to use 
 *                              unblocking wait
 *    - Version 1.19 01/07/09 : - limit the number of events notified regarding
 *                              pb with MAX_RX_QUEUE 
 *                              - Add macros to access Card Time and Host time
 *                              offset in the exchange area
 *    - Version 1.20 01/19/09 : Add macros to read/write 64-bit values
 *                              Timestamp read/write is based on these new macros
 *    - Version 1.21 01/23/09 : Add a cast in DO_SWAP32 macro to avoid
 *                              warning on LITTLE ENDIAN paltforms
 *    - Version 1.21.1 04/08/09 : Add application status in session correlator
 *    - Version 1.21.2 05/14/09 : 
 *         - Add The temperature sensor support
 *    - Version 1.21.2.1 07/01/10 : 
 *         - Add the I2C semaphore implementation constants
 *    - Version 1.21.2.2 07/05/10 : 
 *         - Move the I2C semaphore constants to ppcsys.h
 *    - Version x.xx.x.x 06/09/13 :
 *         - Replace perboard Padding0 with ThermalCount field
 * MH 02-Dec-13  - Correct 32-user to 64-bit kernel copies.
 *
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHWAN_H
#define IPHWAN_H

#ifdef LINUX
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 33)
#include <linux/autoconf.h>
#else
#include <generated/autoconf.h>
#endif
#if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
#define MODVERSIONS
#endif

#ifdef MODVERSIONS
#ifdef LINUX_2_4
#include <linux/modversions.h>
#endif
#ifdef LINUX_2_6
#include <config/modversions.h>
#endif
#endif
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/time.h>
#include <linux/timer.h>
#include <linux/pci.h>
#include <linux/ioport.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/string.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <asm/uaccess.h>
#include <asm/delay.h>
#include <asm/io.h>

#ifdef SEQ_PROC
#include <linux/seq_file.h>
#endif

#include "iphmutex.h" /* contains a library for mutexes in the linux kernel*/
#endif /* LINUX */

#ifdef SOLARIS
#include <sys/debug.h>
#include <sys/types.h>
#include <sys/mkdev.h>
#include <sys/param.h>
#include <sys/buf.h>
#include <sys/errno.h>
#include <sys/conf.h>
#include <sys/file.h>
#include <sys/uio.h>
#include <sys/map.h>
#include <sys/cred.h>
#include <sys/open.h>
#include <sys/stat.h>
#include <sys/kmem.h>
#include <sys/cmn_err.h>
#include <sys/kmem.h>
#include <sys/conf.h>
#include <sys/ddi.h>
#include <sys/devops.h>
#include <sys/sunddi.h>
#include <sys/modctl.h>
#include <sys/poll.h>
#include <sys/ddi_impldefs.h>
#include <errno.h>
#endif /* SOLARIS */

#include "pq3.h"
#include "ppcsys.h"
#include "ppcapi.h"
#include "mgr.h"
#include "svr.h"
#include "toolapi.h"
#include "pex811x.h"

/***************************************************************************/
/* Constants                                                               */
/***************************************************************************/
/* name to build minor nodes */
#define DEVICE_NAME        "ss7md"

#define DRIVER_NAME        "ss7md"
 
/* pci id for the iSPAN 3639 card */
#define IPH_3639_PCI_ID     0x0009
#define PEX_VID             0x10B5
#define IPH_PEX1_PCI_ID     0x8111
#define IPH_PEX2_PCI_ID     0x8112
#define MPC85XX_VID         0x1057 
#define CARD_3639_DID       0x90E0 
#define CARD_5639_DID       0x90E1 
#define CARD_5639E_DID      0x90E2
#define CARD_5639L_DID      0x90E5

/* interphase Corp vendor ID */                                          
#define IPH_VID             0x107E

#define CARD_RESETTING      10

/* boolean values */
#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif                 

/* Maximum size of DRAM that can be mapped */
#define MAX_MAPPED_DRAM     0x200000

/* Maximum number of managed cards */
#define MAX_CARD            8

/* Total number of applications that the driver can support */
#define TOTAL_APPLI         1024

/* Maximum number of DATA_IND dedicated buffers (per application) */
#define MAX_CIRC_POOL_SIZE  32

/* Size for the PCI configuration registers */
#define MAX_PCI_CONF        0x100

/* Values for an adapter or application status */
#define RESET               0
#define RUNNING             1
#define WAIT_TO_SEND        10  /* for user applications only */
#define WAIT_SEND_END       11  /* closing application is waiting for end */
                                /* of transmission */
/* ATTENTION: WAIT_TO_SEND and WAIT_SEND_END must be > CARD_RUNNING */
/* to properly return the card status in CTL_GET_CARD_STATUS */

/* Values for a card session status */
#define SESS_CLOSED         0
#define SESS_OPENING        1
#define SESS_OPENED         2
#define SESS_CLOSING        3

/* mask for a kernel buffer */
#define DMA_BUFFER          0x0100
#define USER_BUFFER         0x0200
#define KERN_BUFFER         0x0400
#define DRV_BUFFER          0x0800

/* No session value */
#define NO_SESSION           0xFFFF

/* Type of applications */
#define TYPE_USER           0
#define TYPE_KERNEL         1

/* Size for application's hash table */
#define MODULO              8

/* Timeout for watchdog (unit=milli-second) */
#define WATCHDOG_TIMEOUT    60000

/* Timeout for polling on device status (unit=milli-second) */
#define POLL_STATUS_TIMEOUT 1000

/* Delay to wait in detach entry point after killing the Poll */
/* Status timer routine (in seconds) */
#define POLL_STATUS_DEL_DELAY 2

/* Timeout for echo poll (unit=milli-second) */
/*#define ECHO_TIMEOUT        50*/
#define ECHO_TIMEOUT        1000

/* max number of events notified regarding pb with MAX_RX_QUEUE */
#define PB_MAX_RX_QUEUE     16

/* Type of PCI chip */
#define PLX                 0       /* PLX 4535/37 */
#define PSP                 1       /* Toundra PowerSpan  */
#define PQ3                 3       /* PowerQuicc III  */

typedef enum
{
  DP_NONE = 0,
  DP_CTX_ALLOCATED,
  DP_PCI_REGISTERS_MAPPED,
  DP_RSRC_ALLOCATED,
  DP_INTERRUPT_ALLOCATED,
  DP_MINOR_CREATED,
  DP_ALL
}DetachPoint_t;

enum {
   BRIDGE_REGION,
   CORE_REGION,
   FLASH_REGION,
   MEM_REGION,
   MAX_REGION
};

#ifdef SOLARIS
#define PCI_DMA_TODEVICE    1
#define PCI_DMA_FROMDEVICE  2
#define PCI_DMA_NONE        3
#endif

#define ALLOCATED           0x01
#define MEM_ALLOCATED       0x02
#define BOUND               0x04

/* ioctl modes */
#define MODE_NONE           0
#define MODE_32             1

/* Number of Polling cycles before checking the current temperature */
#define TEMP_CHECK_CYCLES_NB 10
/* The driver shutdown the card when current temperature >= TOS - STOP_MARGIN */
#define STOP_MARGIN 2

/***************************************************************************/
/* Structures                                                              */
/***************************************************************************/
/* Device context structures definition to allow cross-reference */
/* inside structures */
typedef struct IphWanDev IphWanDev_t;
typedef IphWanDev_t *IphWanDevPtr;
/* Application context structures definition to allow cross-reference */
/* inside structures */
typedef struct ApplCtxt ApplCtxt_t;
typedef ApplCtxt_t *ApplCtxtPtr;

/* circular buffer pool used */
typedef struct CircularPool {
   DataDescPtr BuffPtr[MAX_CIRC_POOL_SIZE];
   word        MaxBuff;
   word        CurIndx;
} CircularPool_t;

/* Structure including default settings for a card */
typedef struct DefCardParm {
   /* Default maximum transfer size for DMA */
   word DefMaxTransferSize;

   /* Default maximum number of inbound transfer descriptors */
   word DefInbCtrlNb;

   /* Default maximum number of inbound data descriptors */
   word DefInbDataNb;

   /* Default maximum number of outbound transfer descriptors */
   word DefOutbCtrlNb;

   /* Default maximum number of outbound data descriptors */
   word DefOutbDataNb;

   /* Default maximum number of MGR sessions */
   word DefMaxSession;

   /* Default maximum number of concurrent applications on the same card */
   word DefMaxAppli;

   /* Default settings for the primitive pool */
   AllocPool_t DefPrimPool;

   /* Default settings for the buffer pools */
   AllocPool_t DefDataPool[MAX_DRV_POOL];

} DefCardParm_t;
typedef DefCardParm_t * DefCardParmPtr;

/* Structure representing a card */
typedef struct IphCardDesc {
   /* PCI Vendor ID */
   word VendorId;

   /* PCI device ID */
   word DevId;

   /* card type CARD_xxxx */
   word Type;

   /* number of ports */
   word PortNb;

   /* one char per port describing the port type */
   char *PortDesc;

   /* commercial name */
   char *CardName;

   /* more information to identify equipment options for example */
   byte DevOption;

   /* major version for interface with embedded firmware */
   word IntfVer;

   /* PCI chip type (PQ3) */
   word PCIDevType;

   /* Custom info offset */
   word CustInfoOff;

   /* Custome info size */
   word CustInfoSize;

   /* default settings */
   DefCardParmPtr DefParmPtr;

   /* address of the hardware interrupt handler */
#ifdef LINUX
#ifdef LINUX_2_4
   void (*ITHandler)(int, void *, struct pt_regs *);
#else
   irqreturn_t (*ITHandler)(int, void *, struct pt_regs *);
#endif
#endif
#ifdef SOLARIS
#ifdef SOL_9
   u_int (*ITHandler)(caddr_t);
#else
   u_int (*ITHandler)(caddr_t, caddr_t);
#endif
#endif

   /* address of the deferred routine for a hardware interrupt */
#ifdef LINUX
   void (*ITHandlerDpc)(unsigned long );
#endif
#ifdef SOLARIS
#ifdef SOL_9
   u_int (*ITHandlerDpc)(caddr_t);
#else
   u_int (*ITHandlerDpc)(caddr_t, caddr_t);
#endif
#endif

   /* address of the routine that prepares a DMA transfer to send */
   /* a primitive to the card */
   dword (*CardSendPrim)(kmutex_t *, IphWanDevPtr, ApplCtxtPtr, PrimDesc_t *);

   /* address of the routine that releases a transfer when send is complete */
   void (*ReleaseP2LTransfer)(kmutex_t *, IphWanDevPtr);

   /* address of the routine to read the serial number */
   void (*AdapterSerialNum)(IphWanDevPtr);

   /* address of the routine to check whether the flashed initial */
   /* software configuration is loaded */
   byte (*CheckCardStatus)(kmutex_t *, IphWanDevPtr);

   /* address of the routine to put the card in reset */
   int (*ResetCard)(IphWanDevPtr);

   /* address of the routine to run the card in reset */
   int (*RunCard)(IphWanDevPtr);

   /* address of the routine to check whether a card is in reset */
   int (*IsCardInReset)(IphWanDevPtr);

   /* Primary subid: BER */
   dword PrimarySubid;

   /* Secondary subid: BER */
   dword SecondarySubid;

   /* Revision Id */
   byte BoardRevisionId;

} IphCardDesc_t;

/* Structure representing the exchange area in DRAM independently from */
/* the type of interface */
typedef union DRAMExchArea {
   /* Exchange area for V2 interface version */
   ExchangeArea_t    V2ExchArea;
   /* Exchange area for V5 interface version */
   V5_CardCtrlArea_t V5ExchArea;

} DRAMExchArea_t;
typedef DRAMExchArea_t *DRAMExchAreaPtr;

/* Structure of the local processor working area */
typedef struct ProcArea {
   byte     Signature[12];     /* Signature of the working area */
   dword    MaxTra;            /* Maximum size of the working area */
   word     MaxTch;            /* Maximum number of tasks */
   byte     MaxNiv;            /* Maximum number of priority levels */
   byte     MaxGev;            /* Maximum number of event groups */
   byte     MaxFil;            /* Maximum number of queues */
   byte     MaxSem;            /* Maximum number of semaphores */
   byte     MaxMem;            /* Maximum number of memory partition */
   byte     Void1;             /* for alignment */
   word     CPUUsage;          /* CPU usage rate */
   word     Void2;             /* for alignment */
   dword    PtrHor;            /* Pointer to the clock descriptor */
   dword    PtrRec;            /* Pointer to the reception buffer descriptor */
   dword    PtrEmi;            /* Pointer to the transmission buffer descriptor*/
   dword    PtrTch;            /* Pointer to the tasks table */
   dword    TchAtt;
   dword    PtrNiv;            /* Pointer to the priority levels table */
   dword    PtrGev;            /* Pointer to the events groups table */
   dword    PtrSem;            /* Pointer to the semaphores table */
   dword    PtrFil;            /* Pointer to the queues table */
   dword    PtrMem;            /* Pointer to the memory partitions table */
   dword    PtrLib;            /* Pointer to the first available area in */
                               /* in the working space */
   dword    MemLib;            /* Available memory in working space */
   byte     DrpCop;            /* Digital coprocessor flag */
   byte     CptImb;            /* Immediate tasks imbrication counter */
   byte     RegiTI;            /* Immediate tasks regions counter */
   byte     RegiTD;            /* Deferred tasks regions counter */
   word     NumTC;             /* Current task number */
   byte     NivTC;             /* Current task priority level */
   byte     NivEl;             /* Priority level for the task that is eligible */
                               /* after critical section */
   byte     ZoneTrav[1];       /* Working area */
} ProcArea_t;
typedef ProcArea_t *ProcAreaPtr;

/* Structure to manage with memory allocations */
/* For 64-bit kernel, change Size type from dword to long */
/* buffers must be 64-bit aligned */
typedef struct MemAlloc
{
   /* size of the buffer */
   long Size;

   /* padding for 64-bit alignment */
   long Reserved;

   /* address of the next allocated buffer */
   struct MemAlloc *NextPtr;

} MemAlloc_t;
typedef MemAlloc_t *MemAllocPtr;

/* Element in a pool */
typedef struct PoolItem
{
   struct PoolItem *NextPtr;
} PoolItem_t;
typedef PoolItem_t *PoolItemPtr;

/* Pool */
typedef struct Pool
{
   /* Pointer to the first item */
   PoolItemPtr NextPtr;

   /* Size of the elements in the pool */
   word PoolSize;

   /* Number of elements in the pool */
   word PoolCount;

} Pool_t;
typedef Pool_t *PoolPtr;

/* Structure of a super primitive internally allocated by the driver */
typedef struct DrvPrimDesc {
   /* the real primitive */
   PrimDesc_t Prim;

   /* Pointer to the next structure when linked in one queue of DrvPool_t */
   /* This is used for statistics */
   struct DrvPrimDesc *NextItemPtr;

   /* Pointer to the previous structure when linked in one queue of */
   /* DrvPool_t */
   /* This is used for statistics */
   struct DrvPrimDesc *PrevItemPtr;

   /* Status of the structure; if 0 the structure is not used, else it */
   /* contains the time when the structure was extracted to be used */
   dword Status;

} DrvPrimDesc_t;
typedef DrvPrimDesc_t *DrvPrimDescPtr;

/* Structure of a super data descriptor internally allocated by the driver */
typedef struct DrvDataDesc {
   /* the real data descriptor */
   DataDesc_t Data;

   /* Pointer to the next structure when linked in one queue of DrvPool_t */
   /* This is used for statistics */
   struct DrvDataDesc *NextItemPtr;

   /* Pointer to the previous structure when linked in one queue of */
   /* DrvPool_t */
   /* This is used for statistics */
   struct DrvDataDesc *PrevItemPtr;

   /* Status of the structure; if 0 the structure is not used, else it */
   /* contains the time when the structure was extracted to be used */
   dword Status;

   /* if attached data is a user buffer: flags for copy from User Space */
   /* if attached data is a DMA buffer: index of the buffer in OutbAddr */
   int iFlags;
} DrvDataDesc_t;
typedef DrvDataDesc_t *DrvDataDescPtr;

/* structure to describe a transferred multi-buffered primitive */
typedef struct TransfDesc {
   /* index of the DMA handle used for the first buffer */
   word FirstHandle;

   /* number of buffers */
   word HandleNb;

} TransfDesc_t;
typedef TransfDesc_t *TransfDescPtr;

/* structure to describe a buffer used for DMA */
typedef struct DmaBuffDesc {
   /* virtual address */
   caddr_t VirtAddr;

   /* physical address (to provide for DMA) */
   dword PhysAddr;

   /* buffer size */
   dword Size;

   /* buffer index */
   word Index;

   /* index of the pool the buffer belongs to */
   byte PoolIndex;

   /* direction (PCI_DMA_TO_DEVICE|PCI_DMA_FROM_DEVICE|PCI_DMA_NONE) */
   byte Direction;

   /* DMA handle status */
   byte Status;

   /* pointer on the associated data descriptor */
   DataDesc_t *pDataDesc;

#ifdef SOLARIS
   /* DMA handle */
   ddi_dma_handle_t Handle;

   /* data access handle */
   ddi_acc_handle_t AccHandle;
#endif

} DmaBuffDesc_t;
typedef DmaBuffDesc_t *DmaBuffDescPtr;

/* Application context */
struct ApplCtxt {
   /* pointer to the next application context */
   struct ApplCtxt *NextPtr;

   /* pointer to the previous application context */
   struct ApplCtxt *PrevPtr;

   /* mutex to protect access to this structure */
   kmutex_t AppliMutex;

   /* an application may wait end of transmission on closure */
   kcondvar_t CondVar;

   /* minor = application id */
   word Minor;

   /* type of application (TYPE_KERNEL or TYPE_USER) */
   byte Type;

   /* status of the application (RESET or RUNNING) */
   byte Status;

   /* structure for poll support (TYPE_USER application only) */
#ifdef LINUX
   wait_queue_head_t Pollhead;
#endif
#ifdef SOLARIS
   pollhead_t Pollhead;
#endif

   /* address of kd_wakeup callback (TYPE_KERNEL application only) */
   void (*kd_wakeup)(void *, word);

   /* address of kd_free callback (TYPE_KERNEL application only) */
   void (*kd_free)(void *, word, byte, void *);

   /* pointer to the opened device structure */
   IphWanDevPtr WanDevPtr;

   /* hash table to help conversion of session numbers in messages to send */
   Queue_t HashTable[MODULO];

   /* pool of free primitive headers given with CTL_GIVE_RX_BUFFER */
   Pool_t FreePrimHeadPool;

   /* flag set when either iph_gpGetPoolUser or iph_gvPutPoolUser is */
   /* running. This flag is used with the conditional variable and the mutex */
   /* of the application context */
   /* This protection replaces the simple mutex because no mutex should be */
   /* held when calling ddi_copyxxx routines */
   byte PoolInUse;

   /* pool of free primitive data descriptor given with */
   /* CTL_GIVE_RX_BUFFER */
   /* Note: each data descriptor points to a user buffer */
   /* The pools are organized as the adapter's ones. */
   Pool_t FreeDataPools[MAX_DRV_POOL];

   /* maximum number of pending received primitives */
   /* Note: the value is set by default by the driver but the */
   /* application can change it thanks to CTL_MAX_RX_QUEUE */
   word MaxRecvNb;

   /* maximum number of received primitives than can be chained in */
   /* a single CTL_RECV_PRIM */
   /* Note: the value is set by default by the driver but the */
   /* application can change it thanks to CTL_MAX_RX_CHAIN */
   word MaxChainRecvNb;

   /* does the driver support chained structures in CTL_GIVE_RX_? */
   /* Note: the value is set by default by the driver but the */
   /* application can change it thanks to CTL_MAX_RX_CHAIN */
   word ChainGiveRx;

   /* number of pending received primitives */
   word RecvNb;

   /* queue of pending received primitives */
   Queue_t RecvQueue;

   /* process ID (for User Application only) */
   pid_t ProcID;

   /* backward reference (for Kernel Application only) */
   void *Backref;

   /* DATA_IND dedicated buffer pool (for user space application only) */
   struct CircularPool DataIndPool;

   /* nb of notifications regarding pb with MAX_RX_QUEUE */
   int PbMaxRxQueue;
};

/* Equivalence between MGR session reference and application context */
typedef struct MGRSessionCorr {

   /* address of the next structure when chained in a queue or pool */
   struct MGRSessionCorr *NextPtr;

   /* address of the previous structure when chained in a queue */
   struct MGRSessionCorr *PrevPtr;

   /* address of the next structure when chained in a hash queue */
   struct MGRSessionCorr *HashNextPtr;

   /* address of the previous structure when chained in a hash queue */
   struct MGRSessionCorr *HashPrevPtr;

   /* MGR session number for the adapter */
   word CardMGRSession;

   /* MGR session number set by the application */
   word LogicalMGRSession;

   /* pointer on the application context */
   ApplCtxtPtr AppliPtr;

   /* primitive structure used to open the session */
   PrimDescPtr OpenPrim;

   /* session status OPENING, OPENED, CLOSING, CLOSED */
   byte Status;

   /* Application type : USER or KERNEL */
   byte AppliType;

   /* is application ready to received primimitives on this session */
   byte AppliReady;

} MGRSessionCorr_t;
typedef MGRSessionCorr_t *MGRSessionCorrPtr;

#ifdef LINUX
typedef struct SysDev
{
   /* pointer to pci_dev node for Pex */
   struct pci_dev *iDev;

   /* pointer to pci_dev node for PQ3*/
   struct pci_dev *Dev;
} SysDev_t;
#endif

#ifdef SOLARIS
typedef struct SysDev
{
   /* pointer to the dev_info node */
   dev_info_t *iDev;

   /* pointer to the dev_info node */
   dev_info_t *Dev;

   /* attributes for DMA */
   ddi_dma_attr_t dma_attr;

   /* attributes for device access to DRAM */
   ddi_device_acc_attr_t dram_attr;

#ifdef SOL_9
   /* interrupt block cookie */
   ddi_iblock_cookie_t Cookie;
#else
   /* interrupt handle */
   ddi_intr_handle_t intHandle;
#endif

   /* interrupt priority */
   uint_t intPri;
} SysDev_t;
#endif

typedef struct DevRegion DevRegion_t;
typedef DevRegion_t *DevRegionPtr;

/* set of operations on a region */
typedef struct RegionOps
{
   /* routine to move window */
   void (*moveWindow) (DevRegionPtr RegPtr, dword addr);

   /* routine to read a byte */
   int  (*read8)      (DevRegionPtr RegPtr, dword offset, byte *data);

   /* routine to read a 16-bit word */
   int  (*read16)     (DevRegionPtr RegPtr, dword offset, word *data);

   /* routine to read a 32-bit dword */
   int  (*read32)     (DevRegionPtr RegPtr, dword offset,  dword *data);

   /* routine to write a byte */
   int  (*write8)     (DevRegionPtr RegPtr, dword offset, byte data);

   /* routine to write a 16-bit word */
   int  (*write16)    (DevRegionPtr RegPtr, dword offset, word data);

   /* routine to write a 32-bit word */
   int  (*write32)    (DevRegionPtr RegPtr, dword offset, dword data);

   /* routine to read a buffer of bytes */
   int  (*readbuf)    (DevRegionPtr RegPtr, dword offset, int size, byte *buf);

   /* routine to write a buffer of bytes */
   int  (*writebuf)   (DevRegionPtr RegPtr, dword offset, int size, byte *buf);
}RegionOps_t;
typedef RegionOps_t *RegionOpsPtr;

/* context description a region of memory or I/O on a device */
struct DevRegion
{
   /* name of the region */
   char Name[20];

   /* region index */
   byte Index;

   /* flag set if region is Big Endian */
   byte BigEnd;

   /* flag set if region is protected */
   byte ProtAccess;

   /* protection access on the region */
   kmutex_t Access;

   /* mapped address */
   volatile byte *Mapped;

   /* start address */
   dword HostBaseAddr;

   /* the PCI window size */
   dword WinSize;

   /* PCI window limit */
   dword WinLimit;

   /* PCI window mask */
   dword WinMask;

   /* current window position */
   dword CurWin;

   /* Region Total Size */
   dword MaxSize;

   /* bit shift to move window */
   dword WinShift;

   /* mapped address in card memory */
   dword CardBaseAddr;

   /* index of the register used to move window */
   dword Cfg;

   /* set of operations on this region */
   RegionOps_t Ops;

   /* private data (device context) */
   void *Priv;

#ifdef SOLARIS
   /* data access handle */
   ddi_acc_handle_t AccHandle;
#endif
};


/* Device context */
struct IphWanDev {
   /* pointer to the next structure when chained in a queue or a pool */
   struct IphWanDev *NextPtr;

   /* pointer to the previous structure when chained in a queue */
   struct IphWanDev *PrevPtr;

   /* more device characteristics (specific to OS) */
   SysDev_t sDev;

   /* mutex to protect access to this structure */
   kmutex_t DevMutex;

   /* mutex to protect access to the i2c critical resource */
   kmutex_t I2CMutex;

   /* an application may wait for access */
   kcondvar_t CondVar;

#ifdef LINUX
   /* contains task used for the Dpc IT handler */
   struct tasklet_struct SoftInterrupt;
#endif

#ifdef SOLARIS
   /* software interrupt Id */
#ifdef SOL_9
   ddi_softintr_t SoftId;
#else
   ddi_softint_handle_t SoftId;
#endif
#endif

   /* flag indicating whether a software interrupt is requested */
   byte SoftITNeeded;

   /* flag indicating whether a software interrupt is running */
   byte SoftITRunning;

   /* adapter index */
   byte Index;

   /* adapter status */
   byte Status;

   /* Serial Number read status*/
   byte SerialNumberRead;

   /* adapter type */
   word Type;

   /* pointer on the card resource */
   IphCardDesc_t *Rsrc;

   /* serial number */
   dword Serial;

   /* Customer information */
   char CustInfo[CARD_PQ3_CUSTOM_INFO_SIZE];

   /* Tells if the card is equipped with a temperature sensor */
   byte TempSensorPresent;

   /* Current temperature */
   byte CurTemp;

   /* Temperature that triggers a card shutdown */
   byte StopThreshold;
   
   /* Number of times we have read over temp in a row */
   byte ThermalCount;

   /* copy of the PCI configuration registers content at */
   /* initialization time */
   byte PCIConf[MAX_PCI_CONF];

   /* list of regions in device */
   DevRegion_t Region[MAX_REGION];

   /* where to start detach to properly release resources */
   DetachPoint_t DetachPoint;

   /* maximum size of a fragment that can be transferred through DMA */
   word MaxTransferSize;

   /* maximum number of inbound transfer descriptors */
   word InbCtrlNb;

   /* maximum number of inbound data descriptors */
   word InbDataNb;

   /* maximum number of outbound transfer descriptors */
   word OutbCtrlNb;

   /* maximum number of outbound data descriptors */
   word OutbDataNb;

   /* DMA buffer descriptor associated to the Dummy Area */
   DmaBuffDesc_t DummyAreaDesc;

   /* address of the Host Control Area */
   volatile V5_HostCtrlAreaPtr HostArea;

   /* DMA buffer descriptor associated to the Host Control Area */
   DmaBuffDesc_t HostAreaDesc;

   /* address of the first buffer used for DMA */
   /* (This is in SendDmaDesc or RecvDmaDesc the one with the lowest addr) */
   DmaBuffDescPtr FirstDmaDesc;

   /* address of the last buffer used for DMA */
   /* (This is in SendDmaDesc or RecvDmaDesc the one with the highest addr) */
   DmaBuffDescPtr LastDmaDesc;

   /* address of the inbound transfer status circular queue located */
   /* in Host Control Area; the card notifies end of host-to-card transfer */
   /* dynamically allocated; size is InbCtrlNb entries */
   volatile V5_TransferStatusPtr InbStatus;

   /* address of the outbound transfer control circular queue located */
   /* in Host Control Area; the card notifies card-to-host transfers */
   /* dynamically allocated; size is OutbCtrlNb entries */
   volatile V5_TransferCtrlPtr OutbCtrl;

   /* address of the outbound send circular queue located */
   /* in Host Control Area; the card notifies buffer index & size of data */
   /* of card-to-host transfer */
   /* dynamically allocated; size is OutbDataNb entries */
   volatile V5_OutboundSendPtr OutbSend;

   /* offset of the exchange area in the local memory of the card */
   dword ExchArea;

   /* address of the inbound transfer control queue located */
   /* in Card Control Area; the host notifies host-to-card transfers */
   /* size is InbCtrlMax but only InbCtrlNb entries are used */
   volatile V5_TransferCtrlPtr InbCtrl;

   /* address of the inbound send queue located in Card Control Area */
   /* the host fills this queue with the size of data in buffers */
   /* used in host-to-card transfers */
   /* size is InbDataMax but only InbDataNb entries are used */
   volatile V5_InboundSendPtr InbSend;

   /* address of the outbound transfer status queue located */
   /* in Card Control Area; the host notifies end of card-to-host transfers */
   /* size is OutbCtrlMax but only OutbCtrlNb entries are used */
   volatile V5_TransferStatusPtr OutbStatus;

   /* address of the outbound data address table located */
   /* in Card Control Area; the host fills this table with the offset */
   /* of its buffers dedicated for card-to-host transfers */
   /* size is OutbDataMax but only OutbDataNb entries are used */
   volatile V5_DataAddrPtr OutbAddr;

   /* address of the outbound buffer pools located in Card Control Area */
   /* each pool has OutbDataMax entries but only OutbDataNb entries are used */
   /* the host fills each table with the indexes in the OutbAddr table */
   /* of the buffers that belong to the corresponding pool */
   volatile V5_OutboundPoolPtr OutbPool[MAX_DRV_POOL];

   /* card offset of the local processor working area */
   volatile dword ProcAreaStart;

   /* context of the application that is owning the control */
   ApplCtxtPtr ControlAppli;

   /* flag set as soon as the dialog with the card needs to be initialized */
   byte OpenPrimToDo;

   /* flag set as soon as the dialog with the card is initialized */
   byte OpenPrimDone;

   /* index in the RefFunction table of the REF_SV6 embedded function */
   word RefIndex;

   /* internal signal counter */
   dword HostToCardSigCount;

   /* status indicating which type of IRQ occured */
   dword IRQStatus;

   /* index of the first free inbound transfert control descriptor */
   word InbCtrlIndex;

   /* index of the first free descriptor in inbound send queue */
   word InbSendIndex;

   /* index of the latest used descriptor in inbound transfer status queue */
   word InbStatusIndex;

   /* number of data descriptors currently in use */
   word InbTotalSendCount;

   /* flag indicating if gdwCardSendPrim is running */
   byte SendPending;

   /* condvar to ensure that part of gdwCardSendPrim routine is not */
   /* re-entered. The condvar is used to wait for completion */
   kcondvar_t SendPendingCv;

   /* time at which a sending application went to sleep while waiting */
   /* for a descriptor */
   dword SendWaiting;

   /* list of primitives being currently transmitted to the card */
   PrimDescPtr *SendingPrim;

   /* list of DMA buffers used to send primitives to the card */
   /* dynamically allocated; size is InbDataNb entries */
   DmaBuffDesc_t *SendDmaDesc;

   /* index of the first free outbound transfert control descriptor */
   word OutbCtrlIndex;

   /* index of the first free descriptor in outbound send queue */
   word OutbSendIndex;

   /* filling indexes for the outbound pools */
   word OutbPoolIndex[MAX_DRV_POOL];

   /* list of DMA buffers used to receive primitives from the card */
   /* dynamically allocated; size is OutbDataNb entries */
   DmaBuffDesc_t *RecvDmaDesc;

   /* maximum number of concurrent sessions on the adapter */
   word MaxSession;

   /* correlators between MGR session references and application */
   /* contexts */
   MGRSessionCorr_t **MGRSessionCorrTable;

   /* pool of free correlator contexts */
   Queue_t FreeMGRSessionCorrQueue;

   /* queue of used correlator contexts */
   Queue_t UsedMGRSessionCorrQueue;

   /* maximum number of concurrent applications */
   word MaxAppli;

   /* current number of applications */
   word NbAppli;

   /* queue of application contexts using this adapter */
   Queue_t UsingAppliQueue;

   /* pool of free primitive headers allocated by the driver */
   DrvPool_t FreePrimHeadPool;

   /* pool of free data descriptors allocated by the driver */
   DrvPool_t FreeDataDescPool;

   /* pools of buffers of various size */
   DrvPool_t FreeDataPools[MAX_DRV_POOL];

   /* index of the last defined pool */
   word LastPool;

   /* current signal counter on last watchdog checking */
   dword LastHostToCard;

   /* Flag set when a watchdog timeout occurred */
   word WatchdogTimeout;

   /* Flag to manage the remove/add of the watchdog timer list */
   word WatchdogTimer;

   /* Flag set when StatusPoll occured */
   word PollTimeout;

   /* Flag to manage the remove/add of the poll timer list */
   word PollTimer;

   /* Flag set when a timeout occurred to examine echo count */
   word EchoTimeout;

   /* Flag to manage the remove/add of the echo count timer list */
   word EchoTimer;

   /* timeout identifier for watchdog */
#ifdef LINUX
   struct timer_list Watchdog;
#endif
#ifdef SOLARIS
#ifdef SOL_7
   timeout_id_t Watchdog;
#else
   int Watchdog;
#endif
#endif

   /* timeout identifier for card status polling */
#ifdef LINUX
   struct timer_list StatusPoll;
#endif
#ifdef SOLARIS
#ifdef SOL_7
   timeout_id_t StatusPoll;
#else
   int StatusPoll;
#endif
#endif

   /* timeout identifier for card status polling */
#ifdef LINUX
   struct timer_list EchoPoll;
#endif
#ifdef SOLARIS
#ifdef SOL_7
   timeout_id_t EchoPoll;
#else
   int EchoPoll;
#endif
#endif

   /* DMA buffer descriptor associated to the DMA buffers */
   DmaBuffDesc_t DmaAreaDesc;

#ifdef DEBUG_PERF
   /* Number of IT calls */
   dword ITCount;

   /* Number of IT Dpc calls */
   dword ITDpcCount;

   /* Number of primitives waiting to be sent */
   dword SendNb;

   /* Maximum number of primitives waiting to be sent */
   dword MaxSendNb;

   /* Maximum number of active loops while sending a primitive */
   dword MaxSendLoop;

   /* Number of times a sending user application waited for a transfer desc */
   dword SendWait;

   /* Number of pending chained received primitives */
   dword RecvChainNb;

   /* Maximum number of chained received primitives */
   dword MaxRecvChainNb;

   /* Number of ITs between 2 calls of Dpc */
   dword ITPerDpc;

   /* Maximum number of ITs between 2 calls of Dpc */
   dword MaxITPerDpc;

   /* Number of times at least 2 ITs occurred before a call to Dpc */
   dword ITBeforeDpc;

   /* Number of sent messages */
   dword SendMsgNb;

   /* Number of received messages */
   dword RecvMsgNb;

   /* Number of times that several received messages are chained */
   dword RecvChainCount;

   /* Counter to memorize a lack of receive Prim and Buffer */
   dword NbrLackRecvPrim;

   dword NbrLackRecvBuffer;

   /* Number of times a sending user application waited in gdwCardSendPrim */
   dword SendPendingWait;

#endif

};

/***************************************************************************/
/* New structures to support both 32-bit and 64-bit applications           */
/***************************************************************************/
/* Element in a pool */
typedef struct PoolItem32
{
   uint32_t NextPtr;
} PoolItem32_t;
typedef PoolItem32_t *PoolItem32Ptr;

typedef struct DataDesc32 {
   /* address of the next block */
   uint32_t NextPtr;

   /* size of the buffer containing the data in the current block */
   word MaxSize;

   /* size of data in the current block */
   word Size;

   /* offset of the first byte of data in the current block */
   word Offset;

   /* field reserved for internal use */
   word Reserved;

   /* address of the data block */
   uint32_t DataPtr;

} DataDesc32_t;
typedef DataDesc32_t *DataDesc32Ptr;

typedef struct PrimDesc32 {
   /* address of the next primitive when chained in a queue or pool */
   uint32_t NextPtr;

   /* address of the previous primitive when chained in a queue */
   uint32_t PrevPtr;

   /* type */
   word PrimId;

   /* reference */
   word PrimRef;

   /* immediate data */
   byte PrimInfo[MAX_PRIM_INFO];

   /* address of the first data descriptor */
   uint32_t DataDescPtr;

   /* number of free primitive structures in the driver for which a received*/
   /* primitive reports the status */
   word PrimInPool;

   /* size of the driver's buffers for which a received primitive */
   /* reports the status */
   word SizeInPool;

   /* number of the driver's buffers for which a received primitive */
   /* reports the status */
   word BuffInPool;

   /* flag set in a received primitive if there is at least another pending */
   /* received primitive */
   word MorePrim;

} PrimDesc32_t;
typedef PrimDesc32_t *PrimDesc32Ptr;

typedef struct MemDesc32 {
   /* size of the block pointed by DataPtr */
   dword Size;

   /* offset of the first data in the pointed block */
   dword Offset;

   /* address of the block */
   uint32_t DataPtr;

} MemDesc32_t;

/* Pool to contain primitive headers and data buffers */
typedef struct DrvPool32
{
   /* queue of elements currently in use */
   uint32_t UsedQueue[2];

   /* queue of elements not currently in use */
   uint32_t FreeQueue[2];

   /* Pool number */
   dword PoolIndex;

   /* Size of the elements in the pool */
   dword PoolSize;

   /* Initial number of elements */
   dword InitCount;

   /* Maximum number of elements that can be allocated for this pool */
   dword MaxCount;

   /* Current number of elements that have been allocated for this pool */
   dword TotalCount;

   /* Number of elements currently in use */
   dword UsedCount;

   /* Number of elements not currently in use */
   dword FreeCount;

   /* Maximal number of elements that have been simultaneously in use */
   dword MaxUsedCount;

} DrvPool32_t;
typedef DrvPool32_t *DrvPool32Ptr;

/***************************************************************************/
/* Macros                                                                  */
/***************************************************************************/

/* Global macro endian conversion */
#define DO_SWAP16(_var)                                               \
   (((((word)(_var)) >> 8) & 0x00FF) | ((((word)(_var)) << 8) & 0xFF00))
#define DO_SWAP32(_lvar)                                              \
   ((dword)(DO_SWAP16(((dword)(_lvar) >> 16) & 0x0000FFFF) |          \
            ((dword)(DO_SWAP16((dword)(_lvar) & 0x0000FFFF)) << 16)))


#define REG_PCI16_TO_APPLIS(var)        (var)
#define REG_PCI32_TO_APPLIS(lvar)       (lvar)
#define REG_PCI16_FROM_APPLIS(var)      (var)
#define REG_PCI32_FROM_APPLIS(lvar)     (lvar)

/* Conversion depending the HOST endian type 
 * The Define _LITTLE_ENDIAN determine if the host is in little endian 
 * This macro must be defined in the makefile if the HOST is in LITTLE_ENDIAN 
 * Note that    : Standard PCI device uses LITTLE ENDIAN byte convention
 *              : Interphase Wan Adapter used BIG ENDIAN byte convention  
 */

#ifdef LINUX
#ifdef _LITTLE_ENDIAN  /* case host little endian */

/* used by the driver to read or to write 16/32 bits PCI device register */
#define PCI_SWAP16(var)     var
#define PCI_SWAP32(lvar)    lvar             

#else  /* case host  big endian */

/* used by the driver to read or to write 16/32 bits PCI device register */
#define PCI_SWAP16(var)     DO_SWAP16(var)
#define PCI_SWAP32(lvar)    DO_SWAP32(lvar)

#endif
#endif /* LINUX */

#ifdef SOLARIS
/* macros to convert values for PCI registers */
/* On Solaris, the access routines to the registers perform the swap. */
#define PCI_SWAP16(var)     var
#define PCI_SWAP32(lvar)    lvar
#endif

#ifdef _LITTLE_ENDIAN  /* case host little endian */
/* used to read or to write 16/32 bits data driver to/from application*/
#define HOST_CARD16(var)    DO_SWAP16(var)
#define HOST_CARD32(lvar)   DO_SWAP32(lvar)

#else  /* case host  big endian */
/* used to read or to write 16/32 bits data driver to/from application*/
#define HOST_CARD16(var)    (var)
#define HOST_CARD32(lvar)   (lvar)
#endif

/* macros to convert CORE register values into host representation */
#ifdef LINUX
#define HOST_CORE16(var)    HOST_CARD16(var)
#define HOST_CORE32(var)    HOST_CARD32(var)
#endif

#ifdef SOLARIS
#define HOST_CORE16(var)    (var)
#define HOST_CORE32(var)    (var)
#endif

/* macro to convert an offset understood by the firmware to an offset */
/* available to the host e.g. most significant bit reset */
#define OFFSET_CARD_TO_HOST(Offset) ((Offset) & (0x7FFFFFFFUL))

/******************************************************************
 * macros to read/write in DRAM 
 *****************************************************************/
/* macro to read a byte in mapped memory */
#define READ_MEM_BYTE(pDev, Address, pVal)                              \
{                                                                       \
   pDev->Region[MEM_REGION].Ops.read8(&pDev->Region[MEM_REGION],        \
                                      (dword)(unsigned long)Address, pVal);            \
}

/* macro to read an word in mapped memory */
#define READ_MEM_WORD(pDev, Address, pVal)                              \
{                                                                       \
   word val16;                                                          \
   pDev->Region[MEM_REGION].Ops.read16(&pDev->Region[MEM_REGION],       \
                                      (dword)(unsigned long)Address, &val16);          \
   *pVal = HOST_CARD16(val16);                                          \
}

/* macro to read an dword in mapped memory */
#define READ_MEM_DWORD(pDev, Address, pVal)                             \
{                                                                       \
   dword val32;                                                         \
   pDev->Region[MEM_REGION].Ops.read32(&pDev->Region[MEM_REGION],       \
                                       (dword)(unsigned long)Address, &val32);         \
   *pVal = HOST_CARD32(val32);                                          \
}

/* macro to read an ddword in mapped memory */
#define READ_MEM_DDWORD(pDev, Address, pVal)                            \
{                                                                       \
   dword val1_32, val2_32;                                              \
   pDev->Region[MEM_REGION].Ops.read32(&pDev->Region[MEM_REGION],       \
                                       (dword)(unsigned long)Address, &val1_32);         \
   val1_32 = HOST_CARD32(val1_32);                                      \
   pDev->Region[MEM_REGION].Ops.read32(&pDev->Region[MEM_REGION],       \
                                       (dword)(unsigned long)((byte *)Address+4), &val2_32);         \
   val2_32 = HOST_CARD32(val2_32);                                      \
   *pVal = (((ddword)val1_32) << 32) | (ddword)val2_32;                 \
}

/* macro to read a buffer of byte in mapped memory */
#define READ_MEM_BUFFER_BYTE(pDev, Address, Buffer, Count)              \
{                                                                       \
   pDev->Region[MEM_REGION].Ops.readbuf(&pDev->Region[MEM_REGION],      \
                                        (dword)(unsigned long)Address, Count, Buffer); \
}
    
/* macro to write a byte in mapped memory */
#define WRITE_MEM_BYTE(pDev, Address, ucVal)                            \
{                                                                       \
   pDev->Region[MEM_REGION].Ops.write8(&pDev->Region[MEM_REGION],       \
                                       (dword)(unsigned long)Address, ucVal);          \
}

/* macro to write a word in mapped memory */
#define WRITE_MEM_WORD(pDev, Address, uwVal)                            \
{                                                                       \
   word val16;                                                          \
   val16 = HOST_CARD16((word)(uwVal));                                  \
   pDev->Region[MEM_REGION].Ops.write16(&pDev->Region[MEM_REGION],      \
                                        (dword)(unsigned long)Address, val16);         \
}

/* macro to write a dword in mapped memory */
#define WRITE_MEM_DWORD(pDev, Address, ulVal)                           \
{                                                                       \
   dword val32;                                                         \
   val32 = HOST_CARD32((dword)(ulVal));                                 \
   pDev->Region[MEM_REGION].Ops.write32(&pDev->Region[MEM_REGION],      \
                                        (dword)(unsigned long)Address, val32);         \
}

/* macro to write a ddword in mapped memory */
#define WRITE_MEM_DDWORD(pDev, Address, ullVal)                         \
{                                                                       \
   dword val32;                                                         \
   val32 = HOST_CARD32((dword)(ullVal >> 32));                          \
   pDev->Region[MEM_REGION].Ops.write32(&pDev->Region[MEM_REGION],      \
                                        (dword)(unsigned long)Address, val32);         \
   val32 = HOST_CARD32((dword)(ullVal & 0x00000000FFFFFFFF));           \
   pDev->Region[MEM_REGION].Ops.write32(&pDev->Region[MEM_REGION],      \
                                        (dword)(unsigned long)((byte *)Address+4), val32);         \
}

/* macro to write a buffer of byte in mapped memory */
#define WRITE_MEM_BUFFER_BYTE(pDev, Address, Buffer, Count)             \
{                                                                       \
   pDev->Region[MEM_REGION].Ops.writebuf(&pDev->Region[MEM_REGION],     \
                                         (dword)(unsigned long)Address, Count, Buffer);\
}

/******************************************************************
 * macro to read/write in PCI bridge register 
 *****************************************************************/
/* macro to read a byte in PCI register */
#define READ_PCI_BYTE(pDev, Address, pVal)                              \
{                                                                       \
   pDev->Region[BRIDGE_REGION].Ops.read8(&pDev->Region[BRIDGE_REGION],  \
                                         (dword)(unsigned long)Address, pVal);         \
}

/* macro to read a word in PCI register */
#define READ_PCI_WORD(pDev, Address, pVal)                              \
{                                                                       \
   word val16;                                                          \
   pDev->Region[BRIDGE_REGION].Ops.read16(&pDev->Region[BRIDGE_REGION], \
                                          (dword)(unsigned long)Address, &val16);      \
   *pVal = PCI_SWAP16(val16);                                           \
}

/* macro to read a dword in PCI register */
#define READ_PCI_DWORD(pDev, Address, pVal)                             \
{                                                                       \
   dword val32;                                                         \
   pDev->Region[BRIDGE_REGION].Ops.read32(&pDev->Region[BRIDGE_REGION], \
                                          (dword)(unsigned long)Address, &val32);      \
   *pVal = PCI_SWAP32(val32);                                           \
}

/* macro to write a byte in PCI register */
#define WRITE_PCI_BYTE(pDev, Address, ucVal)                            \
{                                                                       \
   pDev->Region[BRIDGE_REGION].Ops.write8(&pDev->Region[BRIDGE_REGION], \
                                          (dword)(unsigned long)Address, ucVal);       \
}

/* macro to write a word in PCI register */
#define WRITE_PCI_WORD(pDev, Address, wVal)                             \
{                                                                       \
   word val16;                                                          \
   val16 = PCI_SWAP16((word)(wVal));                                    \
   pDev->Region[BRIDGE_REGION].Ops.write16(&pDev->Region[BRIDGE_REGION],\
                                           (dword)(unsigned long)Address, val16);      \
}

/* macro to write a dword in PCI register */
#define WRITE_PCI_DWORD(pDev, Address, ulVal)                           \
{                                                                       \
   dword val32;                                                         \
   val32 = PCI_SWAP32((dword)(ulVal));                                  \
   pDev->Region[BRIDGE_REGION].Ops.write32(&pDev->Region[BRIDGE_REGION],\
                                           (dword)(unsigned long)Address, val32);      \
}
   
/******************************************************************
 * macro to read/write in PCI configuration register 
 *****************************************************************/
#ifdef LINUX
/* macro to read a byte in PCI configuration register */
#define READ_PCI_CONF_BYTE(pDev, Offset, pVal)                          \
{                                                                       \
   pci_read_config_byte(pDev, Offset, (u8 *)pVal);                      \
}

/* macro to write a word in PCI configuration register */
#define READ_PCI_CONF_WORD(pDev, Offset, pVal)                          \
{                                                                       \
   pci_read_config_word(pDev, Offset, (u16 *)pVal);                     \
}

/* macro to read an dword in PCI configuration register */
#define READ_PCI_CONF_DWORD(pDev, Offset, pVal)                         \
{                                                                       \
   pci_read_config_dword(pDev, Offset, (u32 *)pVal);                    \
}

/* macro to write a byte in PCI configuration register */
#define WRITE_PCI_CONF_BYTE(pDev, Offset, ucVal)                        \
{                                                                       \
   iph_TRACEK(TRCLVL_3, "WritePciConf8 - offset 0x%x - val 0%x",        \
              Offset, ucVal);                                           \
   pci_write_config_byte(pDev, Offset, (u8)ucVal);                      \
}

/* macro to write a word in PCI configuration register */
#define WRITE_PCI_CONF_WORD(pDev, Offset, wVal)                         \
{                                                                       \
   iph_TRACEK(TRCLVL_3, "WritePciConf16 - offset 0x%x - val 0%x",       \
              Offset, wVal);                                            \
   pci_write_config_word(pDev, Offset, (u16)wVal);                      \
}

/* macro to write a dword in PCI configuration register */
#define WRITE_PCI_CONF_DWORD(pDev, Offset, ulVal)                       \
{                                                                       \
   iph_TRACEK(TRCLVL_3, "WritePciConf16 - offset 0x%x - val 0%x",       \
              Offset, ulVal);                                           \
   pci_write_config_dword(pDev, Offset, (u32)ulVal);                    \
}

#endif

#ifdef SOLARIS
/* macro to read a byte in PCI configuration register */
#define READ_PCI_CONF_BYTE(pDev, Offset, pVal)                          \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      *(byte *)pVal = pci_config_get8(myH, Offset);                     \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

/* macro to write a word in PCI configuration register */
#define READ_PCI_CONF_WORD(pDev, Offset, pVal)                          \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      *(word *)pVal = pci_config_get16(myH, Offset);                    \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

/* macro to read an dword in PCI configuration register */
#define READ_PCI_CONF_DWORD(pDev, Offset, pVal)                         \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      *(dword *)pVal = pci_config_get32(myH, Offset);                   \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

/* macro to write a byte in PCI configuration register */
#define WRITE_PCI_CONF_BYTE(pDev, Offset, ucVal)                        \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      pci_config_put8(myH, Offset, (byte)ucVal);                        \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

/* macro to write a word in PCI configuration register */
#define WRITE_PCI_CONF_WORD(pDev, Offset, wVal)                         \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      pci_config_put16(myH, Offset, (word)wVal);                        \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

/* macro to write a dword in PCI configuration register */
#define WRITE_PCI_CONF_DWORD(pDev, Offset, ulVal)                       \
{                                                                       \
   ddi_acc_handle_t myH;                                                \
   if (pci_config_setup(pDev, &myH) == DDI_SUCCESS)                     \
   {                                                                    \
      pci_config_put32(myH, Offset, (dword)ulVal);                      \
      pci_config_teardown(&myH);                                        \
   }                                                                    \
}

#endif

/******************************************************************
 * macro to read/write in Core register 
 *****************************************************************/
/* macro to read a byte in PCI register */
#define READ_CORE_BYTE(pDev, Address, pVal)                             \
{                                                                       \
   pDev->Region[CORE_REGION].Ops.read8(&pDev->Region[CORE_REGION],      \
                                       (dword)(unsigned long)Address, pVal);           \
}

/* macro to read a word in PCI register */
#define READ_CORE_WORD(pDev, Address, pVal)                             \
{                                                                       \
   word val16;                                                          \
   pDev->Region[CORE_REGION].Ops.read16(&pDev->Region[CORE_REGION],     \
                                        (dword)(unsigned long)Address, &val16);        \
   *pVal = HOST_CORE16(val16);                                          \
}

/* macro to read a dword in PCI register */
#define READ_CORE_DWORD(pDev, Address, pVal)                            \
{                                                                       \
   dword val32;                                                         \
   pDev->Region[CORE_REGION].Ops.read32(&pDev->Region[CORE_REGION],     \
                                        (dword)(unsigned long)Address, &val32);        \
   *pVal = HOST_CORE32(val32);                                          \
}

/* macro to write a byte in PCI register */
#define WRITE_CORE_BYTE(pDev, Address, ucVal)                           \
{                                                                       \
   pDev->Region[CORE_REGION].Ops.write8(&pDev->Region[CORE_REGION],     \
                                        (dword)(unsigned long)Address, ucVal);         \
}

/* macro to write a word in PCI register */
#define WRITE_CORE_WORD(pDev, Address, wVal)                            \
{                                                                       \
   word val16;                                                          \
   val16 = HOST_CORE16((word)(wVal));                                   \
   pDev->Region[CORE_REGION].Ops.write16(&pDev->Region[CORE_REGION],    \
                                         (dword)(unsigned long)Address, val16);        \
}

/* macro to write a dword in PCI register */
#define WRITE_CORE_DWORD(pDev, Address, ulVal)                          \
{                                                                       \
   dword val32;                                                         \
   val32 = HOST_CORE32((dword)(ulVal));                                 \
   pDev->Region[CORE_REGION].Ops.write32(&pDev->Region[CORE_REGION],    \
                                         (dword)(unsigned long)Address, val32);        \
}

/*********************************************************************
 * macros to read fields value of a transfer descriptor of the card  
 * Note: The transfer desciptor fiels are in the DRAM memory of card then
 * they are in big endian 
 *********************************************************************/
#define READ_TRANSFER_STATUS(pDev, TransferPtr, pVal)                   \
{                                                                       \
   READ_MEM_BYTE(pDev, (byte *)&(TransferPtr)->Status, pVal);           \
}
#define READ_TRANSFER_REF_INDX(pDev, TransferPtr, pVal)                 \
{                                                                       \
   READ_MEM_WORD(pDev, (word *)&(TransferPtr)->RefIndx, pVal);          \
}
#define READ_TRANSFER_PRIM_ID(pDev, TransferPtr, pVal)                  \
{                                                                       \
   READ_MEM_WORD(pDev, (word *)&(TransferPtr)->PrimitiveId, pVal);      \
}
#define READ_TRANSFER_PRIM_REF(pDev, TransferPtr)                       \
{                                                                       \
   READ_MEM_WORD(pDev, (word *)&(TransferPtr)->PrimitiveRef, pVal);     \
}
#define READ_TRANSFER_DATA_COUNT(pDev, TransferPtr)                     \
{                                                                       \
   READ_MEM_BYTE(pDev, (byte *)&(TransferPtr)->DataCount, pVal);        \
}

/* macros to write fields value of a transfer descriptor of the card */
#define WRITE_TRANSFER_STATUS(pDev, TransferPtr, ucVal)                 \
{                                                                       \
   WRITE_MEM_BYTE(pDev, (byte *)&(TransferPtr)->Status, (byte)(ucVal)); \
}
#define WRITE_TRANSFER_REF_INDX(pDev, TransferPtr, uwVal)               \
{                                                                       \
   WRITE_MEM_WORD(pDev, (word *)&(TransferPtr)->RefIndx, (word)(uwVal));\
}
#define WRITE_TRANSFER_PRIM_ID(pDev, TransferPtr, uwVal)                \
{                                                                       \
   WRITE_MEM_WORD(pDev, (word *)&(TransferPtr)->PrimitiveId, (word)(uwVal));\
}
#define WRITE_TRANSFER_PRIM_REF(pDev, TransferPtr, uwVal)               \
{                                                                       \
   WRITE_MEM_WORD(pDev, (word *)&(TransferPtr)->PrimitiveRef, (word)(uwVal));\
}
#define WRITE_TRANSFER_DATA_COUNT(pDev, TransferPtr, ucVal)             \
{                                                                       \
   WRITE_MEM_BYTE(pDev, (byte *)&(TransferPtr)->DataCount, (byte)(ucVal));\
}

/* macros to read fields value of the Exchange Area in the card */
#define READ_EXCH_INTF_SIGN(pDev, ExchPtr, pVal)                        \
{                                                                       \
   READ_MEM_DWORD(pDev, &((ExchangeAreaPtr)(unsigned long)ExchPtr)->IntfSign,          \
                  pVal);                                                \
}
#define READ_EXCH_INTF_VER(pDev, ExchPtr, pVal)                         \
{                                                                       \
   READ_MEM_DWORD(pDev, &((ExchangeAreaPtr)(unsigned long)ExchPtr)->IntfVer,           \
                  pVal);                                                \
}
#define READ_EXCH_CODE_READY(pDev, ExchPtr, pVal)                       \
{                                                                       \
   READ_MEM_DWORD(pDev, &((ExchangeAreaPtr)(unsigned long)ExchPtr)->CodeReady,         \
                  pVal);                                                \
}
#define READ_EXCH_TRACE_BUFFER_PTR(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->TraceBufferPtr,          \
                  pVal);                                                \
}
#define READ_EXCH_TRACE_BUFFER_SIZE(pDev, ExchPtr, pVal)                \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->TraceBufferSize,         \
                  pVal);                                                \
}
#define READ_EXCH_TRACE_BUFFER_START(pDev, ExchPtr, pVal)               \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->TraceBufferStart,        \
                  pVal);                                                \
}
#define READ_EXCH_TRACE_BUFFER_END(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->TraceBufferEnd,          \
                  pVal);                                                \
}
#define READ_EXCH_HEAP_START_PTR(pDev, ExchPtr, pVal)                   \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->HeapStartPtr,            \
                  pVal);                                                \
}
#define READ_EXCH_HEAP_END_PTR(pDev, ExchPtr, pVal)                     \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->HeapEndPtr,              \
                  pVal);                                                \
}
#define READ_EXCH_WORKING_AREA_PTR(pDev, ExchPtr, pVal)                     \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->WorkingAreaPtr,          \
                  pVal);                                                \
}
#define READ_EXCH_SYSBUFF_CHECK(pDev, ExchPtr, pVal)                    \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->SysBuffCheckLevel,       \
                  pVal);                                                \
}
#define READ_EXCH_NB_SYSBUFF_POOL(pDev, ExchPtr, pVal)                  \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->NbSysBuffPool,           \
                  pVal);                                                \
}
#define READ_EXCH_CONFIG_STATUS(pDev, ExchPtr, pVal)                    \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->ConfigStatus,            \
                  pVal);                                                \
}
#define READ_EXCH_CONFIG_ERR(pDev, ExchPtr, pVal)                       \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->ConfigErrCode,           \
                  pVal);                                                \
}
#define READ_EXCH_NB_FUNCTION(pDev, ExchPtr, pVal)                      \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->NbFunction,              \
                  pVal);                                                \
}
#define READ_EXCH_REF_FUNCTION_I(pDev, ExchPtr, Indx, pVal)             \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &((ExchangeAreaPtr)(unsigned long)ExchPtr)->RefFunction[Indx],       \
                  pVal);                                                \
}
#define READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, Field)                  \
{                                                                       \
   READ_MEM_DWORD(pDev,                                                 \
                  &(((V5_CardCtrlAreaPtr)(unsigned long)ExchPtr)->Field),              \
                  pVal);                                                \
}
#define READ_V5_EXCH_DDWORD(pDev, ExchPtr, pVal, Field)                 \
{                                                                       \
   READ_MEM_DDWORD(pDev,                                                \
                   &(((V5_CardCtrlAreaPtr)(unsigned long)ExchPtr)->Field),             \
                   (ddword *)pVal);                                     \
}
#define READ_EXCH_INB_CTRL_MAX(pDev, ExchPtr, pVal)                     \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbCtrlMax);                 \
}
#define READ_EXCH_INB_CTRL_NB(pDev, ExchPtr, pVal)                      \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbCtrlNumber);              \
}
#define READ_EXCH_INB_CTRL_OFFSET(pDev, ExchPtr, pVal)                  \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbCtrlOffset);              \
}
#define READ_EXCH_INB_STATUS_OFFSET(pDev, ExchPtr, pVal)                \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbStatusOffset);            \
}
#define READ_EXCH_INB_DATA_MAX(pDev, ExchPtr, pVal)                     \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbDataMax);                 \
}
#define READ_EXCH_INB_DATA_NB(pDev, ExchPtr, pVal)                      \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbDataNumber);              \
}
#define READ_EXCH_INB_ADDR_OFFSET(pDev, ExchPtr, pVal)                  \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbAddrOffset);              \
}
#define READ_EXCH_INB_SEND_OFFSET(pDev, ExchPtr, pVal)                  \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, InbSendOffset);              \
}
#define READ_EXCH_OUTB_CTRL_MAX(pDev, ExchPtr, pVal)                    \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbCtrlMax);                \
}
#define READ_EXCH_OUTB_CTRL_NB(pDev, ExchPtr, pVal)                     \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbCtrlNumber);             \
}
#define READ_EXCH_OUTB_CTRL_OFFSET(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbCtrlOffset);             \
}
#define READ_EXCH_OUTB_STATUS_OFFSET(pDev, ExchPtr, pVal)               \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbStatusOffset);           \
}
#define READ_EXCH_OUTB_DATA_MAX(pDev, ExchPtr, pVal)                    \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbDataMax);                \
}
#define READ_EXCH_OUTB_DATA_NUMBER(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbDataNumber);             \
}
#define READ_EXCH_OUTB_ADDR_OFFSET(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbAddrOffset);             \
}
#define READ_EXCH_OUTB_SEND_OFFSET(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbSendOffset);             \
}
#define READ_EXCH_OUTB_POOL_SIZE(pDev, ExchPtr, pVal, Index)            \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbPoolSize[(Index)]);      \
}
#define READ_EXCH_OUTB_POOL_OFFSET(pDev, ExchPtr, pVal, Index)          \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, OutbPoolOffset[(Index)]);    \
}
#define READ_EXCH_SIG_COUNT(pDev, ExchPtr, pVal)                        \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, HostToCardSigCount);         \
}
#define READ_EXCH_ECHO_COUNT(pDev, ExchPtr, pVal)                       \
{                                                                       \
   READ_V5_EXCH_DWORD(pDev, ExchPtr, pVal, CardToHostEchoCount);        \
}
#define READ_EXCH_CARD_TIME(pDev, ExchPtr, pVal)                        \
{                                                                       \
   READ_V5_EXCH_DDWORD(pDev, ExchPtr, pVal, CardTime);                  \
}
#define READ_EXCH_HOST_TIME_OFFSET(pDev, ExchPtr, pVal)                 \
{                                                                       \
   READ_V5_EXCH_DDWORD(pDev, ExchPtr, pVal, HostTimeOffset);            \
}

/* macros to write fields value of the Exchange Area in the card */
#define WRITE_EXCH_CODE_READY(pDev, ExchPtr, dwVal)                     \
{                                                                       \
   WRITE_MEM_DWORD(pDev,                                                \
                   &((ExchangeAreaPtr)(unsigned long)ExchPtr)->CodeReady,              \
                   ((dword)(dwVal)));                                   \
}
#define WRITE_EXCH_CONFIG_STATUS(pDev, ExchPtr, dwVal)                  \
{                                                                       \
   WRITE_MEM_DWORD(pDev,                                                \
                   &((ExchangeAreaPtr)(unsigned long)ExchPtr)->ConfigStatus,           \
                   ((dword)(dwVal)));                                   \
}
#define WRITE_EXCH_CONFIG_ERR(pDev, ExchPtr, dwVal)                     \
{                                                                       \
   WRITE_MEM_DWORD(pDev,                                                \
                   &((ExchangeAreaPtr)(unsigned long)ExchPtr)->ConfigErrCode,          \
                   ((dword)(dwVal)));                                   \
}
#define WRITE_EXCH_TRACE_BUFFER_START(pDev, ExchPtr, dwVal)             \
{                                                                       \
   WRITE_MEM_DWORD(pDev,                                                \
                   &((ExchangeAreaPtr)(unsigned long)ExchPtr)->TraceBufferStart,       \
                   ((dword)(dwVal)));                                   \
}
#define WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, Field)                \
{                                                                       \
   WRITE_MEM_DWORD(pDev,                                                \
                   &(((V5_CardCtrlAreaPtr)(unsigned long)ExchPtr)->Field),             \
                   ((dword)(dwVal)));                                   \
}
#define WRITE_V5_EXCH_DDWORD(pDev, ExchPtr, ddwVal, Field)              \
{                                                                       \
   WRITE_MEM_DDWORD(pDev,                                               \
                    &(((V5_CardCtrlAreaPtr)(unsigned long)ExchPtr)->Field),            \
                    ((ddword)(ddwVal)));                                \
}
#define WRITE_EXCH_INB_CTRL_NB(pDev, ExchPtr, dwVal)                    \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, InbCtrlNumber);            \
}
#define WRITE_EXCH_INB_DATA_NB(pDev, ExchPtr, dwVal)                    \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, InbDataNumber);            \
}
#define WRITE_EXCH_INB_STATUS_OFFSET(pDev, ExchPtr, dwVal)              \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, InbStatusOffset);          \
}
#define WRITE_EXCH_OUTB_CTRL_NB(pDev, ExchPtr, dwVal)                   \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, OutbCtrlNumber);           \
}
#define WRITE_EXCH_OUTB_DATA_NB(pDev, ExchPtr, dwVal)                   \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, OutbDataNumber);           \
}
#define WRITE_EXCH_OUTB_CTRL_OFFSET(pDev, ExchPtr, dwVal)               \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, OutbCtrlOffset);           \
}
#define WRITE_EXCH_OUTB_SEND_OFFSET(pDev, ExchPtr, dwVal)               \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, OutbSendOffset);           \
}
#define WRITE_EXCH_OUTB_POOL_SIZE(pDev, ExchPtr, dwVal, Index)          \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, OutbPoolSize[(Index)]);    \
}
#define WRITE_EXCH_SIG_COUNT(pDev, ExchPtr, dwVal)                      \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, HostToCardSigCount);       \
}
#define WRITE_EXCH_ECHO_COUNT(pDev, ExchPtr, dwVal)                     \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, CardToHostEchoCount);      \
}
#define WRITE_EXCH_HOST_AREA_OFFSET(pDev, ExchPtr, dwVal)               \
{                                                                       \
   WRITE_V5_EXCH_DWORD(pDev, ExchPtr, dwVal, HostAreaOffset);           \
}
#define WRITE_EXCH_HOST_TIME_OFFSET(pDev, ExchPtr, ddwVal)              \
{                                                                       \
   WRITE_V5_EXCH_DDWORD(pDev, ExchPtr, ddwVal, HostTimeOffset);         \
}

/******************************************************************
 * Macros to convert to LINUX some equivalent SOLARIS function     
 *****************************************************************/

#ifdef LINUX
#define bcopy(src, dest, len)   memcpy(dest, src, len)
#define bcmp(src, dest, len)    memcmp(dest, src, len)
#define bzero(dest, len)        memset(dest, 0, len)

#define stoi(str)               simple_strtoul(*str, NULL, 10);
#endif


/* Macro to copy a memory descriptor from user space independently from */
/* the application's data model */
#ifdef LINUX
#define GET_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   MemDesc32_t MyMem32;                                                 \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      *(pError) = copy_from_user((void *)&MyMem32, (void *)(pSrc),      \
                                 sizeof(MemDesc32_t));                  \
      if (*(pError) == 0)                                               \
      {                                                                 \
           (pDest)->Size = MyMem32.Size;                                \
           (pDest)->Offset = MyMem32.Offset;                            \
           (pDest)->DataPtr = (char *)((unsigned long)MyMem32.DataPtr); \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pDest), (void *)(pSrc),       \
                                 sizeof(MemDesc_t));                    \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   MemDesc32_t MyMem32;                                                 \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pSrc), (void *)&MyMem32,          \
                             sizeof(MemDesc32_t), (iFlags));            \
      if (*(pError) == 0)                                               \
      {                                                                 \
         (pDest)->Size = MyMem32.Size;                                  \
         (pDest)->Offset = MyMem32.Offset;                              \
         (pDest)->DataPtr = (byte *)MyMem32.DataPtr;                    \
      }                                                                 \
      else                                                              \
      {                                                                 \
         *(pError) = EFAULT;                                            \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pSrc), (void *)(pDest),           \
                             sizeof(MemDesc_t), (iFlags));              \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyin((void *)(pSrc), (void *)(pDest),              \
                          sizeof(MemDesc_t), (iFlags));                 \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a memory descriptor to user space independently from */
/* the application's data model */
#ifdef LINUX
#define PUT_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   MemDesc32_t MyMem32;                                                 \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      MyMem32.Size = (pSrc)->Size;                                      \
      MyMem32.Offset = (pSrc)->Offset;                                  \
      MyMem32.DataPtr = (uint32_t)((unsigned long)(pSrc)->DataPtr);     \
      *(pError) = copy_to_user((void *)(pDest), (void *)&MyMem32,       \
                               sizeof(MemDesc32_t));                      \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)(pDest), (void *)(pSrc),         \
                               sizeof(MemDesc_t));                      \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   MemDesc32_t MyMem32;                                                 \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      MyMem32.Size = (pSrc)->Size;                                      \
      MyMem32.Offset = (pSrc)->Offset;                                  \
      MyMem32.DataPtr = (uint32_t)((unsigned long)(pSrc)->DataPtr);     \
      *(pError) = ddi_copyout((void *)&MyMem32, (void *)(pDest),        \
                              sizeof(MemDesc32_t), (iFlags));           \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pSrc), (void *)(pDest),          \
                              sizeof(MemDesc_t), (iFlags));             \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_MEM_DESC(pSrc, pDest, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pSrc), (void *)(pDest),             \
                           sizeof(MemDesc_t), (iFlags));                \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a data descriptor from user space independently from */
/* the application's data model */
#ifdef LINUX
#define GET_DATA_DESC(pSrc, pDest, iFlags, pError)                      \
{                                                                       \
   DataDesc32_t MyDesc32;                                               \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      *(pError) = copy_from_user((void *)&MyDesc32,                     \
                                 (void *)(pSrc),                        \
                                 sizeof(DataDesc32_t));                   \
      if (*(pError) == 0)                                               \
      {                                                                 \
         (pDest)->NextPtr = (DataDesc_t *)((unsigned long)MyDesc32.NextPtr); \
         (pDest)->MaxSize = MyDesc32.MaxSize;                           \
         (pDest)->Size = MyDesc32.Size;                                 \
         (pDest)->Offset = MyDesc32.Offset;                             \
         (pDest)->DataPtr = (byte *)((unsigned long)MyDesc32.DataPtr);  \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pDest),                       \
                                 (void *)(pSrc),                        \
                                 sizeof(DataDesc_t));                   \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_DATA_DESC(pSrc, pDest, iFlags, pError)                      \
{                                                                       \
   DataDesc32_t MyDesc32;                                               \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pSrc), (void *)&MyDesc32,         \
                             sizeof(DataDesc32_t), (iFlags));           \
      if (*(pError) == 0)                                               \
      {                                                                 \
         (pDest)->NextPtr = (DataDesc_t *)((unsigned long)MyDesc32.NextPtr); \
         (pDest)->MaxSize = MyDesc32.MaxSize;                           \
         (pDest)->Size = MyDesc32.Size;                                 \
         (pDest)->Offset = MyDesc32.Offset;                             \
         (pDest)->DataPtr = (byte *)((unsigned long)MyDesc32.DataPtr);  \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pSrc), (void *)(pDest),           \
                             sizeof(DataDesc_t), (iFlags));             \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_DATA_DESC(pSrc, pDest, iFlags, pError)                      \
{                                                                       \
   *(pError) = ddi_copyin((void *)(pSrc), (void *)(pDest),              \
                          sizeof(DataDesc_t), (iFlags));                \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a pointer field of a data descriptor from user space */
/* independently from the application's data model */
#ifdef LINUX
#define GET_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError, CastType)      \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = copy_from_user((void *)&Addr32,                       \
                                 (void *)&(pDesc32)->Field,             \
                                 sizeof(uint32_t));                     \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (CastType *)((unsigned long)Addr32);                 \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)&((DataDescPtr)(pDesc))->Field,\
                                 sizeof(void *));                       \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError, CastType)      \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = ddi_copyin((void *)&(pDesc32)->Field,                 \
                             (void *)&Addr32,                           \
                             sizeof(uint32_t), (iFlags));               \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (CastType *)((unsigned long)Addr32);                 \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)&((DataDescPtr)(pDesc))->Field,    \
                             (void *)(pVal),                            \
                             sizeof(void *), (iFlags));                 \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError, CastType)      \
{                                                                       \
   *(pError) = ddi_copyin((void *)&((DataDescPtr)(pDesc))->Field,       \
                          (void *)(pVal),                               \
                          sizeof(void *), (iFlags));                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a pointer field of a data descriptor to user space */
/* independently from the application's data model */
#ifdef LINUX
#define PUT_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError)      \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = copy_to_user((void *)&(pDesc32)->Field,               \
                               (void *)&Addr32,                         \
                               sizeof(uint32_t));                       \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)&((DataDescPtr)(pDesc))->Field,  \
                               (void *)(pVal),                          \
                               sizeof(void *));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError)      \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = ddi_copyout((void *)&Addr32,                          \
                              (void *)&(pDesc32)->Field,                \
                              sizeof(uint32_t), (iFlags));              \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)&((DataDescPtr)(pDesc))->Field,   \
                              sizeof(void *), (iFlags));                \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_DATA_DESC_PTRFIELD(pDesc, pVal, Field, iFlags, pError)      \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)&((DataDescPtr)(pDesc))->Field,      \
                           sizeof(void *), (iFlags));                   \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a word field of a data descriptor from user space */
/* independently from the application's data model */
#ifdef LINUX
#define GET_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   word wMacroVal;                                                      \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = copy_from_user((void *)&wMacroVal,                    \
                                 (void *)&(pDesc32)->Field,             \
                                 sizeof(word));                         \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = wMacroVal;                                           \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)&((DataDescPtr)(pDesc))->Field,\
                                 sizeof(word));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   word wMacroVal;                                                      \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = ddi_copyin((void *)&(pDesc32)->Field,                 \
                             (void *)&wMacroVal,                        \
                             sizeof(word), (iFlags));                   \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = wMacroVal;                                           \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)&((DataDescPtr)(pDesc))->Field,    \
                             (void *)(pVal),                            \
                             sizeof(word), (iFlags));                   \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   *(pError) = ddi_copyin((void *)&((DataDescPtr)(pDesc))->Field,       \
                          (void *)(pVal),                               \
                          sizeof(word), (iFlags));                      \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a word field of a data descriptor to user space */
/* independently from the application's data model */
#ifdef LINUX
#define PUT_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   word wMacroVal;                                                      \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      wMacroVal = (word)*(pVal);                                        \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = copy_to_user((void *)&(pDesc32)->Field,               \
                               (void *)&wMacroVal,                      \
                               sizeof(word));                           \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)&((DataDescPtr)(pDesc))->Field,  \
                               (void *)(pVal),                          \
                               sizeof(word));                           \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   DataDesc32_t *pDesc32;                                               \
   word wMacroVal;                                                      \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      wMacroVal = (word)*(pVal);                                        \
      pDesc32 = (DataDesc32_t *)(pDesc);                                \
      *(pError) = ddi_copyout((void *)&wMacroVal,                       \
                              (void *)&(pDesc32)->Field,                \
                              sizeof(word), (iFlags));                  \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)&((DataDescPtr)(pDesc))->Field,   \
                              sizeof(word), (iFlags));                  \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_DATA_DESC_WORDFIELD(pDesc, pVal, Field, iFlags, pError)     \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)&((DataDescPtr)(pDesc))->Field,      \
                           sizeof(word), (iFlags));                     \
   if (*(pError) != 0)                                                  \
       *(pError) = EFAULT;                                              \
}
#endif
#endif

/* Macro to copy a pointer field of a primitive descriptor from user space */
/* independently from the application's data model */
#ifdef LINUX
#define GET_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError, CastType)      \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_from_user((void *)&Addr32,                       \
                                 (void *)&(pPrim32)->Field,             \
                                 sizeof(uint32_t));                     \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (CastType *)((unsigned long)Addr32);                 \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)&((PrimDescPtr)(pPrim))->Field,\
                                 sizeof(void *));                       \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError, CastType) \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyin((void *)&(pPrim32)->Field,                 \
                             (void *)&Addr32,                           \
                             sizeof(uint32_t), (iFlags));               \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (CastType *)((unsigned long)Addr32);                 \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)&((PrimDescPtr)(pPrim))->Field,    \
                             (void *)(pVal),                            \
                             sizeof(void *), (iFlags));                 \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError, CastType) \
{                                                                       \
   *(pError) = ddi_copyin((void *)&((PrimDescPtr)(pPrim))->Field,       \
                          (void *)(pVal),                               \
                          sizeof(void *), (iFlags));                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a pointer field of a primitive descriptor to user space */
#ifdef LINUX
#define PUT_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError)      \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_to_user((void *)&(pPrim32)->Field,               \
                               (void *)&Addr32,                         \
                               sizeof(uint32_t));                       \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)&((PrimDescPtr)(pPrim))->Field,  \
                               (void *)(pVal),                          \
                               sizeof(void *));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError)      \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyout((void *)&Addr32,                          \
                              (void *)&(pPrim32)->Field,                \
                              sizeof(uint32_t), (iFlags));              \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli (PTRFIELD");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)&((PrimDescPtr)(pPrim))->Field,   \
                              sizeof(void *), (iFlags));                \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_PRIM_DESC_PTRFIELD(pPrim, pVal, Field, iFlags, pError)      \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)&((PrimDescPtr)(pPrim))->Field,      \
                           sizeof(void *), (iFlags));                   \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a word field of a primitive descriptor from user space */
#ifdef LINUX
#define GET_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   word wMacroVal;                                                      \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_from_user((void *)&wMacroVal,                    \
                                 (void *)&(pPrim32)->Field,             \
                                 sizeof(word));                         \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = wMacroVal;                                           \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)&((PrimDescPtr)(pPrim))->Field,\
                                 sizeof(word));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   word wMacroVal;                                                      \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyin((void *)&(pPrim32)->Field,                 \
                             (void *)&wMacroVal,                        \
                             sizeof(word), (iFlags));                   \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = wMacroVal;                                           \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)&((PrimDescPtr)(pPrim))->Field,    \
                             (void *)(pVal),                            \
                             sizeof(word), (iFlags));                   \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   *(pError) = ddi_copyin((void *)&((PrimDescPtr)(pPrim))->Field,       \
                          (void *)(pVal),                               \
                          sizeof(word), (iFlags));                      \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a word field of a primitive descriptor to user space */
#ifdef LINUX
#define PUT_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   word wMacroVal;                                                      \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      wMacroVal = (word)*(pVal);                                        \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_to_user((void *)&(pPrim32)->Field,               \
                               (void *)&wMacroVal,                      \
                               sizeof(word));                           \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)&((PrimDescPtr)(pPrim))->Field,  \
                               (void *)(pVal),                          \
                               sizeof(word));                           \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   word wMacroVal;                                                      \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      wMacroVal = (word)*(pVal);                                        \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyout((void *)&wMacroVal,                       \
                              (void *)&(pPrim32)->Field,                \
                              sizeof(word), (iFlags));                  \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli (WORDFIELD");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)&((PrimDescPtr)(pPrim))->Field,   \
                              sizeof(word), (iFlags));                  \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_PRIM_DESC_WORDFIELD(pPrim, pVal, Field, iFlags, pError)     \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)&((PrimDescPtr)(pPrim))->Field,      \
                           sizeof(word), (iFlags));                     \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy the PrimInfo field of a primitive descriptor from user */
#ifdef LINUX
#define GET_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_from_user((void *)pVal,                          \
                                 (void *)(pPrim32)->PrimInfo,           \
                                 MAX_PRIM_INFO);                        \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)((PrimDescPtr)(pPrim))->PrimInfo,\
                                 MAX_PRIM_INFO);                        \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyin((void *)(pPrim32)->PrimInfo,               \
                             (void *)pVal,                              \
                             MAX_PRIM_INFO, (iFlags));                  \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)((PrimDescPtr)(pPrim))->PrimInfo,  \
                             (void *)(pVal),                            \
                             MAX_PRIM_INFO, (iFlags));                  \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   *(pError) = ddi_copyin((void *)((PrimDescPtr)(pPrim))->PrimInfo,     \
                          (void *)(pVal),                               \
                          MAX_PRIM_INFO, (iFlags));                     \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy the PrimInfo field of a primitive descriptor to user space */
/* independently from the application's data model */
#ifdef LINUX
#define PUT_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_to_user((void *)(pPrim32)->PrimInfo,             \
                               (void *)pVal,                            \
                               MAX_PRIM_INFO);                          \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)((PrimDescPtr)(pPrim))->PrimInfo,\
                               (void *)(pVal),                          \
                               MAX_PRIM_INFO);                          \
   }                                                                    \
   if (*(pError) != 0)                                                  \
     *(pError) = EFAULT;                                                \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   PrimDesc32_t *pPrim32;                                               \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyout((void *)pVal,                             \
                              (void *)(pPrim32)->PrimInfo,              \
                              MAX_PRIM_INFO, (iFlags));                 \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)((PrimDescPtr)(pPrim))->PrimInfo, \
                              MAX_PRIM_INFO, (iFlags));                 \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_PRIM_DESC_PRIMINFO(pPrim, pVal, iFlags, pError)             \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)((PrimDescPtr)(pPrim))->PrimInfo,    \
                           MAX_PRIM_INFO, (iFlags));                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy the whole PrimDesc_t from user */
#ifdef LINUX
#define GET_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   PrimDesc32_t Prim32;                                                 \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      *(pError) = copy_from_user((void *)&Prim32,                       \
                                 (void *)(pPrim),                       \
                                 sizeof(PrimDesc32_t));                 \
      if (*(pError) == 0)                                               \
      {                                                                 \
         (PrimDescPtr)(pVal)->PrimId = Prim32.PrimId;                   \
         (PrimDescPtr)(pVal)->PrimRef = Prim32.PrimRef;                 \
         bcopy(Prim32.PrimInfo, (PrimDescPtr)(pVal)->PrimInfo, MAX_PRIM_INFO);\
         (PrimDescPtr)(pVal)->DataDescPtr = Prim32.DataDescPtr;         \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)(pPrim),                       \
                                 sizeof(PrimDesc_t));                   \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   PrimDesc32_t Prim32;                                                 \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pPrim),                           \
                             (void *)&Prim32,                           \
                             sizeof(PrimDesc32_t), (iFlags));           \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
      (PrimDescPtr)(pVal)->PrimId = Prim32.PrimId;                      \
      (PrimDescPtr)(pVal)->PrimRef = Prim32.PrimRef;                    \
      bcopy(Prim32.PrimInfo, (PrimDescPtr)(pVal)->PrimInfo, MAX_PRIM_INFO);\
      (PrimDescPtr)(pVal)->DataDescPtr = Prim32.DataDescPtr;            \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)((PrimDescPtr)(pPrim)),            \
                             (void *)(pVal),                            \
                             sizeof(PrimDesc_t), (iFlags));             \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   *(pError) = ddi_copyin((void *)((PrimDescPtr)(pPrim)),               \
                          (void *)(pVal),                               \
                          sizeof(PrimDesc_t), (iFlags));                \
   if (*(pError) != 0)                                                  \
       *(pError) = EFAULT;                                              \
}
#endif
#endif

/* Macro to copy the PrimInfo field of a primitive descriptor to user space */
/* independently from the application's data model */
#ifdef LINUX
#define PUT_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   PrimDesc32_t Prim32;                                                 \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      Prim32.NextPtr = (PrimDescPtr)(pVal)->NextPtr;                    \
      Prim32.PrevPtr = (PrimDescPtr)(pVal)->PrevPtr;                    \
      Prim32.PrimId = (PrimDescPtr)(pVal)->PrimId;                      \
      Prim32.PrimRef = (PrimDescPtr)(pVal)->PrimRef;                    \
      bcopy((PrimDescPtr)(pVal)->PrimInfo, Prim32.PrimInfo, MAX_PRIM_INFO);\
      Prim32.DataDescPtr = (PrimDescPtr)(pVal)->DataDescPtr;            \
      Prim32.PrimInPool = (PrimDescPtr)(pVal)->PrimInPool;              \
      Prim32.SizeInPool = (PrimDescPtr)(pVal)->SizeInPool;              \
      Prim32.BuffInPool = (PrimDescPtr)(pVal)->BuffInPool;              \
      Prim32.MorePrim = (PrimDescPtr)(pVal)->MorePrim;                  \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = copy_to_user((void *)(pPrim),                         \
                               (void *)&Prim32,                         \
                               sizeof(PrimDesc32_t));                   \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)((PrimDescPtr)(pPrim)),          \
                               (void *)(pVal),                          \
                               sizeof(PrimDesc_t));                     \
   }                                                                    \
   if (*(pError) != 0)                                                  \
     *(pError) = EFAULT;                                                \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   PrimDesc32_t Prim32;                                                 \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      Prim32.NextPtr = (PrimDescPtr)(pVal)->NextPtr;                    \
      Prim32.PrevPtr = (PrimDescPtr)(pVal)->PrevPtr;                    \
      Prim32.PrimId = (PrimDescPtr)(pVal)->PrimId;                      \
      Prim32.PrimRef = (PrimDescPtr)(pVal)->PrimRef;                    \
      bcopy((PrimDescPtr)(pVal)->PrimInfo, Prim32.PrimInfo, MAX_PRIM_INFO);\
      Prim32.DataDescPtr = (PrimDescPtr)(pVal)->DataDescPtr;            \
      Prim32.PrimInPool = (PrimDescPtr)(pVal)->PrimInPool;              \
      Prim32.SizeInPool = (PrimDescPtr)(pVal)->SizeInPool;              \
      Prim32.BuffInPool = (PrimDescPtr)(pVal)->BuffInPool;              \
      Prim32.MorePrim = (PrimDescPtr)(pVal)->MorePrim;                  \
      pPrim32 = (PrimDesc32_t *)(pPrim);                                \
      *(pError) = ddi_copyout((void *)&Prim32,                          \
                              (void *)(pPrim),                          \
                              sizeof(PrimDesc32_t), (iFlags));          \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)((PrimDescPtr)(pPrim)),           \
                              sizeof(PrimDesc_t), (iFlags));            \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_PRIM_DESC(pPrim, pVal, iFlags, pError)                      \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)((PrimDescPtr)(pPrim)),              \
                           sizeof(PrimDesc_t), (iFlags));               \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a pointer field from user space */
#ifdef LINUX
#define GET_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      *(pError) = copy_from_user((void *)&Addr32,                       \
                                 (void *)(pAddr),                       \
                                 sizeof(uint32_t));                     \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (void *)Addr32;                                      \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)(pAddr),                       \
                                 sizeof(void *));                       \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pAddr),                           \
                             (void *)&Addr32,                           \
                             sizeof(uint32_t), (iFlags));               \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (void *)Addr32;                                      \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)(pAddr),                           \
                             (void *)(pVal),                            \
                             sizeof(void *), (iFlags));                 \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyin((void *)(pAddr),                              \
                          (void *)(pVal),                               \
                          sizeof(void *), (iFlags));                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a pointer field to user space */
#ifdef LINUX
#define PUT_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      *(pError) = copy_to_user((void *)(pAddr),                         \
                               (void *)&Addr32,                         \
                               sizeof(uint32_t));                       \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)(pAddr),                         \
                               (void *)(pVal),                          \
                               sizeof(void *));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      *(pError) = ddi_copyout((void *)&Addr32,                          \
                              (void *)(pAddr),                          \
                              sizeof(uint32_t), (iFlags));              \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)(pAddr),                          \
                              sizeof(void *), (iFlags));                \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_PTRFIELD(pAddr, pVal, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)(pAddr),                             \
                           sizeof(void *), (iFlags));                   \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy a driver pool structure to user space*/
#ifdef LINUX
#define PUT_DRV_POOL(pSrc, pDest, iFlags, pLength, pError)              \
{                                                                       \
   DrvPool32_t Pool32;                                                  \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      Pool32.UsedQueue[0] = (uint32_t)((unsigned long)(pSrc)->UsedQueue[0]); \
      Pool32.UsedQueue[1] = (uint32_t)((unsigned long)(pSrc)->UsedQueue[1]); \
      Pool32.FreeQueue[0] = (uint32_t)((unsigned long)(pSrc)->FreeQueue[0]); \
      Pool32.FreeQueue[1] = (uint32_t)((unsigned long)(pSrc)->FreeQueue[1]); \
      Pool32.PoolIndex = (pSrc)->PoolIndex;                             \
      Pool32.PoolSize = (pSrc)->PoolSize;                               \
      Pool32.InitCount = (pSrc)->InitCount;                             \
      Pool32.MaxCount = (pSrc)->MaxCount;                               \
      Pool32.TotalCount = (pSrc)->TotalCount;                           \
      Pool32.UsedCount = (pSrc)->UsedCount;                             \
      Pool32.FreeCount = (pSrc)->FreeCount;                             \
      Pool32.MaxUsedCount = (pSrc)->MaxUsedCount;                       \
      *(pError) = copy_to_user((void *)(pDest), (void *)&Pool32,        \
                               sizeof(DrvPool32_t));                    \
      if (*(pError) == 0)                                               \
         *(pLength) = sizeof(DrvPool32_t);                              \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)(pDest), (void *)(pSrc),         \
                               sizeof(DrvPool_t));                      \
      if (*(pError) == 0)                                               \
         *(pLength) = sizeof(DrvPool_t);                                \
   }                                                                    \
   if (*(pError) != 0)                                                  \
   {                                                                    \
      *(pLength) = 0;                                                   \
      *(pError) = EFAULT;                                               \
   }                                                                    \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_DRV_POOL(pSrc, pDest, iFlags, pLength, pError)              \
{                                                                       \
   DrvPool32_t Pool32;                                                  \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      Pool32.UsedQueue[0] = (uint32_t)((unsigned long)(pSrc)->UsedQueue[0]); \
      Pool32.UsedQueue[1] = (uint32_t)((unsigned long)(pSrc)->UsedQueue[1]); \
      Pool32.FreeQueue[0] = (uint32_t)((unsigned long)(pSrc)->FreeQueue[0]); \
      Pool32.FreeQueue[1] = (uint32_t)((unsigned long)(pSrc)->FreeQueue[1]); \
      Pool32.PoolIndex = (pSrc)->PoolIndex;                             \
      Pool32.PoolSize = (pSrc)->PoolSize;                               \
      Pool32.InitCount = (pSrc)->InitCount;                             \
      Pool32.MaxCount = (pSrc)->MaxCount;                               \
      Pool32.TotalCount = (pSrc)->TotalCount;                           \
      Pool32.UsedCount = (pSrc)->UsedCount;                             \
      Pool32.FreeCount = (pSrc)->FreeCount;                             \
      Pool32.MaxUsedCount = (pSrc)->MaxUsedCount;                       \
      *(pError) = ddi_copyout((void *)&Pool32, (void *)(pDest),         \
                              sizeof(DrvPool32_t), (iFlags));           \
      if (*(pError) == 0)                                               \
         *(pLength) = sizeof(DrvPool32_t);                              \
      else                                                              \
         *(pLength) = 0;                                                \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pSrc), (void *)(pDest),          \
                              sizeof(DrvPool_t), (iFlags));             \
      if (*(pError) == 0)                                               \
         *(pLength) = sizeof(DrvPool_t);                                \
      else                                                              \
      {                                                                 \
         *(pLength) = 0;                                                \
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
}
#else
#define PUT_DRV_POOL(pSrc, pDest, iFlags, pLength, pError)              \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pSrc), (void *)(pDest),             \
                           sizeof(DrvPool_t), (iFlags));                \
   if (*(pError) == 0)                                                  \
      *(pLength) = sizeof(DrvPool_t);                                   \
   else                                                                 \
   {                                                                    \
      *(pLength) = 0;                                                   \
      *(pError) = EFAULT;                                               \
   }                                                                    \
}
#endif
#endif

/* Macro to copy the NextPtr field of a PoolItem_t from user space */
#ifdef LINUX
#define GET_POOL_ITEM_NEXTPTR(pItem, pVal, iFlags, pError)              \
{                                                                       \
   PoolItem32_t *pItem32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pItem32 = (PoolItem32_t *)(pItem);                                \
      *(pError) = copy_from_user((void *)&Addr32,                       \
                                 (void *)&pItem32->NextPtr,             \
                                 sizeof(uint32_t));                     \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (PoolItemPtr)((unsigned long)Addr32);                \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_from_user((void *)(pVal),                        \
                                 (void *)&(pItem)->NextPtr,             \
                                 sizeof(void *));                       \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define GET_POOL_ITEM_NEXTPTR(pItem, pVal, iFlags, pError)              \
{                                                                       \
   PoolItem32_t *pItem32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pItem32 = (PoolItem32_t *)(pItem);                                \
      *(pError) = ddi_copyin((void *)&pItem32->NextPtr,                 \
                             (void *)&Addr32,                           \
                             sizeof(uint32_t), (iFlags));               \
      if (*(pError) == 0)                                               \
      {                                                                 \
         *(pVal) = (PoolItemPtr)((unsigned long)Addr32);                \
      }                                                                 \
      else                                                              \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data from 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyin((void *)&(pItem)->NextPtr,                 \
                             (void *)(pVal),                            \
                             sizeof(void *), (iFlags));                 \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define GET_POOL_ITEM_NEXTPTR(pItem, pVal, iFlags, pError)              \
{                                                                       \
   *(pError) = ddi_copyin((void *)&(pItem)->NextPtr,                    \
                          (void *)(pVal),                               \
                          sizeof(void *), (iFlags));                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* Macro to copy the NextPtr field of a PoolItem_t to user space */
#ifdef LINUX
#define PUT_POOL_ITEM_NEXTPTR(pAddr, pVal, iFlags, pError)              \
{                                                                       \
   PoolItem32_t *pItem32;                                               \
   uint32_t Addr32;                                                     \
   if (iFlags == MODE_32)                                               \
   {                                                                    \
      pItem32 = (PoolItem32_t *)(pAddr);                                \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      *(pError) = copy_to_user((void *)&pItem32->NextPtr,               \
                               (void *)&Addr32,                         \
                               sizeof(uint32_t));                       \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = copy_to_user((void *)&(pAddr)->NextPtr,               \
                               (void *)(pVal),                          \
                               sizeof(void *));                         \
   }                                                                    \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#ifdef _MULTI_DATAMODEL
#define PUT_POOL_ITEM_NEXTPTR(pAddr, pVal, iFlags, pError)              \
{                                                                       \
   PoolItem32_t *pItem32;                                               \
   uint32_t Addr32;                                                     \
                                                                        \
   if (ddi_model_convert_from((iFlags) & FMODELS) == DDI_MODEL_ILP32)   \
   {                                                                    \
      pItem32 = (PoolItem32_t *)(pAddr);                                \
      Addr32 = (uint32_t)((unsigned long)*(pVal));                      \
      *(pError) = ddi_copyout((void *)&Addr32,                          \
                              (void *)&pItem32->NextPtr,                \
                              sizeof(uint32_t), (iFlags));              \
      if (*(pError) != 0)                                               \
      {                                                                 \
         iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_STR, 0,             \
                             (byte *)"failed to copy data to 32-bit appli");\
         *(pError) = EFAULT;                                            \
      }                                                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      *(pError) = ddi_copyout((void *)(pVal),                           \
                              (void *)&(pAddr)->NextPtr,                \
                              sizeof(void *), (iFlags));                \
      if (*(pError) != 0)                                               \
         *(pError) = EFAULT;                                            \
   }                                                                    \
}
#else
#define PUT_POOL_ITEM_NEXTPTR(pAddr, pVal, iFlags, pError)              \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pVal),                              \
                           (void *)&(pAddr)->NextPtr,                   \
                           sizeof(void *), (iFlags));                   \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif
#endif

/* macro to copy data from user space to kernel space */
#ifdef LINUX
#define GET_DATA_USER(pU, pK, sz, iFlags, pError)                       \
{                                                                       \
   *(pError) = copy_from_user((void *)(pK), (void *)(pU), (sz));        \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#define GET_DATA_USER(pU, pK, sz, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyin((void *)(pU), (void *)(pK),                   \
                          (sz), (iFlags));                              \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

/* macro to copy data to user space from kernel space */
#ifdef LINUX
#define PUT_DATA_USER(pU, pK, sz, iFlags, pError)                       \
{                                                                       \
   *(pError) = copy_to_user((void *)(pU), (void *)(pK), (sz));          \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef SOLARIS
#define PUT_DATA_USER(pU, pK, sz, iFlags, pError)                       \
{                                                                       \
   *(pError) = ddi_copyout((void *)(pK), (void *)(pU),                  \
                           (sz), (iFlags));                             \
   if (*(pError) != 0)                                                  \
      *(pError) = EFAULT;                                               \
}
#endif

#ifdef LINUX
#define ALLOC_KERNEL (GFP_ATOMIC)
#define ALLOC_DMA    (GFP_ATOMIC|__GFP_DMA)
#endif
#ifdef SOLARIS
#define ALLOC_KERNEL (KM_NOSLEEP)
#define ALLOC_DMA    (KM_NOSLEEP)
#endif

#ifdef LINUX
/* The following macros provide an abstraction for the dma handle binding
 * between linux and Solaris. These were added as part of the linux port.
 */
typedef struct DmaCookie
{
   dma_addr_t dma_addr;
} DmaCookie_t;

#define DMA_SLEEP 1
#define DMA_NOSLEEP 0   
   
#define DMA_ADDRESS(cookie) cookie.dma_addr

#define DMA_ALLOC_HANDLE(pDev, pDmaDesc)                                   \
{                                                                          \
   (pDmaDesc)->PhysAddr = 0;                                               \
   (pDmaDesc)->Status |= ALLOCATED;                                         \
}

#define DMA_BIND_RECEIVE_HANDLE(pDev, pDmaDesc, buffer, size)              \
{                                                                          \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      (pDmaDesc)->PhysAddr = pci_map_single((pDev)->sDev.Dev,              \
                                            (void *)(buffer),              \
                                            size, PCI_DMA_FROMDEVICE);     \
      (pDmaDesc)->Size = size;                                             \
      (pDmaDesc)->Direction = PCI_DMA_FROMDEVICE;                          \
      (pDmaDesc)->Status |= BOUND;                                         \
   }                                                                       \
}

#define DMA_BIND_SEND_HANDLE(pDev, pDmaDesc, buffer, size)                 \
{                                                                          \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      (pDmaDesc)->PhysAddr = pci_map_single((pDev)->sDev.Dev,              \
                                            (void *)(buffer),              \
                                            size, PCI_DMA_TODEVICE);       \
      (pDmaDesc)->Size = size;                                             \
      (pDmaDesc)->Direction = PCI_DMA_TODEVICE;                            \
      (pDmaDesc)->Status |= BOUND;                                         \
   }                                                                       \
}

#define DMA_UNBIND_HANDLE(pDev, pDmaDesc)                                  \
{                                                                          \
   if (((pDmaDesc)->Status & BOUND) != 0 &&                                \
       (pDmaDesc)->PhysAddr != 0 && (pDmaDesc)->PhysAddr != 0xFFFFFFFF)    \
   {                                                                       \
      pci_unmap_single(pDev->sDev.Dev, (pDmaDesc)->PhysAddr,               \
                       (pDmaDesc)->Size, (pDmaDesc)->Direction);           \
      (pDmaDesc)->PhysAddr = 0;                                            \
   }                                                                       \
   (pDmaDesc)->Status &= ~BOUND;                                           \
}

#define DMA_FREE_HANDLE(pDev, pDmaDesc)                                    \
{                                                                          \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      (pDmaDesc)->Direction = 0;                                           \
      (pDmaDesc)->PhysAddr = 0;                                            \
   }                                                                       \
   (pDmaDesc)->Status &= ~ALLOCATED;                                       \
}

#define DMA_ALLOC_MEM(pDev, pDmaDesc, len, pReal)                          \
{                                                                          \
   *pReal = 0;                                                             \
   (pDmaDesc)->VirtAddr = kmalloc(len, ALLOC_DMA);                          \
   if ((pDmaDesc)->VirtAddr != NULL)                                       \
   {                                                                       \
      *pReal = len;                                                        \
      (pDmaDesc)->Status |= MEM_ALLOCATED;                                 \
   }                                                                       \
}

#define DMA_FREE_MEM(pDev, pDmaDesc)                                       \
{                                                                          \
   if (((pDmaDesc)->Status & MEM_ALLOCATED) != 0 &&                        \
       (pDmaDesc)->VirtAddr != NULL)                                       \
   {                                                                       \
      kfree((pDmaDesc)->VirtAddr);                                         \
      (pDmaDesc)->VirtAddr = NULL;                                         \
   }                                                                       \
   (pDmaDesc)->Status &= ~MEM_ALLOCATED;                                   \
}

#endif /* LINUX */

#ifdef SOLARIS
#define DMA_ALLOC_HANDLE(pDev, pDmaDesc)                                   \
{                                                                          \
   (pDmaDesc)->Direction = 0;                                              \
   (pDmaDesc)->PhysAddr = 0;                                               \
   if (ddi_dma_alloc_handle((pDev)->sDev.Dev, &(pDev)->sDev.dma_attr,      \
                            DDI_DMA_SLEEP, NULL,                           \
                            &(pDmaDesc)->Handle) != DDI_SUCCESS)           \
   {                                                                       \
      (pDmaDesc)->PhysAddr = 0xFFFFFFFF;                                   \
   }                                                                       \
   else                                                                    \
   {                                                                       \
      (pDmaDesc)->Status |= ALLOCATED;                                     \
   }                                                                       \
}


#define DMA_BIND_RECEIVE_HANDLE(pDev, pDmaDesc, buffer, size)              \
{                                                                          \
   ddi_dma_cookie_t cookie;                                                \
   uint_t uiCount;                                                         \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      if (ddi_dma_addr_bind_handle((pDmaDesc)->Handle,NULL,                \
                                   (caddr_t)(buffer), (size),              \
                                   DDI_DMA_RDWR|DDI_DMA_CONSISTENT,        \
                                   DDI_DMA_SLEEP, NULL,                    \
                                   &cookie, &uiCount) != DDI_SUCCESS)      \
      {                                                                    \
         (pDmaDesc)->PhysAddr = 0;                                         \
      }                                                                    \
      else                                                                 \
      {                                                                    \
         (pDmaDesc)->PhysAddr = cookie.dmac_address;                       \
         (pDmaDesc)->Size = size;                                          \
         (pDmaDesc)->Direction = PCI_DMA_FROMDEVICE;                       \
         (pDmaDesc)->Status |= BOUND;                                      \
      }                                                                    \
   }                                                                       \
}

#define DMA_BIND_SEND_HANDLE(pDev, pDmaDesc, buffer, size)                 \
{                                                                          \
   ddi_dma_cookie_t cookie;                                                \
   uint_t uiCount;                                                         \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      if (ddi_dma_addr_bind_handle((pDmaDesc)->Handle,NULL,                \
                                   (caddr_t)(buffer), (size),              \
                                   DDI_DMA_RDWR|DDI_DMA_CONSISTENT,        \
                                   DDI_DMA_SLEEP, NULL,                    \
                                   &cookie, &uiCount) != DDI_SUCCESS)      \
      {                                                                    \
         (pDmaDesc)->PhysAddr = 0;                                         \
      }                                                                    \
      else                                                                 \
      {                                                                    \
         (pDmaDesc)->PhysAddr = cookie.dmac_address;                       \
         (pDmaDesc)->Size = size;                                          \
         (pDmaDesc)->Direction = PCI_DMA_TODEVICE;                         \
         (pDmaDesc)->Status |= BOUND;                                      \
      }                                                                    \
   }                                                                       \
}

#define DMA_UNBIND_HANDLE(pDev, pDmaDesc)                                  \
{                                                                          \
   if (((pDmaDesc)->Status & BOUND) != 0 &&                                \
       (pDmaDesc)->PhysAddr != 0 && (pDmaDesc)->PhysAddr != 0xFFFFFFFF)    \
   {                                                                       \
      ddi_dma_unbind_handle((pDmaDesc)->Handle);                           \
      (pDmaDesc)->PhysAddr = 0;                                            \
   }                                                                       \
   (pDmaDesc)->Status &= ~BOUND;                                           \
}

#define DMA_FREE_HANDLE(pDev, pDmaDesc)                                    \
{                                                                          \
   if (((pDmaDesc)->Status & ALLOCATED) != 0)                              \
   {                                                                       \
      ddi_dma_free_handle(&(pDmaDesc)->Handle);                            \
   }                                                                       \
   (pDmaDesc)->PhysAddr = 0;                                               \
   (pDmaDesc)->Status &= ~ALLOCATED;                                       \
}

#define DMA_ALLOC_MEM(pDev, pDmaDesc, len, pReal)                          \
{                                                                          \
   if (ddi_dma_mem_alloc((pDmaDesc)->Handle,                               \
                         len, &(pDev)->sDev.dram_attr,                     \
                         DDI_DMA_CONSISTENT, DDI_DMA_SLEEP,                \
                         NULL, &(pDmaDesc)->VirtAddr,                      \
                         pReal, &(pDmaDesc)->AccHandle) != DDI_SUCCESS)    \
   {                                                                       \
      (pDmaDesc)->VirtAddr = NULL;                                         \
      *pReal = 0;                                                          \
   }                                                                       \
   else                                                                    \
   {                                                                       \
      (pDmaDesc)->Status |= MEM_ALLOCATED;                                 \
   }                                                                       \
}

#define DMA_FREE_MEM(pDev, pDmaDesc)                                       \
{                                                                          \
   if (((pDmaDesc)->Status & MEM_ALLOCATED) != 0 &&                        \
       (pDmaDesc)->VirtAddr != NULL)                                       \
   {                                                                       \
      ddi_dma_mem_free(&(pDmaDesc)->AccHandle);                            \
      (pDmaDesc)->VirtAddr = NULL;                                         \
   }                                                                       \
   (pDmaDesc)->Status &= ~MEM_ALLOCATED;                                   \
}
#endif /* SOLARIS */

#define GIVE_BUFF_TO_CARD(pDev, pDesc)                                     \
{                                                                          \
   word wPool;                                                             \
   V5_OutboundPoolPtr pOutbPool;                                           \
   wPool = (pDesc)->PoolIndex;                                             \
   pOutbPool = &pDev->OutbPool[wPool][pDev->OutbPoolIndex[wPool]];         \
   WRITE_MEM_WORD(pDev, (dword *)&(pOutbPool->DataIndex), (pDesc)->Index); \
   iphwae_TRACE_STRING(IPHWAN_ID, TRC, IPHWAN_FNCT, 0,                     \
                       (byte *)"[GIVE_BUFF_TO_CARD] buffer index/addr - pool index/position");\
   iphwae_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2,                         \
                   (pDesc)->Index, (pDesc)->PhysAddr);                     \
   iphwae_TRACE_D2(IPHWAN_ID, TRC, IPHWAN_ARGVAL2,                         \
                   wPool, pDev->OutbPoolIndex[wPool]);                     \
   pDev->OutbPoolIndex[wPool]++;                                           \
   if (pDev->OutbPoolIndex[wPool] == pDev->OutbDataNb)                     \
   {                                                                       \
      pDev->OutbPoolIndex[wPool] = 0;                                      \
   }                                                                       \
}

#ifdef LINUX
#define MUTEX_INIT                  iphwae_mutex_init
#define MUTEX_ENTER                 iphwae_mutex_lock
#define MUTEX_TRY_ENTER             iphwae_mutex_trylock
#define MUTEX_EXIT                  iphwae_mutex_unlock
#define MUTEX_DESTROY
#define CV_INIT(cond, a2, a3, a4)   iphwae_cond_init(cond)
#define CV_SIGNAL                   iphwae_cond_signal
#define CV_WAIT                     iphwae_cond_wait
#define CV_WAIT_SIG                 iphwae_cond_wait
#define CV_TIMEDWAIT                iphwae_cond_timed_wait_abs
#define CV_DESTROY
#endif
#ifdef SOLARIS
#define MUTEX_INIT                  mutex_init
#define MUTEX_ENTER                 mutex_enter
#define MUTEX_TRY_ENTER             mutex_tryenter
#define MUTEX_EXIT                  mutex_exit
#define MUTEX_DESTROY               mutex_destroy
#define CV_INIT                     cv_init
#define CV_SIGNAL                   cv_signal
#define CV_WAIT                     cv_wait
#define CV_WAIT_SIG                 cv_wait_sig
#define CV_TIMEDWAIT                cv_timedwait
#define CV_DESTROY                  cv_destroy
#ifdef SOL_9
#define memcpy(dest, src, len)      bcopy(src, dest, len)   
#define memcmp                      bcmp
#define memset(s1, c, len) \
{\
   int i; \
   for (i = 0; i < len; i++)\
   {\
      ((byte *)(s1))[i] = c;\
   }\
}
#endif
#endif

#define IPH_LOCK(pLock)     \
{                           \
   if (pLock != NULL)       \
   {                                                                 \
      MUTEX_ENTER(pLock);   \
   }                                                                 \
}

#define IPH_UNLOCK(pLock)   \
{                           \
   if (pLock != NULL)       \
   {                                                                 \
      MUTEX_EXIT(pLock);    \
   }                                                                 \
}

/*
 * macro to delete timer
 */
#ifdef LINUX
#ifdef CONFIG_SMP
#define IPH_DEL_TIMER(timer) del_timer_sync(timer) 
#else
#define IPH_DEL_TIMER(timer) del_timer(timer) 
#endif

#define IPH_START_TIMER(pTimer, callback, arg, delay)             \
{                                                                 \
   (pTimer)->function = (callback);                               \
   (pTimer)->data = (unsigned long)(arg);                         \
   (pTimer)->expires = jiffies + ((delay) / 1000 * HZ);           \
   add_timer(pTimer);                                             \
}

#define IPH_DELAY(duration)                                       \
{                                                                 \
   set_current_state ( TASK_UNINTERRUPTIBLE );                    \
   schedule_timeout ( duration * HZ );                            \
}
#endif /* LINUX */

#ifdef SOLARIS
#define IPH_DEL_TIMER(timer)                                      \
{                                                                 \
   untimeout(*(timer));                                           \
}

#define IPH_START_TIMER(pTimer, callback, arg, delay)             \
{                                                                 \
   *(pTimer) = timeout((callback), (caddr_t)(arg),                \
                       (delay)/1000*drv_usectohz(1000000));       \
}

#define IPH_DELAY(duration)                                       \
{                                                                 \
   delay ( duration*drv_usectohz(1000000) );                      \
}
#endif /* SOLARIS */


/*macro to get time */
#ifdef LINUX
#define IPH_GET_TIME(ptime) do_gettimeofday((ptime))
#define IPH_GET_UTIME(ptime) (ptime = 0)
#define MDELAY(val)                                               \
{                                                                 \
   set_current_state ( TASK_UNINTERRUPTIBLE );                    \
   schedule_timeout ( val*HZ/1000 );                              \
}
#define UDELAY(val)         udelay(val)
#endif /* LINUX */

#ifdef SOLARIS
#ifdef SOL_7
#define IPH_GET_TIME(pdwTime)                                     \
{                                                                 \
   *(pdwTime) = (dword)ddi_get_time();                            \
}
#define GET_LBOLT(pdwTime)                                        \
{                                                                 \
   *(pdwTime) = (dword)ddi_get_lbolt();                           \
}

#else
#define IPH_GET_TIME(pdwTime)                                     \
{                                                                 \
   drv_getparm(TIME, pdwTime);                                    \
}
#define GET_LBOLT(pdwTime)                                        \
{                                                                 \
   drv_getparm(LBOLT, pdwTime);                                   \
}
#endif
#define IPH_GET_UTIME(ptime)  GET_LBOLT(ptime)
/*#define MDELAY(val)           drv_usecwait(val * 1000)*/
#define MDELAY(val)                                               \
{                                                                 \
   if ( (val*1000) < drv_hztousec(1) )                            \
      delay(1);                                                   \
   else                                                           \
      delay(drv_usectohz(val*1000));                              \
}
#define UDELAY(val)           drv_usecwait(val)
#endif /* SOLARIS */

#ifdef LINUX
#define RETURN_TO_USER(v)   return(-v)
#endif
#ifdef SOLARIS
#define RETURN_TO_USER(v)   return(v)
#endif

#ifdef LINUX
#define IPH_SET_DRV_STRUCT_STATUS(s)    ((s)->Status = (dword)jiffies)
#endif
#ifdef SOLARIS
#define IPH_SET_DRV_STRUCT_STATUS(s)                              \
{                                                                 \
   IPH_GET_TIME(&(s)->Status);                                    \
}
#endif

#if defined(LINUX) && defined(__x86__)
#define TMP_FREE(pucTmpBuff) (vfree((void *)pucTmpBuff))
#else
/*#define TMP_FREE(pucTmpBuff) (iph_gvMemFree((void *)pucTmpBuff))*/
#define TMP_FREE(pucTmpBuff) \
{\
   byte saveMask = iph_gpucTraceMask[IPHWAN_ID];\
   iph_gpucTraceMask[IPHWAN_ID] = FALSE;\
   iph_gvMemFree((void *)pucTmpBuff);\
   iph_gpucTraceMask[IPHWAN_ID] = saveMask;\
}
#endif

#if defined(LINUX) && defined(__x86__)
#define TMP_ALLOC(size, ppBuf)\
{\
   *ppBuf = vmalloc(size);\
}
#else
#define TMP_ALLOC(size, ppBuf) \
{\
   byte saveMask = iph_gpucTraceMask[IPHWAN_ID];\
   iph_gpucTraceMask[IPHWAN_ID] = FALSE;\
   *ppBuf = iph_gpMemAlloc(size, 1, ALLOC_KERNEL, 1);\
   iph_gpucTraceMask[IPHWAN_ID] = saveMask;\
}
#endif

#if defined(LINUX)
#define INIT_TIMER(pTimer)\
{\
   init_timer(pTimer);\
}
#endif
#if defined(SOLARIS)
#define INIT_TIMER(pTimer)\
{\
   *pTimer = 0;\
}
#endif

#define IPH_WIN_LIMIT(addr, winsize)  ((addr) & ((winsize) -1))
#define ADDR_WINSIZE_MASK(addr, winsize)  ((addr) & ~((winsize) -1))

/***************************************************************************/
/* Public function prototypes                                              */
/***************************************************************************/

#endif

