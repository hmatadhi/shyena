/****************************************************************************
 * NAME : wanapi.h
 * VERSION : 2.10.1
 * DESCRIPTION : 
 *    Values for the control request from the application to the base driver
 * REVISIONS :
 *    - Version 1.0 10/19/99 : Creation
 *    - Version 1.1 02/04/00 : Solaris 7 support
 *    - Version 1.2 03/09/00 : Add NET_SWAP macros
 *    - Version 2.0 06/23/00 : Support for 653x
 *    - Version 2.1 01/09/01 : Add new card status
 *    - Version 2.2 01/13/06 : Add CTL_MAX_RX_CHAIN command
 *    - Version 2.3 01/17/06 : Add prototypes for iphwamc driver entry points
 *    - Version 2.4 06/26/06 : Rename entry points for iphwae base driver
 *    - Version 2.5 04/03/07 : Add CTL_GIVE_RX_DATA_BUFFER command
 *    - Version 2.6 07/19/07 : Add CTL_GET_CUSTOM_INFO support
 *    - Version 2.7 06/24/08 : Change DEF_MAX_RX_QUEUE from 16 to 1024
 *    - Version 2.8 08/11/08 : Change CARD_PQ3_CUSTOM_INFO_SIZE from 16 to 32
 *    - Version 2.9 01/12/09 : Add CTL_GET_TIME and 
 *                             CTL_SET_HOST_TIME_OFFSET commands
 *    - Version 2.10 01/19/09 : Add the ddword (unsigned 64-bit) type
 *                              Use the ddword type in TimeInfo_t
 *    - Version 2.10.1 05/11/09 : Add CTL_GET_TEMP_INFO command
 *                                Add the CARD_UNAVAILABLE status
 ****************************************************************************/
/* To prevent include of include */
#ifndef WANAPI_H
#define WANAPI_H

#define FILE_DEVICE_IPHWAN          ('i' << 8)

/***************************************************************************/
/* Types of request                                                        */
/***************************************************************************/
#define CTL_CLOSE_DEVICE            (FILE_DEVICE_IPHWAN | 1)
#define CTL_SEND_PRIM               (FILE_DEVICE_IPHWAN | 2)
#define CTL_GIVE_RX_PRIM            (FILE_DEVICE_IPHWAN | 3)
#define CTL_GIVE_RX_BUFFER          (FILE_DEVICE_IPHWAN | 4)
#define CTL_RECV_PRIM               (FILE_DEVICE_IPHWAN | 5)
#define CTL_MAX_RX_QUEUE            (FILE_DEVICE_IPHWAN | 6)
#define CTL_NO_OF_DEVICES           (FILE_DEVICE_IPHWAN | 7)
#define CTL_GET_CARD_ID             (FILE_DEVICE_IPHWAN | 8)
#define CTL_MAX_RX_CHAIN            (FILE_DEVICE_IPHWAN | 9)
#define CTL_GET_DRV_VER             (FILE_DEVICE_IPHWAN | 18)
#define CTL_GIVE_RX_DATA_BUFFER     (FILE_DEVICE_IPHWAN | 22)
#define CTL_START_DRV_TRACE         (FILE_DEVICE_IPHWAN | 41)
#define CTL_STOP_DRV_TRACE          (FILE_DEVICE_IPHWAN | 42)

#define CTL_GET_CARD_STATUS         (FILE_DEVICE_IPHWAN | 60)
#define CTL_GET_CUSTOM_INFO         (FILE_DEVICE_IPHWAN | 65)
#define CTL_GET_TIME                (FILE_DEVICE_IPHWAN | 68)
#define CTL_SET_HOST_TIME_OFFSET    (FILE_DEVICE_IPHWAN | 69)

#define CTL_GET_TEMP_INFO           (FILE_DEVICE_IPHWAN | 71)

/***************************************************************************/
/* Some useful types definition                                            */
/***************************************************************************/
#ifndef BYTE_WORD_DWORD
#define BYTE_WORD_DWORD
typedef  unsigned char  byte;
typedef  unsigned short word;
typedef  uint32_t  dword;
typedef  uint64_t  ddword;
#endif

/***************************************************************************/
/* Miscellaneous constant definitions                                      */
/***************************************************************************/
/* Size of immediate data for a primitive */
#define MAX_PRIM_INFO         8

/* No application identificator */
#define NO_APP_ID             0xFFFF

/* No index */
#define NO_INDEX              0xFFFF

/* Type of call on kd_free callback */
#define SENT_PRIM             1
#define RECV_PRIM             2
#define RECV_BUFFER           3

/* Default receive queue depth per application */
#define DEF_MAX_RX_QUEUE      1024

/* Special module identificator value to specify all the modules */
#define MODULE_ALL            0xFF

/* Types of trace (used in a trace header) */
#define NO_TRC                0
#define TRC                   1
#define EVT                   2
#define ERR                   3

/* Status for a device */
#define CARD_POST_FAILED      0
#define CARD_RESET            1
#define CARD_WATCHDOG         2
#define CARD_LOADED           3
#define CARD_RUNNING          4
#define CARD_UNAVAILABLE      5


/* conversion to Big-Endian (depends on the machine processor) */
#ifdef _LITTLE_ENDIAN
#define SWAP16(var)                                               \
   (((((word)(var)) >> 8) & 0x00FF) | ((((word)(var)) << 8) & 0xFF00))
#define SWAP32(lvar)                                              \
   ((dword)(SWAP16(((dword)(lvar) >> 16) & 0x0000FFFF) |          \
            (SWAP16((dword)(lvar) & 0x0000FFFF) << 16)))
#else
#define SWAP16(var) var
#define SWAP32(lvar) lvar
#endif

#define NET_SWAP16(var) SWAP16(var)
#define NET_SWAP32(lvar) SWAP32(lvar)

/***************************************************************************/
/* Structure of a descriptor of primitive data                             */
/***************************************************************************/
typedef struct DataDesc {
   /* address of the next block */
   struct DataDesc *NextPtr;

   /* size of the buffer containing the data in the current block */
   word MaxSize;

   /* size of data in the current block */
   word Size;

   /* offset of the first byte of data in the current block */
   word Offset;

   /* field reserved for internal use */
   word Reserved;

   /* address of the data block */
   byte *DataPtr;
} DataDesc_t;
typedef DataDesc_t *DataDescPtr;

/***************************************************************************/
/* Structure of a primitive header                                         */
/***************************************************************************/
typedef struct PrimDesc {
   /* address of the next primitive when chained in a queue or pool */
   struct PrimDesc *NextPtr;

   /* address of the previous primitive when chained in a queue */
   struct PrimDesc *PrevPtr;

   /* type */
   word PrimId;

   /* reference */
   word PrimRef;

   /* immediate data */
   byte PrimInfo[MAX_PRIM_INFO];

   /* address of the first data descriptor */
   DataDesc_t *DataDescPtr;

   /* number of free primitive structures in the driver for which a received*/
   /* primitive reports the status */
   word PrimInPool;

   /* size of the driver's buffers for which a received primitive */
   /* reports the status */
   word SizeInPool;

   /* number of the driver's buffers for which a received primitive */
   /* reports the status */
   word BuffInPool;

   /* flag set in a received primitive if there is at least another pending */
   /* received primitive */
   word MorePrim;
} PrimDesc_t;
typedef PrimDesc_t *PrimDescPtr;

/***************************************************************************/
/* Structure of a memory area                                              */
/***************************************************************************/
typedef struct MemDesc {
   /* size of the block pointed by DataPtr */
   dword Size;

   /* offset of the first data in the pointed block */
   dword Offset;

   /* address of the block */
   byte *DataPtr;
} MemDesc_t;

/***************************************************************************/
/* Structure used for CTL_GET_CARD_ID                                      */
/***************************************************************************/
typedef struct CardId {
   /* index of the card in the internal structures of the driver */
   dword Index;

   /* type of adapter (Device Id) */
   dword Type;

   /* serial number */
   dword SerialNum;

   /* number of modems */
   dword ModemNb;

   /* PCI bus number */
   dword BusNum;

   /* PCI slot number */
   dword SlotNum;
} CardId_t;

/***************************************************************************/
/* Structure used for CTL_GET_CARD_STATUS                                  */
/***************************************************************************/
typedef struct CardStatus {
   /* serial number */
   dword SerialNum;

   /* card status */
   byte Status;

} CardStatus_t;

/***************************************************************************/
/* Structure used for CTL_GET_CUSTOM_INFO                                  */
/***************************************************************************/
#define CARD_PQ3_CUSTOM_INFO_SIZE      32
typedef struct CustomInfo {
   /* serial number */
   dword SerialNum;

   /* Custom information */
   char Info[CARD_PQ3_CUSTOM_INFO_SIZE];
} CustomInfo_t;

/***************************************************************************/
/* Structure used for CTL_GET_TIME                                         */
/***************************************************************************/
typedef struct TimeInfo {
   /* Card Time */
   ddword Card;

   /* Host Time */
   ddword Host;

   /* Host time offset */
   ddword HostOffset;
} TimeInfo_t;

/***************************************************************************/
/* Structure used for CTL_GET_TEMP_INFO                                    */
/***************************************************************************/
typedef struct TempInfo {
   /* Current temperature */
   byte CurTemp;

   /* Temperature that triggers a card shutdown */
   byte StopThreshold;
} TempInfo_t;


/***************************************************************************/
/* Prototypes of the routines exported to a kernel application             */
/***************************************************************************/
extern dword iph_kernel_open(
    dword serial,             /* serial number of the adapter */
    void  (*wakeup_ptr)(void *, word),              /* kd_wakeup callback */
    void  (*free_ptr)(void *, word, byte, void *),  /* kd_free callback */
    void *backref_ptr,                              /* backward reference */
    word  *app_id_ptr);       /* pointer to application identifier */

extern dword iph_kernel_ioctl(
    word  app_id,             /* application identifier or NO_APP_ID*/
    dword cmd_type,           /* type of request */
    void  *arg);              /* pointer to request argument */

extern dword iph_kernel_close(
    word  app_id);            /* application identifier */

extern dword iph_TRACE_NO_PARAM (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id);           /* trace identifier in the module traces list*/

extern dword iph_TRACE_D1 (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    dword data);              /* integer value to dump */

extern dword iph_TRACE_D2 (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    dword data1,              /* first integer value to dump */
    dword data2);             /* second integer value to dump */

extern dword iph_TRACE_STRING(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the string to dump */
    byte *buf);               /* string to dump */

extern dword iph_TRACE_STRUCT(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the structure to dump */
    byte *buf);               /* structure to dump */

extern dword iph_TRACE_PACKET(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the buffer to dump */
    byte *buf);               /* buffer to dump */

/***************************************************************************/
/* Prototypes of the routines exported to a kernel application by          */
/* iphwae driver                                                           */
/***************************************************************************/
extern dword iphwae_kernel_open(
    dword serial,             /* serial number of the adapter */
    void (*wakeup_ptr)(void *, word),              /* kd_wakeup callback */
    void (*free_ptr)(void *, word, byte, void *),  /* kd_free callback */
    void *backref_ptr,                             /* backward reference */
    word *app_id_ptr);        /* pointer to application identifier */

extern dword iphwae_kernel_ioctl(
    word app_id,              /* application identifier or NO_APP_ID*/
    dword cmd_type,           /* type of request */
    void *arg);               /* pointer to request argument */

extern dword iphwae_kernel_close(
    word app_id);             /* application identifier */

extern dword iphwae_TRACE_NO_PARAM (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id);           /* trace identifier in the module traces list*/

extern dword iphwae_TRACE_D1 (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    dword data);              /* integer value to dump */

extern dword iphwae_TRACE_D2 (
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    dword data1,              /* first integer value to dump */
    dword data2);             /* second integer value to dump */

extern dword iphwae_TRACE_STRING(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the string to dump */
    byte *buf);               /* string to dump */

extern dword iphwae_TRACE_STRUCT(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the structure to dump */
    byte *buf);               /* structure to dump */

extern dword iphwae_TRACE_PACKET(
    byte module_id,           /* module that generates the message */
    byte trace_type,          /* EVT, TRC or ERR */
    word trace_id,            /* trace identifier in the module traces list*/
    word len,                 /* length of the buffer to dump */
    byte *buf);               /* buffer to dump */

#endif


