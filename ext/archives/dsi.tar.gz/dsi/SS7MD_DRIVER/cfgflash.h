/****************************************************************************
 * NAME : cfgflash.h
 * VERSION : 1.1
 * DESCRIPTION : 
 *    Values to store or load the initial software configuration in flash
 * REVISIONS :
 *    - Version 1.0 12/22/00 : Creation
 *    - Version 1.1 01/11/01 : The header structure must be byte-aligned.
 ****************************************************************************/
/* To prevent include of include */
#ifndef CFGFLASH_H
#define CFGFLASH_H


/***************************************************************************/
/* Tag at the beginning and end of the configuration                       */
/***************************************************************************/
#define CFG_BEGIN                   "###CONFIG BEGIN###"
#define CFG_END                     "###CONFIG END###"

/***************************************************************************/
/* Version numbers                                                         */
/***************************************************************************/
#define CFG_MAJOR_NUM               1
#define CFG_MINOR_NUM               0

/***************************************************************************/
/* Types of request                                                        */
/***************************************************************************/
#define CFG_SEND_PRIM               0x01
#define CFG_RECV_PRIM               0x02
#define CFG_SEND_PRIM_ERR           0x03
#define CFG_RECV_PRIM_ERR           0x04

/***************************************************************************/
/* Types of parameter                                                      */
/***************************************************************************/
#define PRIM_TYPE                   0x01
#define PRIM_TYPE_MASK              0x02
#define PRIM_REF                    0x03
#define PRIM_INFO                   0x04
#define PRIM_INFO_MASK              0x05
#define PRIM_BUFFER                 0x06
#define PRIM_TIMEOUT                0x07
#define PRIM_TYPE_IGNORE            0x08

/***************************************************************************/
/* Values for parameter                                                    */
/***************************************************************************/
#define PRIM_IGNORE_ALL             0xFFFF

/***************************************************************************/
/* Structure of the configuration header                                   */
/***************************************************************************/
#pragma pack(1)
typedef struct CfgHeader {
   /* tag */
   byte TagBegin[sizeof(CFG_BEGIN)-1];

   /* major version number */
   byte MajorVer;

   /* minor version number */
   byte MinorVer;

   /* total size of the configuration area including header and trailer */
   dword TotalSize;

   /* checksum computed on the configuration only */
   word Checksum;

} CfgHeader_t;
typedef CfgHeader_t *CfgHeaderPtr;

#pragma pack()

#endif


