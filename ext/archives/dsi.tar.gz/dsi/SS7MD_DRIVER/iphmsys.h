/****************************************************************************
 * NAME : iphmsys.h
 * VERSION : 1.02
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the iphmsys module of the base driver
 * REVISIONS :
 *    - Version 1.00 12/15/05 : Creation
 *    - Version 1.01 04/12/06 : Update for Solaris
 *    - Version 1.02 06/26/06 : Change global prefix into iphwae
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHMSYS_H
#define IPHMSYS_H

#ifdef IPHMSYS_C
static void drv_gvShutdownAdapter(kmutex_t *pLock, IphWanDevPtr pWanDev, 
                                  int Reason);
static void *drv_gpMemAlloc(dword dwSize, word wNb, int iFlags, int addSize);
static void drv_gvMemFree(void *pMem);
static dword drv_gdwAllocDmaMem(kmutex_t *pLock, IphWanDevPtr pDev);
static dword drv_gdwFreeDmaMem(IphWanDevPtr pDev);
static void drv_gvReleaseDrvPrim(kmutex_t *pLock, ApplCtxtPtr pAppli,
                                 IphWanDevPtr pDev, PrimDesc_t *pPrim);
static void drv_gvPurgeAppliSession(kmutex_t *pLock, ApplCtxtPtr pAppli,
                                    word wSession);
static void drv_gvSendPrimToAppli(ApplCtxtPtr pAppli, PrimDescPtr pPrim,
                                  MGRSessionCorrPtr pCorr);
static void drv_gvCloseAppliSession(kmutex_t *pLock, IphWanDevPtr pWanDev,
                                    MGRSessionCorrPtr pCorr, word wDiag);

#define ExportGlobalMsys(PRFX) \
void iph##PRFX##_gvShutdownAdapter(kmutex_t *pLock, IphWanDevPtr pWanDev, \
                                   int Reason)\
{\
   drv_gvShutdownAdapter(pLock, pWanDev, Reason);\
}\
void *iph##PRFX##_gpMemAlloc(dword dwSize, word wNb, int iFlags, int addSize)\
{\
   return(drv_gpMemAlloc(dwSize, wNb, iFlags, addSize));\
}\
void iph##PRFX##_gvMemFree(void *pMem)\
{\
   drv_gvMemFree(pMem);\
}\
dword iph##PRFX##_gdwAllocDmaMem(kmutex_t *pLock, IphWanDevPtr pDev)\
{\
   return(drv_gdwAllocDmaMem(pLock, pDev));\
}\
dword iph##PRFX##_gdwFreeDmaMem(IphWanDevPtr pDev)\
{\
   return(drv_gdwFreeDmaMem(pDev));\
}\
void iph##PRFX##_gvReleaseDrvPrim(kmutex_t *pLock, ApplCtxtPtr pAppli,\
                                  IphWanDevPtr pDev, PrimDesc_t *pPrim)\
{\
   drv_gvReleaseDrvPrim(pLock, pAppli, pDev, pPrim);\
}\
void iph##PRFX##_gvPurgeAppliSession(kmutex_t *pLock, ApplCtxtPtr pAppli,\
                                     word wSession)\
{\
   drv_gvPurgeAppliSession(pLock, pAppli, wSession);\
}\
void iph##PRFX##_gvSendPrimToAppli(ApplCtxtPtr pAppli, PrimDescPtr pPrim,\
                                   MGRSessionCorrPtr pCorr)\
{\
   drv_gvSendPrimToAppli(pAppli, pPrim, pCorr);\
}\
void iph##PRFX##_gvCloseAppliSession(kmutex_t *pLock, IphWanDevPtr pWanDev,\
                                     MGRSessionCorrPtr pCorr, word wDiag)\
{\
   drv_gvCloseAppliSession(pLock, pWanDev, pCorr, wDiag);\
}

ExportGlobalMsys(wae)

#else /* IPHTRACE_C */

#endif

#define ExportExtMsys(PRFX) \
void iph##PRFX##_gvShutdownAdapter(kmutex_t *pLock, IphWanDevPtr pWanDev, \
                                   int Reason);\
void *iph##PRFX##_gpMemAlloc(dword dwSize, word wNb, int iFlags, int addSize);\
void iph##PRFX##_gvMemFree(void *pMem);\
dword iph##PRFX##_gdwAllocDmaMem(kmutex_t *pLock, IphWanDevPtr pDev);\
dword iph##PRFX##_gdwFreeDmaMem(IphWanDevPtr pDev);\
void iph##PRFX##_gvReleaseDrvPrim(kmutex_t *pLock, ApplCtxtPtr pAppli,\
                                  IphWanDevPtr pDev, PrimDesc_t *pPrim);\
void iph##PRFX##_gvPurgeAppliSession(kmutex_t *pLock, ApplCtxtPtr pAppli,\
                                     word wSession);\
void iph##PRFX##_gvSendPrimToAppli(ApplCtxtPtr pAppli, PrimDescPtr pPrim,\
                                   MGRSessionCorrPtr pCorr);\
void iph##PRFX##_gvCloseAppliSession(kmutex_t *pLock, IphWanDevPtr pWanDev,\
                                     MGRSessionCorrPtr pCorr, word wDiag);
ExportExtMsys(wae)

#define iph_gvShutdownAdapter iphwae_gvShutdownAdapter
#define iph_gpMemAlloc iphwae_gpMemAlloc
#define iph_gvMemFree iphwae_gvMemFree
#define iph_gdwAllocDmaMem iphwae_gdwAllocDmaMem
#define iph_gdwFreeDmaMem iphwae_gdwFreeDmaMem
#define iph_gvReleaseDrvPrim iphwae_gvReleaseDrvPrim
#define iph_gvPurgeAppliSession iphwae_gvPurgeAppliSession
#define iph_gvSendPrimToAppli iphwae_gvSendPrimToAppli
#define iph_gvCloseAppliSession iphwae_gvCloseAppliSession

#endif
