/****************************************************************************
 * NAME : ithandle.h
 * VERSION : 1.05
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the ithandle module of the base driver
 * REVISIONS :
 *    - Version 1.00 07/06/06 : Creation
 *    - Version 1.01 11/04/04 : Add the iph_guiCleanTasklet function
 *    - Version 1.02 08/09/05 : kernel 2.6 interrupt handlers return
 *                                irqreturn_t instead of void
 *    - Version 1.03 04/12/06 : Update for Solaris
 *    - Version 1.04 06/26/06 : Change global prefix into iphwae
 *    - Version 1.05 10/15/08 : Add support for Solaris 9 (SOL_9 option)
 ****************************************************************************/
/* To prevent include of include */
#ifndef ITHANDLE_H
#define ITHANDLE_H

#ifdef ITHANDLE_C
static DataDesc_t *drv_gpGetDataDesc(kmutex_t *pLock, ApplCtxtPtr pAppli, 
                                     word wSize);
static void drv_gvReleaseCorr(kmutex_t *pLock, IphWanDevPtr pDev, 
                              MGRSessionCorrPtr pCorr);
static ApplCtxtPtr drv_gpFindCtxtWithMGRSession(kmutex_t *pLock, 
                                                IphWanDevPtr pDev, 
                                                word uwSession,
                                                word *uwLogicalSession,
                                                MGRSessionCorrPtr *ppCorr);
static void drv_gvReleaseP2LTransfer_PQ3(kmutex_t *pLock, IphWanDevPtr pDev);

#define ExportGlobalIt(PRFX)\
DataDesc_t *iph##PRFX##_gpGetDataDesc(kmutex_t *pLock, ApplCtxtPtr pAppli, \
                                      word wSize)\
{\
   return(drv_gpGetDataDesc(pLock, pAppli, wSize));\
}\
void iph##PRFX##_gvReleaseCorr(kmutex_t *pLock, IphWanDevPtr pDev, \
                              MGRSessionCorrPtr pCorr)\
{\
   drv_gvReleaseCorr(pLock, pDev, pCorr);\
}\
ApplCtxtPtr iph##PRFX##_gpFindCtxtWithMGRSession(kmutex_t *pLock, \
                                                 IphWanDevPtr pDev, \
                                                 word uwSession,\
                                                 word *uwLogicalSession,\
                                                 MGRSessionCorrPtr *ppCorr)\
{\
   return(drv_gpFindCtxtWithMGRSession(pLock, pDev, uwSession, \
                                       uwLogicalSession, ppCorr));\
}\
void iph##PRFX##_gvReleaseP2LTransfer_PQ3(kmutex_t *pLock, IphWanDevPtr pDev)\
{\
   drv_gvReleaseP2LTransfer_PQ3(pLock, pDev);\
}

ExportGlobalIt(wae)

#ifdef LINUX
static void drv_guiITHandlerDpc_PQ3(unsigned long ulArg);
static void drv_gvITWatchdog(unsigned long ulArg);
static void drv_gvITPollStatus(unsigned long ulArg);
static void drv_gvITEchoPoll(unsigned long ulArg);
static void drv_guiCleanTasklet(IphWanDevPtr pDev);

#define ExportGlobalItSys(PRFX)\
void iph##PRFX##_guiITHandlerDpc_PQ3(unsigned long ulArg)\
{\
   drv_guiITHandlerDpc_PQ3(ulArg);\
}\
void iph##PRFX##_gvITWatchdog(unsigned long ulArg)\
{\
   drv_gvITWatchdog(ulArg);\
}\
void iph##PRFX##_gvITPollStatus(unsigned long ulArg)\
{\
   drv_gvITPollStatus(ulArg);\
}\
void iph##PRFX##_gvITEchoPoll(unsigned long ulArg)\
{\
   drv_gvITEchoPoll(ulArg);\
}\
void iph##PRFX##_guiCleanTasklet(IphWanDevPtr pDev)\
{\
   drv_guiCleanTasklet(pDev);\
}

ExportGlobalItSys(wae)

#ifdef LINUX_2_4
static void drv_guiITHandler_PQ3(int irq, void *dev_id, struct pt_regs *regs);

#define ExportGlobalItSysb(PRFX)\
void iph##PRFX##_guiITHandler_PQ3(int irq, void *dev_id, struct pt_regs *regs)\
{\
   drv_guiITHandler_PQ3(irq, dev_id, regs);\
}

#else /* !LINUX_2_4 */
static irqreturn_t drv_guiITHandler_PQ3(int irq, void *dev_id, 
                                        struct pt_regs *regs);

#define ExportGlobalItSysb(PRFX)\
irqreturn_t iph##PRFX##_guiITHandler_PQ3(int irq, void *dev_id, \
                                         struct pt_regs *regs)\
{\
   return(drv_guiITHandler_PQ3(irq, dev_id, regs));\
}
#endif /* !LINUX_2_4 */

ExportGlobalItSysb(wae)

#endif /* LINUX */

#ifdef SOLARIS
static u_int drv_guiITHandler_PQ3(caddr_t pCtxt, caddr_t arg);
static void drv_guiITHandlerDpc_PQ3(caddr_t pCtxt, caddr_t arg);
static void drv_gvITWatchdog(void *ulArg);
static void drv_gvITPollStatus(void *ulArg);
static void drv_gvITEchoPoll(void *ulArg);

#ifdef SOL_9
#define ExportGlobalItSys(PRFX)\
u_int iph##PRFX##_guiITHandler_PQ3(caddr_t pCtxt)\
{\
   return(drv_guiITHandler_PQ3(pCtxt, NULL));\
}\
u_int iph##PRFX##_guiITHandlerDpc_PQ3(caddr_t pCtxt)\
{\
   drv_guiITHandlerDpc_PQ3(pCtxt, NULL);\
   return(DDI_INTR_CLAIMED);\
}
#else
#define ExportGlobalItSys(PRFX)\
u_int iph##PRFX##_guiITHandler_PQ3(caddr_t pCtxt, caddr_t arg)\
{\
   return(drv_guiITHandler_PQ3(pCtxt, arg));\
}\
u_int iph##PRFX##_guiITHandlerDpc_PQ3(caddr_t pCtxt, caddr_t arg)\
{\
   drv_guiITHandlerDpc_PQ3(pCtxt, arg);\
   return(DDI_INTR_CLAIMED);\
}
#endif

#define ExportGlobalItOther(PRFX)\
void iph##PRFX##_gvITWatchdog(void *pCtxt)\
{\
   drv_gvITWatchdog(pCtxt);\
}\
void iph##PRFX##_gvITPollStatus(void *ulArg)\
{\
   drv_gvITPollStatus(ulArg);\
}\
void iph##PRFX##_gvITEchoPoll(void *ulArg)\
{\
   drv_gvITEchoPoll(ulArg);\
}

ExportGlobalItSys(wae)
ExportGlobalItOther(wae)

#endif /* SOLARIS */

#else

#define ExportExtIt(PRFX)\
DataDesc_t *iph##PRFX##_gpGetDataDesc(kmutex_t *pLock, ApplCtxtPtr pAppli, \
                                      word wSize);\
void iph##PRFX##_gvReleaseCorr(kmutex_t *pLock, IphWanDevPtr pDev, \
                               MGRSessionCorrPtr pCorr);\
ApplCtxtPtr iph##PRFX##_gpFindCtxtWithMGRSession(kmutex_t *pLock, \
                                                 IphWanDevPtr pDev, \
                                                 word uwSession,\
                                                 word *uwLogicalSession,\
                                                 MGRSessionCorrPtr *ppCorr);\
void iph##PRFX##_gvReleaseP2LTransfer_PQ3(kmutex_t *pLock, IphWanDevPtr pDev);

ExportExtIt(wae)

#ifdef LINUX

#define ExportExtItSys(PRFX)\
void iph##PRFX##_guiITHandlerDpc_PQ3(unsigned long ulArg);\
void iph##PRFX##_gvITWatchdog(unsigned long ulArg);\
void iph##PRFX##_gvITPollStatus(unsigned long ulArg);\
void iph##PRFX##_gvITEchoPoll(unsigned long ulArg);\
void iph##PRFX##_guiCleanTasklet(IphWanDevPtr pDev);\

ExportExtItSys(wae)

#ifdef LINUX_2_4
#define ExportExtItSysb(PRFX)\
void iph##PRFX##_guiITHandler_PQ3(int irq, void *dev_id, struct pt_regs *regs);
#else /* !LINUX_2_4 */
#define ExportExtItSysb(PRFX)\
irqreturn_t iph##PRFX##_guiITHandler_PQ3(int irq, void *dev_id, \
                                         struct pt_regs *regs);
#endif /* !LINUX_2_4 */

ExportExtItSysb(wae)

#endif /* LINUX */

#ifdef SOLARIS

#ifdef SOL_9
#define ExportExtItSys(PRFX)\
u_int iph##PRFX##_guiITHandler_PQ3(caddr_t pCtxt);\
u_int iph##PRFX##_guiITHandlerDpc_PQ3(caddr_t pCtxt);
#else
#define ExportExtItSys(PRFX)\
u_int iph##PRFX##_guiITHandler_PQ3(caddr_t pCtxt, caddr_t arg);\
u_int iph##PRFX##_guiITHandlerDpc_PQ3(caddr_t pCtxt, caddr_t arg);
#endif

#define ExportExtItOther(PRFX)\
void iph##PRFX##_gvITWatchdog(void *pCtxt);\
void iph##PRFX##_gvITPollStatus(void *ulArg);\
void iph##PRFX##_gvITEchoPoll(void *ulArg);

ExportExtItSys(wae)
ExportExtItOther(wae)
#endif /* SOLARIS */

#endif /* !ITHANDLE_C */

#define iph_gpGetDataDesc iphwae_gpGetDataDesc
#define iph_gvReleaseCorr iphwae_gvReleaseCorr
#define iph_gpFindCtxtWithMGRSession iphwae_gpFindCtxtWithMGRSession
#define iph_gvReleaseP2LTransfer_PQ3 iphwae_gvReleaseP2LTransfer_PQ3
#define iph_guiITHandler_PQ3 iphwae_guiITHandler_PQ3
#define iph_guiITHandlerDpc_PQ3 iphwae_guiITHandlerDpc_PQ3
#define iph_gvITWatchdog iphwae_gvITWatchdog
#define iph_gvITPollStatus iphwae_gvITPollStatus
#define iph_gvITEchoPoll iphwae_gvITEchoPoll

#ifdef LINUX
#define iph_guiCleanTasklet iphwae_guiCleanTasklet
#endif

#endif
