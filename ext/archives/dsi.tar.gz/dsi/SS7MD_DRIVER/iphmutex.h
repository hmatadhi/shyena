/*
 * Mutex and condition variable implementation
 * for the Linux Kernel
 *
 * Written by Kaz Kylheku
 *
 * $Id: mutex.h,v 1.4 2002/03/21 22:44:06 marka Exp $
 */

#ifndef MUTEX_H
#define MUTEX_H

#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/delay.h>

typedef struct {
   spinlock_t spin;
   long flags;
   int count_lock;
   int count_unlock;
   int lockIT;
   char *desc;
} mutex_t;

/* added by marka to mimic the solaris version of the type*/
typedef mutex_t kmutex_t;

typedef struct {
   wait_queue_head_t queue;
} cond_t;

/* added by marka to mimic the solaris version of the type*/
typedef cond_t kcondvar_t;

#ifdef MUTEX_C
static void drv_mutex_init(mutex_t *mx, int lockIT, char *desc);
static void drv_mutex_lock(mutex_t *mx);
static int drv_mutex_trylock(mutex_t *mx);
static void drv_mutex_unlock(mutex_t *mx);
static void drv_cond_init(cond_t *cv);
static int drv_cond_wait(cond_t *cv, mutex_t *mx);
static int drv_cond_timed_wait_rel(cond_t *cv, mutex_t *mx, long jiff_delta);
static int drv_cond_timed_wait_abs(cond_t *cv, mutex_t *mx, 
                                   unsigned long jiff_wakeup);
static void drv_cond_signal(cond_t *cv);
static void drv_cond_broadcast(cond_t *cv);

#define ExportGlobalMutex(PRFX)\
void iph##PRFX##_mutex_init(mutex_t *mx, int lockIT, char *desc) \
{\
   drv_mutex_init(mx, lockIT, desc);\
}\
void iph##PRFX##_mutex_lock(mutex_t *mx) \
{\
   drv_mutex_lock(mx);\
}\
int iph##PRFX##_mutex_trylock(mutex_t *mx) \
{\
   return(drv_mutex_trylock(mx));\
}\
void iph##PRFX##_mutex_unlock(mutex_t *mx) \
{\
   drv_mutex_unlock(mx);\
}\
void iph##PRFX##_cond_init(cond_t *cv) \
{\
   drv_cond_init(cv);\
}\
int iph##PRFX##_cond_wait(cond_t *cv, mutex_t *mx) \
{\
   return(drv_cond_wait(cv, mx));\
}\
int iph##PRFX##_cond_timed_wait_rel(cond_t *cv, mutex_t *mx, long jiff_delta) \
{\
   return(drv_cond_timed_wait_rel(cv, mx, jiff_delta));\
}\
int iph##PRFX##_cond_timed_wait_abs(cond_t *cv, mutex_t *mx,\
                                    unsigned long jiff_wakeup) \
{\
   return(drv_cond_timed_wait_abs(cv, mx, jiff_wakeup));\
}\
void iph##PRFX##_cond_signal(cond_t *cv) \
{\
   drv_cond_signal(cv);\
}\
void iph##PRFX##_cond_broadcast(cond_t *cv) \
{\
   drv_cond_broadcast(cv);\
}

ExportGlobalMutex(wae)

#else

#define ExportExtMutex(PRFX)\
void iph##PRFX##_mutex_init(mutex_t *mx, int lockIT, char *desc);\
void iph##PRFX##_mutex_lock(mutex_t *mx);\
int iph##PRFX##_mutex_trylock(mutex_t *mx);\
void iph##PRFX##_mutex_unlock(mutex_t *mx);\
void iph##PRFX##_cond_init(cond_t *cv);\
int iph##PRFX##_cond_wait(cond_t *cv, mutex_t *mx);\
int iph##PRFX##_cond_timed_wait_rel(cond_t *cv, mutex_t *mx, long jiff_delta);\
int iph##PRFX##_cond_timed_wait_abs(cond_t *cv, mutex_t *mx,\
                                    unsigned long jiff_wakeup);\
void iph##PRFX##_cond_signal(cond_t *cv);\
void iph##PRFX##_cond_broadcast(cond_t *cv);

ExportExtMutex(wae)
#endif

enum { COND_WAIT_SUCCESS = 1, COND_WAIT_SIGNAL = 0 , COND_WAIT_TIMEOUT = -1 };

#endif
