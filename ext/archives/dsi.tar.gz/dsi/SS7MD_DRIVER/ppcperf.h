/****************************************************************************
 * NAME : ppcperf.h
 * VERSION : 1.03.1.1
 * DESCRIPTION : 
 *    Constants, types, structures, macros, global variables 
 *    for the ppcperf module of the base driver
 * REVISIONS :
 *    - Version 1.0 07/06/06 : Creation
 *    - Version 1.1 06/26/06 : Change global prefix into iphwae
 *    - Version 1.02 07/25/07 : Change the AdapterSerialNum prototype
 *    - Version 1.03 10/21/08 : drv_gdwAdapterSerialNum_PQ3 is a void function
 *                              (no code to return)
 *    - Version 1.03.1 05/15/09 : Add the Temperature sensor information
 *                                access routines
 *    - Version 1.03.1.1 07/02/10 : Add the I2C bus access functions
 ****************************************************************************/
/* To prevent include of include */
#ifndef PPCPERF_H
#define PPCPERF_H

#ifdef PPCPERF_C
static void drv_gdwAdapterSerialNum_PQ3(IphWanDevPtr pDev);
static dword drv_gdwAdapterBoardEquipReg_PQ3(IphWanDevPtr pDev, dword Offset);
static byte drv_gbAdapterRev_PQ3(IphWanDevPtr pDev);
static void drv_gvSearchWorkingArea(IphWanDevPtr pDev);
static byte drv_gbCheckCardStatus_PQ3(kmutex_t *pLock, IphWanDevPtr pDev);
static byte drv_gbCurTemp(IphWanDevPtr pDev);
static byte drv_gbTOS(IphWanDevPtr pDev);
static int drv_gdwI2CByteRead_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte *pdata);
static int drv_gdwI2CByteWrite_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte data);



#define ExportGlobalPerf(PRFX)\
void iph##PRFX##_gdwAdapterSerialNum_PQ3(IphWanDevPtr pDev)\
{\
   drv_gdwAdapterSerialNum_PQ3(pDev);\
}\
dword iph##PRFX##_gdwAdapterBoardEquipReg_PQ3(IphWanDevPtr pDev, dword Offset)\
{\
   return(drv_gdwAdapterBoardEquipReg_PQ3(pDev, Offset));\
}\
byte iph##PRFX##_gbAdapterRev_PQ3(IphWanDevPtr pDev)\
{\
   return(drv_gbAdapterRev_PQ3(pDev));\
}\
void iph##PRFX##_gvSearchWorkingArea(IphWanDevPtr pDev)\
{\
   drv_gvSearchWorkingArea(pDev);\
}\
byte iph##PRFX##_gbCheckCardStatus_PQ3(kmutex_t *pLock, IphWanDevPtr pDev)\
{\
   return(drv_gbCheckCardStatus_PQ3(pLock, pDev));\
}\
byte iph##PRFX##_gbCurTemp(IphWanDevPtr pDev)\
{\
   return(drv_gbCurTemp(pDev));\
}\
byte iph##PRFX##_gbTOS(IphWanDevPtr pDev)\
{\
   return(drv_gbTOS(pDev));\
}\
int iph##PRFX##_gdwI2CByteRead_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte *pdata)\
{\
   return(drv_gdwI2CByteRead_PQ3(pDev, I2CAddr, Offset, OffSize, pdata));\
}\
int iph##PRFX##_gdwI2CByteWrite_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte data)\
{\
   return(drv_gdwI2CByteWrite_PQ3(pDev, I2CAddr, Offset, OffSize, data));\
}

ExportGlobalPerf(wae)

#else

#define ExportExtPerf(PRFX)\
void iph##PRFX##_gdwAdapterSerialNum_PQ3(IphWanDevPtr pDev);\
dword iph##PRFX##_gdwAdapterBoardEquipReg_PQ3(IphWanDevPtr pDev, dword Offset);\
byte iph##PRFX##_gbAdapterRev_PQ3(IphWanDevPtr pDev);\
void iph##PRFX##_gvSearchWorkingArea(IphWanDevPtr pDev);\
byte iph##PRFX##_gbCheckCardStatus_PQ3(kmutex_t *pLock, IphWanDevPtr pDev);\
byte iph##PRFX##_gbCurTemp(IphWanDevPtr pDev);\
byte iph##PRFX##_gbTOS(IphWanDevPtr pDev);\
int iph##PRFX##_gdwI2CByteRead_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte *pdata);\
int iph##PRFX##_gdwI2CByteWrite_PQ3(IphWanDevPtr pDev, int I2CAddr, int Offset, int OffSize, byte data);

ExportExtPerf(wae)
#endif

#define iph_gdwAdapterSerialNum_PQ3 iphwae_gdwAdapterSerialNum_PQ3
#define iph_gdwAdapterBoardEquipReg_PQ3 iphwae_gdwAdapterBoardEquipReg_PQ3
#define iph_gbAdapterRev_PQ3 iphwae_gbAdapterRev_PQ3
#define iph_gvSearchWorkingArea iphwae_gvSearchWorkingArea
#define iph_gbCheckCardStatus_PQ3 iphwae_gbCheckCardStatus_PQ3
#define iph_gbCurTemp iphwae_gbCurTemp
#define iph_gbTOS iphwae_gbTOS
#define iph_gdwI2CByteRead_PQ3 iphwae_gdwI2CByteRead_PQ3
#define iph_gdwI2CByteWrite_PQ3 iphwae_gdwI2CByteWrite_PQ3

#endif

