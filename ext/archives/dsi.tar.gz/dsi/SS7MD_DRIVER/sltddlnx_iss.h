/*
===========================================================================

    Copyright (C) Dialogic Inc 2008-2016.
    All Rights Reserved.

    Linux/Solaris 5639L Device Driver - Source Code History

    sltddlnx_iss.h

    ********* README ******** ********* README ******** ********* README ********

                1. Update iphwan.h to change DEVICE_NAME and DRIVER_NAME to "ss7md".

                2. Update iphmain.c to include MODULE_LICENSE.

                3. Update iphmain.c to include version and (c) banner.
                   Note - iphmain.c has two locationsL one for Linux, one for Solaris.

    ********* README ******** ********* README ******** ********* README ********
                
==========+======+=========================================================
Date      | Name | Description of status / changes
==========+======+=========================================================
02-Nov-08    GNK  - Extracted from Interphase iphbwae.intel-5.25-0.src.rpm
02-Nov-08    GNK  *** RELEASE V0.01 ***

05-Dec-08    GNK  *** RELEASE V0.01 ***

06-Jan-08    MH   - Updated installation script to use 'ss7md' node name.
06-Jan-09    MH   *** RELEASE V0.03 ***

19-Jan-08    MH   - Update instalation scripts to prevent removal and 
                    insertion scripts being run more than once.
19-Jan-09    MH   *** RELEASE V0.04 ***

19-Mar-09    MH   - Update from iphbwae.intel-5.28-1.00.src.rpm
19-Mar-09    MH   *** RELEASE V0.05 ***

01-Apr-09    IDP  - Change device / driver name from iphwae to ss7md
01-Apr-09    IDP  *** RELEASE V0.06 ***

07-Apr-09    JCo  - Update Makefile_2_4 to fix build issue and change
                    driver object file name to ss7md. 
                  *** RELEASE V0.07 ***
07-May-09    JCo  - Update to support 2.4 64bit build 
                  *** RELEASE V0.08 ***
16-Jun-09    IDP  - Update to iphbwae.intel-5.28-1.02.src.rpm
                  *** RELEASE V0.09 ***

22-Sep-09    MH   - Add GPL and BSD license files.
22-Sep-09    MH   *** RELEASE V0.10 ***

18-Nov-09    IDP  - Update to iphbwae.intel-5.31-0.src.rpm
18-Nov-09    IDP  *** RELEASE V0.11 ***
                  *** Only for use with the 3639 & 3640 ***

12-Jul-10    MH   - Interphase drop 09-Jul-10
                  - Remove:
                    layers.h
                    mgr.h
                    ppcapi.h
                    ppcsys.h
                    pq3.h
                    svr.h
                    toolapi.h
                    wanapi.h

                  - CN DPK/341 - 'SS7MD Taints kernel on insertion'
                    Update iphmain.c:
                      #ifdef MODULE_LICENSE
                      MODULE_LICENSE("Dual BSD/GPL");
                      #endif
12-Jul-10    MH   *** RELEASE V0.12 ***

10-Feb-11    MH   - Add version number.
10-Feb-11    MH   *** RELEASE V0.13 ***

11-Feb-11    MH   - Use product copyright string format.
11-Feb-11    MH   *** RELEASE V0.14 ***

24-Feb-11    JCo  - Update to ddi_intr_set_pri failure
                  handling to allow operation on x86
                  Solaris update 9. Temp fix.   
24-Feb-11    JCo  *** RELEASE V0.15 ***

11-Mar-11    MH   - Correct error with minornum/instance mapping.
11-Mar-11    MH   *** RELEASE V0.16 ***

19-Apr-11    MH   - Update install + build scripts to specify /bin/bash.
11-Mar-11    MH   *** RELEASE V0.17 ***

12-May-11    IDP  - Add CTL_GET_TEMP_INFO to list of IOCTLs registered with ioctl32
                  - Dont shutdown the board on a thermal reading of 127
12-May-11    IDP  *** RELEASE V0.18 ***

13-Dec-11    IDP  - CN493DPK - Correct install / build scripts for Linux 3.x kernels
13-Dec-11    IDP  *** RELEASE V0.19 ***
08-Feb-12    IDP  - TS004SLT Support upto 8 boards
08-Feb-12    IDP  *** RELEASE V0.20 ***
04-Sep-13    IDP  - CN654DPK Increase checks around I2C access
04-Sep-13    IDP  *** RELEASE V200.00 ***
05-Sep-13    IDP  - CN654DPK Only act on 'n'th over temp reading
05-Sep-13    IDP  *** RELEASE V200.01 ***
03-Dec-13    MH   - CN674DPK - 'SS7MD failure under Suse 12.3 (64bit)'
03-Dec-13    MH   *** RELEASE V0.21 ***
21-Jan-14    IDP  - CN679DPK - Provide debug on session failure
21-Jan-14    IDP  *** RELEASE V0.22 ***
03-Dec-14    MH   - TS149DPK - Solaris 11 update.
03-Dec-14    MH   *** RELEASE V0.23 ***
16-Dec-14    MH   - Update Solaris 11 banner.
16-Dec-14    MH   *** RELEASE V0.24 ***
10-Feb-15    IDP  - Add clean target to Makefile_2_6
10-Feb-15    IDP  *** RELEASE V0.25 ***
17-Feb-15    IDP  - Ensure both sides of PCIe-PCI bridge are enabled
17-Feb-15    IDP  *** RELEASE V0.26 ***
10-Aug-15    IDP  - Ensure both sides of PCIe-PCI bridge are enabled for Solaris
10-Aug-15    IDP  - Restrict Solaris DMA to bottom 2G of address space
10-Aug-15    IDP  *** RELEASE V0.27 ***
11-Aug-15    IDP  - Only restrict DMA on Sol11 X86
11-Aug-15    IDP  *** RELEASE V0.28 ***
30-Apr-15    IDP  - Cope with RHEL7 kernel API changes
08-Sep-15    IDP  *** RELEASE V0.29 ***
12-Feb-16    IDP  - Merge changes to act on n'th over temp
12-Feb-16    IDP  *** RELEASE V0.30 ***
14-Mar-16    MH   - No source change!
                  - Update to correct mis-applied label in 0.30.
                    (0.30 label used in software release)
14-Mar-16    IDP  *** RELEASE V0.31 ***
*/

/*
 * Embed version number within binary build.
 */

#ifndef _SLTDDLNX_ISS_H
#define _SLTDDLNX_ISS_H

#define SLTDDLNX_MAJ        (0)
#define SLTDDLNX_MIN        (31)

#define COPYRIGHT_BEGIN     (2008)

#endif  /* end ifndef _SLTDDLNX_ISS_H */

