/****************************************************************************
 * NAME : iphwantr.h
 * VERSION : 1.03
 * DESCRIPTION : 
 *    Trace identificators for the base driver
 * REVISIONS :
 * - Version 1.0 07/06/06 : Creation
 * - Version 1.01 06/23/05 : Changes to support Linux 2.6
 * - Version 1.02 04/24/06 : Add the IPHWAN_SVRDATA_ID module id to isolate
 *                           SVR traffic from normal traffic
 *                           Add the IPHWAN_REGACC_ID module id to trace 
 *                           register and memory access
 * - Version 1.03 06/25/08 : All the module identifiers are moved to toolapi.h
 ****************************************************************************/
/* To prevent include of include */
#ifndef IPHWANTR_H
#define IPHWANTR_H

/* trace identifiers for the base driver */
typedef enum {
   IPHWAN_FNCT,               /* function entries and returns */
   IPHWAN_ARGVAL,             /* function argument value (D1) */
   IPHWAN_RETCODE,            /* function return value (D1) */
   IPHWAN_STR,                /* display for a constant string */
   IPHWAN_DEV_MINOR,          /* device instance and minor value (D2) */
   IPHWAN_DEV,                /* device instance (D1) */
   IPHWAN_NO_OF_DEV,          /* number of devices (D1) */
   IPHWAN_DEV_MAX_SESSION,    /* device instance and max session (D2) */
   IPHWAN_DEV_MAX_APPLI,      /* device instance and max application (D2) */
   IPHWAN_POOL_SIZE,          /* PoolSize value (D1) */
   IPHWAN_INIT_COUNT,         /* InitCount field value (D1) */
   IPHWAN_MAX_COUNT,          /* MaxCount field value (D1) */
   IPHWAN_TOTAL_COUNT,        /* TotalCount field value (D1) */
   IPHWAN_USED_COUNT,         /* UsedCount field value (D1) */
   IPHWAN_FREE_COUNT,         /* FreeCount field value (D1) */
   IPHWAN_MAX_USED_COUNT,     /* MaxUsedCount field value (D1) */
   IPHWAN_DEV_SESSION,        /* session number relative to dev (D2) */
   IPHWAN_APPLI_SESSION,      /* session number relative to appli (D2)*/
   IPHWAN_DEV_TRANSFER,       /* transfer descriptor on device (D2) */
   IPHWAN_DEV_INTR,           /* interrupt status on device (D2) */
   IPHWAN_DESC_COUNT,         /* buffer number (D1) */
   IPHWAN_SIZE,               /* size (D1) */
   IPHWAN_ALIGNMENT,          /* transfer alignment (D1) */
   IPHWAN_PRIM_ID_REF,        /* primitive Id and Ref fields (D2) */
   IPHWAN_PRIM_INFO,          /* primitive Info field (PACKET) */
   IPHWAN_PRIM_DATA,          /* primitive data field (PACKET) */
   IPHWAN_LOGICAL_REF,        /* logical primitive ref (D1) */
   IPHWAN_ARGVAL2             /* function argument value (D2) */
} IphWanTraceId;

/* trace identifiers for the base driver */
typedef enum {
   IPHWAN_DATA_STR,           /* display for a constant string */
   IPHWAN_DATA_DEV_MINOR,     /* device instance and minor value (D2) */
   IPHWAN_DATA_SIZE,          /* size (D1) */
   IPHWAN_DATA_PRIM_ID_REF,   /* primitive Id and Ref fields (D2) */
   IPHWAN_DATA_PRIM_INFO,     /* primitive Info field (PACKET) */
   IPHWAN_DATA_PRIM_DATA      /* primitive data field (PACKET) */
} IphWanTraceDataId;

#define TRCLVL_0       0
#define TRCLVL_1       1
#define TRCLVL_2       2
#define TRCLVL_3       3

#endif
