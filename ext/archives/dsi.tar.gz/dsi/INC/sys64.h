/*             
                Copyright (C) 2013 Dialogic Inc. All Rights Reserved.

 Name:          sys64.h

 Description:   Definition of fundamental types specific to 64 bit systems


 -----  ---------   ---------------------------------------------
 Issue    Date                        Changes
 -----  ---------   ---------------------------------------------
   1    21-Jun-13

*/

#ifndef _SYS64_H
#define _SYS64_H

typedef unsigned long long u64;

typedef long long s64;

#endif
